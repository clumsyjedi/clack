# basic transit-js lookup
assert "cat test/fixtures/transit-0.8.json | clack -i tjs -e first :district/region" ":region/e"
