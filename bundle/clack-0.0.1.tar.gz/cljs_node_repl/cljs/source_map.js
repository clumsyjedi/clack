// Compiled by ClojureScript 1.8.51 {:target :nodejs}
goog.provide('cljs.source_map');
goog.require('cljs.core');
goog.require('goog.object');
goog.require('clojure.string');
goog.require('clojure.set');
goog.require('cljs.source_map.base64_vlq');
/**
 * Take a seq of source file names and return a map from
 * file number to integer index. For reverse source maps.
 */
cljs.source_map.indexed_sources = (function cljs$source_map$indexed_sources(sources){
return cljs.core.reduce.call(null,(function (m,p__29486){
var vec__29487 = p__29486;
var i = cljs.core.nth.call(null,vec__29487,(0),null);
var v = cljs.core.nth.call(null,vec__29487,(1),null);
return cljs.core.assoc.call(null,m,v,i);
}),cljs.core.PersistentArrayMap.EMPTY,cljs.core.map_indexed.call(null,(function (a,b){
return new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [a,b], null);
}),sources));
});
/**
 * Take a seq of source file names and return a comparator
 * that can be used to construct a sorted map. For reverse
 * source maps.
 */
cljs.source_map.source_compare = (function cljs$source_map$source_compare(sources){
var sources__$1 = cljs.source_map.indexed_sources.call(null,sources);
return ((function (sources__$1){
return (function (a,b){
return cljs.core.compare.call(null,sources__$1.call(null,a),sources__$1.call(null,b));
});
;})(sources__$1))
});
/**
 * Take a source map segment represented as a vector
 * and return a map.
 */
cljs.source_map.seg__GT_map = (function cljs$source_map$seg__GT_map(seg,source_map){
var vec__29489 = seg;
var gcol = cljs.core.nth.call(null,vec__29489,(0),null);
var source = cljs.core.nth.call(null,vec__29489,(1),null);
var line = cljs.core.nth.call(null,vec__29489,(2),null);
var col = cljs.core.nth.call(null,vec__29489,(3),null);
var name = cljs.core.nth.call(null,vec__29489,(4),null);
return new cljs.core.PersistentArrayMap(null, 5, [new cljs.core.Keyword(null,"gcol","gcol",309250807),gcol,new cljs.core.Keyword(null,"source","source",-433931539),(goog.object.get(source_map,"sources")[source]),new cljs.core.Keyword(null,"line","line",212345235),line,new cljs.core.Keyword(null,"col","col",-1959363084),col,new cljs.core.Keyword(null,"name","name",1843675177),(function (){var temp__4657__auto__ = new cljs.core.Keyword(null,"name","name",1843675177).cljs$core$IFn$_invoke$arity$1(cljs.core.meta.call(null,seg));
if(cljs.core.truth_(temp__4657__auto__)){
var name__$1 = temp__4657__auto__;
return (goog.object.get(source_map,"names")[name__$1]);
} else {
return null;
}
})()], null);
});
/**
 * Combine a source map segment vector and a relative
 * source map segment vector and combine them to get
 * an absolute segment posititon information as a vector.
 */
cljs.source_map.seg_combine = (function cljs$source_map$seg_combine(seg,relseg){
var vec__29492 = seg;
var gcol = cljs.core.nth.call(null,vec__29492,(0),null);
var source = cljs.core.nth.call(null,vec__29492,(1),null);
var line = cljs.core.nth.call(null,vec__29492,(2),null);
var col = cljs.core.nth.call(null,vec__29492,(3),null);
var name = cljs.core.nth.call(null,vec__29492,(4),null);
var vec__29493 = relseg;
var rgcol = cljs.core.nth.call(null,vec__29493,(0),null);
var rsource = cljs.core.nth.call(null,vec__29493,(1),null);
var rline = cljs.core.nth.call(null,vec__29493,(2),null);
var rcol = cljs.core.nth.call(null,vec__29493,(3),null);
var rname = cljs.core.nth.call(null,vec__29493,(4),null);
var nseg = new cljs.core.PersistentVector(null, 5, 5, cljs.core.PersistentVector.EMPTY_NODE, [(gcol + rgcol),((function (){var or__22912__auto__ = source;
if(cljs.core.truth_(or__22912__auto__)){
return or__22912__auto__;
} else {
return (0);
}
})() + rsource),((function (){var or__22912__auto__ = line;
if(cljs.core.truth_(or__22912__auto__)){
return or__22912__auto__;
} else {
return (0);
}
})() + rline),((function (){var or__22912__auto__ = col;
if(cljs.core.truth_(or__22912__auto__)){
return or__22912__auto__;
} else {
return (0);
}
})() + rcol),((function (){var or__22912__auto__ = name;
if(cljs.core.truth_(or__22912__auto__)){
return or__22912__auto__;
} else {
return (0);
}
})() + rname)], null);
if(cljs.core.truth_(name)){
return cljs.core.with_meta.call(null,nseg,new cljs.core.PersistentArrayMap(null, 1, [new cljs.core.Keyword(null,"name","name",1843675177),(name + rname)], null));
} else {
return nseg;
}
});
/**
 * Helper for decode-reverse. Take a reverse source map and
 *   update it with a segment map.
 */
cljs.source_map.update_reverse_result = (function cljs$source_map$update_reverse_result(result,segmap,gline){
var map__29496 = segmap;
var map__29496__$1 = ((((!((map__29496 == null)))?((((map__29496.cljs$lang$protocol_mask$partition0$ & (64))) || (map__29496.cljs$core$ISeq$))?true:false):false))?cljs.core.apply.call(null,cljs.core.hash_map,map__29496):map__29496);
var gcol = cljs.core.get.call(null,map__29496__$1,new cljs.core.Keyword(null,"gcol","gcol",309250807));
var source = cljs.core.get.call(null,map__29496__$1,new cljs.core.Keyword(null,"source","source",-433931539));
var line = cljs.core.get.call(null,map__29496__$1,new cljs.core.Keyword(null,"line","line",212345235));
var col = cljs.core.get.call(null,map__29496__$1,new cljs.core.Keyword(null,"col","col",-1959363084));
var name = cljs.core.get.call(null,map__29496__$1,new cljs.core.Keyword(null,"name","name",1843675177));
var d = new cljs.core.PersistentArrayMap(null, 2, [new cljs.core.Keyword(null,"gline","gline",-1086242431),gline,new cljs.core.Keyword(null,"gcol","gcol",309250807),gcol], null);
var d__$1 = (cljs.core.truth_(name)?cljs.core.assoc.call(null,d,new cljs.core.Keyword(null,"name","name",1843675177),name):d);
return cljs.core.update_in.call(null,result,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [source], null),cljs.core.fnil.call(null,((function (map__29496,map__29496__$1,gcol,source,line,col,name,d,d__$1){
return (function (m){
return cljs.core.update_in.call(null,m,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [line], null),cljs.core.fnil.call(null,((function (map__29496,map__29496__$1,gcol,source,line,col,name,d,d__$1){
return (function (m__$1){
return cljs.core.update_in.call(null,m__$1,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [col], null),cljs.core.fnil.call(null,((function (map__29496,map__29496__$1,gcol,source,line,col,name,d,d__$1){
return (function (v){
return cljs.core.conj.call(null,v,d__$1);
});})(map__29496,map__29496__$1,gcol,source,line,col,name,d,d__$1))
,cljs.core.PersistentVector.EMPTY));
});})(map__29496,map__29496__$1,gcol,source,line,col,name,d,d__$1))
,cljs.core.sorted_map.call(null)));
});})(map__29496,map__29496__$1,gcol,source,line,col,name,d,d__$1))
,cljs.core.sorted_map.call(null)));
});
/**
 * Convert a v3 source map JSON object into a reverse source map
 *   mapping original ClojureScript source locations to the generated
 *   JavaScript.
 */
cljs.source_map.decode_reverse = (function cljs$source_map$decode_reverse(var_args){
var args29498 = [];
var len__23982__auto___29502 = arguments.length;
var i__23983__auto___29503 = (0);
while(true){
if((i__23983__auto___29503 < len__23982__auto___29502)){
args29498.push((arguments[i__23983__auto___29503]));

var G__29504 = (i__23983__auto___29503 + (1));
i__23983__auto___29503 = G__29504;
continue;
} else {
}
break;
}

var G__29500 = args29498.length;
switch (G__29500) {
case 1:
return cljs.source_map.decode_reverse.cljs$core$IFn$_invoke$arity$1((arguments[(0)]));

break;
case 2:
return cljs.source_map.decode_reverse.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
default:
throw (new Error([cljs.core.str("Invalid arity: "),cljs.core.str(args29498.length)].join('')));

}
});

cljs.source_map.decode_reverse.cljs$core$IFn$_invoke$arity$1 = (function (source_map){
return cljs.source_map.decode_reverse.call(null,goog.object.get(source_map,"mappings"),source_map);
});

cljs.source_map.decode_reverse.cljs$core$IFn$_invoke$arity$2 = (function (mappings,source_map){
var sources = goog.object.get(source_map,"sources");
var relseg_init = new cljs.core.PersistentVector(null, 5, 5, cljs.core.PersistentVector.EMPTY_NODE, [(0),(0),(0),(0),(0)], null);
var lines = cljs.core.seq.call(null,clojure.string.split.call(null,mappings,/;/));
var gline = (0);
var lines__$1 = lines;
var relseg = relseg_init;
var result = cljs.core.sorted_map_by.call(null,cljs.source_map.source_compare.call(null,sources));
while(true){
if(lines__$1){
var line = cljs.core.first.call(null,lines__$1);
var vec__29501 = ((clojure.string.blank_QMARK_.call(null,line))?new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [result,relseg], null):(function (){var segs = cljs.core.seq.call(null,clojure.string.split.call(null,line,/,/));
var segs__$1 = segs;
var relseg__$1 = relseg;
var result__$1 = result;
while(true){
if(segs__$1){
var seg = cljs.core.first.call(null,segs__$1);
var nrelseg = cljs.source_map.seg_combine.call(null,cljs.source_map.base64_vlq.decode.call(null,seg),relseg__$1);
var G__29506 = cljs.core.next.call(null,segs__$1);
var G__29507 = nrelseg;
var G__29508 = cljs.source_map.update_reverse_result.call(null,result__$1,cljs.source_map.seg__GT_map.call(null,nrelseg,source_map),gline);
segs__$1 = G__29506;
relseg__$1 = G__29507;
result__$1 = G__29508;
continue;
} else {
return new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [result__$1,relseg__$1], null);
}
break;
}
})());
var result__$1 = cljs.core.nth.call(null,vec__29501,(0),null);
var relseg__$1 = cljs.core.nth.call(null,vec__29501,(1),null);
var G__29509 = (gline + (1));
var G__29510 = cljs.core.next.call(null,lines__$1);
var G__29511 = cljs.core.assoc.call(null,relseg__$1,(0),(0));
var G__29512 = result__$1;
gline = G__29509;
lines__$1 = G__29510;
relseg = G__29511;
result = G__29512;
continue;
} else {
return result;
}
break;
}
});

cljs.source_map.decode_reverse.cljs$lang$maxFixedArity = 2;
/**
 * Helper for decode. Take a source map and update it based on a
 *   segment map.
 */
cljs.source_map.update_result = (function cljs$source_map$update_result(result,segmap,gline){
var map__29516 = segmap;
var map__29516__$1 = ((((!((map__29516 == null)))?((((map__29516.cljs$lang$protocol_mask$partition0$ & (64))) || (map__29516.cljs$core$ISeq$))?true:false):false))?cljs.core.apply.call(null,cljs.core.hash_map,map__29516):map__29516);
var gcol = cljs.core.get.call(null,map__29516__$1,new cljs.core.Keyword(null,"gcol","gcol",309250807));
var source = cljs.core.get.call(null,map__29516__$1,new cljs.core.Keyword(null,"source","source",-433931539));
var line = cljs.core.get.call(null,map__29516__$1,new cljs.core.Keyword(null,"line","line",212345235));
var col = cljs.core.get.call(null,map__29516__$1,new cljs.core.Keyword(null,"col","col",-1959363084));
var name = cljs.core.get.call(null,map__29516__$1,new cljs.core.Keyword(null,"name","name",1843675177));
var d = new cljs.core.PersistentArrayMap(null, 3, [new cljs.core.Keyword(null,"line","line",212345235),line,new cljs.core.Keyword(null,"col","col",-1959363084),col,new cljs.core.Keyword(null,"source","source",-433931539),source], null);
var d__$1 = (cljs.core.truth_(name)?cljs.core.assoc.call(null,d,new cljs.core.Keyword(null,"name","name",1843675177),name):d);
return cljs.core.update_in.call(null,result,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [gline], null),cljs.core.fnil.call(null,((function (map__29516,map__29516__$1,gcol,source,line,col,name,d,d__$1){
return (function (m){
return cljs.core.update_in.call(null,m,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [gcol], null),cljs.core.fnil.call(null,((function (map__29516,map__29516__$1,gcol,source,line,col,name,d,d__$1){
return (function (p1__29513_SHARP_){
return cljs.core.conj.call(null,p1__29513_SHARP_,d__$1);
});})(map__29516,map__29516__$1,gcol,source,line,col,name,d,d__$1))
,cljs.core.PersistentVector.EMPTY));
});})(map__29516,map__29516__$1,gcol,source,line,col,name,d,d__$1))
,cljs.core.sorted_map.call(null)));
});
/**
 * Convert a v3 source map JSON object into a source map mapping
 *   generated JavaScript source locations to the original
 *   ClojureScript.
 */
cljs.source_map.decode = (function cljs$source_map$decode(var_args){
var args29518 = [];
var len__23982__auto___29522 = arguments.length;
var i__23983__auto___29523 = (0);
while(true){
if((i__23983__auto___29523 < len__23982__auto___29522)){
args29518.push((arguments[i__23983__auto___29523]));

var G__29524 = (i__23983__auto___29523 + (1));
i__23983__auto___29523 = G__29524;
continue;
} else {
}
break;
}

var G__29520 = args29518.length;
switch (G__29520) {
case 1:
return cljs.source_map.decode.cljs$core$IFn$_invoke$arity$1((arguments[(0)]));

break;
case 2:
return cljs.source_map.decode.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
default:
throw (new Error([cljs.core.str("Invalid arity: "),cljs.core.str(args29518.length)].join('')));

}
});

cljs.source_map.decode.cljs$core$IFn$_invoke$arity$1 = (function (source_map){
return cljs.source_map.decode.call(null,goog.object.get(source_map,"mappings"),source_map);
});

cljs.source_map.decode.cljs$core$IFn$_invoke$arity$2 = (function (mappings,source_map){
var sources = goog.object.get(source_map,"sources");
var relseg_init = new cljs.core.PersistentVector(null, 5, 5, cljs.core.PersistentVector.EMPTY_NODE, [(0),(0),(0),(0),(0)], null);
var lines = cljs.core.seq.call(null,clojure.string.split.call(null,mappings,/;/));
var gline = (0);
var lines__$1 = lines;
var relseg = relseg_init;
var result = cljs.core.PersistentArrayMap.EMPTY;
while(true){
if(lines__$1){
var line = cljs.core.first.call(null,lines__$1);
var vec__29521 = ((clojure.string.blank_QMARK_.call(null,line))?new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [result,relseg], null):(function (){var segs = cljs.core.seq.call(null,clojure.string.split.call(null,line,/,/));
var segs__$1 = segs;
var relseg__$1 = relseg;
var result__$1 = result;
while(true){
if(segs__$1){
var seg = cljs.core.first.call(null,segs__$1);
var nrelseg = cljs.source_map.seg_combine.call(null,cljs.source_map.base64_vlq.decode.call(null,seg),relseg__$1);
var G__29526 = cljs.core.next.call(null,segs__$1);
var G__29527 = nrelseg;
var G__29528 = cljs.source_map.update_result.call(null,result__$1,cljs.source_map.seg__GT_map.call(null,nrelseg,source_map),gline);
segs__$1 = G__29526;
relseg__$1 = G__29527;
result__$1 = G__29528;
continue;
} else {
return new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [result__$1,relseg__$1], null);
}
break;
}
})());
var result__$1 = cljs.core.nth.call(null,vec__29521,(0),null);
var relseg__$1 = cljs.core.nth.call(null,vec__29521,(1),null);
var G__29529 = (gline + (1));
var G__29530 = cljs.core.next.call(null,lines__$1);
var G__29531 = cljs.core.assoc.call(null,relseg__$1,(0),(0));
var G__29532 = result__$1;
gline = G__29529;
lines__$1 = G__29530;
relseg = G__29531;
result = G__29532;
continue;
} else {
return result;
}
break;
}
});

cljs.source_map.decode.cljs$lang$maxFixedArity = 2;
/**
 * Take a nested sorted map encoding line and column information
 * for a file and return a vector of vectors of encoded segments.
 * Each vector represents a line, and the internal vectors are segments
 * representing the contents of the line.
 */
cljs.source_map.lines__GT_segs = (function cljs$source_map$lines__GT_segs(lines){
var relseg = cljs.core.atom.call(null,new cljs.core.PersistentVector(null, 5, 5, cljs.core.PersistentVector.EMPTY_NODE, [(0),(0),(0),(0),(0)], null));
return cljs.core.reduce.call(null,((function (relseg){
return (function (segs,cols){
cljs.core.swap_BANG_.call(null,relseg,((function (relseg){
return (function (p__29539){
var vec__29540 = p__29539;
var _ = cljs.core.nth.call(null,vec__29540,(0),null);
var source = cljs.core.nth.call(null,vec__29540,(1),null);
var line = cljs.core.nth.call(null,vec__29540,(2),null);
var col = cljs.core.nth.call(null,vec__29540,(3),null);
var name = cljs.core.nth.call(null,vec__29540,(4),null);
return new cljs.core.PersistentVector(null, 5, 5, cljs.core.PersistentVector.EMPTY_NODE, [(0),source,line,col,name], null);
});})(relseg))
);

return cljs.core.conj.call(null,segs,cljs.core.reduce.call(null,((function (relseg){
return (function (cols__$1,p__29541){
var vec__29542 = p__29541;
var gcol = cljs.core.nth.call(null,vec__29542,(0),null);
var sidx = cljs.core.nth.call(null,vec__29542,(1),null);
var line = cljs.core.nth.call(null,vec__29542,(2),null);
var col = cljs.core.nth.call(null,vec__29542,(3),null);
var name = cljs.core.nth.call(null,vec__29542,(4),null);
var seg = vec__29542;
var offset = cljs.core.map.call(null,cljs.core._,seg,cljs.core.deref.call(null,relseg));
cljs.core.swap_BANG_.call(null,relseg,((function (offset,vec__29542,gcol,sidx,line,col,name,seg,relseg){
return (function (p__29543){
var vec__29544 = p__29543;
var _ = cljs.core.nth.call(null,vec__29544,(0),null);
var ___$1 = cljs.core.nth.call(null,vec__29544,(1),null);
var ___$2 = cljs.core.nth.call(null,vec__29544,(2),null);
var ___$3 = cljs.core.nth.call(null,vec__29544,(3),null);
var lname = cljs.core.nth.call(null,vec__29544,(4),null);
return new cljs.core.PersistentVector(null, 5, 5, cljs.core.PersistentVector.EMPTY_NODE, [gcol,sidx,line,col,(function (){var or__22912__auto__ = name;
if(cljs.core.truth_(or__22912__auto__)){
return or__22912__auto__;
} else {
return lname;
}
})()], null);
});})(offset,vec__29542,gcol,sidx,line,col,name,seg,relseg))
);

return cljs.core.conj.call(null,cols__$1,cljs.source_map.base64_vlq.encode.call(null,offset));
});})(relseg))
,cljs.core.PersistentVector.EMPTY,cols));
});})(relseg))
,cljs.core.PersistentVector.EMPTY,lines);
});
/**
 * Take an internal source map representation represented as nested
 * sorted maps of file, line, column and return a source map v3 JSON
 * string.
 */
cljs.source_map.encode = (function cljs$source_map$encode(m,opts){
var lines = cljs.core.atom.call(null,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.PersistentVector.EMPTY], null));
var names__GT_idx = cljs.core.atom.call(null,cljs.core.PersistentArrayMap.EMPTY);
var name_idx = cljs.core.atom.call(null,(0));
var preamble_lines = cljs.core.take.call(null,(function (){var or__22912__auto__ = new cljs.core.Keyword(null,"preamble-line-count","preamble-line-count",-659949744).cljs$core$IFn$_invoke$arity$1(opts);
if(cljs.core.truth_(or__22912__auto__)){
return or__22912__auto__;
} else {
return (0);
}
})(),cljs.core.repeat.call(null,cljs.core.PersistentVector.EMPTY));
var info__GT_segv = ((function (lines,names__GT_idx,name_idx,preamble_lines){
return (function (info,source_idx,line,col){
var segv = new cljs.core.PersistentVector(null, 4, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword(null,"gcol","gcol",309250807).cljs$core$IFn$_invoke$arity$1(info),source_idx,line,col], null);
var temp__4655__auto__ = new cljs.core.Keyword(null,"name","name",1843675177).cljs$core$IFn$_invoke$arity$1(info);
if(cljs.core.truth_(temp__4655__auto__)){
var name = temp__4655__auto__;
var idx = (function (){var temp__4655__auto____$1 = cljs.core.get.call(null,cljs.core.deref.call(null,names__GT_idx),name);
if(cljs.core.truth_(temp__4655__auto____$1)){
var idx = temp__4655__auto____$1;
return idx;
} else {
var cidx = cljs.core.deref.call(null,name_idx);
cljs.core.swap_BANG_.call(null,names__GT_idx,cljs.core.assoc,name,cidx);

cljs.core.swap_BANG_.call(null,name_idx,cljs.core.inc);

return cidx;
}
})();
return cljs.core.conj.call(null,segv,idx);
} else {
return segv;
}
});})(lines,names__GT_idx,name_idx,preamble_lines))
;
var encode_cols = ((function (lines,names__GT_idx,name_idx,preamble_lines,info__GT_segv){
return (function (infos,source_idx,line,col){
var seq__29598 = cljs.core.seq.call(null,infos);
var chunk__29599 = null;
var count__29600 = (0);
var i__29601 = (0);
while(true){
if((i__29601 < count__29600)){
var info = cljs.core._nth.call(null,chunk__29599,i__29601);
var segv_29648 = info__GT_segv.call(null,info,source_idx,line,col);
var gline_29649 = new cljs.core.Keyword(null,"gline","gline",-1086242431).cljs$core$IFn$_invoke$arity$1(info);
var lc_29650 = cljs.core.count.call(null,cljs.core.deref.call(null,lines));
if((gline_29649 > (lc_29650 - (1)))){
cljs.core.swap_BANG_.call(null,lines,((function (seq__29598,chunk__29599,count__29600,i__29601,segv_29648,gline_29649,lc_29650,info,lines,names__GT_idx,name_idx,preamble_lines,info__GT_segv){
return (function (lines__$1){
return cljs.core.conj.call(null,cljs.core.into.call(null,lines__$1,cljs.core.repeat.call(null,((gline_29649 - (lc_29650 - (1))) - (1)),cljs.core.PersistentVector.EMPTY)),new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [segv_29648], null));
});})(seq__29598,chunk__29599,count__29600,i__29601,segv_29648,gline_29649,lc_29650,info,lines,names__GT_idx,name_idx,preamble_lines,info__GT_segv))
);
} else {
cljs.core.swap_BANG_.call(null,lines,((function (seq__29598,chunk__29599,count__29600,i__29601,segv_29648,gline_29649,lc_29650,info,lines,names__GT_idx,name_idx,preamble_lines,info__GT_segv){
return (function (lines__$1){
return cljs.core.update_in.call(null,lines__$1,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [gline_29649], null),cljs.core.conj,segv_29648);
});})(seq__29598,chunk__29599,count__29600,i__29601,segv_29648,gline_29649,lc_29650,info,lines,names__GT_idx,name_idx,preamble_lines,info__GT_segv))
);
}

var G__29651 = seq__29598;
var G__29652 = chunk__29599;
var G__29653 = count__29600;
var G__29654 = (i__29601 + (1));
seq__29598 = G__29651;
chunk__29599 = G__29652;
count__29600 = G__29653;
i__29601 = G__29654;
continue;
} else {
var temp__4657__auto__ = cljs.core.seq.call(null,seq__29598);
if(temp__4657__auto__){
var seq__29598__$1 = temp__4657__auto__;
if(cljs.core.chunked_seq_QMARK_.call(null,seq__29598__$1)){
var c__23723__auto__ = cljs.core.chunk_first.call(null,seq__29598__$1);
var G__29655 = cljs.core.chunk_rest.call(null,seq__29598__$1);
var G__29656 = c__23723__auto__;
var G__29657 = cljs.core.count.call(null,c__23723__auto__);
var G__29658 = (0);
seq__29598 = G__29655;
chunk__29599 = G__29656;
count__29600 = G__29657;
i__29601 = G__29658;
continue;
} else {
var info = cljs.core.first.call(null,seq__29598__$1);
var segv_29659 = info__GT_segv.call(null,info,source_idx,line,col);
var gline_29660 = new cljs.core.Keyword(null,"gline","gline",-1086242431).cljs$core$IFn$_invoke$arity$1(info);
var lc_29661 = cljs.core.count.call(null,cljs.core.deref.call(null,lines));
if((gline_29660 > (lc_29661 - (1)))){
cljs.core.swap_BANG_.call(null,lines,((function (seq__29598,chunk__29599,count__29600,i__29601,segv_29659,gline_29660,lc_29661,info,seq__29598__$1,temp__4657__auto__,lines,names__GT_idx,name_idx,preamble_lines,info__GT_segv){
return (function (lines__$1){
return cljs.core.conj.call(null,cljs.core.into.call(null,lines__$1,cljs.core.repeat.call(null,((gline_29660 - (lc_29661 - (1))) - (1)),cljs.core.PersistentVector.EMPTY)),new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [segv_29659], null));
});})(seq__29598,chunk__29599,count__29600,i__29601,segv_29659,gline_29660,lc_29661,info,seq__29598__$1,temp__4657__auto__,lines,names__GT_idx,name_idx,preamble_lines,info__GT_segv))
);
} else {
cljs.core.swap_BANG_.call(null,lines,((function (seq__29598,chunk__29599,count__29600,i__29601,segv_29659,gline_29660,lc_29661,info,seq__29598__$1,temp__4657__auto__,lines,names__GT_idx,name_idx,preamble_lines,info__GT_segv){
return (function (lines__$1){
return cljs.core.update_in.call(null,lines__$1,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [gline_29660], null),cljs.core.conj,segv_29659);
});})(seq__29598,chunk__29599,count__29600,i__29601,segv_29659,gline_29660,lc_29661,info,seq__29598__$1,temp__4657__auto__,lines,names__GT_idx,name_idx,preamble_lines,info__GT_segv))
);
}

var G__29662 = cljs.core.next.call(null,seq__29598__$1);
var G__29663 = null;
var G__29664 = (0);
var G__29665 = (0);
seq__29598 = G__29662;
chunk__29599 = G__29663;
count__29600 = G__29664;
i__29601 = G__29665;
continue;
}
} else {
return null;
}
}
break;
}
});})(lines,names__GT_idx,name_idx,preamble_lines,info__GT_segv))
;
var seq__29602_29666 = cljs.core.seq.call(null,cljs.core.map_indexed.call(null,((function (lines,names__GT_idx,name_idx,preamble_lines,info__GT_segv,encode_cols){
return (function (i,v){
return new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [i,v], null);
});})(lines,names__GT_idx,name_idx,preamble_lines,info__GT_segv,encode_cols))
,m));
var chunk__29603_29667 = null;
var count__29604_29668 = (0);
var i__29605_29669 = (0);
while(true){
if((i__29605_29669 < count__29604_29668)){
var vec__29606_29670 = cljs.core._nth.call(null,chunk__29603_29667,i__29605_29669);
var source_idx_29671 = cljs.core.nth.call(null,vec__29606_29670,(0),null);
var vec__29607_29672 = cljs.core.nth.call(null,vec__29606_29670,(1),null);
var __29673 = cljs.core.nth.call(null,vec__29607_29672,(0),null);
var lines_29674__$1 = cljs.core.nth.call(null,vec__29607_29672,(1),null);
var seq__29608_29675 = cljs.core.seq.call(null,lines_29674__$1);
var chunk__29609_29676 = null;
var count__29610_29677 = (0);
var i__29611_29678 = (0);
while(true){
if((i__29611_29678 < count__29610_29677)){
var vec__29612_29679 = cljs.core._nth.call(null,chunk__29609_29676,i__29611_29678);
var line_29680 = cljs.core.nth.call(null,vec__29612_29679,(0),null);
var cols_29681 = cljs.core.nth.call(null,vec__29612_29679,(1),null);
var seq__29613_29682 = cljs.core.seq.call(null,cols_29681);
var chunk__29614_29683 = null;
var count__29615_29684 = (0);
var i__29616_29685 = (0);
while(true){
if((i__29616_29685 < count__29615_29684)){
var vec__29617_29686 = cljs.core._nth.call(null,chunk__29614_29683,i__29616_29685);
var col_29687 = cljs.core.nth.call(null,vec__29617_29686,(0),null);
var infos_29688 = cljs.core.nth.call(null,vec__29617_29686,(1),null);
encode_cols.call(null,infos_29688,source_idx_29671,line_29680,col_29687);

var G__29689 = seq__29613_29682;
var G__29690 = chunk__29614_29683;
var G__29691 = count__29615_29684;
var G__29692 = (i__29616_29685 + (1));
seq__29613_29682 = G__29689;
chunk__29614_29683 = G__29690;
count__29615_29684 = G__29691;
i__29616_29685 = G__29692;
continue;
} else {
var temp__4657__auto___29693 = cljs.core.seq.call(null,seq__29613_29682);
if(temp__4657__auto___29693){
var seq__29613_29694__$1 = temp__4657__auto___29693;
if(cljs.core.chunked_seq_QMARK_.call(null,seq__29613_29694__$1)){
var c__23723__auto___29695 = cljs.core.chunk_first.call(null,seq__29613_29694__$1);
var G__29696 = cljs.core.chunk_rest.call(null,seq__29613_29694__$1);
var G__29697 = c__23723__auto___29695;
var G__29698 = cljs.core.count.call(null,c__23723__auto___29695);
var G__29699 = (0);
seq__29613_29682 = G__29696;
chunk__29614_29683 = G__29697;
count__29615_29684 = G__29698;
i__29616_29685 = G__29699;
continue;
} else {
var vec__29618_29700 = cljs.core.first.call(null,seq__29613_29694__$1);
var col_29701 = cljs.core.nth.call(null,vec__29618_29700,(0),null);
var infos_29702 = cljs.core.nth.call(null,vec__29618_29700,(1),null);
encode_cols.call(null,infos_29702,source_idx_29671,line_29680,col_29701);

var G__29703 = cljs.core.next.call(null,seq__29613_29694__$1);
var G__29704 = null;
var G__29705 = (0);
var G__29706 = (0);
seq__29613_29682 = G__29703;
chunk__29614_29683 = G__29704;
count__29615_29684 = G__29705;
i__29616_29685 = G__29706;
continue;
}
} else {
}
}
break;
}

var G__29707 = seq__29608_29675;
var G__29708 = chunk__29609_29676;
var G__29709 = count__29610_29677;
var G__29710 = (i__29611_29678 + (1));
seq__29608_29675 = G__29707;
chunk__29609_29676 = G__29708;
count__29610_29677 = G__29709;
i__29611_29678 = G__29710;
continue;
} else {
var temp__4657__auto___29711 = cljs.core.seq.call(null,seq__29608_29675);
if(temp__4657__auto___29711){
var seq__29608_29712__$1 = temp__4657__auto___29711;
if(cljs.core.chunked_seq_QMARK_.call(null,seq__29608_29712__$1)){
var c__23723__auto___29713 = cljs.core.chunk_first.call(null,seq__29608_29712__$1);
var G__29714 = cljs.core.chunk_rest.call(null,seq__29608_29712__$1);
var G__29715 = c__23723__auto___29713;
var G__29716 = cljs.core.count.call(null,c__23723__auto___29713);
var G__29717 = (0);
seq__29608_29675 = G__29714;
chunk__29609_29676 = G__29715;
count__29610_29677 = G__29716;
i__29611_29678 = G__29717;
continue;
} else {
var vec__29619_29718 = cljs.core.first.call(null,seq__29608_29712__$1);
var line_29719 = cljs.core.nth.call(null,vec__29619_29718,(0),null);
var cols_29720 = cljs.core.nth.call(null,vec__29619_29718,(1),null);
var seq__29620_29721 = cljs.core.seq.call(null,cols_29720);
var chunk__29621_29722 = null;
var count__29622_29723 = (0);
var i__29623_29724 = (0);
while(true){
if((i__29623_29724 < count__29622_29723)){
var vec__29624_29725 = cljs.core._nth.call(null,chunk__29621_29722,i__29623_29724);
var col_29726 = cljs.core.nth.call(null,vec__29624_29725,(0),null);
var infos_29727 = cljs.core.nth.call(null,vec__29624_29725,(1),null);
encode_cols.call(null,infos_29727,source_idx_29671,line_29719,col_29726);

var G__29728 = seq__29620_29721;
var G__29729 = chunk__29621_29722;
var G__29730 = count__29622_29723;
var G__29731 = (i__29623_29724 + (1));
seq__29620_29721 = G__29728;
chunk__29621_29722 = G__29729;
count__29622_29723 = G__29730;
i__29623_29724 = G__29731;
continue;
} else {
var temp__4657__auto___29732__$1 = cljs.core.seq.call(null,seq__29620_29721);
if(temp__4657__auto___29732__$1){
var seq__29620_29733__$1 = temp__4657__auto___29732__$1;
if(cljs.core.chunked_seq_QMARK_.call(null,seq__29620_29733__$1)){
var c__23723__auto___29734 = cljs.core.chunk_first.call(null,seq__29620_29733__$1);
var G__29735 = cljs.core.chunk_rest.call(null,seq__29620_29733__$1);
var G__29736 = c__23723__auto___29734;
var G__29737 = cljs.core.count.call(null,c__23723__auto___29734);
var G__29738 = (0);
seq__29620_29721 = G__29735;
chunk__29621_29722 = G__29736;
count__29622_29723 = G__29737;
i__29623_29724 = G__29738;
continue;
} else {
var vec__29625_29739 = cljs.core.first.call(null,seq__29620_29733__$1);
var col_29740 = cljs.core.nth.call(null,vec__29625_29739,(0),null);
var infos_29741 = cljs.core.nth.call(null,vec__29625_29739,(1),null);
encode_cols.call(null,infos_29741,source_idx_29671,line_29719,col_29740);

var G__29742 = cljs.core.next.call(null,seq__29620_29733__$1);
var G__29743 = null;
var G__29744 = (0);
var G__29745 = (0);
seq__29620_29721 = G__29742;
chunk__29621_29722 = G__29743;
count__29622_29723 = G__29744;
i__29623_29724 = G__29745;
continue;
}
} else {
}
}
break;
}

var G__29746 = cljs.core.next.call(null,seq__29608_29712__$1);
var G__29747 = null;
var G__29748 = (0);
var G__29749 = (0);
seq__29608_29675 = G__29746;
chunk__29609_29676 = G__29747;
count__29610_29677 = G__29748;
i__29611_29678 = G__29749;
continue;
}
} else {
}
}
break;
}

var G__29750 = seq__29602_29666;
var G__29751 = chunk__29603_29667;
var G__29752 = count__29604_29668;
var G__29753 = (i__29605_29669 + (1));
seq__29602_29666 = G__29750;
chunk__29603_29667 = G__29751;
count__29604_29668 = G__29752;
i__29605_29669 = G__29753;
continue;
} else {
var temp__4657__auto___29754 = cljs.core.seq.call(null,seq__29602_29666);
if(temp__4657__auto___29754){
var seq__29602_29755__$1 = temp__4657__auto___29754;
if(cljs.core.chunked_seq_QMARK_.call(null,seq__29602_29755__$1)){
var c__23723__auto___29756 = cljs.core.chunk_first.call(null,seq__29602_29755__$1);
var G__29757 = cljs.core.chunk_rest.call(null,seq__29602_29755__$1);
var G__29758 = c__23723__auto___29756;
var G__29759 = cljs.core.count.call(null,c__23723__auto___29756);
var G__29760 = (0);
seq__29602_29666 = G__29757;
chunk__29603_29667 = G__29758;
count__29604_29668 = G__29759;
i__29605_29669 = G__29760;
continue;
} else {
var vec__29626_29761 = cljs.core.first.call(null,seq__29602_29755__$1);
var source_idx_29762 = cljs.core.nth.call(null,vec__29626_29761,(0),null);
var vec__29627_29763 = cljs.core.nth.call(null,vec__29626_29761,(1),null);
var __29764 = cljs.core.nth.call(null,vec__29627_29763,(0),null);
var lines_29765__$1 = cljs.core.nth.call(null,vec__29627_29763,(1),null);
var seq__29628_29766 = cljs.core.seq.call(null,lines_29765__$1);
var chunk__29629_29767 = null;
var count__29630_29768 = (0);
var i__29631_29769 = (0);
while(true){
if((i__29631_29769 < count__29630_29768)){
var vec__29632_29770 = cljs.core._nth.call(null,chunk__29629_29767,i__29631_29769);
var line_29771 = cljs.core.nth.call(null,vec__29632_29770,(0),null);
var cols_29772 = cljs.core.nth.call(null,vec__29632_29770,(1),null);
var seq__29633_29773 = cljs.core.seq.call(null,cols_29772);
var chunk__29634_29774 = null;
var count__29635_29775 = (0);
var i__29636_29776 = (0);
while(true){
if((i__29636_29776 < count__29635_29775)){
var vec__29637_29777 = cljs.core._nth.call(null,chunk__29634_29774,i__29636_29776);
var col_29778 = cljs.core.nth.call(null,vec__29637_29777,(0),null);
var infos_29779 = cljs.core.nth.call(null,vec__29637_29777,(1),null);
encode_cols.call(null,infos_29779,source_idx_29762,line_29771,col_29778);

var G__29780 = seq__29633_29773;
var G__29781 = chunk__29634_29774;
var G__29782 = count__29635_29775;
var G__29783 = (i__29636_29776 + (1));
seq__29633_29773 = G__29780;
chunk__29634_29774 = G__29781;
count__29635_29775 = G__29782;
i__29636_29776 = G__29783;
continue;
} else {
var temp__4657__auto___29784__$1 = cljs.core.seq.call(null,seq__29633_29773);
if(temp__4657__auto___29784__$1){
var seq__29633_29785__$1 = temp__4657__auto___29784__$1;
if(cljs.core.chunked_seq_QMARK_.call(null,seq__29633_29785__$1)){
var c__23723__auto___29786 = cljs.core.chunk_first.call(null,seq__29633_29785__$1);
var G__29787 = cljs.core.chunk_rest.call(null,seq__29633_29785__$1);
var G__29788 = c__23723__auto___29786;
var G__29789 = cljs.core.count.call(null,c__23723__auto___29786);
var G__29790 = (0);
seq__29633_29773 = G__29787;
chunk__29634_29774 = G__29788;
count__29635_29775 = G__29789;
i__29636_29776 = G__29790;
continue;
} else {
var vec__29638_29791 = cljs.core.first.call(null,seq__29633_29785__$1);
var col_29792 = cljs.core.nth.call(null,vec__29638_29791,(0),null);
var infos_29793 = cljs.core.nth.call(null,vec__29638_29791,(1),null);
encode_cols.call(null,infos_29793,source_idx_29762,line_29771,col_29792);

var G__29794 = cljs.core.next.call(null,seq__29633_29785__$1);
var G__29795 = null;
var G__29796 = (0);
var G__29797 = (0);
seq__29633_29773 = G__29794;
chunk__29634_29774 = G__29795;
count__29635_29775 = G__29796;
i__29636_29776 = G__29797;
continue;
}
} else {
}
}
break;
}

var G__29798 = seq__29628_29766;
var G__29799 = chunk__29629_29767;
var G__29800 = count__29630_29768;
var G__29801 = (i__29631_29769 + (1));
seq__29628_29766 = G__29798;
chunk__29629_29767 = G__29799;
count__29630_29768 = G__29800;
i__29631_29769 = G__29801;
continue;
} else {
var temp__4657__auto___29802__$1 = cljs.core.seq.call(null,seq__29628_29766);
if(temp__4657__auto___29802__$1){
var seq__29628_29803__$1 = temp__4657__auto___29802__$1;
if(cljs.core.chunked_seq_QMARK_.call(null,seq__29628_29803__$1)){
var c__23723__auto___29804 = cljs.core.chunk_first.call(null,seq__29628_29803__$1);
var G__29805 = cljs.core.chunk_rest.call(null,seq__29628_29803__$1);
var G__29806 = c__23723__auto___29804;
var G__29807 = cljs.core.count.call(null,c__23723__auto___29804);
var G__29808 = (0);
seq__29628_29766 = G__29805;
chunk__29629_29767 = G__29806;
count__29630_29768 = G__29807;
i__29631_29769 = G__29808;
continue;
} else {
var vec__29639_29809 = cljs.core.first.call(null,seq__29628_29803__$1);
var line_29810 = cljs.core.nth.call(null,vec__29639_29809,(0),null);
var cols_29811 = cljs.core.nth.call(null,vec__29639_29809,(1),null);
var seq__29640_29812 = cljs.core.seq.call(null,cols_29811);
var chunk__29641_29813 = null;
var count__29642_29814 = (0);
var i__29643_29815 = (0);
while(true){
if((i__29643_29815 < count__29642_29814)){
var vec__29644_29816 = cljs.core._nth.call(null,chunk__29641_29813,i__29643_29815);
var col_29817 = cljs.core.nth.call(null,vec__29644_29816,(0),null);
var infos_29818 = cljs.core.nth.call(null,vec__29644_29816,(1),null);
encode_cols.call(null,infos_29818,source_idx_29762,line_29810,col_29817);

var G__29819 = seq__29640_29812;
var G__29820 = chunk__29641_29813;
var G__29821 = count__29642_29814;
var G__29822 = (i__29643_29815 + (1));
seq__29640_29812 = G__29819;
chunk__29641_29813 = G__29820;
count__29642_29814 = G__29821;
i__29643_29815 = G__29822;
continue;
} else {
var temp__4657__auto___29823__$2 = cljs.core.seq.call(null,seq__29640_29812);
if(temp__4657__auto___29823__$2){
var seq__29640_29824__$1 = temp__4657__auto___29823__$2;
if(cljs.core.chunked_seq_QMARK_.call(null,seq__29640_29824__$1)){
var c__23723__auto___29825 = cljs.core.chunk_first.call(null,seq__29640_29824__$1);
var G__29826 = cljs.core.chunk_rest.call(null,seq__29640_29824__$1);
var G__29827 = c__23723__auto___29825;
var G__29828 = cljs.core.count.call(null,c__23723__auto___29825);
var G__29829 = (0);
seq__29640_29812 = G__29826;
chunk__29641_29813 = G__29827;
count__29642_29814 = G__29828;
i__29643_29815 = G__29829;
continue;
} else {
var vec__29645_29830 = cljs.core.first.call(null,seq__29640_29824__$1);
var col_29831 = cljs.core.nth.call(null,vec__29645_29830,(0),null);
var infos_29832 = cljs.core.nth.call(null,vec__29645_29830,(1),null);
encode_cols.call(null,infos_29832,source_idx_29762,line_29810,col_29831);

var G__29833 = cljs.core.next.call(null,seq__29640_29824__$1);
var G__29834 = null;
var G__29835 = (0);
var G__29836 = (0);
seq__29640_29812 = G__29833;
chunk__29641_29813 = G__29834;
count__29642_29814 = G__29835;
i__29643_29815 = G__29836;
continue;
}
} else {
}
}
break;
}

var G__29837 = cljs.core.next.call(null,seq__29628_29803__$1);
var G__29838 = null;
var G__29839 = (0);
var G__29840 = (0);
seq__29628_29766 = G__29837;
chunk__29629_29767 = G__29838;
count__29630_29768 = G__29839;
i__29631_29769 = G__29840;
continue;
}
} else {
}
}
break;
}

var G__29841 = cljs.core.next.call(null,seq__29602_29755__$1);
var G__29842 = null;
var G__29843 = (0);
var G__29844 = (0);
seq__29602_29666 = G__29841;
chunk__29603_29667 = G__29842;
count__29604_29668 = G__29843;
i__29605_29669 = G__29844;
continue;
}
} else {
}
}
break;
}

var source_map_file_contents = (function (){var G__29646 = {"version": (3), "file": new cljs.core.Keyword(null,"file","file",-1269645878).cljs$core$IFn$_invoke$arity$1(opts), "sources": (function (){var paths = cljs.core.keys.call(null,m);
var f = cljs.core.comp.call(null,((new cljs.core.Keyword(null,"source-map-timestamp","source-map-timestamp",1973015633).cljs$core$IFn$_invoke$arity$1(opts) === true)?((function (paths,lines,names__GT_idx,name_idx,preamble_lines,info__GT_segv,encode_cols){
return (function (p1__29545_SHARP_){
return [cljs.core.str(p1__29545_SHARP_),cljs.core.str("?rel="),cljs.core.str((new Date()).valueOf())].join('');
});})(paths,lines,names__GT_idx,name_idx,preamble_lines,info__GT_segv,encode_cols))
:cljs.core.identity),((function (paths,lines,names__GT_idx,name_idx,preamble_lines,info__GT_segv,encode_cols){
return (function (p1__29546_SHARP_){
return cljs.core.last.call(null,clojure.string.split.call(null,p1__29546_SHARP_,/\//));
});})(paths,lines,names__GT_idx,name_idx,preamble_lines,info__GT_segv,encode_cols))
);
return cljs.core.into_array.call(null,cljs.core.map.call(null,f,paths));
})(), "lineCount": new cljs.core.Keyword(null,"lines","lines",-700165781).cljs$core$IFn$_invoke$arity$1(opts), "mappings": clojure.string.join.call(null,";",cljs.core.map.call(null,((function (lines,names__GT_idx,name_idx,preamble_lines,info__GT_segv,encode_cols){
return (function (p1__29547_SHARP_){
return clojure.string.join.call(null,",",p1__29547_SHARP_);
});})(lines,names__GT_idx,name_idx,preamble_lines,info__GT_segv,encode_cols))
,cljs.source_map.lines__GT_segs.call(null,cljs.core.concat.call(null,preamble_lines,cljs.core.deref.call(null,lines))))), "names": cljs.core.into_array.call(null,cljs.core.map.call(null,clojure.set.map_invert.call(null,cljs.core.deref.call(null,names__GT_idx)),cljs.core.range.call(null,cljs.core.count.call(null,cljs.core.deref.call(null,names__GT_idx)))))};
if(cljs.core.truth_(new cljs.core.Keyword(null,"sources-content","sources-content",1729970239).cljs$core$IFn$_invoke$arity$1(opts))){
var G__29647 = G__29646;
goog.object.set(G__29647,"sourcesContent",cljs.core.into_array.call(null,new cljs.core.Keyword(null,"sources-content","sources-content",1729970239).cljs$core$IFn$_invoke$arity$1(opts)));

return G__29647;
} else {
return G__29646;
}
})();
return JSON.stringify(source_map_file_contents);
});
/**
 * Merge an internal source map representation of a single
 * ClojureScript file mapping original to generated with a
 * second source map mapping original JS to generated JS.
 * The is to support source maps that work through multiple
 * compilation steps like Google Closure optimization passes.
 */
cljs.source_map.merge_source_maps = (function cljs$source_map$merge_source_maps(cljs_map,js_map){
var line_map_seq = cljs.core.seq.call(null,cljs_map);
var new_lines = cljs.core.sorted_map.call(null);
while(true){
if(line_map_seq){
var vec__29850 = cljs.core.first.call(null,line_map_seq);
var line = cljs.core.nth.call(null,vec__29850,(0),null);
var col_map = cljs.core.nth.call(null,vec__29850,(1),null);
var new_cols = (function (){var col_map_seq = cljs.core.seq.call(null,col_map);
var new_cols = cljs.core.sorted_map.call(null);
while(true){
if(col_map_seq){
var vec__29851 = cljs.core.first.call(null,col_map_seq);
var col = cljs.core.nth.call(null,vec__29851,(0),null);
var infos = cljs.core.nth.call(null,vec__29851,(1),null);
var G__29855 = cljs.core.next.call(null,col_map_seq);
var G__29856 = cljs.core.assoc.call(null,new_cols,col,cljs.core.reduce.call(null,((function (col_map_seq,new_cols,line_map_seq,new_lines,vec__29851,col,infos,vec__29850,line,col_map){
return (function (v,p__29852){
var map__29853 = p__29852;
var map__29853__$1 = ((((!((map__29853 == null)))?((((map__29853.cljs$lang$protocol_mask$partition0$ & (64))) || (map__29853.cljs$core$ISeq$))?true:false):false))?cljs.core.apply.call(null,cljs.core.hash_map,map__29853):map__29853);
var gline = cljs.core.get.call(null,map__29853__$1,new cljs.core.Keyword(null,"gline","gline",-1086242431));
var gcol = cljs.core.get.call(null,map__29853__$1,new cljs.core.Keyword(null,"gcol","gcol",309250807));
return cljs.core.into.call(null,v,cljs.core.get_in.call(null,js_map,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [gline,gcol], null)));
});})(col_map_seq,new_cols,line_map_seq,new_lines,vec__29851,col,infos,vec__29850,line,col_map))
,cljs.core.PersistentVector.EMPTY,infos));
col_map_seq = G__29855;
new_cols = G__29856;
continue;
} else {
return new_cols;
}
break;
}
})();
var G__29857 = cljs.core.next.call(null,line_map_seq);
var G__29858 = cljs.core.assoc.call(null,new_lines,line,new_cols);
line_map_seq = G__29857;
new_lines = G__29858;
continue;
} else {
return new_lines;
}
break;
}
});
/**
 * Given a ClojureScript to JavaScript source map, invert it. Useful when
 * mapping JavaScript stack traces when environment support is unavailable.
 */
cljs.source_map.invert_reverse_map = (function cljs$source_map$invert_reverse_map(reverse_map){
var inverted = cljs.core.atom.call(null,cljs.core.sorted_map.call(null));
var seq__29909_29959 = cljs.core.seq.call(null,reverse_map);
var chunk__29910_29960 = null;
var count__29911_29961 = (0);
var i__29912_29962 = (0);
while(true){
if((i__29912_29962 < count__29911_29961)){
var vec__29913_29963 = cljs.core._nth.call(null,chunk__29910_29960,i__29912_29962);
var line_29964 = cljs.core.nth.call(null,vec__29913_29963,(0),null);
var columns_29965 = cljs.core.nth.call(null,vec__29913_29963,(1),null);
var seq__29914_29966 = cljs.core.seq.call(null,columns_29965);
var chunk__29915_29967 = null;
var count__29916_29968 = (0);
var i__29917_29969 = (0);
while(true){
if((i__29917_29969 < count__29916_29968)){
var vec__29918_29970 = cljs.core._nth.call(null,chunk__29915_29967,i__29917_29969);
var column_29971 = cljs.core.nth.call(null,vec__29918_29970,(0),null);
var column_info_29972 = cljs.core.nth.call(null,vec__29918_29970,(1),null);
var seq__29919_29973 = cljs.core.seq.call(null,column_info_29972);
var chunk__29920_29974 = null;
var count__29921_29975 = (0);
var i__29922_29976 = (0);
while(true){
if((i__29922_29976 < count__29921_29975)){
var map__29923_29977 = cljs.core._nth.call(null,chunk__29920_29974,i__29922_29976);
var map__29923_29978__$1 = ((((!((map__29923_29977 == null)))?((((map__29923_29977.cljs$lang$protocol_mask$partition0$ & (64))) || (map__29923_29977.cljs$core$ISeq$))?true:false):false))?cljs.core.apply.call(null,cljs.core.hash_map,map__29923_29977):map__29923_29977);
var gline_29979 = cljs.core.get.call(null,map__29923_29978__$1,new cljs.core.Keyword(null,"gline","gline",-1086242431));
var gcol_29980 = cljs.core.get.call(null,map__29923_29978__$1,new cljs.core.Keyword(null,"gcol","gcol",309250807));
var name_29981 = cljs.core.get.call(null,map__29923_29978__$1,new cljs.core.Keyword(null,"name","name",1843675177));
cljs.core.swap_BANG_.call(null,inverted,cljs.core.update_in,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [gline_29979], null),cljs.core.fnil.call(null,((function (seq__29919_29973,chunk__29920_29974,count__29921_29975,i__29922_29976,seq__29914_29966,chunk__29915_29967,count__29916_29968,i__29917_29969,seq__29909_29959,chunk__29910_29960,count__29911_29961,i__29912_29962,map__29923_29977,map__29923_29978__$1,gline_29979,gcol_29980,name_29981,vec__29918_29970,column_29971,column_info_29972,vec__29913_29963,line_29964,columns_29965,inverted){
return (function (columns__$1){
return cljs.core.update_in.call(null,columns__$1,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [gcol_29980], null),cljs.core.fnil.call(null,cljs.core.conj,cljs.core.PersistentVector.EMPTY),new cljs.core.PersistentArrayMap(null, 3, [new cljs.core.Keyword(null,"line","line",212345235),line_29964,new cljs.core.Keyword(null,"col","col",-1959363084),column_29971,new cljs.core.Keyword(null,"name","name",1843675177),name_29981], null));
});})(seq__29919_29973,chunk__29920_29974,count__29921_29975,i__29922_29976,seq__29914_29966,chunk__29915_29967,count__29916_29968,i__29917_29969,seq__29909_29959,chunk__29910_29960,count__29911_29961,i__29912_29962,map__29923_29977,map__29923_29978__$1,gline_29979,gcol_29980,name_29981,vec__29918_29970,column_29971,column_info_29972,vec__29913_29963,line_29964,columns_29965,inverted))
,cljs.core.sorted_map.call(null)));

var G__29982 = seq__29919_29973;
var G__29983 = chunk__29920_29974;
var G__29984 = count__29921_29975;
var G__29985 = (i__29922_29976 + (1));
seq__29919_29973 = G__29982;
chunk__29920_29974 = G__29983;
count__29921_29975 = G__29984;
i__29922_29976 = G__29985;
continue;
} else {
var temp__4657__auto___29986 = cljs.core.seq.call(null,seq__29919_29973);
if(temp__4657__auto___29986){
var seq__29919_29987__$1 = temp__4657__auto___29986;
if(cljs.core.chunked_seq_QMARK_.call(null,seq__29919_29987__$1)){
var c__23723__auto___29988 = cljs.core.chunk_first.call(null,seq__29919_29987__$1);
var G__29989 = cljs.core.chunk_rest.call(null,seq__29919_29987__$1);
var G__29990 = c__23723__auto___29988;
var G__29991 = cljs.core.count.call(null,c__23723__auto___29988);
var G__29992 = (0);
seq__29919_29973 = G__29989;
chunk__29920_29974 = G__29990;
count__29921_29975 = G__29991;
i__29922_29976 = G__29992;
continue;
} else {
var map__29925_29993 = cljs.core.first.call(null,seq__29919_29987__$1);
var map__29925_29994__$1 = ((((!((map__29925_29993 == null)))?((((map__29925_29993.cljs$lang$protocol_mask$partition0$ & (64))) || (map__29925_29993.cljs$core$ISeq$))?true:false):false))?cljs.core.apply.call(null,cljs.core.hash_map,map__29925_29993):map__29925_29993);
var gline_29995 = cljs.core.get.call(null,map__29925_29994__$1,new cljs.core.Keyword(null,"gline","gline",-1086242431));
var gcol_29996 = cljs.core.get.call(null,map__29925_29994__$1,new cljs.core.Keyword(null,"gcol","gcol",309250807));
var name_29997 = cljs.core.get.call(null,map__29925_29994__$1,new cljs.core.Keyword(null,"name","name",1843675177));
cljs.core.swap_BANG_.call(null,inverted,cljs.core.update_in,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [gline_29995], null),cljs.core.fnil.call(null,((function (seq__29919_29973,chunk__29920_29974,count__29921_29975,i__29922_29976,seq__29914_29966,chunk__29915_29967,count__29916_29968,i__29917_29969,seq__29909_29959,chunk__29910_29960,count__29911_29961,i__29912_29962,map__29925_29993,map__29925_29994__$1,gline_29995,gcol_29996,name_29997,seq__29919_29987__$1,temp__4657__auto___29986,vec__29918_29970,column_29971,column_info_29972,vec__29913_29963,line_29964,columns_29965,inverted){
return (function (columns__$1){
return cljs.core.update_in.call(null,columns__$1,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [gcol_29996], null),cljs.core.fnil.call(null,cljs.core.conj,cljs.core.PersistentVector.EMPTY),new cljs.core.PersistentArrayMap(null, 3, [new cljs.core.Keyword(null,"line","line",212345235),line_29964,new cljs.core.Keyword(null,"col","col",-1959363084),column_29971,new cljs.core.Keyword(null,"name","name",1843675177),name_29997], null));
});})(seq__29919_29973,chunk__29920_29974,count__29921_29975,i__29922_29976,seq__29914_29966,chunk__29915_29967,count__29916_29968,i__29917_29969,seq__29909_29959,chunk__29910_29960,count__29911_29961,i__29912_29962,map__29925_29993,map__29925_29994__$1,gline_29995,gcol_29996,name_29997,seq__29919_29987__$1,temp__4657__auto___29986,vec__29918_29970,column_29971,column_info_29972,vec__29913_29963,line_29964,columns_29965,inverted))
,cljs.core.sorted_map.call(null)));

var G__29998 = cljs.core.next.call(null,seq__29919_29987__$1);
var G__29999 = null;
var G__30000 = (0);
var G__30001 = (0);
seq__29919_29973 = G__29998;
chunk__29920_29974 = G__29999;
count__29921_29975 = G__30000;
i__29922_29976 = G__30001;
continue;
}
} else {
}
}
break;
}

var G__30002 = seq__29914_29966;
var G__30003 = chunk__29915_29967;
var G__30004 = count__29916_29968;
var G__30005 = (i__29917_29969 + (1));
seq__29914_29966 = G__30002;
chunk__29915_29967 = G__30003;
count__29916_29968 = G__30004;
i__29917_29969 = G__30005;
continue;
} else {
var temp__4657__auto___30006 = cljs.core.seq.call(null,seq__29914_29966);
if(temp__4657__auto___30006){
var seq__29914_30007__$1 = temp__4657__auto___30006;
if(cljs.core.chunked_seq_QMARK_.call(null,seq__29914_30007__$1)){
var c__23723__auto___30008 = cljs.core.chunk_first.call(null,seq__29914_30007__$1);
var G__30009 = cljs.core.chunk_rest.call(null,seq__29914_30007__$1);
var G__30010 = c__23723__auto___30008;
var G__30011 = cljs.core.count.call(null,c__23723__auto___30008);
var G__30012 = (0);
seq__29914_29966 = G__30009;
chunk__29915_29967 = G__30010;
count__29916_29968 = G__30011;
i__29917_29969 = G__30012;
continue;
} else {
var vec__29927_30013 = cljs.core.first.call(null,seq__29914_30007__$1);
var column_30014 = cljs.core.nth.call(null,vec__29927_30013,(0),null);
var column_info_30015 = cljs.core.nth.call(null,vec__29927_30013,(1),null);
var seq__29928_30016 = cljs.core.seq.call(null,column_info_30015);
var chunk__29929_30017 = null;
var count__29930_30018 = (0);
var i__29931_30019 = (0);
while(true){
if((i__29931_30019 < count__29930_30018)){
var map__29932_30020 = cljs.core._nth.call(null,chunk__29929_30017,i__29931_30019);
var map__29932_30021__$1 = ((((!((map__29932_30020 == null)))?((((map__29932_30020.cljs$lang$protocol_mask$partition0$ & (64))) || (map__29932_30020.cljs$core$ISeq$))?true:false):false))?cljs.core.apply.call(null,cljs.core.hash_map,map__29932_30020):map__29932_30020);
var gline_30022 = cljs.core.get.call(null,map__29932_30021__$1,new cljs.core.Keyword(null,"gline","gline",-1086242431));
var gcol_30023 = cljs.core.get.call(null,map__29932_30021__$1,new cljs.core.Keyword(null,"gcol","gcol",309250807));
var name_30024 = cljs.core.get.call(null,map__29932_30021__$1,new cljs.core.Keyword(null,"name","name",1843675177));
cljs.core.swap_BANG_.call(null,inverted,cljs.core.update_in,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [gline_30022], null),cljs.core.fnil.call(null,((function (seq__29928_30016,chunk__29929_30017,count__29930_30018,i__29931_30019,seq__29914_29966,chunk__29915_29967,count__29916_29968,i__29917_29969,seq__29909_29959,chunk__29910_29960,count__29911_29961,i__29912_29962,map__29932_30020,map__29932_30021__$1,gline_30022,gcol_30023,name_30024,vec__29927_30013,column_30014,column_info_30015,seq__29914_30007__$1,temp__4657__auto___30006,vec__29913_29963,line_29964,columns_29965,inverted){
return (function (columns__$1){
return cljs.core.update_in.call(null,columns__$1,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [gcol_30023], null),cljs.core.fnil.call(null,cljs.core.conj,cljs.core.PersistentVector.EMPTY),new cljs.core.PersistentArrayMap(null, 3, [new cljs.core.Keyword(null,"line","line",212345235),line_29964,new cljs.core.Keyword(null,"col","col",-1959363084),column_30014,new cljs.core.Keyword(null,"name","name",1843675177),name_30024], null));
});})(seq__29928_30016,chunk__29929_30017,count__29930_30018,i__29931_30019,seq__29914_29966,chunk__29915_29967,count__29916_29968,i__29917_29969,seq__29909_29959,chunk__29910_29960,count__29911_29961,i__29912_29962,map__29932_30020,map__29932_30021__$1,gline_30022,gcol_30023,name_30024,vec__29927_30013,column_30014,column_info_30015,seq__29914_30007__$1,temp__4657__auto___30006,vec__29913_29963,line_29964,columns_29965,inverted))
,cljs.core.sorted_map.call(null)));

var G__30025 = seq__29928_30016;
var G__30026 = chunk__29929_30017;
var G__30027 = count__29930_30018;
var G__30028 = (i__29931_30019 + (1));
seq__29928_30016 = G__30025;
chunk__29929_30017 = G__30026;
count__29930_30018 = G__30027;
i__29931_30019 = G__30028;
continue;
} else {
var temp__4657__auto___30029__$1 = cljs.core.seq.call(null,seq__29928_30016);
if(temp__4657__auto___30029__$1){
var seq__29928_30030__$1 = temp__4657__auto___30029__$1;
if(cljs.core.chunked_seq_QMARK_.call(null,seq__29928_30030__$1)){
var c__23723__auto___30031 = cljs.core.chunk_first.call(null,seq__29928_30030__$1);
var G__30032 = cljs.core.chunk_rest.call(null,seq__29928_30030__$1);
var G__30033 = c__23723__auto___30031;
var G__30034 = cljs.core.count.call(null,c__23723__auto___30031);
var G__30035 = (0);
seq__29928_30016 = G__30032;
chunk__29929_30017 = G__30033;
count__29930_30018 = G__30034;
i__29931_30019 = G__30035;
continue;
} else {
var map__29934_30036 = cljs.core.first.call(null,seq__29928_30030__$1);
var map__29934_30037__$1 = ((((!((map__29934_30036 == null)))?((((map__29934_30036.cljs$lang$protocol_mask$partition0$ & (64))) || (map__29934_30036.cljs$core$ISeq$))?true:false):false))?cljs.core.apply.call(null,cljs.core.hash_map,map__29934_30036):map__29934_30036);
var gline_30038 = cljs.core.get.call(null,map__29934_30037__$1,new cljs.core.Keyword(null,"gline","gline",-1086242431));
var gcol_30039 = cljs.core.get.call(null,map__29934_30037__$1,new cljs.core.Keyword(null,"gcol","gcol",309250807));
var name_30040 = cljs.core.get.call(null,map__29934_30037__$1,new cljs.core.Keyword(null,"name","name",1843675177));
cljs.core.swap_BANG_.call(null,inverted,cljs.core.update_in,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [gline_30038], null),cljs.core.fnil.call(null,((function (seq__29928_30016,chunk__29929_30017,count__29930_30018,i__29931_30019,seq__29914_29966,chunk__29915_29967,count__29916_29968,i__29917_29969,seq__29909_29959,chunk__29910_29960,count__29911_29961,i__29912_29962,map__29934_30036,map__29934_30037__$1,gline_30038,gcol_30039,name_30040,seq__29928_30030__$1,temp__4657__auto___30029__$1,vec__29927_30013,column_30014,column_info_30015,seq__29914_30007__$1,temp__4657__auto___30006,vec__29913_29963,line_29964,columns_29965,inverted){
return (function (columns__$1){
return cljs.core.update_in.call(null,columns__$1,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [gcol_30039], null),cljs.core.fnil.call(null,cljs.core.conj,cljs.core.PersistentVector.EMPTY),new cljs.core.PersistentArrayMap(null, 3, [new cljs.core.Keyword(null,"line","line",212345235),line_29964,new cljs.core.Keyword(null,"col","col",-1959363084),column_30014,new cljs.core.Keyword(null,"name","name",1843675177),name_30040], null));
});})(seq__29928_30016,chunk__29929_30017,count__29930_30018,i__29931_30019,seq__29914_29966,chunk__29915_29967,count__29916_29968,i__29917_29969,seq__29909_29959,chunk__29910_29960,count__29911_29961,i__29912_29962,map__29934_30036,map__29934_30037__$1,gline_30038,gcol_30039,name_30040,seq__29928_30030__$1,temp__4657__auto___30029__$1,vec__29927_30013,column_30014,column_info_30015,seq__29914_30007__$1,temp__4657__auto___30006,vec__29913_29963,line_29964,columns_29965,inverted))
,cljs.core.sorted_map.call(null)));

var G__30041 = cljs.core.next.call(null,seq__29928_30030__$1);
var G__30042 = null;
var G__30043 = (0);
var G__30044 = (0);
seq__29928_30016 = G__30041;
chunk__29929_30017 = G__30042;
count__29930_30018 = G__30043;
i__29931_30019 = G__30044;
continue;
}
} else {
}
}
break;
}

var G__30045 = cljs.core.next.call(null,seq__29914_30007__$1);
var G__30046 = null;
var G__30047 = (0);
var G__30048 = (0);
seq__29914_29966 = G__30045;
chunk__29915_29967 = G__30046;
count__29916_29968 = G__30047;
i__29917_29969 = G__30048;
continue;
}
} else {
}
}
break;
}

var G__30049 = seq__29909_29959;
var G__30050 = chunk__29910_29960;
var G__30051 = count__29911_29961;
var G__30052 = (i__29912_29962 + (1));
seq__29909_29959 = G__30049;
chunk__29910_29960 = G__30050;
count__29911_29961 = G__30051;
i__29912_29962 = G__30052;
continue;
} else {
var temp__4657__auto___30053 = cljs.core.seq.call(null,seq__29909_29959);
if(temp__4657__auto___30053){
var seq__29909_30054__$1 = temp__4657__auto___30053;
if(cljs.core.chunked_seq_QMARK_.call(null,seq__29909_30054__$1)){
var c__23723__auto___30055 = cljs.core.chunk_first.call(null,seq__29909_30054__$1);
var G__30056 = cljs.core.chunk_rest.call(null,seq__29909_30054__$1);
var G__30057 = c__23723__auto___30055;
var G__30058 = cljs.core.count.call(null,c__23723__auto___30055);
var G__30059 = (0);
seq__29909_29959 = G__30056;
chunk__29910_29960 = G__30057;
count__29911_29961 = G__30058;
i__29912_29962 = G__30059;
continue;
} else {
var vec__29936_30060 = cljs.core.first.call(null,seq__29909_30054__$1);
var line_30061 = cljs.core.nth.call(null,vec__29936_30060,(0),null);
var columns_30062 = cljs.core.nth.call(null,vec__29936_30060,(1),null);
var seq__29937_30063 = cljs.core.seq.call(null,columns_30062);
var chunk__29938_30064 = null;
var count__29939_30065 = (0);
var i__29940_30066 = (0);
while(true){
if((i__29940_30066 < count__29939_30065)){
var vec__29941_30067 = cljs.core._nth.call(null,chunk__29938_30064,i__29940_30066);
var column_30068 = cljs.core.nth.call(null,vec__29941_30067,(0),null);
var column_info_30069 = cljs.core.nth.call(null,vec__29941_30067,(1),null);
var seq__29942_30070 = cljs.core.seq.call(null,column_info_30069);
var chunk__29943_30071 = null;
var count__29944_30072 = (0);
var i__29945_30073 = (0);
while(true){
if((i__29945_30073 < count__29944_30072)){
var map__29946_30074 = cljs.core._nth.call(null,chunk__29943_30071,i__29945_30073);
var map__29946_30075__$1 = ((((!((map__29946_30074 == null)))?((((map__29946_30074.cljs$lang$protocol_mask$partition0$ & (64))) || (map__29946_30074.cljs$core$ISeq$))?true:false):false))?cljs.core.apply.call(null,cljs.core.hash_map,map__29946_30074):map__29946_30074);
var gline_30076 = cljs.core.get.call(null,map__29946_30075__$1,new cljs.core.Keyword(null,"gline","gline",-1086242431));
var gcol_30077 = cljs.core.get.call(null,map__29946_30075__$1,new cljs.core.Keyword(null,"gcol","gcol",309250807));
var name_30078 = cljs.core.get.call(null,map__29946_30075__$1,new cljs.core.Keyword(null,"name","name",1843675177));
cljs.core.swap_BANG_.call(null,inverted,cljs.core.update_in,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [gline_30076], null),cljs.core.fnil.call(null,((function (seq__29942_30070,chunk__29943_30071,count__29944_30072,i__29945_30073,seq__29937_30063,chunk__29938_30064,count__29939_30065,i__29940_30066,seq__29909_29959,chunk__29910_29960,count__29911_29961,i__29912_29962,map__29946_30074,map__29946_30075__$1,gline_30076,gcol_30077,name_30078,vec__29941_30067,column_30068,column_info_30069,vec__29936_30060,line_30061,columns_30062,seq__29909_30054__$1,temp__4657__auto___30053,inverted){
return (function (columns__$1){
return cljs.core.update_in.call(null,columns__$1,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [gcol_30077], null),cljs.core.fnil.call(null,cljs.core.conj,cljs.core.PersistentVector.EMPTY),new cljs.core.PersistentArrayMap(null, 3, [new cljs.core.Keyword(null,"line","line",212345235),line_30061,new cljs.core.Keyword(null,"col","col",-1959363084),column_30068,new cljs.core.Keyword(null,"name","name",1843675177),name_30078], null));
});})(seq__29942_30070,chunk__29943_30071,count__29944_30072,i__29945_30073,seq__29937_30063,chunk__29938_30064,count__29939_30065,i__29940_30066,seq__29909_29959,chunk__29910_29960,count__29911_29961,i__29912_29962,map__29946_30074,map__29946_30075__$1,gline_30076,gcol_30077,name_30078,vec__29941_30067,column_30068,column_info_30069,vec__29936_30060,line_30061,columns_30062,seq__29909_30054__$1,temp__4657__auto___30053,inverted))
,cljs.core.sorted_map.call(null)));

var G__30079 = seq__29942_30070;
var G__30080 = chunk__29943_30071;
var G__30081 = count__29944_30072;
var G__30082 = (i__29945_30073 + (1));
seq__29942_30070 = G__30079;
chunk__29943_30071 = G__30080;
count__29944_30072 = G__30081;
i__29945_30073 = G__30082;
continue;
} else {
var temp__4657__auto___30083__$1 = cljs.core.seq.call(null,seq__29942_30070);
if(temp__4657__auto___30083__$1){
var seq__29942_30084__$1 = temp__4657__auto___30083__$1;
if(cljs.core.chunked_seq_QMARK_.call(null,seq__29942_30084__$1)){
var c__23723__auto___30085 = cljs.core.chunk_first.call(null,seq__29942_30084__$1);
var G__30086 = cljs.core.chunk_rest.call(null,seq__29942_30084__$1);
var G__30087 = c__23723__auto___30085;
var G__30088 = cljs.core.count.call(null,c__23723__auto___30085);
var G__30089 = (0);
seq__29942_30070 = G__30086;
chunk__29943_30071 = G__30087;
count__29944_30072 = G__30088;
i__29945_30073 = G__30089;
continue;
} else {
var map__29948_30090 = cljs.core.first.call(null,seq__29942_30084__$1);
var map__29948_30091__$1 = ((((!((map__29948_30090 == null)))?((((map__29948_30090.cljs$lang$protocol_mask$partition0$ & (64))) || (map__29948_30090.cljs$core$ISeq$))?true:false):false))?cljs.core.apply.call(null,cljs.core.hash_map,map__29948_30090):map__29948_30090);
var gline_30092 = cljs.core.get.call(null,map__29948_30091__$1,new cljs.core.Keyword(null,"gline","gline",-1086242431));
var gcol_30093 = cljs.core.get.call(null,map__29948_30091__$1,new cljs.core.Keyword(null,"gcol","gcol",309250807));
var name_30094 = cljs.core.get.call(null,map__29948_30091__$1,new cljs.core.Keyword(null,"name","name",1843675177));
cljs.core.swap_BANG_.call(null,inverted,cljs.core.update_in,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [gline_30092], null),cljs.core.fnil.call(null,((function (seq__29942_30070,chunk__29943_30071,count__29944_30072,i__29945_30073,seq__29937_30063,chunk__29938_30064,count__29939_30065,i__29940_30066,seq__29909_29959,chunk__29910_29960,count__29911_29961,i__29912_29962,map__29948_30090,map__29948_30091__$1,gline_30092,gcol_30093,name_30094,seq__29942_30084__$1,temp__4657__auto___30083__$1,vec__29941_30067,column_30068,column_info_30069,vec__29936_30060,line_30061,columns_30062,seq__29909_30054__$1,temp__4657__auto___30053,inverted){
return (function (columns__$1){
return cljs.core.update_in.call(null,columns__$1,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [gcol_30093], null),cljs.core.fnil.call(null,cljs.core.conj,cljs.core.PersistentVector.EMPTY),new cljs.core.PersistentArrayMap(null, 3, [new cljs.core.Keyword(null,"line","line",212345235),line_30061,new cljs.core.Keyword(null,"col","col",-1959363084),column_30068,new cljs.core.Keyword(null,"name","name",1843675177),name_30094], null));
});})(seq__29942_30070,chunk__29943_30071,count__29944_30072,i__29945_30073,seq__29937_30063,chunk__29938_30064,count__29939_30065,i__29940_30066,seq__29909_29959,chunk__29910_29960,count__29911_29961,i__29912_29962,map__29948_30090,map__29948_30091__$1,gline_30092,gcol_30093,name_30094,seq__29942_30084__$1,temp__4657__auto___30083__$1,vec__29941_30067,column_30068,column_info_30069,vec__29936_30060,line_30061,columns_30062,seq__29909_30054__$1,temp__4657__auto___30053,inverted))
,cljs.core.sorted_map.call(null)));

var G__30095 = cljs.core.next.call(null,seq__29942_30084__$1);
var G__30096 = null;
var G__30097 = (0);
var G__30098 = (0);
seq__29942_30070 = G__30095;
chunk__29943_30071 = G__30096;
count__29944_30072 = G__30097;
i__29945_30073 = G__30098;
continue;
}
} else {
}
}
break;
}

var G__30099 = seq__29937_30063;
var G__30100 = chunk__29938_30064;
var G__30101 = count__29939_30065;
var G__30102 = (i__29940_30066 + (1));
seq__29937_30063 = G__30099;
chunk__29938_30064 = G__30100;
count__29939_30065 = G__30101;
i__29940_30066 = G__30102;
continue;
} else {
var temp__4657__auto___30103__$1 = cljs.core.seq.call(null,seq__29937_30063);
if(temp__4657__auto___30103__$1){
var seq__29937_30104__$1 = temp__4657__auto___30103__$1;
if(cljs.core.chunked_seq_QMARK_.call(null,seq__29937_30104__$1)){
var c__23723__auto___30105 = cljs.core.chunk_first.call(null,seq__29937_30104__$1);
var G__30106 = cljs.core.chunk_rest.call(null,seq__29937_30104__$1);
var G__30107 = c__23723__auto___30105;
var G__30108 = cljs.core.count.call(null,c__23723__auto___30105);
var G__30109 = (0);
seq__29937_30063 = G__30106;
chunk__29938_30064 = G__30107;
count__29939_30065 = G__30108;
i__29940_30066 = G__30109;
continue;
} else {
var vec__29950_30110 = cljs.core.first.call(null,seq__29937_30104__$1);
var column_30111 = cljs.core.nth.call(null,vec__29950_30110,(0),null);
var column_info_30112 = cljs.core.nth.call(null,vec__29950_30110,(1),null);
var seq__29951_30113 = cljs.core.seq.call(null,column_info_30112);
var chunk__29952_30114 = null;
var count__29953_30115 = (0);
var i__29954_30116 = (0);
while(true){
if((i__29954_30116 < count__29953_30115)){
var map__29955_30117 = cljs.core._nth.call(null,chunk__29952_30114,i__29954_30116);
var map__29955_30118__$1 = ((((!((map__29955_30117 == null)))?((((map__29955_30117.cljs$lang$protocol_mask$partition0$ & (64))) || (map__29955_30117.cljs$core$ISeq$))?true:false):false))?cljs.core.apply.call(null,cljs.core.hash_map,map__29955_30117):map__29955_30117);
var gline_30119 = cljs.core.get.call(null,map__29955_30118__$1,new cljs.core.Keyword(null,"gline","gline",-1086242431));
var gcol_30120 = cljs.core.get.call(null,map__29955_30118__$1,new cljs.core.Keyword(null,"gcol","gcol",309250807));
var name_30121 = cljs.core.get.call(null,map__29955_30118__$1,new cljs.core.Keyword(null,"name","name",1843675177));
cljs.core.swap_BANG_.call(null,inverted,cljs.core.update_in,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [gline_30119], null),cljs.core.fnil.call(null,((function (seq__29951_30113,chunk__29952_30114,count__29953_30115,i__29954_30116,seq__29937_30063,chunk__29938_30064,count__29939_30065,i__29940_30066,seq__29909_29959,chunk__29910_29960,count__29911_29961,i__29912_29962,map__29955_30117,map__29955_30118__$1,gline_30119,gcol_30120,name_30121,vec__29950_30110,column_30111,column_info_30112,seq__29937_30104__$1,temp__4657__auto___30103__$1,vec__29936_30060,line_30061,columns_30062,seq__29909_30054__$1,temp__4657__auto___30053,inverted){
return (function (columns__$1){
return cljs.core.update_in.call(null,columns__$1,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [gcol_30120], null),cljs.core.fnil.call(null,cljs.core.conj,cljs.core.PersistentVector.EMPTY),new cljs.core.PersistentArrayMap(null, 3, [new cljs.core.Keyword(null,"line","line",212345235),line_30061,new cljs.core.Keyword(null,"col","col",-1959363084),column_30111,new cljs.core.Keyword(null,"name","name",1843675177),name_30121], null));
});})(seq__29951_30113,chunk__29952_30114,count__29953_30115,i__29954_30116,seq__29937_30063,chunk__29938_30064,count__29939_30065,i__29940_30066,seq__29909_29959,chunk__29910_29960,count__29911_29961,i__29912_29962,map__29955_30117,map__29955_30118__$1,gline_30119,gcol_30120,name_30121,vec__29950_30110,column_30111,column_info_30112,seq__29937_30104__$1,temp__4657__auto___30103__$1,vec__29936_30060,line_30061,columns_30062,seq__29909_30054__$1,temp__4657__auto___30053,inverted))
,cljs.core.sorted_map.call(null)));

var G__30122 = seq__29951_30113;
var G__30123 = chunk__29952_30114;
var G__30124 = count__29953_30115;
var G__30125 = (i__29954_30116 + (1));
seq__29951_30113 = G__30122;
chunk__29952_30114 = G__30123;
count__29953_30115 = G__30124;
i__29954_30116 = G__30125;
continue;
} else {
var temp__4657__auto___30126__$2 = cljs.core.seq.call(null,seq__29951_30113);
if(temp__4657__auto___30126__$2){
var seq__29951_30127__$1 = temp__4657__auto___30126__$2;
if(cljs.core.chunked_seq_QMARK_.call(null,seq__29951_30127__$1)){
var c__23723__auto___30128 = cljs.core.chunk_first.call(null,seq__29951_30127__$1);
var G__30129 = cljs.core.chunk_rest.call(null,seq__29951_30127__$1);
var G__30130 = c__23723__auto___30128;
var G__30131 = cljs.core.count.call(null,c__23723__auto___30128);
var G__30132 = (0);
seq__29951_30113 = G__30129;
chunk__29952_30114 = G__30130;
count__29953_30115 = G__30131;
i__29954_30116 = G__30132;
continue;
} else {
var map__29957_30133 = cljs.core.first.call(null,seq__29951_30127__$1);
var map__29957_30134__$1 = ((((!((map__29957_30133 == null)))?((((map__29957_30133.cljs$lang$protocol_mask$partition0$ & (64))) || (map__29957_30133.cljs$core$ISeq$))?true:false):false))?cljs.core.apply.call(null,cljs.core.hash_map,map__29957_30133):map__29957_30133);
var gline_30135 = cljs.core.get.call(null,map__29957_30134__$1,new cljs.core.Keyword(null,"gline","gline",-1086242431));
var gcol_30136 = cljs.core.get.call(null,map__29957_30134__$1,new cljs.core.Keyword(null,"gcol","gcol",309250807));
var name_30137 = cljs.core.get.call(null,map__29957_30134__$1,new cljs.core.Keyword(null,"name","name",1843675177));
cljs.core.swap_BANG_.call(null,inverted,cljs.core.update_in,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [gline_30135], null),cljs.core.fnil.call(null,((function (seq__29951_30113,chunk__29952_30114,count__29953_30115,i__29954_30116,seq__29937_30063,chunk__29938_30064,count__29939_30065,i__29940_30066,seq__29909_29959,chunk__29910_29960,count__29911_29961,i__29912_29962,map__29957_30133,map__29957_30134__$1,gline_30135,gcol_30136,name_30137,seq__29951_30127__$1,temp__4657__auto___30126__$2,vec__29950_30110,column_30111,column_info_30112,seq__29937_30104__$1,temp__4657__auto___30103__$1,vec__29936_30060,line_30061,columns_30062,seq__29909_30054__$1,temp__4657__auto___30053,inverted){
return (function (columns__$1){
return cljs.core.update_in.call(null,columns__$1,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [gcol_30136], null),cljs.core.fnil.call(null,cljs.core.conj,cljs.core.PersistentVector.EMPTY),new cljs.core.PersistentArrayMap(null, 3, [new cljs.core.Keyword(null,"line","line",212345235),line_30061,new cljs.core.Keyword(null,"col","col",-1959363084),column_30111,new cljs.core.Keyword(null,"name","name",1843675177),name_30137], null));
});})(seq__29951_30113,chunk__29952_30114,count__29953_30115,i__29954_30116,seq__29937_30063,chunk__29938_30064,count__29939_30065,i__29940_30066,seq__29909_29959,chunk__29910_29960,count__29911_29961,i__29912_29962,map__29957_30133,map__29957_30134__$1,gline_30135,gcol_30136,name_30137,seq__29951_30127__$1,temp__4657__auto___30126__$2,vec__29950_30110,column_30111,column_info_30112,seq__29937_30104__$1,temp__4657__auto___30103__$1,vec__29936_30060,line_30061,columns_30062,seq__29909_30054__$1,temp__4657__auto___30053,inverted))
,cljs.core.sorted_map.call(null)));

var G__30138 = cljs.core.next.call(null,seq__29951_30127__$1);
var G__30139 = null;
var G__30140 = (0);
var G__30141 = (0);
seq__29951_30113 = G__30138;
chunk__29952_30114 = G__30139;
count__29953_30115 = G__30140;
i__29954_30116 = G__30141;
continue;
}
} else {
}
}
break;
}

var G__30142 = cljs.core.next.call(null,seq__29937_30104__$1);
var G__30143 = null;
var G__30144 = (0);
var G__30145 = (0);
seq__29937_30063 = G__30142;
chunk__29938_30064 = G__30143;
count__29939_30065 = G__30144;
i__29940_30066 = G__30145;
continue;
}
} else {
}
}
break;
}

var G__30146 = cljs.core.next.call(null,seq__29909_30054__$1);
var G__30147 = null;
var G__30148 = (0);
var G__30149 = (0);
seq__29909_29959 = G__30146;
chunk__29910_29960 = G__30147;
count__29911_29961 = G__30148;
i__29912_29962 = G__30149;
continue;
}
} else {
}
}
break;
}

return cljs.core.deref.call(null,inverted);
});

//# sourceMappingURL=source_map.js.map