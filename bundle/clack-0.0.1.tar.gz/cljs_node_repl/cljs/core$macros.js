// Compiled by ClojureScript 1.8.51 {:target :nodejs}
goog.provide('cljs.core$macros');
goog.require('cljs.core');
goog.require('cljs.compiler');
goog.require('cljs.core');
goog.require('cljs.env');
goog.require('cljs.analyzer');
goog.require('clojure.set');
goog.require('clojure.string');
goog.require('clojure.walk');
/**
 * Threads the expr through the forms. Inserts x as the
 *   second item in the first form, making a list of it if it is not a
 *   list already. If there are more forms, inserts the first form as the
 *   second item in second form, etc.
 */
cljs.core$macros.__GT_ = (function cljs$core$macros$__GT_(var_args){
var args__23989__auto__ = [];
var len__23982__auto___28224 = arguments.length;
var i__23983__auto___28225 = (0);
while(true){
if((i__23983__auto___28225 < len__23982__auto___28224)){
args__23989__auto__.push((arguments[i__23983__auto___28225]));

var G__28226 = (i__23983__auto___28225 + (1));
i__23983__auto___28225 = G__28226;
continue;
} else {
}
break;
}

var argseq__23990__auto__ = ((((3) < args__23989__auto__.length))?(new cljs.core.IndexedSeq(args__23989__auto__.slice((3)),(0),null)):null);
return cljs.core$macros.__GT_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),argseq__23990__auto__);
});

cljs.core$macros.__GT_.cljs$core$IFn$_invoke$arity$variadic = (function (_AMPERSAND_form,_AMPERSAND_env,x,forms){
var x__$1 = x;
var forms__$1 = forms;
while(true){
if(cljs.core.truth_(forms__$1)){
var form = cljs.core.first.call(null,forms__$1);
var threaded = ((cljs.core.seq_QMARK_.call(null,form))?cljs.core.with_meta.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,(function (){var x__23746__auto__ = cljs.core.first.call(null,form);
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = x__$1;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),cljs.core.next.call(null,form)))),cljs.core.meta.call(null,form)):(function (){var x__23746__auto__ = form;
return cljs.core._conj.call(null,(function (){var x__23746__auto____$1 = x__$1;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto____$1);
})(),x__23746__auto__);
})());
var G__28227 = threaded;
var G__28228 = cljs.core.next.call(null,forms__$1);
x__$1 = G__28227;
forms__$1 = G__28228;
continue;
} else {
return x__$1;
}
break;
}
});

cljs.core$macros.__GT_.cljs$lang$maxFixedArity = (3);

cljs.core$macros.__GT_.cljs$lang$applyTo = (function (seq28220){
var G__28221 = cljs.core.first.call(null,seq28220);
var seq28220__$1 = cljs.core.next.call(null,seq28220);
var G__28222 = cljs.core.first.call(null,seq28220__$1);
var seq28220__$2 = cljs.core.next.call(null,seq28220__$1);
var G__28223 = cljs.core.first.call(null,seq28220__$2);
var seq28220__$3 = cljs.core.next.call(null,seq28220__$2);
return cljs.core$macros.__GT_.cljs$core$IFn$_invoke$arity$variadic(G__28221,G__28222,G__28223,seq28220__$3);
});

cljs.core$macros.__GT_.cljs$lang$macro = true;
/**
 * Threads the expr through the forms. Inserts x as the
 *   last item in the first form, making a list of it if it is not a
 *   list already. If there are more forms, inserts the first form as the
 *   last item in second form, etc.
 */
cljs.core$macros.__GT__GT_ = (function cljs$core$macros$__GT__GT_(var_args){
var args__23989__auto__ = [];
var len__23982__auto___28233 = arguments.length;
var i__23983__auto___28234 = (0);
while(true){
if((i__23983__auto___28234 < len__23982__auto___28233)){
args__23989__auto__.push((arguments[i__23983__auto___28234]));

var G__28235 = (i__23983__auto___28234 + (1));
i__23983__auto___28234 = G__28235;
continue;
} else {
}
break;
}

var argseq__23990__auto__ = ((((3) < args__23989__auto__.length))?(new cljs.core.IndexedSeq(args__23989__auto__.slice((3)),(0),null)):null);
return cljs.core$macros.__GT__GT_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),argseq__23990__auto__);
});

cljs.core$macros.__GT__GT_.cljs$core$IFn$_invoke$arity$variadic = (function (_AMPERSAND_form,_AMPERSAND_env,x,forms){
var x__$1 = x;
var forms__$1 = forms;
while(true){
if(cljs.core.truth_(forms__$1)){
var form = cljs.core.first.call(null,forms__$1);
var threaded = ((cljs.core.seq_QMARK_.call(null,form))?cljs.core.with_meta.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,(function (){var x__23746__auto__ = cljs.core.first.call(null,form);
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),cljs.core.next.call(null,form),(function (){var x__23746__auto__ = x__$1;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})()))),cljs.core.meta.call(null,form)):(function (){var x__23746__auto__ = form;
return cljs.core._conj.call(null,(function (){var x__23746__auto____$1 = x__$1;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto____$1);
})(),x__23746__auto__);
})());
var G__28236 = threaded;
var G__28237 = cljs.core.next.call(null,forms__$1);
x__$1 = G__28236;
forms__$1 = G__28237;
continue;
} else {
return x__$1;
}
break;
}
});

cljs.core$macros.__GT__GT_.cljs$lang$maxFixedArity = (3);

cljs.core$macros.__GT__GT_.cljs$lang$applyTo = (function (seq28229){
var G__28230 = cljs.core.first.call(null,seq28229);
var seq28229__$1 = cljs.core.next.call(null,seq28229);
var G__28231 = cljs.core.first.call(null,seq28229__$1);
var seq28229__$2 = cljs.core.next.call(null,seq28229__$1);
var G__28232 = cljs.core.first.call(null,seq28229__$2);
var seq28229__$3 = cljs.core.next.call(null,seq28229__$2);
return cljs.core$macros.__GT__GT_.cljs$core$IFn$_invoke$arity$variadic(G__28230,G__28231,G__28232,seq28229__$3);
});

cljs.core$macros.__GT__GT_.cljs$lang$macro = true;
/**
 * form => fieldName-symbol or (instanceMethodName-symbol args*)
 * 
 *   Expands into a member access (.) of the first member on the first
 *   argument, followed by the next member on the result, etc. For
 *   instance:
 * 
 *   (.. System (getProperties) (get "os.name"))
 * 
 *   expands to:
 * 
 *   (. (. System (getProperties)) (get "os.name"))
 * 
 *   but is easier to write, read, and understand.
 */
cljs.core$macros._DOT__DOT_ = (function cljs$core$macros$_DOT__DOT_(var_args){
var args28238 = [];
var len__23982__auto___28246 = arguments.length;
var i__23983__auto___28247 = (0);
while(true){
if((i__23983__auto___28247 < len__23982__auto___28246)){
args28238.push((arguments[i__23983__auto___28247]));

var G__28248 = (i__23983__auto___28247 + (1));
i__23983__auto___28247 = G__28248;
continue;
} else {
}
break;
}

var G__28245 = args28238.length;
switch (G__28245) {
case 4:
return cljs.core$macros._DOT__DOT_.cljs$core$IFn$_invoke$arity$4((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]));

break;
default:
var argseq__24001__auto__ = (new cljs.core.IndexedSeq(args28238.slice((4)),(0),null));
return cljs.core$macros._DOT__DOT_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]),argseq__24001__auto__);

}
});

cljs.core$macros._DOT__DOT_.cljs$core$IFn$_invoke$arity$4 = (function (_AMPERSAND_form,_AMPERSAND_env,x,form){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,".",".",1975675962,null)),(function (){var x__23746__auto__ = x;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = form;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
});

cljs.core$macros._DOT__DOT_.cljs$core$IFn$_invoke$arity$variadic = (function (_AMPERSAND_form,_AMPERSAND_env,x,form,more){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"..","..",-300507420,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,".",".",1975675962,null)),(function (){var x__23746__auto__ = x;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = form;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),more)));
});

cljs.core$macros._DOT__DOT_.cljs$lang$applyTo = (function (seq28239){
var G__28240 = cljs.core.first.call(null,seq28239);
var seq28239__$1 = cljs.core.next.call(null,seq28239);
var G__28241 = cljs.core.first.call(null,seq28239__$1);
var seq28239__$2 = cljs.core.next.call(null,seq28239__$1);
var G__28242 = cljs.core.first.call(null,seq28239__$2);
var seq28239__$3 = cljs.core.next.call(null,seq28239__$2);
var G__28243 = cljs.core.first.call(null,seq28239__$3);
var seq28239__$4 = cljs.core.next.call(null,seq28239__$3);
return cljs.core$macros._DOT__DOT_.cljs$core$IFn$_invoke$arity$variadic(G__28240,G__28241,G__28242,G__28243,seq28239__$4);
});

cljs.core$macros._DOT__DOT_.cljs$lang$maxFixedArity = (4);

cljs.core$macros._DOT__DOT_.cljs$lang$macro = true;
/**
 * Ignores body, yields nil
 */
cljs.core$macros.comment = (function cljs$core$macros$comment(var_args){
var args__23989__auto__ = [];
var len__23982__auto___28253 = arguments.length;
var i__23983__auto___28254 = (0);
while(true){
if((i__23983__auto___28254 < len__23982__auto___28253)){
args__23989__auto__.push((arguments[i__23983__auto___28254]));

var G__28255 = (i__23983__auto___28254 + (1));
i__23983__auto___28254 = G__28255;
continue;
} else {
}
break;
}

var argseq__23990__auto__ = ((((2) < args__23989__auto__.length))?(new cljs.core.IndexedSeq(args__23989__auto__.slice((2)),(0),null)):null);
return cljs.core$macros.comment.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__23990__auto__);
});

cljs.core$macros.comment.cljs$core$IFn$_invoke$arity$variadic = (function (_AMPERSAND_form,_AMPERSAND_env,body){
return null;
});

cljs.core$macros.comment.cljs$lang$maxFixedArity = (2);

cljs.core$macros.comment.cljs$lang$applyTo = (function (seq28250){
var G__28251 = cljs.core.first.call(null,seq28250);
var seq28250__$1 = cljs.core.next.call(null,seq28250);
var G__28252 = cljs.core.first.call(null,seq28250__$1);
var seq28250__$2 = cljs.core.next.call(null,seq28250__$1);
return cljs.core$macros.comment.cljs$core$IFn$_invoke$arity$variadic(G__28251,G__28252,seq28250__$2);
});

cljs.core$macros.comment.cljs$lang$macro = true;
/**
 * Takes a set of test/expr pairs. It evaluates each test one at a
 *   time.  If a test returns logical true, cond evaluates and returns
 *   the value of the corresponding expr and doesn't evaluate any of the
 *   other tests or exprs. (cond) returns nil.
 */
cljs.core$macros.cond = (function cljs$core$macros$cond(var_args){
var args__23989__auto__ = [];
var len__23982__auto___28259 = arguments.length;
var i__23983__auto___28260 = (0);
while(true){
if((i__23983__auto___28260 < len__23982__auto___28259)){
args__23989__auto__.push((arguments[i__23983__auto___28260]));

var G__28261 = (i__23983__auto___28260 + (1));
i__23983__auto___28260 = G__28261;
continue;
} else {
}
break;
}

var argseq__23990__auto__ = ((((2) < args__23989__auto__.length))?(new cljs.core.IndexedSeq(args__23989__auto__.slice((2)),(0),null)):null);
return cljs.core$macros.cond.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__23990__auto__);
});

cljs.core$macros.cond.cljs$core$IFn$_invoke$arity$variadic = (function (_AMPERSAND_form,_AMPERSAND_env,clauses){
if(cljs.core.truth_(clauses)){
return cljs.core._conj.call(null,(function (){var x__23746__auto__ = cljs.core.first.call(null,clauses);
return cljs.core._conj.call(null,(function (){var x__23746__auto____$1 = ((cljs.core.next.call(null,clauses))?cljs.core.second.call(null,clauses):(function(){throw (new Error("cond requires an even number of forms"))})());
return cljs.core._conj.call(null,(function (){var x__23746__auto____$2 = cljs.core.cons.call(null,new cljs.core.Symbol("cljs.core","cond","cljs.core/cond",2005388338,null),cljs.core.next.call(null,cljs.core.next.call(null,clauses)));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto____$2);
})(),x__23746__auto____$1);
})(),x__23746__auto__);
})(),new cljs.core.Symbol(null,"if","if",1181717262,null));
} else {
return null;
}
});

cljs.core$macros.cond.cljs$lang$maxFixedArity = (2);

cljs.core$macros.cond.cljs$lang$applyTo = (function (seq28256){
var G__28257 = cljs.core.first.call(null,seq28256);
var seq28256__$1 = cljs.core.next.call(null,seq28256);
var G__28258 = cljs.core.first.call(null,seq28256__$1);
var seq28256__$2 = cljs.core.next.call(null,seq28256__$1);
return cljs.core$macros.cond.cljs$core$IFn$_invoke$arity$variadic(G__28257,G__28258,seq28256__$2);
});

cljs.core$macros.cond.cljs$lang$macro = true;
/**
 * defs the supplied var names with no bindings, useful for making forward declarations.
 */
cljs.core$macros.declare = (function cljs$core$macros$declare(var_args){
var args__23989__auto__ = [];
var len__23982__auto___28266 = arguments.length;
var i__23983__auto___28267 = (0);
while(true){
if((i__23983__auto___28267 < len__23982__auto___28266)){
args__23989__auto__.push((arguments[i__23983__auto___28267]));

var G__28268 = (i__23983__auto___28267 + (1));
i__23983__auto___28267 = G__28268;
continue;
} else {
}
break;
}

var argseq__23990__auto__ = ((((2) < args__23989__auto__.length))?(new cljs.core.IndexedSeq(args__23989__auto__.slice((2)),(0),null)):null);
return cljs.core$macros.declare.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__23990__auto__);
});

cljs.core$macros.declare.cljs$core$IFn$_invoke$arity$variadic = (function (_AMPERSAND_form,_AMPERSAND_env,names){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"do","do",1686842252,null)),cljs.core.map.call(null,(function (p1__28262_SHARP_){
return cljs.core._conj.call(null,(function (){var x__23746__auto__ = cljs.core.vary_meta.call(null,p1__28262_SHARP_,cljs.core.assoc,new cljs.core.Keyword(null,"declared","declared",92336021),true);
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),new cljs.core.Symbol(null,"def","def",597100991,null));
}),names))));
});

cljs.core$macros.declare.cljs$lang$maxFixedArity = (2);

cljs.core$macros.declare.cljs$lang$applyTo = (function (seq28263){
var G__28264 = cljs.core.first.call(null,seq28263);
var seq28263__$1 = cljs.core.next.call(null,seq28263);
var G__28265 = cljs.core.first.call(null,seq28263__$1);
var seq28263__$2 = cljs.core.next.call(null,seq28263__$1);
return cljs.core$macros.declare.cljs$core$IFn$_invoke$arity$variadic(G__28264,G__28265,seq28263__$2);
});

cljs.core$macros.declare.cljs$lang$macro = true;
/**
 * Evaluates x then calls all of the methods and functions with the
 *   value of x supplied at the front of the given arguments.  The forms
 *   are evaluated in order.  Returns x.
 * 
 *   (doto (new java.util.HashMap) (.put "a" 1) (.put "b" 2))
 */
cljs.core$macros.doto = (function cljs$core$macros$doto(var_args){
var args__23989__auto__ = [];
var len__23982__auto___28273 = arguments.length;
var i__23983__auto___28274 = (0);
while(true){
if((i__23983__auto___28274 < len__23982__auto___28273)){
args__23989__auto__.push((arguments[i__23983__auto___28274]));

var G__28275 = (i__23983__auto___28274 + (1));
i__23983__auto___28274 = G__28275;
continue;
} else {
}
break;
}

var argseq__23990__auto__ = ((((3) < args__23989__auto__.length))?(new cljs.core.IndexedSeq(args__23989__auto__.slice((3)),(0),null)):null);
return cljs.core$macros.doto.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),argseq__23990__auto__);
});

cljs.core$macros.doto.cljs$core$IFn$_invoke$arity$variadic = (function (_AMPERSAND_form,_AMPERSAND_env,x,forms){
var gx = cljs.core.gensym.call(null);
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","let","cljs.core$macros/let",-160286726,null)),(function (){var x__23746__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,(function (){var x__23746__auto__ = gx;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = x;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})()))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),cljs.core.map.call(null,((function (gx){
return (function (f){
if(cljs.core.seq_QMARK_.call(null,f)){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,(function (){var x__23746__auto__ = cljs.core.first.call(null,f);
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = gx;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),cljs.core.next.call(null,f))));
} else {
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,(function (){var x__23746__auto__ = f;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = gx;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
}
});})(gx))
,forms),(function (){var x__23746__auto__ = gx;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
});

cljs.core$macros.doto.cljs$lang$maxFixedArity = (3);

cljs.core$macros.doto.cljs$lang$applyTo = (function (seq28269){
var G__28270 = cljs.core.first.call(null,seq28269);
var seq28269__$1 = cljs.core.next.call(null,seq28269);
var G__28271 = cljs.core.first.call(null,seq28269__$1);
var seq28269__$2 = cljs.core.next.call(null,seq28269__$1);
var G__28272 = cljs.core.first.call(null,seq28269__$2);
var seq28269__$3 = cljs.core.next.call(null,seq28269__$2);
return cljs.core$macros.doto.cljs$core$IFn$_invoke$arity$variadic(G__28270,G__28271,G__28272,seq28269__$3);
});

cljs.core$macros.doto.cljs$lang$macro = true;
cljs.core$macros.parse_impls = (function cljs$core$macros$parse_impls(specs){
var ret = cljs.core.PersistentArrayMap.EMPTY;
var s = specs;
while(true){
if(cljs.core.seq.call(null,s)){
var G__28276 = cljs.core.assoc.call(null,ret,cljs.core.first.call(null,s),cljs.core.take_while.call(null,cljs.core.seq_QMARK_,cljs.core.next.call(null,s)));
var G__28277 = cljs.core.drop_while.call(null,cljs.core.seq_QMARK_,cljs.core.next.call(null,s));
ret = G__28276;
s = G__28277;
continue;
} else {
return ret;
}
break;
}
});
cljs.core$macros.emit_extend_protocol = (function cljs$core$macros$emit_extend_protocol(p,specs){
var impls = cljs.core$macros.parse_impls.call(null,specs);
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"do","do",1686842252,null)),cljs.core.map.call(null,((function (impls){
return (function (p__28280){
var vec__28281 = p__28280;
var t = cljs.core.nth.call(null,vec__28281,(0),null);
var fs = cljs.core.nth.call(null,vec__28281,(1),null);
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","extend-type","cljs.core$macros/extend-type",1713295201,null)),(function (){var x__23746__auto__ = t;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = p;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),fs)));
});})(impls))
,impls))));
});
/**
 * Useful when you want to provide several implementations of the same
 *   protocol all at once. Takes a single protocol and the implementation
 *   of that protocol for one or more types. Expands into calls to
 *   extend-type:
 * 
 *   (extend-protocol Protocol
 *     AType
 *       (foo [x] ...)
 *       (bar [x y] ...)
 *     BType
 *       (foo [x] ...)
 *       (bar [x y] ...)
 *     AClass
 *       (foo [x] ...)
 *       (bar [x y] ...)
 *     nil
 *       (foo [x] ...)
 *       (bar [x y] ...))
 * 
 *   expands into:
 * 
 *   (do
 *    (clojure.core/extend-type AType Protocol
 *      (foo [x] ...)
 *      (bar [x y] ...))
 *    (clojure.core/extend-type BType Protocol
 *      (foo [x] ...)
 *      (bar [x y] ...))
 *    (clojure.core/extend-type AClass Protocol
 *      (foo [x] ...)
 *      (bar [x y] ...))
 *    (clojure.core/extend-type nil Protocol
 *      (foo [x] ...)
 *      (bar [x y] ...)))
 */
cljs.core$macros.extend_protocol = (function cljs$core$macros$extend_protocol(var_args){
var args__23989__auto__ = [];
var len__23982__auto___28286 = arguments.length;
var i__23983__auto___28287 = (0);
while(true){
if((i__23983__auto___28287 < len__23982__auto___28286)){
args__23989__auto__.push((arguments[i__23983__auto___28287]));

var G__28288 = (i__23983__auto___28287 + (1));
i__23983__auto___28287 = G__28288;
continue;
} else {
}
break;
}

var argseq__23990__auto__ = ((((3) < args__23989__auto__.length))?(new cljs.core.IndexedSeq(args__23989__auto__.slice((3)),(0),null)):null);
return cljs.core$macros.extend_protocol.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),argseq__23990__auto__);
});

cljs.core$macros.extend_protocol.cljs$core$IFn$_invoke$arity$variadic = (function (_AMPERSAND_form,_AMPERSAND_env,p,specs){
return cljs.core$macros.emit_extend_protocol.call(null,p,specs);
});

cljs.core$macros.extend_protocol.cljs$lang$maxFixedArity = (3);

cljs.core$macros.extend_protocol.cljs$lang$applyTo = (function (seq28282){
var G__28283 = cljs.core.first.call(null,seq28282);
var seq28282__$1 = cljs.core.next.call(null,seq28282);
var G__28284 = cljs.core.first.call(null,seq28282__$1);
var seq28282__$2 = cljs.core.next.call(null,seq28282__$1);
var G__28285 = cljs.core.first.call(null,seq28282__$2);
var seq28282__$3 = cljs.core.next.call(null,seq28282__$2);
return cljs.core$macros.extend_protocol.cljs$core$IFn$_invoke$arity$variadic(G__28283,G__28284,G__28285,seq28282__$3);
});

cljs.core$macros.extend_protocol.cljs$lang$macro = true;
cljs.core$macros.maybe_destructured = (function cljs$core$macros$maybe_destructured(params,body){
if(cljs.core.every_QMARK_.call(null,cljs.core.symbol_QMARK_,params)){
return cljs.core.cons.call(null,params,body);
} else {
var params__$1 = params;
var new_params = cljs.core.with_meta.call(null,cljs.core.PersistentVector.EMPTY,cljs.core.meta.call(null,params__$1));
var lets = cljs.core.PersistentVector.EMPTY;
while(true){
if(cljs.core.truth_(params__$1)){
if((cljs.core.first.call(null,params__$1) instanceof cljs.core.Symbol)){
var G__28289 = cljs.core.next.call(null,params__$1);
var G__28290 = cljs.core.conj.call(null,new_params,cljs.core.first.call(null,params__$1));
var G__28291 = lets;
params__$1 = G__28289;
new_params = G__28290;
lets = G__28291;
continue;
} else {
var gparam = cljs.core.gensym.call(null,"p__");
var G__28292 = cljs.core.next.call(null,params__$1);
var G__28293 = cljs.core.conj.call(null,new_params,gparam);
var G__28294 = cljs.core.conj.call(null,cljs.core.conj.call(null,lets,cljs.core.first.call(null,params__$1)),gparam);
params__$1 = G__28292;
new_params = G__28293;
lets = G__28294;
continue;
}
} else {
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,(function (){var x__23746__auto__ = new_params;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","let","cljs.core$macros/let",-160286726,null)),(function (){var x__23746__auto__ = lets;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),body)));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
}
break;
}
}
});
/**
 * params => positional-params* , or positional-params* & next-param
 *   positional-param => binding-form
 *   next-param => binding-form
 *   name => symbol
 * 
 *   Defines a function
 */
cljs.core$macros.fn = (function cljs$core$macros$fn(var_args){
var args__23989__auto__ = [];
var len__23982__auto___28299 = arguments.length;
var i__23983__auto___28300 = (0);
while(true){
if((i__23983__auto___28300 < len__23982__auto___28299)){
args__23989__auto__.push((arguments[i__23983__auto___28300]));

var G__28301 = (i__23983__auto___28300 + (1));
i__23983__auto___28300 = G__28301;
continue;
} else {
}
break;
}

var argseq__23990__auto__ = ((((2) < args__23989__auto__.length))?(new cljs.core.IndexedSeq(args__23989__auto__.slice((2)),(0),null)):null);
return cljs.core$macros.fn.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__23990__auto__);
});

cljs.core$macros.fn.cljs$core$IFn$_invoke$arity$variadic = (function (_AMPERSAND_form,_AMPERSAND_env,sigs){
var name = (((cljs.core.first.call(null,sigs) instanceof cljs.core.Symbol))?cljs.core.first.call(null,sigs):null);
var sigs__$1 = (cljs.core.truth_(name)?cljs.core.next.call(null,sigs):sigs);
var sigs__$2 = ((cljs.core.vector_QMARK_.call(null,cljs.core.first.call(null,sigs__$1)))?(function (){var x__23746__auto__ = sigs__$1;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})():((cljs.core.seq_QMARK_.call(null,cljs.core.first.call(null,sigs__$1)))?sigs__$1:(function(){throw (new Error(((cljs.core.seq.call(null,sigs__$1))?[cljs.core.str("Parameter declaration "),cljs.core.str(cljs.core.first.call(null,sigs__$1)),cljs.core.str(" should be a vector")].join(''):[cljs.core.str("Parameter declaration missing")].join(''))))})()));
var psig = ((function (name,sigs__$1,sigs__$2){
return (function (sig){
if(!(cljs.core.seq_QMARK_.call(null,sig))){
throw (new Error([cljs.core.str("Invalid signature "),cljs.core.str(sig),cljs.core.str(" should be a list")].join('')));
} else {
}

var vec__28298 = sig;
var params = cljs.core.nth.call(null,vec__28298,(0),null);
var body = cljs.core.nthnext.call(null,vec__28298,(1));
var _ = ((!(cljs.core.vector_QMARK_.call(null,params)))?(function(){throw (new Error(((cljs.core.seq_QMARK_.call(null,cljs.core.first.call(null,sigs__$2)))?[cljs.core.str("Parameter declaration "),cljs.core.str(params),cljs.core.str(" should be a vector")].join(''):[cljs.core.str("Invalid signature "),cljs.core.str(sig),cljs.core.str(" should be a list")].join(''))))})():null);
var conds = (((cljs.core.next.call(null,body)) && (cljs.core.map_QMARK_.call(null,cljs.core.first.call(null,body))))?cljs.core.first.call(null,body):null);
var body__$1 = (cljs.core.truth_(conds)?cljs.core.next.call(null,body):body);
var conds__$1 = (function (){var or__22912__auto__ = conds;
if(cljs.core.truth_(or__22912__auto__)){
return or__22912__auto__;
} else {
return cljs.core.meta.call(null,params);
}
})();
var pre = new cljs.core.Keyword(null,"pre","pre",2118456869).cljs$core$IFn$_invoke$arity$1(conds__$1);
var post = new cljs.core.Keyword(null,"post","post",269697687).cljs$core$IFn$_invoke$arity$1(conds__$1);
var body__$2 = (cljs.core.truth_(post)?cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","let","cljs.core$macros/let",-160286726,null)),(function (){var x__23746__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"%","%",-950237169,null)),(function (){var x__23746__auto__ = ((((1) < cljs.core.count.call(null,body__$1)))?cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"do","do",1686842252,null)),body__$1))):cljs.core.first.call(null,body__$1));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})()))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),cljs.core.map.call(null,((function (vec__28298,params,body,_,conds,body__$1,conds__$1,pre,post,name,sigs__$1,sigs__$2){
return (function (c){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","assert","cljs.core$macros/assert",1333198789,null)),(function (){var x__23746__auto__ = c;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
});})(vec__28298,params,body,_,conds,body__$1,conds__$1,pre,post,name,sigs__$1,sigs__$2))
,post),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"%","%",-950237169,null)))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})()))):body__$1);
var body__$3 = (cljs.core.truth_(pre)?cljs.core.concat.call(null,cljs.core.map.call(null,((function (vec__28298,params,body,_,conds,body__$1,conds__$1,pre,post,body__$2,name,sigs__$1,sigs__$2){
return (function (c){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","assert","cljs.core$macros/assert",1333198789,null)),(function (){var x__23746__auto__ = c;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
});})(vec__28298,params,body,_,conds,body__$1,conds__$1,pre,post,body__$2,name,sigs__$1,sigs__$2))
,pre),body__$2):body__$2);
return cljs.core$macros.maybe_destructured.call(null,params,body__$3);
});})(name,sigs__$1,sigs__$2))
;
var new_sigs = cljs.core.map.call(null,psig,sigs__$2);
return cljs.core.with_meta.call(null,(cljs.core.truth_(name)?cljs.core.list_STAR_.call(null,new cljs.core.Symbol(null,"fn*","fn*",-752876845,null),name,new_sigs):cljs.core.cons.call(null,new cljs.core.Symbol(null,"fn*","fn*",-752876845,null),new_sigs)),cljs.core.meta.call(null,_AMPERSAND_form));
});

cljs.core$macros.fn.cljs$lang$maxFixedArity = (2);

cljs.core$macros.fn.cljs$lang$applyTo = (function (seq28295){
var G__28296 = cljs.core.first.call(null,seq28295);
var seq28295__$1 = cljs.core.next.call(null,seq28295);
var G__28297 = cljs.core.first.call(null,seq28295__$1);
var seq28295__$2 = cljs.core.next.call(null,seq28295__$1);
return cljs.core$macros.fn.cljs$core$IFn$_invoke$arity$variadic(G__28296,G__28297,seq28295__$2);
});

cljs.core$macros.fn.cljs$lang$macro = true;
/**
 * same as defn, yielding non-public def
 */
cljs.core$macros.defn_ = (function cljs$core$macros$defn_(var_args){
var args__23989__auto__ = [];
var len__23982__auto___28306 = arguments.length;
var i__23983__auto___28307 = (0);
while(true){
if((i__23983__auto___28307 < len__23982__auto___28306)){
args__23989__auto__.push((arguments[i__23983__auto___28307]));

var G__28308 = (i__23983__auto___28307 + (1));
i__23983__auto___28307 = G__28308;
continue;
} else {
}
break;
}

var argseq__23990__auto__ = ((((3) < args__23989__auto__.length))?(new cljs.core.IndexedSeq(args__23989__auto__.slice((3)),(0),null)):null);
return cljs.core$macros.defn_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),argseq__23990__auto__);
});

cljs.core$macros.defn_.cljs$core$IFn$_invoke$arity$variadic = (function (_AMPERSAND_form,_AMPERSAND_env,name,decls){
return cljs.core.list_STAR_.call(null,new cljs.core.Symbol("cljs.core$macros","defn","cljs.core$macros/defn",-728332354,null),cljs.core.with_meta.call(null,name,cljs.core.assoc.call(null,cljs.core.meta.call(null,name),new cljs.core.Keyword(null,"private","private",-558947994),true)),decls);
});

cljs.core$macros.defn_.cljs$lang$maxFixedArity = (3);

cljs.core$macros.defn_.cljs$lang$applyTo = (function (seq28302){
var G__28303 = cljs.core.first.call(null,seq28302);
var seq28302__$1 = cljs.core.next.call(null,seq28302);
var G__28304 = cljs.core.first.call(null,seq28302__$1);
var seq28302__$2 = cljs.core.next.call(null,seq28302__$1);
var G__28305 = cljs.core.first.call(null,seq28302__$2);
var seq28302__$3 = cljs.core.next.call(null,seq28302__$2);
return cljs.core$macros.defn_.cljs$core$IFn$_invoke$arity$variadic(G__28303,G__28304,G__28305,seq28302__$3);
});

cljs.core$macros.defn_.cljs$lang$macro = true;
/**
 * bindings => binding-form test
 * 
 *   If test is true, evaluates then with binding-form bound to the value of
 *   test, if not, yields else
 */
cljs.core$macros.if_let = (function cljs$core$macros$if_let(var_args){
var args28310 = [];
var len__23982__auto___28319 = arguments.length;
var i__23983__auto___28320 = (0);
while(true){
if((i__23983__auto___28320 < len__23982__auto___28319)){
args28310.push((arguments[i__23983__auto___28320]));

var G__28321 = (i__23983__auto___28320 + (1));
i__23983__auto___28320 = G__28321;
continue;
} else {
}
break;
}

var G__28318 = args28310.length;
switch (G__28318) {
case 4:
return cljs.core$macros.if_let.cljs$core$IFn$_invoke$arity$4((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]));

break;
default:
var argseq__24001__auto__ = (new cljs.core.IndexedSeq(args28310.slice((5)),(0),null));
return cljs.core$macros.if_let.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]),(arguments[(4)]),argseq__24001__auto__);

}
});

cljs.core$macros.if_let.cljs$core$IFn$_invoke$arity$4 = (function (_AMPERSAND_form,_AMPERSAND_env,bindings,then){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","if-let","cljs.core$macros/if-let",1291543946,null)),(function (){var x__23746__auto__ = bindings;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = then;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,null))));
});

cljs.core$macros.if_let.cljs$core$IFn$_invoke$arity$variadic = (function (_AMPERSAND_form,_AMPERSAND_env,bindings,then,else$,oldform){
if(cljs.core.vector_QMARK_.call(null,bindings)){
} else {
throw cljs.core.ex_info.call(null,"if-let requires a vector for its binding",cljs.core.PersistentArrayMap.EMPTY);
}

if(cljs.core.empty_QMARK_.call(null,oldform)){
} else {
throw cljs.core.ex_info.call(null,"if-let requires 1 or 2 forms after binding vector",cljs.core.PersistentArrayMap.EMPTY);
}

if(cljs.core._EQ_.call(null,(2),cljs.core.count.call(null,bindings))){
} else {
throw cljs.core.ex_info.call(null,"if-let requires exactly 2 forms in binding vector",cljs.core.PersistentArrayMap.EMPTY);
}


var form = bindings.call(null,(0));
var tst = bindings.call(null,(1));
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","let","cljs.core$macros/let",-160286726,null)),(function (){var x__23746__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"temp__28309__auto__","temp__28309__auto__",-776122768,null)),(function (){var x__23746__auto__ = tst;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})()))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"if","if",1181717262,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"temp__28309__auto__","temp__28309__auto__",-776122768,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","let","cljs.core$macros/let",-160286726,null)),(function (){var x__23746__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,(function (){var x__23746__auto__ = form;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"temp__28309__auto__","temp__28309__auto__",-776122768,null))))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = then;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = else$;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
});

cljs.core$macros.if_let.cljs$lang$applyTo = (function (seq28311){
var G__28312 = cljs.core.first.call(null,seq28311);
var seq28311__$1 = cljs.core.next.call(null,seq28311);
var G__28313 = cljs.core.first.call(null,seq28311__$1);
var seq28311__$2 = cljs.core.next.call(null,seq28311__$1);
var G__28314 = cljs.core.first.call(null,seq28311__$2);
var seq28311__$3 = cljs.core.next.call(null,seq28311__$2);
var G__28315 = cljs.core.first.call(null,seq28311__$3);
var seq28311__$4 = cljs.core.next.call(null,seq28311__$3);
var G__28316 = cljs.core.first.call(null,seq28311__$4);
var seq28311__$5 = cljs.core.next.call(null,seq28311__$4);
return cljs.core$macros.if_let.cljs$core$IFn$_invoke$arity$variadic(G__28312,G__28313,G__28314,G__28315,G__28316,seq28311__$5);
});

cljs.core$macros.if_let.cljs$lang$maxFixedArity = (5);

cljs.core$macros.if_let.cljs$lang$macro = true;
/**
 * Evaluates test. If logical false, evaluates and returns then expr,
 *   otherwise else expr, if supplied, else nil.
 */
cljs.core$macros.if_not = (function cljs$core$macros$if_not(var_args){
var args28323 = [];
var len__23982__auto___28326 = arguments.length;
var i__23983__auto___28327 = (0);
while(true){
if((i__23983__auto___28327 < len__23982__auto___28326)){
args28323.push((arguments[i__23983__auto___28327]));

var G__28328 = (i__23983__auto___28327 + (1));
i__23983__auto___28327 = G__28328;
continue;
} else {
}
break;
}

var G__28325 = args28323.length;
switch (G__28325) {
case 4:
return cljs.core$macros.if_not.cljs$core$IFn$_invoke$arity$4((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]));

break;
case 5:
return cljs.core$macros.if_not.cljs$core$IFn$_invoke$arity$5((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]),(arguments[(4)]));

break;
default:
throw (new Error([cljs.core.str("Invalid arity: "),cljs.core.str((args28323.length - (2)))].join('')));

}
});

cljs.core$macros.if_not.cljs$core$IFn$_invoke$arity$4 = (function (_AMPERSAND_form,_AMPERSAND_env,test,then){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","if-not","cljs.core$macros/if-not",-1825285737,null)),(function (){var x__23746__auto__ = test;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = then;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,null))));
});

cljs.core$macros.if_not.cljs$core$IFn$_invoke$arity$5 = (function (_AMPERSAND_form,_AMPERSAND_env,test,then,else$){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"if","if",1181717262,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","not","cljs.core/not",100665144,null)),(function (){var x__23746__auto__ = test;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = then;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = else$;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
});

cljs.core$macros.if_not.cljs$lang$maxFixedArity = 5;

cljs.core$macros.if_not.cljs$lang$macro = true;
/**
 * fnspec ==> (fname [params*] exprs) or (fname ([params*] exprs)+)
 * 
 *   Takes a vector of function specs and a body, and generates a set of
 *   bindings of functions to their names. All of the names are available
 *   in all of the definitions of the functions, as well as the body.
 */
cljs.core$macros.letfn = (function cljs$core$macros$letfn(var_args){
var args__23989__auto__ = [];
var len__23982__auto___28335 = arguments.length;
var i__23983__auto___28336 = (0);
while(true){
if((i__23983__auto___28336 < len__23982__auto___28335)){
args__23989__auto__.push((arguments[i__23983__auto___28336]));

var G__28337 = (i__23983__auto___28336 + (1));
i__23983__auto___28336 = G__28337;
continue;
} else {
}
break;
}

var argseq__23990__auto__ = ((((3) < args__23989__auto__.length))?(new cljs.core.IndexedSeq(args__23989__auto__.slice((3)),(0),null)):null);
return cljs.core$macros.letfn.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),argseq__23990__auto__);
});

cljs.core$macros.letfn.cljs$core$IFn$_invoke$arity$variadic = (function (_AMPERSAND_form,_AMPERSAND_env,fnspecs,body){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"letfn*","letfn*",-110097810,null)),(function (){var x__23746__auto__ = cljs.core.vec.call(null,cljs.core.interleave.call(null,cljs.core.map.call(null,cljs.core.first,fnspecs),cljs.core.map.call(null,(function (p1__28330_SHARP_){
return cljs.core.cons.call(null,new cljs.core.Symbol("cljs.core$macros","fn","cljs.core$macros/fn",-187522821,null),p1__28330_SHARP_);
}),fnspecs)));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),body)));
});

cljs.core$macros.letfn.cljs$lang$maxFixedArity = (3);

cljs.core$macros.letfn.cljs$lang$applyTo = (function (seq28331){
var G__28332 = cljs.core.first.call(null,seq28331);
var seq28331__$1 = cljs.core.next.call(null,seq28331);
var G__28333 = cljs.core.first.call(null,seq28331__$1);
var seq28331__$2 = cljs.core.next.call(null,seq28331__$1);
var G__28334 = cljs.core.first.call(null,seq28331__$2);
var seq28331__$3 = cljs.core.next.call(null,seq28331__$2);
return cljs.core$macros.letfn.cljs$core$IFn$_invoke$arity$variadic(G__28332,G__28333,G__28334,seq28331__$3);
});

cljs.core$macros.letfn.cljs$lang$macro = true;
/**
 * Expands into code that creates a fn that expects to be passed an
 *   object and any args and calls the named instance method on the
 *   object passing the args. Use when you want to treat a Java method as
 *   a first-class fn. name may be type-hinted with the method receiver's
 *   type in order to avoid reflective calls.
 */
cljs.core$macros.memfn = (function cljs$core$macros$memfn(var_args){
var args__23989__auto__ = [];
var len__23982__auto___28342 = arguments.length;
var i__23983__auto___28343 = (0);
while(true){
if((i__23983__auto___28343 < len__23982__auto___28342)){
args__23989__auto__.push((arguments[i__23983__auto___28343]));

var G__28344 = (i__23983__auto___28343 + (1));
i__23983__auto___28343 = G__28344;
continue;
} else {
}
break;
}

var argseq__23990__auto__ = ((((3) < args__23989__auto__.length))?(new cljs.core.IndexedSeq(args__23989__auto__.slice((3)),(0),null)):null);
return cljs.core$macros.memfn.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),argseq__23990__auto__);
});

cljs.core$macros.memfn.cljs$core$IFn$_invoke$arity$variadic = (function (_AMPERSAND_form,_AMPERSAND_env,name,args){
var t = cljs.core.with_meta.call(null,cljs.core.gensym.call(null,"target"),cljs.core.meta.call(null,name));
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","fn","cljs.core$macros/fn",-187522821,null)),(function (){var x__23746__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,(function (){var x__23746__auto__ = t;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),args))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,".",".",1975675962,null)),(function (){var x__23746__auto__ = t;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,(function (){var x__23746__auto__ = name;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),args)));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
});

cljs.core$macros.memfn.cljs$lang$maxFixedArity = (3);

cljs.core$macros.memfn.cljs$lang$applyTo = (function (seq28338){
var G__28339 = cljs.core.first.call(null,seq28338);
var seq28338__$1 = cljs.core.next.call(null,seq28338);
var G__28340 = cljs.core.first.call(null,seq28338__$1);
var seq28338__$2 = cljs.core.next.call(null,seq28338__$1);
var G__28341 = cljs.core.first.call(null,seq28338__$2);
var seq28338__$3 = cljs.core.next.call(null,seq28338__$2);
return cljs.core$macros.memfn.cljs$core$IFn$_invoke$arity$variadic(G__28339,G__28340,G__28341,seq28338__$3);
});

cljs.core$macros.memfn.cljs$lang$macro = true;
/**
 * Evaluates test. If logical true, evaluates body in an implicit do.
 */
cljs.core$macros.when = (function cljs$core$macros$when(var_args){
var args__23989__auto__ = [];
var len__23982__auto___28349 = arguments.length;
var i__23983__auto___28350 = (0);
while(true){
if((i__23983__auto___28350 < len__23982__auto___28349)){
args__23989__auto__.push((arguments[i__23983__auto___28350]));

var G__28351 = (i__23983__auto___28350 + (1));
i__23983__auto___28350 = G__28351;
continue;
} else {
}
break;
}

var argseq__23990__auto__ = ((((3) < args__23989__auto__.length))?(new cljs.core.IndexedSeq(args__23989__auto__.slice((3)),(0),null)):null);
return cljs.core$macros.when.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),argseq__23990__auto__);
});

cljs.core$macros.when.cljs$core$IFn$_invoke$arity$variadic = (function (_AMPERSAND_form,_AMPERSAND_env,test,body){
return cljs.core._conj.call(null,(function (){var x__23746__auto__ = test;
return cljs.core._conj.call(null,(function (){var x__23746__auto____$1 = cljs.core.cons.call(null,new cljs.core.Symbol(null,"do","do",1686842252,null),body);
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto____$1);
})(),x__23746__auto__);
})(),new cljs.core.Symbol(null,"if","if",1181717262,null));
});

cljs.core$macros.when.cljs$lang$maxFixedArity = (3);

cljs.core$macros.when.cljs$lang$applyTo = (function (seq28345){
var G__28346 = cljs.core.first.call(null,seq28345);
var seq28345__$1 = cljs.core.next.call(null,seq28345);
var G__28347 = cljs.core.first.call(null,seq28345__$1);
var seq28345__$2 = cljs.core.next.call(null,seq28345__$1);
var G__28348 = cljs.core.first.call(null,seq28345__$2);
var seq28345__$3 = cljs.core.next.call(null,seq28345__$2);
return cljs.core$macros.when.cljs$core$IFn$_invoke$arity$variadic(G__28346,G__28347,G__28348,seq28345__$3);
});

cljs.core$macros.when.cljs$lang$macro = true;
/**
 * bindings => x xs
 * 
 *   Roughly the same as (when (seq xs) (let [x (first xs)] body)) but xs is evaluated only once
 */
cljs.core$macros.when_first = (function cljs$core$macros$when_first(var_args){
var args__23989__auto__ = [];
var len__23982__auto___28358 = arguments.length;
var i__23983__auto___28359 = (0);
while(true){
if((i__23983__auto___28359 < len__23982__auto___28358)){
args__23989__auto__.push((arguments[i__23983__auto___28359]));

var G__28360 = (i__23983__auto___28359 + (1));
i__23983__auto___28359 = G__28360;
continue;
} else {
}
break;
}

var argseq__23990__auto__ = ((((3) < args__23989__auto__.length))?(new cljs.core.IndexedSeq(args__23989__auto__.slice((3)),(0),null)):null);
return cljs.core$macros.when_first.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),argseq__23990__auto__);
});

cljs.core$macros.when_first.cljs$core$IFn$_invoke$arity$variadic = (function (_AMPERSAND_form,_AMPERSAND_env,bindings,body){
if(cljs.core.vector_QMARK_.call(null,bindings)){
} else {
throw cljs.core.ex_info.call(null,"when-first requires a vector for its binding",cljs.core.PersistentArrayMap.EMPTY);
}

if(cljs.core._EQ_.call(null,(2),cljs.core.count.call(null,bindings))){
} else {
throw cljs.core.ex_info.call(null,"when-first requires exactly 2 forms in binding vector",cljs.core.PersistentArrayMap.EMPTY);
}


var vec__28357 = bindings;
var x = cljs.core.nth.call(null,vec__28357,(0),null);
var xs = cljs.core.nth.call(null,vec__28357,(1),null);
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","when-let","cljs.core$macros/when-let",-2004472648,null)),(function (){var x__23746__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"xs__28352__auto__","xs__28352__auto__",1155400990,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","seq","cljs.core/seq",-1649497689,null)),(function (){var x__23746__auto__ = xs;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})()))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","let","cljs.core$macros/let",-160286726,null)),(function (){var x__23746__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,(function (){var x__23746__auto__ = x;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","first","cljs.core/first",-752535972,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"xs__28352__auto__","xs__28352__auto__",1155400990,null)))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})()))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),body)));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
});

cljs.core$macros.when_first.cljs$lang$maxFixedArity = (3);

cljs.core$macros.when_first.cljs$lang$applyTo = (function (seq28353){
var G__28354 = cljs.core.first.call(null,seq28353);
var seq28353__$1 = cljs.core.next.call(null,seq28353);
var G__28355 = cljs.core.first.call(null,seq28353__$1);
var seq28353__$2 = cljs.core.next.call(null,seq28353__$1);
var G__28356 = cljs.core.first.call(null,seq28353__$2);
var seq28353__$3 = cljs.core.next.call(null,seq28353__$2);
return cljs.core$macros.when_first.cljs$core$IFn$_invoke$arity$variadic(G__28354,G__28355,G__28356,seq28353__$3);
});

cljs.core$macros.when_first.cljs$lang$macro = true;
/**
 * bindings => binding-form test
 * 
 *   When test is true, evaluates body with binding-form bound to the value of test
 */
cljs.core$macros.when_let = (function cljs$core$macros$when_let(var_args){
var args__23989__auto__ = [];
var len__23982__auto___28366 = arguments.length;
var i__23983__auto___28367 = (0);
while(true){
if((i__23983__auto___28367 < len__23982__auto___28366)){
args__23989__auto__.push((arguments[i__23983__auto___28367]));

var G__28368 = (i__23983__auto___28367 + (1));
i__23983__auto___28367 = G__28368;
continue;
} else {
}
break;
}

var argseq__23990__auto__ = ((((3) < args__23989__auto__.length))?(new cljs.core.IndexedSeq(args__23989__auto__.slice((3)),(0),null)):null);
return cljs.core$macros.when_let.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),argseq__23990__auto__);
});

cljs.core$macros.when_let.cljs$core$IFn$_invoke$arity$variadic = (function (_AMPERSAND_form,_AMPERSAND_env,bindings,body){
if(cljs.core.vector_QMARK_.call(null,bindings)){
} else {
throw cljs.core.ex_info.call(null,"when-let requires a vector for its binding",cljs.core.PersistentArrayMap.EMPTY);
}

if(cljs.core._EQ_.call(null,(2),cljs.core.count.call(null,bindings))){
} else {
throw cljs.core.ex_info.call(null,"when-let requires exactly 2 forms in binding vector",cljs.core.PersistentArrayMap.EMPTY);
}


var form = bindings.call(null,(0));
var tst = bindings.call(null,(1));
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","let","cljs.core$macros/let",-160286726,null)),(function (){var x__23746__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"temp__28361__auto__","temp__28361__auto__",-1757350798,null)),(function (){var x__23746__auto__ = tst;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})()))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","when","cljs.core$macros/when",328457725,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"temp__28361__auto__","temp__28361__auto__",-1757350798,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","let","cljs.core$macros/let",-160286726,null)),(function (){var x__23746__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,(function (){var x__23746__auto__ = form;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"temp__28361__auto__","temp__28361__auto__",-1757350798,null))))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),body)));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
});

cljs.core$macros.when_let.cljs$lang$maxFixedArity = (3);

cljs.core$macros.when_let.cljs$lang$applyTo = (function (seq28362){
var G__28363 = cljs.core.first.call(null,seq28362);
var seq28362__$1 = cljs.core.next.call(null,seq28362);
var G__28364 = cljs.core.first.call(null,seq28362__$1);
var seq28362__$2 = cljs.core.next.call(null,seq28362__$1);
var G__28365 = cljs.core.first.call(null,seq28362__$2);
var seq28362__$3 = cljs.core.next.call(null,seq28362__$2);
return cljs.core$macros.when_let.cljs$core$IFn$_invoke$arity$variadic(G__28363,G__28364,G__28365,seq28362__$3);
});

cljs.core$macros.when_let.cljs$lang$macro = true;
/**
 * Evaluates test. If logical false, evaluates body in an implicit do.
 */
cljs.core$macros.when_not = (function cljs$core$macros$when_not(var_args){
var args__23989__auto__ = [];
var len__23982__auto___28373 = arguments.length;
var i__23983__auto___28374 = (0);
while(true){
if((i__23983__auto___28374 < len__23982__auto___28373)){
args__23989__auto__.push((arguments[i__23983__auto___28374]));

var G__28375 = (i__23983__auto___28374 + (1));
i__23983__auto___28374 = G__28375;
continue;
} else {
}
break;
}

var argseq__23990__auto__ = ((((3) < args__23989__auto__.length))?(new cljs.core.IndexedSeq(args__23989__auto__.slice((3)),(0),null)):null);
return cljs.core$macros.when_not.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),argseq__23990__auto__);
});

cljs.core$macros.when_not.cljs$core$IFn$_invoke$arity$variadic = (function (_AMPERSAND_form,_AMPERSAND_env,test,body){
return cljs.core._conj.call(null,(function (){var x__23746__auto__ = test;
return cljs.core._conj.call(null,cljs.core._conj.call(null,(function (){var x__23746__auto____$1 = cljs.core.cons.call(null,new cljs.core.Symbol(null,"do","do",1686842252,null),body);
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto____$1);
})(),null),x__23746__auto__);
})(),new cljs.core.Symbol(null,"if","if",1181717262,null));
});

cljs.core$macros.when_not.cljs$lang$maxFixedArity = (3);

cljs.core$macros.when_not.cljs$lang$applyTo = (function (seq28369){
var G__28370 = cljs.core.first.call(null,seq28369);
var seq28369__$1 = cljs.core.next.call(null,seq28369);
var G__28371 = cljs.core.first.call(null,seq28369__$1);
var seq28369__$2 = cljs.core.next.call(null,seq28369__$1);
var G__28372 = cljs.core.first.call(null,seq28369__$2);
var seq28369__$3 = cljs.core.next.call(null,seq28369__$2);
return cljs.core$macros.when_not.cljs$core$IFn$_invoke$arity$variadic(G__28370,G__28371,G__28372,seq28369__$3);
});

cljs.core$macros.when_not.cljs$lang$macro = true;
/**
 * Repeatedly executes body while test expression is true. Presumes
 *   some side-effect will cause test to become false/nil. Returns nil
 */
cljs.core$macros.while$ = (function cljs$core$macros$while(var_args){
var args__23989__auto__ = [];
var len__23982__auto___28380 = arguments.length;
var i__23983__auto___28381 = (0);
while(true){
if((i__23983__auto___28381 < len__23982__auto___28380)){
args__23989__auto__.push((arguments[i__23983__auto___28381]));

var G__28382 = (i__23983__auto___28381 + (1));
i__23983__auto___28381 = G__28382;
continue;
} else {
}
break;
}

var argseq__23990__auto__ = ((((3) < args__23989__auto__.length))?(new cljs.core.IndexedSeq(args__23989__auto__.slice((3)),(0),null)):null);
return cljs.core$macros.while$.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),argseq__23990__auto__);
});

cljs.core$macros.while$.cljs$core$IFn$_invoke$arity$variadic = (function (_AMPERSAND_form,_AMPERSAND_env,test,body){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","loop","cljs.core$macros/loop",1731108390,null)),(function (){var x__23746__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","when","cljs.core$macros/when",328457725,null)),(function (){var x__23746__auto__ = test;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),body,(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"recur","recur",1202958259,null)))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
});

cljs.core$macros.while$.cljs$lang$maxFixedArity = (3);

cljs.core$macros.while$.cljs$lang$applyTo = (function (seq28376){
var G__28377 = cljs.core.first.call(null,seq28376);
var seq28376__$1 = cljs.core.next.call(null,seq28376);
var G__28378 = cljs.core.first.call(null,seq28376__$1);
var seq28376__$2 = cljs.core.next.call(null,seq28376__$1);
var G__28379 = cljs.core.first.call(null,seq28376__$2);
var seq28376__$3 = cljs.core.next.call(null,seq28376__$2);
return cljs.core$macros.while$.cljs$core$IFn$_invoke$arity$variadic(G__28377,G__28378,G__28379,seq28376__$3);
});

cljs.core$macros.while$.cljs$lang$macro = true;
/**
 * Takes an expression and a set of test/form pairs. Threads expr (via ->)
 *   through each form for which the corresponding test
 *   expression is true. Note that, unlike cond branching, cond-> threading does
 *   not short circuit after the first true test expression.
 */
cljs.core$macros.cond__GT_ = (function cljs$core$macros$cond__GT_(var_args){
var args__23989__auto__ = [];
var len__23982__auto___28389 = arguments.length;
var i__23983__auto___28390 = (0);
while(true){
if((i__23983__auto___28390 < len__23982__auto___28389)){
args__23989__auto__.push((arguments[i__23983__auto___28390]));

var G__28391 = (i__23983__auto___28390 + (1));
i__23983__auto___28390 = G__28391;
continue;
} else {
}
break;
}

var argseq__23990__auto__ = ((((3) < args__23989__auto__.length))?(new cljs.core.IndexedSeq(args__23989__auto__.slice((3)),(0),null)):null);
return cljs.core$macros.cond__GT_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),argseq__23990__auto__);
});

cljs.core$macros.cond__GT_.cljs$core$IFn$_invoke$arity$variadic = (function (_AMPERSAND_form,_AMPERSAND_env,expr,clauses){
if(cljs.core.even_QMARK_.call(null,cljs.core.count.call(null,clauses))){
} else {
throw (new Error("Assert failed: (even? (count clauses))"));
}

var g = cljs.core.gensym.call(null);
var pstep = ((function (g){
return (function (p__28387){
var vec__28388 = p__28387;
var test = cljs.core.nth.call(null,vec__28388,(0),null);
var step = cljs.core.nth.call(null,vec__28388,(1),null);
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"if","if",1181717262,null)),(function (){var x__23746__auto__ = test;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","->","cljs.core$macros/->",-1519455206,null)),(function (){var x__23746__auto__ = g;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = step;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = g;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
});})(g))
;
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","let","cljs.core$macros/let",-160286726,null)),(function (){var x__23746__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,(function (){var x__23746__auto__ = g;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = expr;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),cljs.core.interleave.call(null,cljs.core.repeat.call(null,g),cljs.core.map.call(null,pstep,cljs.core.partition.call(null,(2),clauses)))))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = g;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
});

cljs.core$macros.cond__GT_.cljs$lang$maxFixedArity = (3);

cljs.core$macros.cond__GT_.cljs$lang$applyTo = (function (seq28383){
var G__28384 = cljs.core.first.call(null,seq28383);
var seq28383__$1 = cljs.core.next.call(null,seq28383);
var G__28385 = cljs.core.first.call(null,seq28383__$1);
var seq28383__$2 = cljs.core.next.call(null,seq28383__$1);
var G__28386 = cljs.core.first.call(null,seq28383__$2);
var seq28383__$3 = cljs.core.next.call(null,seq28383__$2);
return cljs.core$macros.cond__GT_.cljs$core$IFn$_invoke$arity$variadic(G__28384,G__28385,G__28386,seq28383__$3);
});

cljs.core$macros.cond__GT_.cljs$lang$macro = true;
/**
 * Takes an expression and a set of test/form pairs. Threads expr (via ->>)
 *   through each form for which the corresponding test expression
 *   is true.  Note that, unlike cond branching, cond->> threading does not short circuit
 *   after the first true test expression.
 */
cljs.core$macros.cond__GT__GT_ = (function cljs$core$macros$cond__GT__GT_(var_args){
var args__23989__auto__ = [];
var len__23982__auto___28398 = arguments.length;
var i__23983__auto___28399 = (0);
while(true){
if((i__23983__auto___28399 < len__23982__auto___28398)){
args__23989__auto__.push((arguments[i__23983__auto___28399]));

var G__28400 = (i__23983__auto___28399 + (1));
i__23983__auto___28399 = G__28400;
continue;
} else {
}
break;
}

var argseq__23990__auto__ = ((((3) < args__23989__auto__.length))?(new cljs.core.IndexedSeq(args__23989__auto__.slice((3)),(0),null)):null);
return cljs.core$macros.cond__GT__GT_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),argseq__23990__auto__);
});

cljs.core$macros.cond__GT__GT_.cljs$core$IFn$_invoke$arity$variadic = (function (_AMPERSAND_form,_AMPERSAND_env,expr,clauses){
if(cljs.core.even_QMARK_.call(null,cljs.core.count.call(null,clauses))){
} else {
throw (new Error("Assert failed: (even? (count clauses))"));
}

var g = cljs.core.gensym.call(null);
var pstep = ((function (g){
return (function (p__28396){
var vec__28397 = p__28396;
var test = cljs.core.nth.call(null,vec__28397,(0),null);
var step = cljs.core.nth.call(null,vec__28397,(1),null);
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"if","if",1181717262,null)),(function (){var x__23746__auto__ = test;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","->>","cljs.core$macros/->>",-1353108561,null)),(function (){var x__23746__auto__ = g;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = step;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = g;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
});})(g))
;
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","let","cljs.core$macros/let",-160286726,null)),(function (){var x__23746__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,(function (){var x__23746__auto__ = g;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = expr;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),cljs.core.interleave.call(null,cljs.core.repeat.call(null,g),cljs.core.map.call(null,pstep,cljs.core.partition.call(null,(2),clauses)))))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = g;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
});

cljs.core$macros.cond__GT__GT_.cljs$lang$maxFixedArity = (3);

cljs.core$macros.cond__GT__GT_.cljs$lang$applyTo = (function (seq28392){
var G__28393 = cljs.core.first.call(null,seq28392);
var seq28392__$1 = cljs.core.next.call(null,seq28392);
var G__28394 = cljs.core.first.call(null,seq28392__$1);
var seq28392__$2 = cljs.core.next.call(null,seq28392__$1);
var G__28395 = cljs.core.first.call(null,seq28392__$2);
var seq28392__$3 = cljs.core.next.call(null,seq28392__$2);
return cljs.core$macros.cond__GT__GT_.cljs$core$IFn$_invoke$arity$variadic(G__28393,G__28394,G__28395,seq28392__$3);
});

cljs.core$macros.cond__GT__GT_.cljs$lang$macro = true;
/**
 * Binds name to expr, evaluates the first form in the lexical context
 *   of that binding, then binds name to that result, repeating for each
 *   successive form, returning the result of the last form.
 */
cljs.core$macros.as__GT_ = (function cljs$core$macros$as__GT_(var_args){
var args__23989__auto__ = [];
var len__23982__auto___28406 = arguments.length;
var i__23983__auto___28407 = (0);
while(true){
if((i__23983__auto___28407 < len__23982__auto___28406)){
args__23989__auto__.push((arguments[i__23983__auto___28407]));

var G__28408 = (i__23983__auto___28407 + (1));
i__23983__auto___28407 = G__28408;
continue;
} else {
}
break;
}

var argseq__23990__auto__ = ((((4) < args__23989__auto__.length))?(new cljs.core.IndexedSeq(args__23989__auto__.slice((4)),(0),null)):null);
return cljs.core$macros.as__GT_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]),argseq__23990__auto__);
});

cljs.core$macros.as__GT_.cljs$core$IFn$_invoke$arity$variadic = (function (_AMPERSAND_form,_AMPERSAND_env,expr,name,forms){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","let","cljs.core$macros/let",-160286726,null)),(function (){var x__23746__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,(function (){var x__23746__auto__ = name;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = expr;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),cljs.core.interleave.call(null,cljs.core.repeat.call(null,name),forms)))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = name;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
});

cljs.core$macros.as__GT_.cljs$lang$maxFixedArity = (4);

cljs.core$macros.as__GT_.cljs$lang$applyTo = (function (seq28401){
var G__28402 = cljs.core.first.call(null,seq28401);
var seq28401__$1 = cljs.core.next.call(null,seq28401);
var G__28403 = cljs.core.first.call(null,seq28401__$1);
var seq28401__$2 = cljs.core.next.call(null,seq28401__$1);
var G__28404 = cljs.core.first.call(null,seq28401__$2);
var seq28401__$3 = cljs.core.next.call(null,seq28401__$2);
var G__28405 = cljs.core.first.call(null,seq28401__$3);
var seq28401__$4 = cljs.core.next.call(null,seq28401__$3);
return cljs.core$macros.as__GT_.cljs$core$IFn$_invoke$arity$variadic(G__28402,G__28403,G__28404,G__28405,seq28401__$4);
});

cljs.core$macros.as__GT_.cljs$lang$macro = true;
/**
 * When expr is not nil, threads it into the first form (via ->),
 *   and when that result is not nil, through the next etc
 */
cljs.core$macros.some__GT_ = (function cljs$core$macros$some__GT_(var_args){
var args__23989__auto__ = [];
var len__23982__auto___28413 = arguments.length;
var i__23983__auto___28414 = (0);
while(true){
if((i__23983__auto___28414 < len__23982__auto___28413)){
args__23989__auto__.push((arguments[i__23983__auto___28414]));

var G__28415 = (i__23983__auto___28414 + (1));
i__23983__auto___28414 = G__28415;
continue;
} else {
}
break;
}

var argseq__23990__auto__ = ((((3) < args__23989__auto__.length))?(new cljs.core.IndexedSeq(args__23989__auto__.slice((3)),(0),null)):null);
return cljs.core$macros.some__GT_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),argseq__23990__auto__);
});

cljs.core$macros.some__GT_.cljs$core$IFn$_invoke$arity$variadic = (function (_AMPERSAND_form,_AMPERSAND_env,expr,forms){
var g = cljs.core.gensym.call(null);
var pstep = ((function (g){
return (function (step){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"if","if",1181717262,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","nil?","cljs.core$macros/nil?",83624258,null)),(function (){var x__23746__auto__ = g;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,null),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","->","cljs.core$macros/->",-1519455206,null)),(function (){var x__23746__auto__ = g;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = step;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
});})(g))
;
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","let","cljs.core$macros/let",-160286726,null)),(function (){var x__23746__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,(function (){var x__23746__auto__ = g;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = expr;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),cljs.core.interleave.call(null,cljs.core.repeat.call(null,g),cljs.core.map.call(null,pstep,forms))))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = g;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
});

cljs.core$macros.some__GT_.cljs$lang$maxFixedArity = (3);

cljs.core$macros.some__GT_.cljs$lang$applyTo = (function (seq28409){
var G__28410 = cljs.core.first.call(null,seq28409);
var seq28409__$1 = cljs.core.next.call(null,seq28409);
var G__28411 = cljs.core.first.call(null,seq28409__$1);
var seq28409__$2 = cljs.core.next.call(null,seq28409__$1);
var G__28412 = cljs.core.first.call(null,seq28409__$2);
var seq28409__$3 = cljs.core.next.call(null,seq28409__$2);
return cljs.core$macros.some__GT_.cljs$core$IFn$_invoke$arity$variadic(G__28410,G__28411,G__28412,seq28409__$3);
});

cljs.core$macros.some__GT_.cljs$lang$macro = true;
/**
 * When expr is not nil, threads it into the first form (via ->>),
 *   and when that result is not nil, through the next etc
 */
cljs.core$macros.some__GT__GT_ = (function cljs$core$macros$some__GT__GT_(var_args){
var args__23989__auto__ = [];
var len__23982__auto___28420 = arguments.length;
var i__23983__auto___28421 = (0);
while(true){
if((i__23983__auto___28421 < len__23982__auto___28420)){
args__23989__auto__.push((arguments[i__23983__auto___28421]));

var G__28422 = (i__23983__auto___28421 + (1));
i__23983__auto___28421 = G__28422;
continue;
} else {
}
break;
}

var argseq__23990__auto__ = ((((3) < args__23989__auto__.length))?(new cljs.core.IndexedSeq(args__23989__auto__.slice((3)),(0),null)):null);
return cljs.core$macros.some__GT__GT_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),argseq__23990__auto__);
});

cljs.core$macros.some__GT__GT_.cljs$core$IFn$_invoke$arity$variadic = (function (_AMPERSAND_form,_AMPERSAND_env,expr,forms){
var g = cljs.core.gensym.call(null);
var pstep = ((function (g){
return (function (step){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"if","if",1181717262,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","nil?","cljs.core$macros/nil?",83624258,null)),(function (){var x__23746__auto__ = g;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,null),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","->>","cljs.core$macros/->>",-1353108561,null)),(function (){var x__23746__auto__ = g;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = step;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
});})(g))
;
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","let","cljs.core$macros/let",-160286726,null)),(function (){var x__23746__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,(function (){var x__23746__auto__ = g;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = expr;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),cljs.core.interleave.call(null,cljs.core.repeat.call(null,g),cljs.core.map.call(null,pstep,forms))))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = g;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
});

cljs.core$macros.some__GT__GT_.cljs$lang$maxFixedArity = (3);

cljs.core$macros.some__GT__GT_.cljs$lang$applyTo = (function (seq28416){
var G__28417 = cljs.core.first.call(null,seq28416);
var seq28416__$1 = cljs.core.next.call(null,seq28416);
var G__28418 = cljs.core.first.call(null,seq28416__$1);
var seq28416__$2 = cljs.core.next.call(null,seq28416__$1);
var G__28419 = cljs.core.first.call(null,seq28416__$2);
var seq28416__$3 = cljs.core.next.call(null,seq28416__$2);
return cljs.core$macros.some__GT__GT_.cljs$core$IFn$_invoke$arity$variadic(G__28417,G__28418,G__28419,seq28416__$3);
});

cljs.core$macros.some__GT__GT_.cljs$lang$macro = true;
/**
 * bindings => binding-form test
 * 
 *    If test is not nil, evaluates then with binding-form bound to the
 *    value of test, if not, yields else
 */
cljs.core$macros.if_some = (function cljs$core$macros$if_some(var_args){
var args28424 = [];
var len__23982__auto___28433 = arguments.length;
var i__23983__auto___28434 = (0);
while(true){
if((i__23983__auto___28434 < len__23982__auto___28433)){
args28424.push((arguments[i__23983__auto___28434]));

var G__28435 = (i__23983__auto___28434 + (1));
i__23983__auto___28434 = G__28435;
continue;
} else {
}
break;
}

var G__28432 = args28424.length;
switch (G__28432) {
case 4:
return cljs.core$macros.if_some.cljs$core$IFn$_invoke$arity$4((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]));

break;
default:
var argseq__24001__auto__ = (new cljs.core.IndexedSeq(args28424.slice((5)),(0),null));
return cljs.core$macros.if_some.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]),(arguments[(4)]),argseq__24001__auto__);

}
});

cljs.core$macros.if_some.cljs$core$IFn$_invoke$arity$4 = (function (_AMPERSAND_form,_AMPERSAND_env,bindings,then){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","if-some","cljs.core$macros/if-some",1405341529,null)),(function (){var x__23746__auto__ = bindings;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = then;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,null))));
});

cljs.core$macros.if_some.cljs$core$IFn$_invoke$arity$variadic = (function (_AMPERSAND_form,_AMPERSAND_env,bindings,then,else$,oldform){
if(cljs.core.vector_QMARK_.call(null,bindings)){
} else {
throw cljs.core.ex_info.call(null,"if-some requires a vector for its binding",cljs.core.PersistentArrayMap.EMPTY);
}

if(cljs.core.empty_QMARK_.call(null,oldform)){
} else {
throw cljs.core.ex_info.call(null,"if-some requires 1 or 2 forms after binding vector",cljs.core.PersistentArrayMap.EMPTY);
}

if(cljs.core._EQ_.call(null,(2),cljs.core.count.call(null,bindings))){
} else {
throw cljs.core.ex_info.call(null,"if-some requires exactly 2 forms in binding vector",cljs.core.PersistentArrayMap.EMPTY);
}


var form = bindings.call(null,(0));
var tst = bindings.call(null,(1));
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","let","cljs.core$macros/let",-160286726,null)),(function (){var x__23746__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"temp__28423__auto__","temp__28423__auto__",-1521637496,null)),(function (){var x__23746__auto__ = tst;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})()))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"if","if",1181717262,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","nil?","cljs.core$macros/nil?",83624258,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"temp__28423__auto__","temp__28423__auto__",-1521637496,null)))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = else$;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","let","cljs.core$macros/let",-160286726,null)),(function (){var x__23746__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,(function (){var x__23746__auto__ = form;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"temp__28423__auto__","temp__28423__auto__",-1521637496,null))))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = then;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
});

cljs.core$macros.if_some.cljs$lang$applyTo = (function (seq28425){
var G__28426 = cljs.core.first.call(null,seq28425);
var seq28425__$1 = cljs.core.next.call(null,seq28425);
var G__28427 = cljs.core.first.call(null,seq28425__$1);
var seq28425__$2 = cljs.core.next.call(null,seq28425__$1);
var G__28428 = cljs.core.first.call(null,seq28425__$2);
var seq28425__$3 = cljs.core.next.call(null,seq28425__$2);
var G__28429 = cljs.core.first.call(null,seq28425__$3);
var seq28425__$4 = cljs.core.next.call(null,seq28425__$3);
var G__28430 = cljs.core.first.call(null,seq28425__$4);
var seq28425__$5 = cljs.core.next.call(null,seq28425__$4);
return cljs.core$macros.if_some.cljs$core$IFn$_invoke$arity$variadic(G__28426,G__28427,G__28428,G__28429,G__28430,seq28425__$5);
});

cljs.core$macros.if_some.cljs$lang$maxFixedArity = (5);

cljs.core$macros.if_some.cljs$lang$macro = true;
/**
 * bindings => binding-form test
 * 
 *    When test is not nil, evaluates body with binding-form bound to the
 *    value of test
 */
cljs.core$macros.when_some = (function cljs$core$macros$when_some(var_args){
var args__23989__auto__ = [];
var len__23982__auto___28442 = arguments.length;
var i__23983__auto___28443 = (0);
while(true){
if((i__23983__auto___28443 < len__23982__auto___28442)){
args__23989__auto__.push((arguments[i__23983__auto___28443]));

var G__28444 = (i__23983__auto___28443 + (1));
i__23983__auto___28443 = G__28444;
continue;
} else {
}
break;
}

var argseq__23990__auto__ = ((((3) < args__23989__auto__.length))?(new cljs.core.IndexedSeq(args__23989__auto__.slice((3)),(0),null)):null);
return cljs.core$macros.when_some.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),argseq__23990__auto__);
});

cljs.core$macros.when_some.cljs$core$IFn$_invoke$arity$variadic = (function (_AMPERSAND_form,_AMPERSAND_env,bindings,body){
if(cljs.core.vector_QMARK_.call(null,bindings)){
} else {
throw cljs.core.ex_info.call(null,"when-some requires a vector for its binding",cljs.core.PersistentArrayMap.EMPTY);
}

if(cljs.core._EQ_.call(null,(2),cljs.core.count.call(null,bindings))){
} else {
throw cljs.core.ex_info.call(null,"when-some requires exactly 2 forms in binding vector",cljs.core.PersistentArrayMap.EMPTY);
}


var form = bindings.call(null,(0));
var tst = bindings.call(null,(1));
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","let","cljs.core$macros/let",-160286726,null)),(function (){var x__23746__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"temp__28437__auto__","temp__28437__auto__",-774946372,null)),(function (){var x__23746__auto__ = tst;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})()))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"if","if",1181717262,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","nil?","cljs.core$macros/nil?",83624258,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"temp__28437__auto__","temp__28437__auto__",-774946372,null)))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,null),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","let","cljs.core$macros/let",-160286726,null)),(function (){var x__23746__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,(function (){var x__23746__auto__ = form;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"temp__28437__auto__","temp__28437__auto__",-774946372,null))))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),body)));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
});

cljs.core$macros.when_some.cljs$lang$maxFixedArity = (3);

cljs.core$macros.when_some.cljs$lang$applyTo = (function (seq28438){
var G__28439 = cljs.core.first.call(null,seq28438);
var seq28438__$1 = cljs.core.next.call(null,seq28438);
var G__28440 = cljs.core.first.call(null,seq28438__$1);
var seq28438__$2 = cljs.core.next.call(null,seq28438__$1);
var G__28441 = cljs.core.first.call(null,seq28438__$2);
var seq28438__$3 = cljs.core.next.call(null,seq28438__$2);
return cljs.core$macros.when_some.cljs$core$IFn$_invoke$arity$variadic(G__28439,G__28440,G__28441,seq28438__$3);
});

cljs.core$macros.when_some.cljs$lang$macro = true;
/**
 * A good fdecl looks like (([a] ...) ([a b] ...)) near the end of defn.
 */
cljs.core$macros.assert_valid_fdecl = (function cljs$core$macros$assert_valid_fdecl(fdecl){
if(cljs.core.empty_QMARK_.call(null,fdecl)){
throw (new Error("Parameter declaration missing"));
} else {
}

var argdecls = cljs.core.map.call(null,(function (p1__28445_SHARP_){
if(cljs.core.seq_QMARK_.call(null,p1__28445_SHARP_)){
return cljs.core.first.call(null,p1__28445_SHARP_);
} else {
throw (new Error(((cljs.core.seq_QMARK_.call(null,cljs.core.first.call(null,fdecl)))?[cljs.core.str("Invalid signature \""),cljs.core.str(p1__28445_SHARP_),cljs.core.str("\" should be a list")].join(''):[cljs.core.str("Parameter declaration \""),cljs.core.str(p1__28445_SHARP_),cljs.core.str("\" should be a vector")].join(''))));
}
}),fdecl);
var bad_args = cljs.core.seq.call(null,cljs.core.remove.call(null,((function (argdecls){
return (function (p1__28446_SHARP_){
return cljs.core.vector_QMARK_.call(null,p1__28446_SHARP_);
});})(argdecls))
,argdecls));
if(bad_args){
throw (new Error([cljs.core.str("Parameter declaration \""),cljs.core.str(cljs.core.first.call(null,bad_args)),cljs.core.str("\" should be a vector")].join('')));
} else {
return null;
}
});
cljs.core$macros.sigs = (function cljs$core$macros$sigs(fdecl){
cljs.core$macros.assert_valid_fdecl.call(null,fdecl);

var asig = (function (fdecl__$1){
var arglist = cljs.core.first.call(null,fdecl__$1);
var arglist__$1 = ((cljs.core._EQ_.call(null,new cljs.core.Symbol(null,"&form","&form",1482799337,null),cljs.core.first.call(null,arglist)))?cljs.core.subvec.call(null,arglist,(2),cljs.core.count.call(null,arglist)):arglist);
var body = cljs.core.next.call(null,fdecl__$1);
if(cljs.core.map_QMARK_.call(null,cljs.core.first.call(null,body))){
if(cljs.core.next.call(null,body)){
return cljs.core.with_meta.call(null,arglist__$1,cljs.core.conj.call(null,(cljs.core.truth_(cljs.core.meta.call(null,arglist__$1))?cljs.core.meta.call(null,arglist__$1):cljs.core.PersistentArrayMap.EMPTY),cljs.core.first.call(null,body)));
} else {
return arglist__$1;
}
} else {
return arglist__$1;
}
});
if(cljs.core.seq_QMARK_.call(null,cljs.core.first.call(null,fdecl))){
var ret = cljs.core.PersistentVector.EMPTY;
var fdecls = fdecl;
while(true){
if(cljs.core.truth_(fdecls)){
var G__28447 = cljs.core.conj.call(null,ret,asig.call(null,cljs.core.first.call(null,fdecls)));
var G__28448 = cljs.core.next.call(null,fdecls);
ret = G__28447;
fdecls = G__28448;
continue;
} else {
return cljs.core.seq.call(null,ret);
}
break;
}
} else {
var x__23746__auto__ = asig.call(null,fdecl);
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
}
});
cljs.core$macros.defonce = (function cljs$core$macros$defonce(_AMPERSAND_form,_AMPERSAND_env,x,init){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","when-not","cljs.core$macros/when-not",-764302244,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","exists?","cljs.core$macros/exists?",-1828590389,null)),(function (){var x__23746__auto__ = x;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"def","def",597100991,null)),(function (){var x__23746__auto__ = x;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = init;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
});

cljs.core$macros.defonce.cljs$lang$macro = true;
cljs.core$macros.destructure = (function cljs$core$macros$destructure(bindings){
var bents = cljs.core.partition.call(null,(2),bindings);
var pb = ((function (bents){
return (function cljs$core$macros$destructure_$_pb(bvec,b,v){
var pvec = ((function (bents){
return (function (bvec__$1,b__$1,val){
var gvec = cljs.core.gensym.call(null,"vec__");
var ret = cljs.core.conj.call(null,cljs.core.conj.call(null,bvec__$1,gvec),val);
var n = (0);
var bs = b__$1;
var seen_rest_QMARK_ = false;
while(true){
if(cljs.core.seq.call(null,bs)){
var firstb = cljs.core.first.call(null,bs);
if(cljs.core._EQ_.call(null,firstb,new cljs.core.Symbol(null,"&","&",-2144855648,null))){
var G__28454 = cljs$core$macros$destructure_$_pb.call(null,ret,cljs.core.second.call(null,bs),cljs.core._conj.call(null,(function (){var x__23746__auto__ = gvec;
return cljs.core._conj.call(null,(function (){var x__23746__auto____$1 = n;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto____$1);
})(),x__23746__auto__);
})(),new cljs.core.Symbol("cljs.core","nthnext","cljs.core/nthnext",-1690777327,null)));
var G__28455 = n;
var G__28456 = cljs.core.nnext.call(null,bs);
var G__28457 = true;
ret = G__28454;
n = G__28455;
bs = G__28456;
seen_rest_QMARK_ = G__28457;
continue;
} else {
if(cljs.core._EQ_.call(null,firstb,new cljs.core.Keyword(null,"as","as",1148689641))){
return cljs$core$macros$destructure_$_pb.call(null,ret,cljs.core.second.call(null,bs),gvec);
} else {
if(seen_rest_QMARK_){
throw (new Error("Unsupported binding form, only :as can follow & parameter"));
} else {
var G__28458 = cljs$core$macros$destructure_$_pb.call(null,ret,firstb,cljs.core._conj.call(null,(function (){var x__23746__auto__ = gvec;
return cljs.core._conj.call(null,(function (){var x__23746__auto____$1 = n;
return cljs.core._conj.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,null),x__23746__auto____$1);
})(),x__23746__auto__);
})(),new cljs.core.Symbol("cljs.core","nth","cljs.core/nth",1961052085,null)));
var G__28459 = (n + (1));
var G__28460 = cljs.core.next.call(null,bs);
var G__28461 = seen_rest_QMARK_;
ret = G__28458;
n = G__28459;
bs = G__28460;
seen_rest_QMARK_ = G__28461;
continue;
}

}
}
} else {
return ret;
}
break;
}
});})(bents))
;
var pmap = ((function (pvec,bents){
return (function (bvec__$1,b__$1,v__$1){
var gmap = cljs.core.gensym.call(null,"map__");
var defaults = new cljs.core.Keyword(null,"or","or",235744169).cljs$core$IFn$_invoke$arity$1(b__$1);
var ret = ((function (gmap,defaults,pvec,bents){
return (function (ret){
if(cljs.core.truth_(new cljs.core.Keyword(null,"as","as",1148689641).cljs$core$IFn$_invoke$arity$1(b__$1))){
return cljs.core.conj.call(null,ret,new cljs.core.Keyword(null,"as","as",1148689641).cljs$core$IFn$_invoke$arity$1(b__$1),gmap);
} else {
return ret;
}
});})(gmap,defaults,pvec,bents))
.call(null,cljs.core.conj.call(null,cljs.core.conj.call(null,cljs.core.conj.call(null,cljs.core.conj.call(null,bvec__$1,gmap),v__$1),gmap),cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"if","if",1181717262,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","implements?","cljs.core$macros/implements?",-94762250,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","ISeq","cljs.core/ISeq",230133392,null)),(function (){var x__23746__auto__ = gmap;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","apply","cljs.core/apply",1757277831,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","hash-map","cljs.core/hash-map",303385767,null)),(function (){var x__23746__auto__ = gmap;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = gmap;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())))));
var bes = cljs.core.reduce.call(null,((function (ret,gmap,defaults,pvec,bents){
return (function (bes,entry){
return cljs.core.reduce.call(null,((function (ret,gmap,defaults,pvec,bents){
return (function (p1__28449_SHARP_,p2__28450_SHARP_){
return cljs.core.assoc.call(null,p1__28449_SHARP_,p2__28450_SHARP_,cljs.core.val.call(null,entry).call(null,p2__28450_SHARP_));
});})(ret,gmap,defaults,pvec,bents))
,cljs.core.dissoc.call(null,bes,cljs.core.key.call(null,entry)),cljs.core.key.call(null,entry).call(null,bes));
});})(ret,gmap,defaults,pvec,bents))
,cljs.core.dissoc.call(null,b__$1,new cljs.core.Keyword(null,"as","as",1148689641),new cljs.core.Keyword(null,"or","or",235744169)),new cljs.core.PersistentArrayMap(null, 3, [new cljs.core.Keyword(null,"keys","keys",1068423698),((function (ret,gmap,defaults,pvec,bents){
return (function (p1__28451_SHARP_){
if((p1__28451_SHARP_ instanceof cljs.core.Keyword)){
return p1__28451_SHARP_;
} else {
return cljs.core.keyword.call(null,[cljs.core.str(p1__28451_SHARP_)].join(''));
}
});})(ret,gmap,defaults,pvec,bents))
,new cljs.core.Keyword(null,"strs","strs",1175537277),cljs.core.str,new cljs.core.Keyword(null,"syms","syms",-1575891762),((function (ret,gmap,defaults,pvec,bents){
return (function (p1__28452_SHARP_){
return cljs.core._conj.call(null,(function (){var x__23746__auto__ = p1__28452_SHARP_;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),new cljs.core.Symbol(null,"quote","quote",1377916282,null));
});})(ret,gmap,defaults,pvec,bents))
], null));
while(true){
if(cljs.core.seq.call(null,bes)){
var bb = cljs.core.key.call(null,cljs.core.first.call(null,bes));
var bk = cljs.core.val.call(null,cljs.core.first.call(null,bes));
var has_default = cljs.core.contains_QMARK_.call(null,defaults,bb);
var G__28462 = cljs$core$macros$destructure_$_pb.call(null,ret,bb,((has_default)?cljs.core._conj.call(null,(function (){var x__23746__auto__ = gmap;
return cljs.core._conj.call(null,(function (){var x__23746__auto____$1 = bk;
return cljs.core._conj.call(null,(function (){var x__23746__auto____$2 = defaults.call(null,bb);
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto____$2);
})(),x__23746__auto____$1);
})(),x__23746__auto__);
})(),new cljs.core.Symbol("cljs.core","get","cljs.core/get",-296075407,null)):cljs.core._conj.call(null,(function (){var x__23746__auto__ = gmap;
return cljs.core._conj.call(null,(function (){var x__23746__auto____$1 = bk;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto____$1);
})(),x__23746__auto__);
})(),new cljs.core.Symbol("cljs.core","get","cljs.core/get",-296075407,null))));
var G__28463 = cljs.core.next.call(null,bes);
ret = G__28462;
bes = G__28463;
continue;
} else {
return ret;
}
break;
}
});})(pvec,bents))
;
if((b instanceof cljs.core.Symbol)){
return cljs.core.conj.call(null,cljs.core.conj.call(null,bvec,(cljs.core.truth_(cljs.core.namespace.call(null,b))?cljs.core.symbol.call(null,cljs.core.name.call(null,b)):b)),v);
} else {
if((b instanceof cljs.core.Keyword)){
return cljs.core.conj.call(null,cljs.core.conj.call(null,bvec,cljs.core.symbol.call(null,cljs.core.name.call(null,b))),v);
} else {
if(cljs.core.vector_QMARK_.call(null,b)){
return pvec.call(null,bvec,b,v);
} else {
if(cljs.core.map_QMARK_.call(null,b)){
return pmap.call(null,bvec,b,v);
} else {
throw (new Error([cljs.core.str("Unsupported binding form: "),cljs.core.str(b)].join('')));

}
}
}
}
});})(bents))
;
var process_entry = ((function (bents,pb){
return (function (bvec,b){
return pb.call(null,bvec,cljs.core.first.call(null,b),cljs.core.second.call(null,b));
});})(bents,pb))
;
if(cljs.core.every_QMARK_.call(null,cljs.core.symbol_QMARK_,cljs.core.map.call(null,cljs.core.first,bents))){
return bindings;
} else {
var temp__4655__auto__ = cljs.core.seq.call(null,cljs.core.filter.call(null,((function (bents,pb,process_entry){
return (function (p1__28453_SHARP_){
return (cljs.core.first.call(null,p1__28453_SHARP_) instanceof cljs.core.Keyword);
});})(bents,pb,process_entry))
,bents));
if(temp__4655__auto__){
var kwbs = temp__4655__auto__;
throw (new Error([cljs.core.str("Unsupported binding key: "),cljs.core.str(cljs.core.ffirst.call(null,kwbs))].join('')));
} else {
return cljs.core.reduce.call(null,process_entry,cljs.core.PersistentVector.EMPTY,bents);
}
}
});
/**
 * Defines a var using `goog.define`. Passed default value must be
 *   string, number or boolean.
 * 
 *   Default value can be overridden at compile time using the
 *   compiler option `:closure-defines`.
 * 
 *   Example:
 *  (ns your-app.core)
 *  (goog-define DEBUG! false)
 *  ;; can be overridden with
 *  :closure-defines {"your_app.core.DEBUG_BANG_" true}
 *  or
 *  :closure-defines {'your-app.core/DEBUG! true}
 */
cljs.core$macros.goog_define = (function cljs$core$macros$goog_define(_AMPERSAND_form,_AMPERSAND_env,sym,default$){
if((typeof default$ === 'string') || (typeof default$ === 'number') || (default$ === true) || (default$ === false)){
} else {
throw cljs.core.ex_info.call(null,"goog-define requires a string, number or boolean as default value",cljs.core.PersistentArrayMap.EMPTY);
}


var defname = cljs.compiler.munge.call(null,[cljs.core.str(cljs.core._STAR_ns_STAR_),cljs.core.str("/"),cljs.core.str(sym)].join(''));
var type = ((typeof default$ === 'string')?"string":((typeof default$ === 'number')?"number":(((default$ === true) || (default$ === false))?"boolean":null)));
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"do","do",1686842252,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","declare","cljs.core$macros/declare",1172642527,null)),(function (){var x__23746__auto__ = cljs.core.symbol.call(null,sym);
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"js*","js*",-1134233646,null)),(function (){var x__23746__auto__ = [cljs.core.str("/** @define {"),cljs.core.str(type),cljs.core.str("} */")].join('');
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("goog","define","goog/define",-352722538,null)),(function (){var x__23746__auto__ = defname;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = default$;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
});

cljs.core$macros.goog_define.cljs$lang$macro = true;
/**
 * binding => binding-form init-expr
 * 
 *   Evaluates the exprs in a lexical context in which the symbols in
 *   the binding-forms are bound to their respective init-exprs or parts
 *   therein.
 */
cljs.core$macros.let$ = (function cljs$core$macros$let(var_args){
var args__23989__auto__ = [];
var len__23982__auto___28468 = arguments.length;
var i__23983__auto___28469 = (0);
while(true){
if((i__23983__auto___28469 < len__23982__auto___28468)){
args__23989__auto__.push((arguments[i__23983__auto___28469]));

var G__28470 = (i__23983__auto___28469 + (1));
i__23983__auto___28469 = G__28470;
continue;
} else {
}
break;
}

var argseq__23990__auto__ = ((((3) < args__23989__auto__.length))?(new cljs.core.IndexedSeq(args__23989__auto__.slice((3)),(0),null)):null);
return cljs.core$macros.let$.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),argseq__23990__auto__);
});

cljs.core$macros.let$.cljs$core$IFn$_invoke$arity$variadic = (function (_AMPERSAND_form,_AMPERSAND_env,bindings,body){
if(cljs.core.vector_QMARK_.call(null,bindings)){
} else {
throw cljs.core.ex_info.call(null,"let requires a vector for its binding",cljs.core.PersistentArrayMap.EMPTY);
}

if(cljs.core.even_QMARK_.call(null,cljs.core.count.call(null,bindings))){
} else {
throw cljs.core.ex_info.call(null,"let requires an even number of forms in binding vector",cljs.core.PersistentArrayMap.EMPTY);
}


return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"let*","let*",1920721458,null)),(function (){var x__23746__auto__ = cljs.core$macros.destructure.call(null,bindings);
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),body)));
});

cljs.core$macros.let$.cljs$lang$maxFixedArity = (3);

cljs.core$macros.let$.cljs$lang$applyTo = (function (seq28464){
var G__28465 = cljs.core.first.call(null,seq28464);
var seq28464__$1 = cljs.core.next.call(null,seq28464);
var G__28466 = cljs.core.first.call(null,seq28464__$1);
var seq28464__$2 = cljs.core.next.call(null,seq28464__$1);
var G__28467 = cljs.core.first.call(null,seq28464__$2);
var seq28464__$3 = cljs.core.next.call(null,seq28464__$2);
return cljs.core$macros.let$.cljs$core$IFn$_invoke$arity$variadic(G__28465,G__28466,G__28467,seq28464__$3);
});

cljs.core$macros.let$.cljs$lang$macro = true;
/**
 * Evaluates the exprs in a lexical context in which the symbols in
 *   the binding-forms are bound to their respective init-exprs or parts
 *   therein. Acts as a recur target.
 */
cljs.core$macros.loop = (function cljs$core$macros$loop(var_args){
var args__23989__auto__ = [];
var len__23982__auto___28477 = arguments.length;
var i__23983__auto___28478 = (0);
while(true){
if((i__23983__auto___28478 < len__23982__auto___28477)){
args__23989__auto__.push((arguments[i__23983__auto___28478]));

var G__28479 = (i__23983__auto___28478 + (1));
i__23983__auto___28478 = G__28479;
continue;
} else {
}
break;
}

var argseq__23990__auto__ = ((((3) < args__23989__auto__.length))?(new cljs.core.IndexedSeq(args__23989__auto__.slice((3)),(0),null)):null);
return cljs.core$macros.loop.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),argseq__23990__auto__);
});

cljs.core$macros.loop.cljs$core$IFn$_invoke$arity$variadic = (function (_AMPERSAND_form,_AMPERSAND_env,bindings,body){
if(cljs.core.vector_QMARK_.call(null,bindings)){
} else {
throw cljs.core.ex_info.call(null,"loop requires a vector for its binding",cljs.core.PersistentArrayMap.EMPTY);
}

if(cljs.core.even_QMARK_.call(null,cljs.core.count.call(null,bindings))){
} else {
throw cljs.core.ex_info.call(null,"loop requires an even number of forms in binding vector",cljs.core.PersistentArrayMap.EMPTY);
}


var db = cljs.core$macros.destructure.call(null,bindings);
if(cljs.core._EQ_.call(null,db,bindings)){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"loop*","loop*",615029416,null)),(function (){var x__23746__auto__ = bindings;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),body)));
} else {
var vs = cljs.core.take_nth.call(null,(2),cljs.core.drop.call(null,(1),bindings));
var bs = cljs.core.take_nth.call(null,(2),bindings);
var gs = cljs.core.map.call(null,((function (vs,bs,db){
return (function (b){
if((b instanceof cljs.core.Symbol)){
return b;
} else {
return cljs.core.gensym.call(null);
}
});})(vs,bs,db))
,bs);
var bfs = cljs.core.reduce.call(null,((function (vs,bs,gs,db){
return (function (ret,p__28475){
var vec__28476 = p__28475;
var b = cljs.core.nth.call(null,vec__28476,(0),null);
var v = cljs.core.nth.call(null,vec__28476,(1),null);
var g = cljs.core.nth.call(null,vec__28476,(2),null);
if((b instanceof cljs.core.Symbol)){
return cljs.core.conj.call(null,ret,g,v);
} else {
return cljs.core.conj.call(null,ret,g,v,b,g);
}
});})(vs,bs,gs,db))
,cljs.core.PersistentVector.EMPTY,cljs.core.map.call(null,cljs.core.vector,bs,vs,gs));
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","let","cljs.core$macros/let",-160286726,null)),(function (){var x__23746__auto__ = bfs;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"loop*","loop*",615029416,null)),(function (){var x__23746__auto__ = cljs.core.vec.call(null,cljs.core.interleave.call(null,gs,gs));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","let","cljs.core$macros/let",-160286726,null)),(function (){var x__23746__auto__ = cljs.core.vec.call(null,cljs.core.interleave.call(null,bs,gs));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),body)));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
}
});

cljs.core$macros.loop.cljs$lang$maxFixedArity = (3);

cljs.core$macros.loop.cljs$lang$applyTo = (function (seq28471){
var G__28472 = cljs.core.first.call(null,seq28471);
var seq28471__$1 = cljs.core.next.call(null,seq28471);
var G__28473 = cljs.core.first.call(null,seq28471__$1);
var seq28471__$2 = cljs.core.next.call(null,seq28471__$1);
var G__28474 = cljs.core.first.call(null,seq28471__$2);
var seq28471__$3 = cljs.core.next.call(null,seq28471__$2);
return cljs.core$macros.loop.cljs$core$IFn$_invoke$arity$variadic(G__28472,G__28473,G__28474,seq28471__$3);
});

cljs.core$macros.loop.cljs$lang$macro = true;
/**
 * protocol fqn -> [partition number, bit]
 */
cljs.core$macros.fast_path_protocols = cljs.core.zipmap.call(null,cljs.core.map.call(null,(function (p1__28480_SHARP_){
return cljs.core.symbol.call(null,"cljs.core",[cljs.core.str(p1__28480_SHARP_)].join(''));
}),cljs.core.PersistentVector.fromArray([new cljs.core.Symbol(null,"IFn","IFn",-244881638,null),new cljs.core.Symbol(null,"ICounted","ICounted",-1705786327,null),new cljs.core.Symbol(null,"IEmptyableCollection","IEmptyableCollection",1477271438,null),new cljs.core.Symbol(null,"ICollection","ICollection",-686709190,null),new cljs.core.Symbol(null,"IIndexed","IIndexed",-574812826,null),new cljs.core.Symbol(null,"ASeq","ASeq",266390234,null),new cljs.core.Symbol(null,"ISeq","ISeq",1517365813,null),new cljs.core.Symbol(null,"INext","INext",562211849,null),new cljs.core.Symbol(null,"ILookup","ILookup",784647298,null),new cljs.core.Symbol(null,"IAssociative","IAssociative",-1306431882,null),new cljs.core.Symbol(null,"IMap","IMap",992876629,null),new cljs.core.Symbol(null,"IMapEntry","IMapEntry",-943754199,null),new cljs.core.Symbol(null,"ISet","ISet",-1398072657,null),new cljs.core.Symbol(null,"IStack","IStack",1136769449,null),new cljs.core.Symbol(null,"IVector","IVector",-1120721434,null),new cljs.core.Symbol(null,"IDeref","IDeref",1738423197,null),new cljs.core.Symbol(null,"IDerefWithTimeout","IDerefWithTimeout",2140974319,null),new cljs.core.Symbol(null,"IMeta","IMeta",1095313672,null),new cljs.core.Symbol(null,"IWithMeta","IWithMeta",-509493158,null),new cljs.core.Symbol(null,"IReduce","IReduce",-440384974,null),new cljs.core.Symbol(null,"IKVReduce","IKVReduce",-870856862,null),new cljs.core.Symbol(null,"IEquiv","IEquiv",-1912850869,null),new cljs.core.Symbol(null,"IHash","IHash",-1495374645,null),new cljs.core.Symbol(null,"ISeqable","ISeqable",1349682102,null),new cljs.core.Symbol(null,"ISequential","ISequential",-1626174217,null),new cljs.core.Symbol(null,"IList","IList",1682281311,null),new cljs.core.Symbol(null,"IRecord","IRecord",-903221169,null),new cljs.core.Symbol(null,"IReversible","IReversible",-723048599,null),new cljs.core.Symbol(null,"ISorted","ISorted",-253627362,null),new cljs.core.Symbol(null,"IPrintWithWriter","IPrintWithWriter",-1205316154,null),new cljs.core.Symbol(null,"IWriter","IWriter",-1681087107,null),new cljs.core.Symbol(null,"IPrintWithWriter","IPrintWithWriter",-1205316154,null),new cljs.core.Symbol(null,"IPending","IPending",1229113039,null),new cljs.core.Symbol(null,"IWatchable","IWatchable",-1929659016,null),new cljs.core.Symbol(null,"IEditableCollection","IEditableCollection",-906687187,null),new cljs.core.Symbol(null,"ITransientCollection","ITransientCollection",252832402,null),new cljs.core.Symbol(null,"ITransientAssociative","ITransientAssociative",-1612754624,null),new cljs.core.Symbol(null,"ITransientMap","ITransientMap",298423651,null),new cljs.core.Symbol(null,"ITransientVector","ITransientVector",1978793164,null),new cljs.core.Symbol(null,"ITransientSet","ITransientSet",-575559912,null),new cljs.core.Symbol(null,"IMultiFn","IMultiFn",-1848282794,null),new cljs.core.Symbol(null,"IChunkedSeq","IChunkedSeq",-1299765705,null),new cljs.core.Symbol(null,"IChunkedNext","IChunkedNext",1193289532,null),new cljs.core.Symbol(null,"IComparable","IComparable",1834481627,null),new cljs.core.Symbol(null,"INamed","INamed",357992946,null),new cljs.core.Symbol(null,"ICloneable","ICloneable",1882653160,null),new cljs.core.Symbol(null,"IAtom","IAtom",-1411134312,null),new cljs.core.Symbol(null,"IReset","IReset",-1893729426,null),new cljs.core.Symbol(null,"ISwap","ISwap",484378193,null)], true)),cljs.core.iterate.call(null,(function (p__28481){
var vec__28482 = p__28481;
var p = cljs.core.nth.call(null,vec__28482,(0),null);
var b = cljs.core.nth.call(null,vec__28482,(1),null);
if(((2147483648) === b)){
return new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [(p + (1)),(1)], null);
} else {
return new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [p,((2) * b)], null);
}
}),new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [(0),(1)], null)));
/**
 * total number of partitions
 */
cljs.core$macros.fast_path_protocol_partitions_count = (function (){var c = cljs.core.count.call(null,cljs.core$macros.fast_path_protocols);
var m = cljs.core.mod.call(null,c,(32));
if((m === (0))){
return cljs.core.quot.call(null,c,(32));
} else {
return (cljs.core.quot.call(null,c,(32)) + (1));
}
})();
cljs.core$macros.str = (function cljs$core$macros$str(var_args){
var args__23989__auto__ = [];
var len__23982__auto___28486 = arguments.length;
var i__23983__auto___28487 = (0);
while(true){
if((i__23983__auto___28487 < len__23982__auto___28486)){
args__23989__auto__.push((arguments[i__23983__auto___28487]));

var G__28488 = (i__23983__auto___28487 + (1));
i__23983__auto___28487 = G__28488;
continue;
} else {
}
break;
}

var argseq__23990__auto__ = ((((2) < args__23989__auto__.length))?(new cljs.core.IndexedSeq(args__23989__auto__.slice((2)),(0),null)):null);
return cljs.core$macros.str.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__23990__auto__);
});

cljs.core$macros.str.cljs$core$IFn$_invoke$arity$variadic = (function (_AMPERSAND_form,_AMPERSAND_env,xs){
var strs = cljs.core.apply.call(null,cljs.core.str,cljs.core.interpose.call(null,",",cljs.core.repeat.call(null,cljs.core.count.call(null,xs),"cljs.core.str(~{})")));
return cljs.core.list_STAR_.call(null,new cljs.core.Symbol(null,"js*","js*",-1134233646,null),[cljs.core.str("["),cljs.core.str(strs),cljs.core.str("].join('')")].join(''),xs);
});

cljs.core$macros.str.cljs$lang$maxFixedArity = (2);

cljs.core$macros.str.cljs$lang$applyTo = (function (seq28483){
var G__28484 = cljs.core.first.call(null,seq28483);
var seq28483__$1 = cljs.core.next.call(null,seq28483);
var G__28485 = cljs.core.first.call(null,seq28483__$1);
var seq28483__$2 = cljs.core.next.call(null,seq28483__$1);
return cljs.core$macros.str.cljs$core$IFn$_invoke$arity$variadic(G__28484,G__28485,seq28483__$2);
});

cljs.core$macros.str.cljs$lang$macro = true;
cljs.core$macros.bool_expr = (function cljs$core$macros$bool_expr(e){
return cljs.core.vary_meta.call(null,e,cljs.core.assoc,new cljs.core.Keyword(null,"tag","tag",-1290361223),new cljs.core.Symbol(null,"boolean","boolean",-278886877,null));
});
cljs.core$macros.simple_test_expr_QMARK_ = (function cljs$core$macros$simple_test_expr_QMARK_(env,ast){
var and__22900__auto__ = new cljs.core.PersistentHashSet(null, new cljs.core.PersistentArrayMap(null, 5, [new cljs.core.Keyword(null,"js","js",1768080579),null,new cljs.core.Keyword(null,"constant","constant",-379609303),null,new cljs.core.Keyword(null,"var","var",-769682797),null,new cljs.core.Keyword(null,"invoke","invoke",1145927159),null,new cljs.core.Keyword(null,"dot","dot",1442709401),null], null), null).call(null,new cljs.core.Keyword(null,"op","op",-1882987955).cljs$core$IFn$_invoke$arity$1(ast));
if(cljs.core.truth_(and__22900__auto__)){
return new cljs.core.PersistentHashSet(null, new cljs.core.PersistentArrayMap(null, 2, [new cljs.core.Symbol(null,"seq","seq",-177272256,null),null,new cljs.core.Symbol(null,"boolean","boolean",-278886877,null),null], null), null).call(null,cljs.analyzer.infer_tag.call(null,env,ast));
} else {
return and__22900__auto__;
}
});
/**
 * Evaluates exprs one at a time, from left to right. If a form
 *   returns logical false (nil or false), and returns that value and
 *   doesn't evaluate any of the other expressions, otherwise it returns
 *   the value of the last expr. (and) returns true.
 */
cljs.core$macros.and = (function cljs$core$macros$and(var_args){
var args28492 = [];
var len__23982__auto___28499 = arguments.length;
var i__23983__auto___28500 = (0);
while(true){
if((i__23983__auto___28500 < len__23982__auto___28499)){
args28492.push((arguments[i__23983__auto___28500]));

var G__28501 = (i__23983__auto___28500 + (1));
i__23983__auto___28500 = G__28501;
continue;
} else {
}
break;
}

var G__28498 = args28492.length;
switch (G__28498) {
case 2:
return cljs.core$macros.and.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core$macros.and.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
var argseq__24001__auto__ = (new cljs.core.IndexedSeq(args28492.slice((3)),(0),null));
return cljs.core$macros.and.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),argseq__24001__auto__);

}
});

cljs.core$macros.and.cljs$core$IFn$_invoke$arity$2 = (function (_AMPERSAND_form,_AMPERSAND_env){
return true;
});

cljs.core$macros.and.cljs$core$IFn$_invoke$arity$3 = (function (_AMPERSAND_form,_AMPERSAND_env,x){
return x;
});

cljs.core$macros.and.cljs$core$IFn$_invoke$arity$variadic = (function (_AMPERSAND_form,_AMPERSAND_env,x,next){
var forms = cljs.core.concat.call(null,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [x], null),next);
if(cljs.core.every_QMARK_.call(null,((function (forms){
return (function (p1__28489_SHARP_){
return cljs.core$macros.simple_test_expr_QMARK_.call(null,_AMPERSAND_env,p1__28489_SHARP_);
});})(forms))
,cljs.core.map.call(null,((function (forms){
return (function (p1__28490_SHARP_){
return cljs.analyzer.analyze.call(null,_AMPERSAND_env,p1__28490_SHARP_);
});})(forms))
,forms))){
var and_str = cljs.core.apply.call(null,cljs.core.str,cljs.core.interpose.call(null," && ",cljs.core.repeat.call(null,cljs.core.count.call(null,forms),"(~{})")));
return cljs.core$macros.bool_expr.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"js*","js*",-1134233646,null)),(function (){var x__23746__auto__ = and_str;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),forms))));
} else {
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","let","cljs.core$macros/let",-160286726,null)),(function (){var x__23746__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"and__28491__auto__","and__28491__auto__",-1992480141,null)),(function (){var x__23746__auto__ = x;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})()))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"if","if",1181717262,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"and__28491__auto__","and__28491__auto__",-1992480141,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","and","cljs.core$macros/and",48320334,null)),next)));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"and__28491__auto__","and__28491__auto__",-1992480141,null)))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
}
});

cljs.core$macros.and.cljs$lang$applyTo = (function (seq28493){
var G__28494 = cljs.core.first.call(null,seq28493);
var seq28493__$1 = cljs.core.next.call(null,seq28493);
var G__28495 = cljs.core.first.call(null,seq28493__$1);
var seq28493__$2 = cljs.core.next.call(null,seq28493__$1);
var G__28496 = cljs.core.first.call(null,seq28493__$2);
var seq28493__$3 = cljs.core.next.call(null,seq28493__$2);
return cljs.core$macros.and.cljs$core$IFn$_invoke$arity$variadic(G__28494,G__28495,G__28496,seq28493__$3);
});

cljs.core$macros.and.cljs$lang$maxFixedArity = (3);

cljs.core$macros.and.cljs$lang$macro = true;
/**
 * Evaluates exprs one at a time, from left to right. If a form
 *   returns a logical true value, or returns that value and doesn't
 *   evaluate any of the other expressions, otherwise it returns the
 *   value of the last expression. (or) returns nil.
 */
cljs.core$macros.or = (function cljs$core$macros$or(var_args){
var args28506 = [];
var len__23982__auto___28513 = arguments.length;
var i__23983__auto___28514 = (0);
while(true){
if((i__23983__auto___28514 < len__23982__auto___28513)){
args28506.push((arguments[i__23983__auto___28514]));

var G__28515 = (i__23983__auto___28514 + (1));
i__23983__auto___28514 = G__28515;
continue;
} else {
}
break;
}

var G__28512 = args28506.length;
switch (G__28512) {
case 2:
return cljs.core$macros.or.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core$macros.or.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
var argseq__24001__auto__ = (new cljs.core.IndexedSeq(args28506.slice((3)),(0),null));
return cljs.core$macros.or.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),argseq__24001__auto__);

}
});

cljs.core$macros.or.cljs$core$IFn$_invoke$arity$2 = (function (_AMPERSAND_form,_AMPERSAND_env){
return null;
});

cljs.core$macros.or.cljs$core$IFn$_invoke$arity$3 = (function (_AMPERSAND_form,_AMPERSAND_env,x){
return x;
});

cljs.core$macros.or.cljs$core$IFn$_invoke$arity$variadic = (function (_AMPERSAND_form,_AMPERSAND_env,x,next){
var forms = cljs.core.concat.call(null,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [x], null),next);
if(cljs.core.every_QMARK_.call(null,((function (forms){
return (function (p1__28503_SHARP_){
return cljs.core$macros.simple_test_expr_QMARK_.call(null,_AMPERSAND_env,p1__28503_SHARP_);
});})(forms))
,cljs.core.map.call(null,((function (forms){
return (function (p1__28504_SHARP_){
return cljs.analyzer.analyze.call(null,_AMPERSAND_env,p1__28504_SHARP_);
});})(forms))
,forms))){
var or_str = cljs.core.apply.call(null,cljs.core.str,cljs.core.interpose.call(null," || ",cljs.core.repeat.call(null,cljs.core.count.call(null,forms),"(~{})")));
return cljs.core$macros.bool_expr.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"js*","js*",-1134233646,null)),(function (){var x__23746__auto__ = or_str;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),forms))));
} else {
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","let","cljs.core$macros/let",-160286726,null)),(function (){var x__23746__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"or__28505__auto__","or__28505__auto__",1826291721,null)),(function (){var x__23746__auto__ = x;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})()))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"if","if",1181717262,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"or__28505__auto__","or__28505__auto__",1826291721,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"or__28505__auto__","or__28505__auto__",1826291721,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","or","cljs.core$macros/or",1346243648,null)),next)));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
}
});

cljs.core$macros.or.cljs$lang$applyTo = (function (seq28507){
var G__28508 = cljs.core.first.call(null,seq28507);
var seq28507__$1 = cljs.core.next.call(null,seq28507);
var G__28509 = cljs.core.first.call(null,seq28507__$1);
var seq28507__$2 = cljs.core.next.call(null,seq28507__$1);
var G__28510 = cljs.core.first.call(null,seq28507__$2);
var seq28507__$3 = cljs.core.next.call(null,seq28507__$2);
return cljs.core$macros.or.cljs$core$IFn$_invoke$arity$variadic(G__28508,G__28509,G__28510,seq28507__$3);
});

cljs.core$macros.or.cljs$lang$maxFixedArity = (3);

cljs.core$macros.or.cljs$lang$macro = true;
cljs.core$macros.nil_QMARK_ = (function cljs$core$macros$nil_QMARK_(_AMPERSAND_form,_AMPERSAND_env,x){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","coercive-=","cljs.core$macros/coercive-=",-1655776086,null)),(function (){var x__23746__auto__ = x;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,null))));
});

cljs.core$macros.nil_QMARK_.cljs$lang$macro = true;
cljs.core$macros.coercive_not = (function cljs$core$macros$coercive_not(_AMPERSAND_form,_AMPERSAND_env,x){
return cljs.core$macros.bool_expr.call(null,cljs.core._conj.call(null,cljs.core._conj.call(null,(function (){var x__23746__auto__ = x;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),"(!~{})"),new cljs.core.Symbol(null,"js*","js*",-1134233646,null)));
});

cljs.core$macros.coercive_not.cljs$lang$macro = true;
cljs.core$macros.coercive_not_EQ_ = (function cljs$core$macros$coercive_not_EQ_(_AMPERSAND_form,_AMPERSAND_env,x,y){
return cljs.core$macros.bool_expr.call(null,cljs.core._conj.call(null,cljs.core._conj.call(null,(function (){var x__23746__auto__ = x;
return cljs.core._conj.call(null,(function (){var x__23746__auto____$1 = y;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto____$1);
})(),x__23746__auto__);
})(),"(~{} != ~{})"),new cljs.core.Symbol(null,"js*","js*",-1134233646,null)));
});

cljs.core$macros.coercive_not_EQ_.cljs$lang$macro = true;
cljs.core$macros.coercive__EQ_ = (function cljs$core$macros$coercive__EQ_(_AMPERSAND_form,_AMPERSAND_env,x,y){
return cljs.core$macros.bool_expr.call(null,cljs.core._conj.call(null,cljs.core._conj.call(null,(function (){var x__23746__auto__ = x;
return cljs.core._conj.call(null,(function (){var x__23746__auto____$1 = y;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto____$1);
})(),x__23746__auto__);
})(),"(~{} == ~{})"),new cljs.core.Symbol(null,"js*","js*",-1134233646,null)));
});

cljs.core$macros.coercive__EQ_.cljs$lang$macro = true;
cljs.core$macros.coercive_boolean = (function cljs$core$macros$coercive_boolean(_AMPERSAND_form,_AMPERSAND_env,x){
return cljs.core.with_meta.call(null,cljs.core._conj.call(null,cljs.core._conj.call(null,(function (){var x__23746__auto__ = x;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),"~{}"),new cljs.core.Symbol(null,"js*","js*",-1134233646,null)),new cljs.core.PersistentArrayMap(null, 1, [new cljs.core.Keyword(null,"tag","tag",-1290361223),new cljs.core.Symbol(null,"boolean","boolean",-278886877,null)], null));
});

cljs.core$macros.coercive_boolean.cljs$lang$macro = true;
cljs.core$macros.truth_ = (function cljs$core$macros$truth_(_AMPERSAND_form,_AMPERSAND_env,x){
if((x instanceof cljs.core.Symbol)){
} else {
throw (new Error([cljs.core.str("Assert failed: "),cljs.core.str("x is substituted twice"),cljs.core.str("\n"),cljs.core.str("(core/symbol? x)")].join('')));
}

return cljs.core._conj.call(null,cljs.core._conj.call(null,(function (){var x__23746__auto__ = x;
return cljs.core._conj.call(null,(function (){var x__23746__auto____$1 = x;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto____$1);
})(),x__23746__auto__);
})(),"(~{} != null && ~{} !== false)"),new cljs.core.Symbol(null,"js*","js*",-1134233646,null));
});

cljs.core$macros.truth_.cljs$lang$macro = true;
cljs.core$macros.js_arguments = (function cljs$core$macros$js_arguments(_AMPERSAND_form,_AMPERSAND_env){
return cljs.core._conj.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,"arguments"),new cljs.core.Symbol(null,"js*","js*",-1134233646,null));
});

cljs.core$macros.js_arguments.cljs$lang$macro = true;
cljs.core$macros.js_delete = (function cljs$core$macros$js_delete(_AMPERSAND_form,_AMPERSAND_env,obj,key){
return cljs.core._conj.call(null,cljs.core._conj.call(null,(function (){var x__23746__auto__ = obj;
return cljs.core._conj.call(null,(function (){var x__23746__auto____$1 = key;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto____$1);
})(),x__23746__auto__);
})(),"delete ~{}[~{}]"),new cljs.core.Symbol(null,"js*","js*",-1134233646,null));
});

cljs.core$macros.js_delete.cljs$lang$macro = true;
cljs.core$macros.js_in = (function cljs$core$macros$js_in(_AMPERSAND_form,_AMPERSAND_env,key,obj){
return cljs.core._conj.call(null,cljs.core._conj.call(null,(function (){var x__23746__auto__ = key;
return cljs.core._conj.call(null,(function (){var x__23746__auto____$1 = obj;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto____$1);
})(),x__23746__auto__);
})(),"~{} in ~{}"),new cljs.core.Symbol(null,"js*","js*",-1134233646,null));
});

cljs.core$macros.js_in.cljs$lang$macro = true;
/**
 * Emit JavaScript "debugger;" statement
 */
cljs.core$macros.js_debugger = (function cljs$core$macros$js_debugger(_AMPERSAND_form,_AMPERSAND_env){
return cljs.core._conj.call(null,(function (){var x__23746__auto__ = cljs.core._conj.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,"debugger"),new cljs.core.Symbol(null,"js*","js*",-1134233646,null));
return cljs.core._conj.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,null),x__23746__auto__);
})(),new cljs.core.Symbol(null,"do","do",1686842252,null));
});

cljs.core$macros.js_debugger.cljs$lang$macro = true;
/**
 * Emit a top-level JavaScript multi-line comment. New lines will create a
 *   new comment line. Comment block will be preceded and followed by a newline
 */
cljs.core$macros.js_comment = (function cljs$core$macros$js_comment(_AMPERSAND_form,_AMPERSAND_env,comment){
var vec__28519 = clojure.string.split.call(null,comment,/\n/);
var x = cljs.core.nth.call(null,vec__28519,(0),null);
var ys = cljs.core.nthnext.call(null,vec__28519,(1));
return cljs.core._conj.call(null,(function (){var x__23746__auto__ = [cljs.core.str("\n/**\n"),cljs.core.str([cljs.core.str(" * "),cljs.core.str(x),cljs.core.str("\n")].join('')),cljs.core.str(cljs.core.reduce.call(null,cljs.core.str,"",cljs.core.map.call(null,((function (vec__28519,x,ys){
return (function (p1__28517_SHARP_){
return [cljs.core.str(" * "),cljs.core.str(clojure.string.replace.call(null,p1__28517_SHARP_,/^   /,"")),cljs.core.str("\n")].join('');
});})(vec__28519,x,ys))
,ys))),cljs.core.str(" */\n")].join('');
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),new cljs.core.Symbol(null,"js*","js*",-1134233646,null));
});

cljs.core$macros.js_comment.cljs$lang$macro = true;
/**
 * EXPERIMENTAL: Subject to change. Unsafely cast a value to a different type.
 */
cljs.core$macros.unsafe_cast = (function cljs$core$macros$unsafe_cast(_AMPERSAND_form,_AMPERSAND_env,t,x){
var cast_expr = [cljs.core.str("~{} = /** @type {"),cljs.core.str(t),cljs.core.str("} */ (~{})")].join('');
return cljs.core._conj.call(null,(function (){var x__23746__auto__ = cast_expr;
return cljs.core._conj.call(null,(function (){var x__23746__auto____$1 = x;
return cljs.core._conj.call(null,(function (){var x__23746__auto____$2 = x;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto____$2);
})(),x__23746__auto____$1);
})(),x__23746__auto__);
})(),new cljs.core.Symbol(null,"js*","js*",-1134233646,null));
});

cljs.core$macros.unsafe_cast.cljs$lang$macro = true;
/**
 * Emit an inline JavaScript comment.
 */
cljs.core$macros.js_inline_comment = (function cljs$core$macros$js_inline_comment(_AMPERSAND_form,_AMPERSAND_env,comment){
return cljs.core._conj.call(null,(function (){var x__23746__auto__ = [cljs.core.str("/**"),cljs.core.str(comment),cljs.core.str("*/")].join('');
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),new cljs.core.Symbol(null,"js*","js*",-1134233646,null));
});

cljs.core$macros.js_inline_comment.cljs$lang$macro = true;
cljs.core$macros.true_QMARK_ = (function cljs$core$macros$true_QMARK_(_AMPERSAND_form,_AMPERSAND_env,x){
return cljs.core$macros.bool_expr.call(null,cljs.core._conj.call(null,cljs.core._conj.call(null,(function (){var x__23746__auto__ = x;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),"~{} === true"),new cljs.core.Symbol(null,"js*","js*",-1134233646,null)));
});

cljs.core$macros.true_QMARK_.cljs$lang$macro = true;
cljs.core$macros.false_QMARK_ = (function cljs$core$macros$false_QMARK_(_AMPERSAND_form,_AMPERSAND_env,x){
return cljs.core$macros.bool_expr.call(null,cljs.core._conj.call(null,cljs.core._conj.call(null,(function (){var x__23746__auto__ = x;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),"~{} === false"),new cljs.core.Symbol(null,"js*","js*",-1134233646,null)));
});

cljs.core$macros.false_QMARK_.cljs$lang$macro = true;
cljs.core$macros.string_QMARK_ = (function cljs$core$macros$string_QMARK_(_AMPERSAND_form,_AMPERSAND_env,x){
return cljs.core$macros.bool_expr.call(null,cljs.core._conj.call(null,cljs.core._conj.call(null,(function (){var x__23746__auto__ = x;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),"typeof ~{} === 'string'"),new cljs.core.Symbol(null,"js*","js*",-1134233646,null)));
});

cljs.core$macros.string_QMARK_.cljs$lang$macro = true;
/**
 * Return true if argument exists, analogous to usage of typeof operator
 * in JavaScript.
 */
cljs.core$macros.exists_QMARK_ = (function cljs$core$macros$exists_QMARK_(_AMPERSAND_form,_AMPERSAND_env,x){
return cljs.core$macros.bool_expr.call(null,cljs.core._conj.call(null,cljs.core._conj.call(null,(function (){var x__23746__auto__ = cljs.core.vary_meta.call(null,x,cljs.core.assoc,new cljs.core.Keyword("cljs.analyzer","no-resolve","cljs.analyzer/no-resolve",-1872351017),true);
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),"typeof ~{} !== 'undefined'"),new cljs.core.Symbol(null,"js*","js*",-1134233646,null)));
});

cljs.core$macros.exists_QMARK_.cljs$lang$macro = true;
/**
 * Return true if argument is identical to the JavaScript undefined value.
 */
cljs.core$macros.undefined_QMARK_ = (function cljs$core$macros$undefined_QMARK_(_AMPERSAND_form,_AMPERSAND_env,x){
return cljs.core$macros.bool_expr.call(null,cljs.core._conj.call(null,cljs.core._conj.call(null,(function (){var x__23746__auto__ = x;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),"(void 0 === ~{})"),new cljs.core.Symbol(null,"js*","js*",-1134233646,null)));
});

cljs.core$macros.undefined_QMARK_.cljs$lang$macro = true;
cljs.core$macros.identical_QMARK_ = (function cljs$core$macros$identical_QMARK_(_AMPERSAND_form,_AMPERSAND_env,a,b){
return cljs.core$macros.bool_expr.call(null,cljs.core._conj.call(null,cljs.core._conj.call(null,(function (){var x__23746__auto__ = a;
return cljs.core._conj.call(null,(function (){var x__23746__auto____$1 = b;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto____$1);
})(),x__23746__auto__);
})(),"(~{} === ~{})"),new cljs.core.Symbol(null,"js*","js*",-1134233646,null)));
});

cljs.core$macros.identical_QMARK_.cljs$lang$macro = true;
cljs.core$macros.instance_QMARK_ = (function cljs$core$macros$instance_QMARK_(_AMPERSAND_form,_AMPERSAND_env,c,x){
return cljs.core$macros.bool_expr.call(null,(((c instanceof cljs.core.Symbol))?cljs.core._conj.call(null,cljs.core._conj.call(null,(function (){var x__23746__auto__ = x;
return cljs.core._conj.call(null,(function (){var x__23746__auto____$1 = c;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto____$1);
})(),x__23746__auto__);
})(),"(~{} instanceof ~{})"),new cljs.core.Symbol(null,"js*","js*",-1134233646,null)):cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","let","cljs.core$macros/let",-160286726,null)),(function (){var x__23746__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"c__28520__auto__","c__28520__auto__",483937587,null)),(function (){var x__23746__auto__ = c;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"x__28521__auto__","x__28521__auto__",-2073569994,null)),(function (){var x__23746__auto__ = x;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})()))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"js*","js*",-1134233646,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,"(~{} instanceof ~{})"),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"x__28521__auto__","x__28521__auto__",-2073569994,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"c__28520__auto__","c__28520__auto__",483937587,null)))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())))));
});

cljs.core$macros.instance_QMARK_.cljs$lang$macro = true;
cljs.core$macros.number_QMARK_ = (function cljs$core$macros$number_QMARK_(_AMPERSAND_form,_AMPERSAND_env,x){
return cljs.core$macros.bool_expr.call(null,cljs.core._conj.call(null,cljs.core._conj.call(null,(function (){var x__23746__auto__ = x;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),"typeof ~{} === 'number'"),new cljs.core.Symbol(null,"js*","js*",-1134233646,null)));
});

cljs.core$macros.number_QMARK_.cljs$lang$macro = true;
cljs.core$macros.symbol_QMARK_ = (function cljs$core$macros$symbol_QMARK_(_AMPERSAND_form,_AMPERSAND_env,x){
return cljs.core$macros.bool_expr.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","instance?","cljs.core$macros/instance?",1829750179,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","Symbol","cljs.core/Symbol",292989338,null)),(function (){var x__23746__auto__ = x;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})()))));
});

cljs.core$macros.symbol_QMARK_.cljs$lang$macro = true;
cljs.core$macros.keyword_QMARK_ = (function cljs$core$macros$keyword_QMARK_(_AMPERSAND_form,_AMPERSAND_env,x){
return cljs.core$macros.bool_expr.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","instance?","cljs.core$macros/instance?",1829750179,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","Keyword","cljs.core/Keyword",-451434488,null)),(function (){var x__23746__auto__ = x;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})()))));
});

cljs.core$macros.keyword_QMARK_.cljs$lang$macro = true;
cljs.core$macros.aget = (function cljs$core$macros$aget(var_args){
var args28522 = [];
var len__23982__auto___28530 = arguments.length;
var i__23983__auto___28531 = (0);
while(true){
if((i__23983__auto___28531 < len__23982__auto___28530)){
args28522.push((arguments[i__23983__auto___28531]));

var G__28532 = (i__23983__auto___28531 + (1));
i__23983__auto___28531 = G__28532;
continue;
} else {
}
break;
}

var G__28529 = args28522.length;
switch (G__28529) {
case 4:
return cljs.core$macros.aget.cljs$core$IFn$_invoke$arity$4((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]));

break;
default:
var argseq__24001__auto__ = (new cljs.core.IndexedSeq(args28522.slice((4)),(0),null));
return cljs.core$macros.aget.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]),argseq__24001__auto__);

}
});

cljs.core$macros.aget.cljs$core$IFn$_invoke$arity$4 = (function (_AMPERSAND_form,_AMPERSAND_env,a,i){
return cljs.core._conj.call(null,cljs.core._conj.call(null,(function (){var x__23746__auto__ = a;
return cljs.core._conj.call(null,(function (){var x__23746__auto____$1 = i;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto____$1);
})(),x__23746__auto__);
})(),"(~{}[~{}])"),new cljs.core.Symbol(null,"js*","js*",-1134233646,null));
});

cljs.core$macros.aget.cljs$core$IFn$_invoke$arity$variadic = (function (_AMPERSAND_form,_AMPERSAND_env,a,i,idxs){
var astr = cljs.core.apply.call(null,cljs.core.str,cljs.core.repeat.call(null,cljs.core.count.call(null,idxs),"[~{}]"));
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"js*","js*",-1134233646,null)),(function (){var x__23746__auto__ = [cljs.core.str("(~{}[~{}]"),cljs.core.str(astr),cljs.core.str(")")].join('');
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = a;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = i;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),idxs)));
});

cljs.core$macros.aget.cljs$lang$applyTo = (function (seq28523){
var G__28524 = cljs.core.first.call(null,seq28523);
var seq28523__$1 = cljs.core.next.call(null,seq28523);
var G__28525 = cljs.core.first.call(null,seq28523__$1);
var seq28523__$2 = cljs.core.next.call(null,seq28523__$1);
var G__28526 = cljs.core.first.call(null,seq28523__$2);
var seq28523__$3 = cljs.core.next.call(null,seq28523__$2);
var G__28527 = cljs.core.first.call(null,seq28523__$3);
var seq28523__$4 = cljs.core.next.call(null,seq28523__$3);
return cljs.core$macros.aget.cljs$core$IFn$_invoke$arity$variadic(G__28524,G__28525,G__28526,G__28527,seq28523__$4);
});

cljs.core$macros.aget.cljs$lang$maxFixedArity = (4);

cljs.core$macros.aget.cljs$lang$macro = true;
cljs.core$macros.aset = (function cljs$core$macros$aset(var_args){
var args28534 = [];
var len__23982__auto___28543 = arguments.length;
var i__23983__auto___28544 = (0);
while(true){
if((i__23983__auto___28544 < len__23982__auto___28543)){
args28534.push((arguments[i__23983__auto___28544]));

var G__28545 = (i__23983__auto___28544 + (1));
i__23983__auto___28544 = G__28545;
continue;
} else {
}
break;
}

var G__28542 = args28534.length;
switch (G__28542) {
case 5:
return cljs.core$macros.aset.cljs$core$IFn$_invoke$arity$5((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]),(arguments[(4)]));

break;
default:
var argseq__24001__auto__ = (new cljs.core.IndexedSeq(args28534.slice((5)),(0),null));
return cljs.core$macros.aset.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]),(arguments[(4)]),argseq__24001__auto__);

}
});

cljs.core$macros.aset.cljs$core$IFn$_invoke$arity$5 = (function (_AMPERSAND_form,_AMPERSAND_env,a,i,v){
return cljs.core._conj.call(null,cljs.core._conj.call(null,(function (){var x__23746__auto__ = a;
return cljs.core._conj.call(null,(function (){var x__23746__auto____$1 = i;
return cljs.core._conj.call(null,(function (){var x__23746__auto____$2 = v;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto____$2);
})(),x__23746__auto____$1);
})(),x__23746__auto__);
})(),"(~{}[~{}] = ~{})"),new cljs.core.Symbol(null,"js*","js*",-1134233646,null));
});

cljs.core$macros.aset.cljs$core$IFn$_invoke$arity$variadic = (function (_AMPERSAND_form,_AMPERSAND_env,a,idx,idx2,idxv){
var n = (cljs.core.count.call(null,idxv) - (1));
var astr = cljs.core.apply.call(null,cljs.core.str,cljs.core.repeat.call(null,n,"[~{}]"));
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"js*","js*",-1134233646,null)),(function (){var x__23746__auto__ = [cljs.core.str("(~{}[~{}][~{}]"),cljs.core.str(astr),cljs.core.str(" = ~{})")].join('');
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = a;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = idx;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = idx2;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),idxv)));
});

cljs.core$macros.aset.cljs$lang$applyTo = (function (seq28535){
var G__28536 = cljs.core.first.call(null,seq28535);
var seq28535__$1 = cljs.core.next.call(null,seq28535);
var G__28537 = cljs.core.first.call(null,seq28535__$1);
var seq28535__$2 = cljs.core.next.call(null,seq28535__$1);
var G__28538 = cljs.core.first.call(null,seq28535__$2);
var seq28535__$3 = cljs.core.next.call(null,seq28535__$2);
var G__28539 = cljs.core.first.call(null,seq28535__$3);
var seq28535__$4 = cljs.core.next.call(null,seq28535__$3);
var G__28540 = cljs.core.first.call(null,seq28535__$4);
var seq28535__$5 = cljs.core.next.call(null,seq28535__$4);
return cljs.core$macros.aset.cljs$core$IFn$_invoke$arity$variadic(G__28536,G__28537,G__28538,G__28539,G__28540,seq28535__$5);
});

cljs.core$macros.aset.cljs$lang$maxFixedArity = (5);

cljs.core$macros.aset.cljs$lang$macro = true;
cljs.core$macros._PLUS_ = (function cljs$core$macros$_PLUS_(var_args){
var args28547 = [];
var len__23982__auto___28555 = arguments.length;
var i__23983__auto___28556 = (0);
while(true){
if((i__23983__auto___28556 < len__23982__auto___28555)){
args28547.push((arguments[i__23983__auto___28556]));

var G__28557 = (i__23983__auto___28556 + (1));
i__23983__auto___28556 = G__28557;
continue;
} else {
}
break;
}

var G__28554 = args28547.length;
switch (G__28554) {
case 2:
return cljs.core$macros._PLUS_.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core$macros._PLUS_.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
case 4:
return cljs.core$macros._PLUS_.cljs$core$IFn$_invoke$arity$4((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]));

break;
default:
var argseq__24001__auto__ = (new cljs.core.IndexedSeq(args28547.slice((4)),(0),null));
return cljs.core$macros._PLUS_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]),argseq__24001__auto__);

}
});

cljs.core$macros._PLUS_.cljs$core$IFn$_invoke$arity$2 = (function (_AMPERSAND_form,_AMPERSAND_env){
return (0);
});

cljs.core$macros._PLUS_.cljs$core$IFn$_invoke$arity$3 = (function (_AMPERSAND_form,_AMPERSAND_env,x){
return x;
});

cljs.core$macros._PLUS_.cljs$core$IFn$_invoke$arity$4 = (function (_AMPERSAND_form,_AMPERSAND_env,x,y){
return cljs.core._conj.call(null,cljs.core._conj.call(null,(function (){var x__23746__auto__ = x;
return cljs.core._conj.call(null,(function (){var x__23746__auto____$1 = y;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto____$1);
})(),x__23746__auto__);
})(),"(~{} + ~{})"),new cljs.core.Symbol(null,"js*","js*",-1134233646,null));
});

cljs.core$macros._PLUS_.cljs$core$IFn$_invoke$arity$variadic = (function (_AMPERSAND_form,_AMPERSAND_env,x,y,more){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","+","cljs.core$macros/+",-18260342,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","+","cljs.core$macros/+",-18260342,null)),(function (){var x__23746__auto__ = x;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = y;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),more)));
});

cljs.core$macros._PLUS_.cljs$lang$applyTo = (function (seq28548){
var G__28549 = cljs.core.first.call(null,seq28548);
var seq28548__$1 = cljs.core.next.call(null,seq28548);
var G__28550 = cljs.core.first.call(null,seq28548__$1);
var seq28548__$2 = cljs.core.next.call(null,seq28548__$1);
var G__28551 = cljs.core.first.call(null,seq28548__$2);
var seq28548__$3 = cljs.core.next.call(null,seq28548__$2);
var G__28552 = cljs.core.first.call(null,seq28548__$3);
var seq28548__$4 = cljs.core.next.call(null,seq28548__$3);
return cljs.core$macros._PLUS_.cljs$core$IFn$_invoke$arity$variadic(G__28549,G__28550,G__28551,G__28552,seq28548__$4);
});

cljs.core$macros._PLUS_.cljs$lang$maxFixedArity = (4);

cljs.core$macros._PLUS_.cljs$lang$macro = true;
cljs.core$macros.byte$ = (function cljs$core$macros$byte(_AMPERSAND_form,_AMPERSAND_env,x){
return x;
});

cljs.core$macros.byte$.cljs$lang$macro = true;
cljs.core$macros.short$ = (function cljs$core$macros$short(_AMPERSAND_form,_AMPERSAND_env,x){
return x;
});

cljs.core$macros.short$.cljs$lang$macro = true;
cljs.core$macros.float$ = (function cljs$core$macros$float(_AMPERSAND_form,_AMPERSAND_env,x){
return x;
});

cljs.core$macros.float$.cljs$lang$macro = true;
cljs.core$macros.double$ = (function cljs$core$macros$double(_AMPERSAND_form,_AMPERSAND_env,x){
return x;
});

cljs.core$macros.double$.cljs$lang$macro = true;
cljs.core$macros.unchecked_byte = (function cljs$core$macros$unchecked_byte(_AMPERSAND_form,_AMPERSAND_env,x){
return x;
});

cljs.core$macros.unchecked_byte.cljs$lang$macro = true;
cljs.core$macros.unchecked_char = (function cljs$core$macros$unchecked_char(_AMPERSAND_form,_AMPERSAND_env,x){
return x;
});

cljs.core$macros.unchecked_char.cljs$lang$macro = true;
cljs.core$macros.unchecked_short = (function cljs$core$macros$unchecked_short(_AMPERSAND_form,_AMPERSAND_env,x){
return x;
});

cljs.core$macros.unchecked_short.cljs$lang$macro = true;
cljs.core$macros.unchecked_float = (function cljs$core$macros$unchecked_float(_AMPERSAND_form,_AMPERSAND_env,x){
return x;
});

cljs.core$macros.unchecked_float.cljs$lang$macro = true;
cljs.core$macros.unchecked_double = (function cljs$core$macros$unchecked_double(_AMPERSAND_form,_AMPERSAND_env,x){
return x;
});

cljs.core$macros.unchecked_double.cljs$lang$macro = true;
cljs.core$macros.unchecked_add = (function cljs$core$macros$unchecked_add(var_args){
var args__23989__auto__ = [];
var len__23982__auto___28562 = arguments.length;
var i__23983__auto___28563 = (0);
while(true){
if((i__23983__auto___28563 < len__23982__auto___28562)){
args__23989__auto__.push((arguments[i__23983__auto___28563]));

var G__28564 = (i__23983__auto___28563 + (1));
i__23983__auto___28563 = G__28564;
continue;
} else {
}
break;
}

var argseq__23990__auto__ = ((((2) < args__23989__auto__.length))?(new cljs.core.IndexedSeq(args__23989__auto__.slice((2)),(0),null)):null);
return cljs.core$macros.unchecked_add.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__23990__auto__);
});

cljs.core$macros.unchecked_add.cljs$core$IFn$_invoke$arity$variadic = (function (_AMPERSAND_form,_AMPERSAND_env,xs){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","+","cljs.core$macros/+",-18260342,null)),xs)));
});

cljs.core$macros.unchecked_add.cljs$lang$maxFixedArity = (2);

cljs.core$macros.unchecked_add.cljs$lang$applyTo = (function (seq28559){
var G__28560 = cljs.core.first.call(null,seq28559);
var seq28559__$1 = cljs.core.next.call(null,seq28559);
var G__28561 = cljs.core.first.call(null,seq28559__$1);
var seq28559__$2 = cljs.core.next.call(null,seq28559__$1);
return cljs.core$macros.unchecked_add.cljs$core$IFn$_invoke$arity$variadic(G__28560,G__28561,seq28559__$2);
});

cljs.core$macros.unchecked_add.cljs$lang$macro = true;
cljs.core$macros.unchecked_add_int = (function cljs$core$macros$unchecked_add_int(var_args){
var args__23989__auto__ = [];
var len__23982__auto___28568 = arguments.length;
var i__23983__auto___28569 = (0);
while(true){
if((i__23983__auto___28569 < len__23982__auto___28568)){
args__23989__auto__.push((arguments[i__23983__auto___28569]));

var G__28570 = (i__23983__auto___28569 + (1));
i__23983__auto___28569 = G__28570;
continue;
} else {
}
break;
}

var argseq__23990__auto__ = ((((2) < args__23989__auto__.length))?(new cljs.core.IndexedSeq(args__23989__auto__.slice((2)),(0),null)):null);
return cljs.core$macros.unchecked_add_int.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__23990__auto__);
});

cljs.core$macros.unchecked_add_int.cljs$core$IFn$_invoke$arity$variadic = (function (_AMPERSAND_form,_AMPERSAND_env,xs){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","+","cljs.core$macros/+",-18260342,null)),xs)));
});

cljs.core$macros.unchecked_add_int.cljs$lang$maxFixedArity = (2);

cljs.core$macros.unchecked_add_int.cljs$lang$applyTo = (function (seq28565){
var G__28566 = cljs.core.first.call(null,seq28565);
var seq28565__$1 = cljs.core.next.call(null,seq28565);
var G__28567 = cljs.core.first.call(null,seq28565__$1);
var seq28565__$2 = cljs.core.next.call(null,seq28565__$1);
return cljs.core$macros.unchecked_add_int.cljs$core$IFn$_invoke$arity$variadic(G__28566,G__28567,seq28565__$2);
});

cljs.core$macros.unchecked_add_int.cljs$lang$macro = true;
cljs.core$macros.unchecked_dec = (function cljs$core$macros$unchecked_dec(_AMPERSAND_form,_AMPERSAND_env,x){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","dec","cljs.core$macros/dec",-247694061,null)),(function (){var x__23746__auto__ = x;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
});

cljs.core$macros.unchecked_dec.cljs$lang$macro = true;
cljs.core$macros.unchecked_dec_int = (function cljs$core$macros$unchecked_dec_int(_AMPERSAND_form,_AMPERSAND_env,x){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","dec","cljs.core$macros/dec",-247694061,null)),(function (){var x__23746__auto__ = x;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
});

cljs.core$macros.unchecked_dec_int.cljs$lang$macro = true;
cljs.core$macros.unchecked_divide_int = (function cljs$core$macros$unchecked_divide_int(var_args){
var args__23989__auto__ = [];
var len__23982__auto___28574 = arguments.length;
var i__23983__auto___28575 = (0);
while(true){
if((i__23983__auto___28575 < len__23982__auto___28574)){
args__23989__auto__.push((arguments[i__23983__auto___28575]));

var G__28576 = (i__23983__auto___28575 + (1));
i__23983__auto___28575 = G__28576;
continue;
} else {
}
break;
}

var argseq__23990__auto__ = ((((2) < args__23989__auto__.length))?(new cljs.core.IndexedSeq(args__23989__auto__.slice((2)),(0),null)):null);
return cljs.core$macros.unchecked_divide_int.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__23990__auto__);
});

cljs.core$macros.unchecked_divide_int.cljs$core$IFn$_invoke$arity$variadic = (function (_AMPERSAND_form,_AMPERSAND_env,xs){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","/","cljs.core$macros//",-893374331,null)),xs)));
});

cljs.core$macros.unchecked_divide_int.cljs$lang$maxFixedArity = (2);

cljs.core$macros.unchecked_divide_int.cljs$lang$applyTo = (function (seq28571){
var G__28572 = cljs.core.first.call(null,seq28571);
var seq28571__$1 = cljs.core.next.call(null,seq28571);
var G__28573 = cljs.core.first.call(null,seq28571__$1);
var seq28571__$2 = cljs.core.next.call(null,seq28571__$1);
return cljs.core$macros.unchecked_divide_int.cljs$core$IFn$_invoke$arity$variadic(G__28572,G__28573,seq28571__$2);
});

cljs.core$macros.unchecked_divide_int.cljs$lang$macro = true;
cljs.core$macros.unchecked_inc = (function cljs$core$macros$unchecked_inc(_AMPERSAND_form,_AMPERSAND_env,x){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","inc","cljs.core$macros/inc",876629257,null)),(function (){var x__23746__auto__ = x;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
});

cljs.core$macros.unchecked_inc.cljs$lang$macro = true;
cljs.core$macros.unchecked_inc_int = (function cljs$core$macros$unchecked_inc_int(_AMPERSAND_form,_AMPERSAND_env,x){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","inc","cljs.core$macros/inc",876629257,null)),(function (){var x__23746__auto__ = x;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
});

cljs.core$macros.unchecked_inc_int.cljs$lang$macro = true;
cljs.core$macros.unchecked_multiply = (function cljs$core$macros$unchecked_multiply(var_args){
var args__23989__auto__ = [];
var len__23982__auto___28580 = arguments.length;
var i__23983__auto___28581 = (0);
while(true){
if((i__23983__auto___28581 < len__23982__auto___28580)){
args__23989__auto__.push((arguments[i__23983__auto___28581]));

var G__28582 = (i__23983__auto___28581 + (1));
i__23983__auto___28581 = G__28582;
continue;
} else {
}
break;
}

var argseq__23990__auto__ = ((((2) < args__23989__auto__.length))?(new cljs.core.IndexedSeq(args__23989__auto__.slice((2)),(0),null)):null);
return cljs.core$macros.unchecked_multiply.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__23990__auto__);
});

cljs.core$macros.unchecked_multiply.cljs$core$IFn$_invoke$arity$variadic = (function (_AMPERSAND_form,_AMPERSAND_env,xs){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","*","cljs.core$macros/*",946321529,null)),xs)));
});

cljs.core$macros.unchecked_multiply.cljs$lang$maxFixedArity = (2);

cljs.core$macros.unchecked_multiply.cljs$lang$applyTo = (function (seq28577){
var G__28578 = cljs.core.first.call(null,seq28577);
var seq28577__$1 = cljs.core.next.call(null,seq28577);
var G__28579 = cljs.core.first.call(null,seq28577__$1);
var seq28577__$2 = cljs.core.next.call(null,seq28577__$1);
return cljs.core$macros.unchecked_multiply.cljs$core$IFn$_invoke$arity$variadic(G__28578,G__28579,seq28577__$2);
});

cljs.core$macros.unchecked_multiply.cljs$lang$macro = true;
cljs.core$macros.unchecked_multiply_int = (function cljs$core$macros$unchecked_multiply_int(var_args){
var args__23989__auto__ = [];
var len__23982__auto___28586 = arguments.length;
var i__23983__auto___28587 = (0);
while(true){
if((i__23983__auto___28587 < len__23982__auto___28586)){
args__23989__auto__.push((arguments[i__23983__auto___28587]));

var G__28588 = (i__23983__auto___28587 + (1));
i__23983__auto___28587 = G__28588;
continue;
} else {
}
break;
}

var argseq__23990__auto__ = ((((2) < args__23989__auto__.length))?(new cljs.core.IndexedSeq(args__23989__auto__.slice((2)),(0),null)):null);
return cljs.core$macros.unchecked_multiply_int.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__23990__auto__);
});

cljs.core$macros.unchecked_multiply_int.cljs$core$IFn$_invoke$arity$variadic = (function (_AMPERSAND_form,_AMPERSAND_env,xs){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","*","cljs.core$macros/*",946321529,null)),xs)));
});

cljs.core$macros.unchecked_multiply_int.cljs$lang$maxFixedArity = (2);

cljs.core$macros.unchecked_multiply_int.cljs$lang$applyTo = (function (seq28583){
var G__28584 = cljs.core.first.call(null,seq28583);
var seq28583__$1 = cljs.core.next.call(null,seq28583);
var G__28585 = cljs.core.first.call(null,seq28583__$1);
var seq28583__$2 = cljs.core.next.call(null,seq28583__$1);
return cljs.core$macros.unchecked_multiply_int.cljs$core$IFn$_invoke$arity$variadic(G__28584,G__28585,seq28583__$2);
});

cljs.core$macros.unchecked_multiply_int.cljs$lang$macro = true;
cljs.core$macros.unchecked_negate = (function cljs$core$macros$unchecked_negate(_AMPERSAND_form,_AMPERSAND_env,x){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","-","cljs.core$macros/-",13526976,null)),(function (){var x__23746__auto__ = x;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
});

cljs.core$macros.unchecked_negate.cljs$lang$macro = true;
cljs.core$macros.unchecked_negate_int = (function cljs$core$macros$unchecked_negate_int(_AMPERSAND_form,_AMPERSAND_env,x){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","-","cljs.core$macros/-",13526976,null)),(function (){var x__23746__auto__ = x;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
});

cljs.core$macros.unchecked_negate_int.cljs$lang$macro = true;
cljs.core$macros.unchecked_remainder_int = (function cljs$core$macros$unchecked_remainder_int(_AMPERSAND_form,_AMPERSAND_env,x,n){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","mod","cljs.core$macros/mod",2132457375,null)),(function (){var x__23746__auto__ = x;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = n;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
});

cljs.core$macros.unchecked_remainder_int.cljs$lang$macro = true;
cljs.core$macros.unchecked_subtract = (function cljs$core$macros$unchecked_subtract(var_args){
var args__23989__auto__ = [];
var len__23982__auto___28592 = arguments.length;
var i__23983__auto___28593 = (0);
while(true){
if((i__23983__auto___28593 < len__23982__auto___28592)){
args__23989__auto__.push((arguments[i__23983__auto___28593]));

var G__28594 = (i__23983__auto___28593 + (1));
i__23983__auto___28593 = G__28594;
continue;
} else {
}
break;
}

var argseq__23990__auto__ = ((((2) < args__23989__auto__.length))?(new cljs.core.IndexedSeq(args__23989__auto__.slice((2)),(0),null)):null);
return cljs.core$macros.unchecked_subtract.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__23990__auto__);
});

cljs.core$macros.unchecked_subtract.cljs$core$IFn$_invoke$arity$variadic = (function (_AMPERSAND_form,_AMPERSAND_env,xs){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","-","cljs.core$macros/-",13526976,null)),xs)));
});

cljs.core$macros.unchecked_subtract.cljs$lang$maxFixedArity = (2);

cljs.core$macros.unchecked_subtract.cljs$lang$applyTo = (function (seq28589){
var G__28590 = cljs.core.first.call(null,seq28589);
var seq28589__$1 = cljs.core.next.call(null,seq28589);
var G__28591 = cljs.core.first.call(null,seq28589__$1);
var seq28589__$2 = cljs.core.next.call(null,seq28589__$1);
return cljs.core$macros.unchecked_subtract.cljs$core$IFn$_invoke$arity$variadic(G__28590,G__28591,seq28589__$2);
});

cljs.core$macros.unchecked_subtract.cljs$lang$macro = true;
cljs.core$macros.unchecked_subtract_int = (function cljs$core$macros$unchecked_subtract_int(var_args){
var args__23989__auto__ = [];
var len__23982__auto___28598 = arguments.length;
var i__23983__auto___28599 = (0);
while(true){
if((i__23983__auto___28599 < len__23982__auto___28598)){
args__23989__auto__.push((arguments[i__23983__auto___28599]));

var G__28600 = (i__23983__auto___28599 + (1));
i__23983__auto___28599 = G__28600;
continue;
} else {
}
break;
}

var argseq__23990__auto__ = ((((2) < args__23989__auto__.length))?(new cljs.core.IndexedSeq(args__23989__auto__.slice((2)),(0),null)):null);
return cljs.core$macros.unchecked_subtract_int.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__23990__auto__);
});

cljs.core$macros.unchecked_subtract_int.cljs$core$IFn$_invoke$arity$variadic = (function (_AMPERSAND_form,_AMPERSAND_env,xs){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","-","cljs.core$macros/-",13526976,null)),xs)));
});

cljs.core$macros.unchecked_subtract_int.cljs$lang$maxFixedArity = (2);

cljs.core$macros.unchecked_subtract_int.cljs$lang$applyTo = (function (seq28595){
var G__28596 = cljs.core.first.call(null,seq28595);
var seq28595__$1 = cljs.core.next.call(null,seq28595);
var G__28597 = cljs.core.first.call(null,seq28595__$1);
var seq28595__$2 = cljs.core.next.call(null,seq28595__$1);
return cljs.core$macros.unchecked_subtract_int.cljs$core$IFn$_invoke$arity$variadic(G__28596,G__28597,seq28595__$2);
});

cljs.core$macros.unchecked_subtract_int.cljs$lang$macro = true;
cljs.core$macros._ = (function cljs$core$macros$_(var_args){
var args28601 = [];
var len__23982__auto___28609 = arguments.length;
var i__23983__auto___28610 = (0);
while(true){
if((i__23983__auto___28610 < len__23982__auto___28609)){
args28601.push((arguments[i__23983__auto___28610]));

var G__28611 = (i__23983__auto___28610 + (1));
i__23983__auto___28610 = G__28611;
continue;
} else {
}
break;
}

var G__28608 = args28601.length;
switch (G__28608) {
case 3:
return cljs.core$macros._.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
case 4:
return cljs.core$macros._.cljs$core$IFn$_invoke$arity$4((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]));

break;
default:
var argseq__24001__auto__ = (new cljs.core.IndexedSeq(args28601.slice((4)),(0),null));
return cljs.core$macros._.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]),argseq__24001__auto__);

}
});

cljs.core$macros._.cljs$core$IFn$_invoke$arity$3 = (function (_AMPERSAND_form,_AMPERSAND_env,x){
return cljs.core._conj.call(null,cljs.core._conj.call(null,(function (){var x__23746__auto__ = x;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),"(- ~{})"),new cljs.core.Symbol(null,"js*","js*",-1134233646,null));
});

cljs.core$macros._.cljs$core$IFn$_invoke$arity$4 = (function (_AMPERSAND_form,_AMPERSAND_env,x,y){
return cljs.core._conj.call(null,cljs.core._conj.call(null,(function (){var x__23746__auto__ = x;
return cljs.core._conj.call(null,(function (){var x__23746__auto____$1 = y;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto____$1);
})(),x__23746__auto__);
})(),"(~{} - ~{})"),new cljs.core.Symbol(null,"js*","js*",-1134233646,null));
});

cljs.core$macros._.cljs$core$IFn$_invoke$arity$variadic = (function (_AMPERSAND_form,_AMPERSAND_env,x,y,more){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","-","cljs.core$macros/-",13526976,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","-","cljs.core$macros/-",13526976,null)),(function (){var x__23746__auto__ = x;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = y;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),more)));
});

cljs.core$macros._.cljs$lang$applyTo = (function (seq28602){
var G__28603 = cljs.core.first.call(null,seq28602);
var seq28602__$1 = cljs.core.next.call(null,seq28602);
var G__28604 = cljs.core.first.call(null,seq28602__$1);
var seq28602__$2 = cljs.core.next.call(null,seq28602__$1);
var G__28605 = cljs.core.first.call(null,seq28602__$2);
var seq28602__$3 = cljs.core.next.call(null,seq28602__$2);
var G__28606 = cljs.core.first.call(null,seq28602__$3);
var seq28602__$4 = cljs.core.next.call(null,seq28602__$3);
return cljs.core$macros._.cljs$core$IFn$_invoke$arity$variadic(G__28603,G__28604,G__28605,G__28606,seq28602__$4);
});

cljs.core$macros._.cljs$lang$maxFixedArity = (4);

cljs.core$macros._.cljs$lang$macro = true;
cljs.core$macros._STAR_ = (function cljs$core$macros$_STAR_(var_args){
var args28613 = [];
var len__23982__auto___28621 = arguments.length;
var i__23983__auto___28622 = (0);
while(true){
if((i__23983__auto___28622 < len__23982__auto___28621)){
args28613.push((arguments[i__23983__auto___28622]));

var G__28623 = (i__23983__auto___28622 + (1));
i__23983__auto___28622 = G__28623;
continue;
} else {
}
break;
}

var G__28620 = args28613.length;
switch (G__28620) {
case 2:
return cljs.core$macros._STAR_.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core$macros._STAR_.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
case 4:
return cljs.core$macros._STAR_.cljs$core$IFn$_invoke$arity$4((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]));

break;
default:
var argseq__24001__auto__ = (new cljs.core.IndexedSeq(args28613.slice((4)),(0),null));
return cljs.core$macros._STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]),argseq__24001__auto__);

}
});

cljs.core$macros._STAR_.cljs$core$IFn$_invoke$arity$2 = (function (_AMPERSAND_form,_AMPERSAND_env){
return (1);
});

cljs.core$macros._STAR_.cljs$core$IFn$_invoke$arity$3 = (function (_AMPERSAND_form,_AMPERSAND_env,x){
return x;
});

cljs.core$macros._STAR_.cljs$core$IFn$_invoke$arity$4 = (function (_AMPERSAND_form,_AMPERSAND_env,x,y){
return cljs.core._conj.call(null,cljs.core._conj.call(null,(function (){var x__23746__auto__ = x;
return cljs.core._conj.call(null,(function (){var x__23746__auto____$1 = y;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto____$1);
})(),x__23746__auto__);
})(),"(~{} * ~{})"),new cljs.core.Symbol(null,"js*","js*",-1134233646,null));
});

cljs.core$macros._STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (_AMPERSAND_form,_AMPERSAND_env,x,y,more){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","*","cljs.core$macros/*",946321529,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","*","cljs.core$macros/*",946321529,null)),(function (){var x__23746__auto__ = x;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = y;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),more)));
});

cljs.core$macros._STAR_.cljs$lang$applyTo = (function (seq28614){
var G__28615 = cljs.core.first.call(null,seq28614);
var seq28614__$1 = cljs.core.next.call(null,seq28614);
var G__28616 = cljs.core.first.call(null,seq28614__$1);
var seq28614__$2 = cljs.core.next.call(null,seq28614__$1);
var G__28617 = cljs.core.first.call(null,seq28614__$2);
var seq28614__$3 = cljs.core.next.call(null,seq28614__$2);
var G__28618 = cljs.core.first.call(null,seq28614__$3);
var seq28614__$4 = cljs.core.next.call(null,seq28614__$3);
return cljs.core$macros._STAR_.cljs$core$IFn$_invoke$arity$variadic(G__28615,G__28616,G__28617,G__28618,seq28614__$4);
});

cljs.core$macros._STAR_.cljs$lang$maxFixedArity = (4);

cljs.core$macros._STAR_.cljs$lang$macro = true;
cljs.core$macros._SLASH_ = (function cljs$core$macros$_SLASH_(var_args){
var args28625 = [];
var len__23982__auto___28633 = arguments.length;
var i__23983__auto___28634 = (0);
while(true){
if((i__23983__auto___28634 < len__23982__auto___28633)){
args28625.push((arguments[i__23983__auto___28634]));

var G__28635 = (i__23983__auto___28634 + (1));
i__23983__auto___28634 = G__28635;
continue;
} else {
}
break;
}

var G__28632 = args28625.length;
switch (G__28632) {
case 3:
return cljs.core$macros._SLASH_.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
case 4:
return cljs.core$macros._SLASH_.cljs$core$IFn$_invoke$arity$4((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]));

break;
default:
var argseq__24001__auto__ = (new cljs.core.IndexedSeq(args28625.slice((4)),(0),null));
return cljs.core$macros._SLASH_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]),argseq__24001__auto__);

}
});

cljs.core$macros._SLASH_.cljs$core$IFn$_invoke$arity$3 = (function (_AMPERSAND_form,_AMPERSAND_env,x){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","/","cljs.core$macros//",-893374331,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,(1)),(function (){var x__23746__auto__ = x;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
});

cljs.core$macros._SLASH_.cljs$core$IFn$_invoke$arity$4 = (function (_AMPERSAND_form,_AMPERSAND_env,x,y){
return cljs.core._conj.call(null,cljs.core._conj.call(null,(function (){var x__23746__auto__ = x;
return cljs.core._conj.call(null,(function (){var x__23746__auto____$1 = y;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto____$1);
})(),x__23746__auto__);
})(),"(~{} / ~{})"),new cljs.core.Symbol(null,"js*","js*",-1134233646,null));
});

cljs.core$macros._SLASH_.cljs$core$IFn$_invoke$arity$variadic = (function (_AMPERSAND_form,_AMPERSAND_env,x,y,more){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","/","cljs.core$macros//",-893374331,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","/","cljs.core$macros//",-893374331,null)),(function (){var x__23746__auto__ = x;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = y;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),more)));
});

cljs.core$macros._SLASH_.cljs$lang$applyTo = (function (seq28626){
var G__28627 = cljs.core.first.call(null,seq28626);
var seq28626__$1 = cljs.core.next.call(null,seq28626);
var G__28628 = cljs.core.first.call(null,seq28626__$1);
var seq28626__$2 = cljs.core.next.call(null,seq28626__$1);
var G__28629 = cljs.core.first.call(null,seq28626__$2);
var seq28626__$3 = cljs.core.next.call(null,seq28626__$2);
var G__28630 = cljs.core.first.call(null,seq28626__$3);
var seq28626__$4 = cljs.core.next.call(null,seq28626__$3);
return cljs.core$macros._SLASH_.cljs$core$IFn$_invoke$arity$variadic(G__28627,G__28628,G__28629,G__28630,seq28626__$4);
});

cljs.core$macros._SLASH_.cljs$lang$maxFixedArity = (4);

cljs.core$macros._SLASH_.cljs$lang$macro = true;
cljs.core$macros.divide = (function cljs$core$macros$divide(var_args){
var args28637 = [];
var len__23982__auto___28645 = arguments.length;
var i__23983__auto___28646 = (0);
while(true){
if((i__23983__auto___28646 < len__23982__auto___28645)){
args28637.push((arguments[i__23983__auto___28646]));

var G__28647 = (i__23983__auto___28646 + (1));
i__23983__auto___28646 = G__28647;
continue;
} else {
}
break;
}

var G__28644 = args28637.length;
switch (G__28644) {
case 3:
return cljs.core$macros.divide.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
case 4:
return cljs.core$macros.divide.cljs$core$IFn$_invoke$arity$4((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]));

break;
default:
var argseq__24001__auto__ = (new cljs.core.IndexedSeq(args28637.slice((4)),(0),null));
return cljs.core$macros.divide.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]),argseq__24001__auto__);

}
});

cljs.core$macros.divide.cljs$core$IFn$_invoke$arity$3 = (function (_AMPERSAND_form,_AMPERSAND_env,x){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","/","cljs.core$macros//",-893374331,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,(1)),(function (){var x__23746__auto__ = x;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
});

cljs.core$macros.divide.cljs$core$IFn$_invoke$arity$4 = (function (_AMPERSAND_form,_AMPERSAND_env,x,y){
return cljs.core._conj.call(null,cljs.core._conj.call(null,(function (){var x__23746__auto__ = x;
return cljs.core._conj.call(null,(function (){var x__23746__auto____$1 = y;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto____$1);
})(),x__23746__auto__);
})(),"(~{} / ~{})"),new cljs.core.Symbol(null,"js*","js*",-1134233646,null));
});

cljs.core$macros.divide.cljs$core$IFn$_invoke$arity$variadic = (function (_AMPERSAND_form,_AMPERSAND_env,x,y,more){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","/","cljs.core$macros//",-893374331,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","/","cljs.core$macros//",-893374331,null)),(function (){var x__23746__auto__ = x;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = y;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),more)));
});

cljs.core$macros.divide.cljs$lang$applyTo = (function (seq28638){
var G__28639 = cljs.core.first.call(null,seq28638);
var seq28638__$1 = cljs.core.next.call(null,seq28638);
var G__28640 = cljs.core.first.call(null,seq28638__$1);
var seq28638__$2 = cljs.core.next.call(null,seq28638__$1);
var G__28641 = cljs.core.first.call(null,seq28638__$2);
var seq28638__$3 = cljs.core.next.call(null,seq28638__$2);
var G__28642 = cljs.core.first.call(null,seq28638__$3);
var seq28638__$4 = cljs.core.next.call(null,seq28638__$3);
return cljs.core$macros.divide.cljs$core$IFn$_invoke$arity$variadic(G__28639,G__28640,G__28641,G__28642,seq28638__$4);
});

cljs.core$macros.divide.cljs$lang$maxFixedArity = (4);

cljs.core$macros.divide.cljs$lang$macro = true;
cljs.core$macros._LT_ = (function cljs$core$macros$_LT_(var_args){
var args28649 = [];
var len__23982__auto___28657 = arguments.length;
var i__23983__auto___28658 = (0);
while(true){
if((i__23983__auto___28658 < len__23982__auto___28657)){
args28649.push((arguments[i__23983__auto___28658]));

var G__28659 = (i__23983__auto___28658 + (1));
i__23983__auto___28658 = G__28659;
continue;
} else {
}
break;
}

var G__28656 = args28649.length;
switch (G__28656) {
case 3:
return cljs.core$macros._LT_.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
case 4:
return cljs.core$macros._LT_.cljs$core$IFn$_invoke$arity$4((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]));

break;
default:
var argseq__24001__auto__ = (new cljs.core.IndexedSeq(args28649.slice((4)),(0),null));
return cljs.core$macros._LT_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]),argseq__24001__auto__);

}
});

cljs.core$macros._LT_.cljs$core$IFn$_invoke$arity$3 = (function (_AMPERSAND_form,_AMPERSAND_env,x){
return true;
});

cljs.core$macros._LT_.cljs$core$IFn$_invoke$arity$4 = (function (_AMPERSAND_form,_AMPERSAND_env,x,y){
return cljs.core$macros.bool_expr.call(null,cljs.core._conj.call(null,cljs.core._conj.call(null,(function (){var x__23746__auto__ = x;
return cljs.core._conj.call(null,(function (){var x__23746__auto____$1 = y;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto____$1);
})(),x__23746__auto__);
})(),"(~{} < ~{})"),new cljs.core.Symbol(null,"js*","js*",-1134233646,null)));
});

cljs.core$macros._LT_.cljs$core$IFn$_invoke$arity$variadic = (function (_AMPERSAND_form,_AMPERSAND_env,x,y,more){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","and","cljs.core$macros/and",48320334,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","<","cljs.core$macros/<",371512596,null)),(function (){var x__23746__auto__ = x;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = y;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","<","cljs.core$macros/<",371512596,null)),(function (){var x__23746__auto__ = y;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),more)));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
});

cljs.core$macros._LT_.cljs$lang$applyTo = (function (seq28650){
var G__28651 = cljs.core.first.call(null,seq28650);
var seq28650__$1 = cljs.core.next.call(null,seq28650);
var G__28652 = cljs.core.first.call(null,seq28650__$1);
var seq28650__$2 = cljs.core.next.call(null,seq28650__$1);
var G__28653 = cljs.core.first.call(null,seq28650__$2);
var seq28650__$3 = cljs.core.next.call(null,seq28650__$2);
var G__28654 = cljs.core.first.call(null,seq28650__$3);
var seq28650__$4 = cljs.core.next.call(null,seq28650__$3);
return cljs.core$macros._LT_.cljs$core$IFn$_invoke$arity$variadic(G__28651,G__28652,G__28653,G__28654,seq28650__$4);
});

cljs.core$macros._LT_.cljs$lang$maxFixedArity = (4);

cljs.core$macros._LT_.cljs$lang$macro = true;
cljs.core$macros._LT__EQ_ = (function cljs$core$macros$_LT__EQ_(var_args){
var args28661 = [];
var len__23982__auto___28669 = arguments.length;
var i__23983__auto___28670 = (0);
while(true){
if((i__23983__auto___28670 < len__23982__auto___28669)){
args28661.push((arguments[i__23983__auto___28670]));

var G__28671 = (i__23983__auto___28670 + (1));
i__23983__auto___28670 = G__28671;
continue;
} else {
}
break;
}

var G__28668 = args28661.length;
switch (G__28668) {
case 3:
return cljs.core$macros._LT__EQ_.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
case 4:
return cljs.core$macros._LT__EQ_.cljs$core$IFn$_invoke$arity$4((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]));

break;
default:
var argseq__24001__auto__ = (new cljs.core.IndexedSeq(args28661.slice((4)),(0),null));
return cljs.core$macros._LT__EQ_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]),argseq__24001__auto__);

}
});

cljs.core$macros._LT__EQ_.cljs$core$IFn$_invoke$arity$3 = (function (_AMPERSAND_form,_AMPERSAND_env,x){
return true;
});

cljs.core$macros._LT__EQ_.cljs$core$IFn$_invoke$arity$4 = (function (_AMPERSAND_form,_AMPERSAND_env,x,y){
return cljs.core$macros.bool_expr.call(null,cljs.core._conj.call(null,cljs.core._conj.call(null,(function (){var x__23746__auto__ = x;
return cljs.core._conj.call(null,(function (){var x__23746__auto____$1 = y;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto____$1);
})(),x__23746__auto__);
})(),"(~{} <= ~{})"),new cljs.core.Symbol(null,"js*","js*",-1134233646,null)));
});

cljs.core$macros._LT__EQ_.cljs$core$IFn$_invoke$arity$variadic = (function (_AMPERSAND_form,_AMPERSAND_env,x,y,more){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","and","cljs.core$macros/and",48320334,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","<=","cljs.core$macros/<=",1865244377,null)),(function (){var x__23746__auto__ = x;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = y;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","<=","cljs.core$macros/<=",1865244377,null)),(function (){var x__23746__auto__ = y;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),more)));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
});

cljs.core$macros._LT__EQ_.cljs$lang$applyTo = (function (seq28662){
var G__28663 = cljs.core.first.call(null,seq28662);
var seq28662__$1 = cljs.core.next.call(null,seq28662);
var G__28664 = cljs.core.first.call(null,seq28662__$1);
var seq28662__$2 = cljs.core.next.call(null,seq28662__$1);
var G__28665 = cljs.core.first.call(null,seq28662__$2);
var seq28662__$3 = cljs.core.next.call(null,seq28662__$2);
var G__28666 = cljs.core.first.call(null,seq28662__$3);
var seq28662__$4 = cljs.core.next.call(null,seq28662__$3);
return cljs.core$macros._LT__EQ_.cljs$core$IFn$_invoke$arity$variadic(G__28663,G__28664,G__28665,G__28666,seq28662__$4);
});

cljs.core$macros._LT__EQ_.cljs$lang$maxFixedArity = (4);

cljs.core$macros._LT__EQ_.cljs$lang$macro = true;
cljs.core$macros._GT_ = (function cljs$core$macros$_GT_(var_args){
var args28673 = [];
var len__23982__auto___28681 = arguments.length;
var i__23983__auto___28682 = (0);
while(true){
if((i__23983__auto___28682 < len__23982__auto___28681)){
args28673.push((arguments[i__23983__auto___28682]));

var G__28683 = (i__23983__auto___28682 + (1));
i__23983__auto___28682 = G__28683;
continue;
} else {
}
break;
}

var G__28680 = args28673.length;
switch (G__28680) {
case 3:
return cljs.core$macros._GT_.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
case 4:
return cljs.core$macros._GT_.cljs$core$IFn$_invoke$arity$4((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]));

break;
default:
var argseq__24001__auto__ = (new cljs.core.IndexedSeq(args28673.slice((4)),(0),null));
return cljs.core$macros._GT_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]),argseq__24001__auto__);

}
});

cljs.core$macros._GT_.cljs$core$IFn$_invoke$arity$3 = (function (_AMPERSAND_form,_AMPERSAND_env,x){
return true;
});

cljs.core$macros._GT_.cljs$core$IFn$_invoke$arity$4 = (function (_AMPERSAND_form,_AMPERSAND_env,x,y){
return cljs.core$macros.bool_expr.call(null,cljs.core._conj.call(null,cljs.core._conj.call(null,(function (){var x__23746__auto__ = x;
return cljs.core._conj.call(null,(function (){var x__23746__auto____$1 = y;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto____$1);
})(),x__23746__auto__);
})(),"(~{} > ~{})"),new cljs.core.Symbol(null,"js*","js*",-1134233646,null)));
});

cljs.core$macros._GT_.cljs$core$IFn$_invoke$arity$variadic = (function (_AMPERSAND_form,_AMPERSAND_env,x,y,more){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","and","cljs.core$macros/and",48320334,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros",">","cljs.core$macros/>",1703297853,null)),(function (){var x__23746__auto__ = x;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = y;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros",">","cljs.core$macros/>",1703297853,null)),(function (){var x__23746__auto__ = y;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),more)));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
});

cljs.core$macros._GT_.cljs$lang$applyTo = (function (seq28674){
var G__28675 = cljs.core.first.call(null,seq28674);
var seq28674__$1 = cljs.core.next.call(null,seq28674);
var G__28676 = cljs.core.first.call(null,seq28674__$1);
var seq28674__$2 = cljs.core.next.call(null,seq28674__$1);
var G__28677 = cljs.core.first.call(null,seq28674__$2);
var seq28674__$3 = cljs.core.next.call(null,seq28674__$2);
var G__28678 = cljs.core.first.call(null,seq28674__$3);
var seq28674__$4 = cljs.core.next.call(null,seq28674__$3);
return cljs.core$macros._GT_.cljs$core$IFn$_invoke$arity$variadic(G__28675,G__28676,G__28677,G__28678,seq28674__$4);
});

cljs.core$macros._GT_.cljs$lang$maxFixedArity = (4);

cljs.core$macros._GT_.cljs$lang$macro = true;
cljs.core$macros._GT__EQ_ = (function cljs$core$macros$_GT__EQ_(var_args){
var args28685 = [];
var len__23982__auto___28693 = arguments.length;
var i__23983__auto___28694 = (0);
while(true){
if((i__23983__auto___28694 < len__23982__auto___28693)){
args28685.push((arguments[i__23983__auto___28694]));

var G__28695 = (i__23983__auto___28694 + (1));
i__23983__auto___28694 = G__28695;
continue;
} else {
}
break;
}

var G__28692 = args28685.length;
switch (G__28692) {
case 3:
return cljs.core$macros._GT__EQ_.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
case 4:
return cljs.core$macros._GT__EQ_.cljs$core$IFn$_invoke$arity$4((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]));

break;
default:
var argseq__24001__auto__ = (new cljs.core.IndexedSeq(args28685.slice((4)),(0),null));
return cljs.core$macros._GT__EQ_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]),argseq__24001__auto__);

}
});

cljs.core$macros._GT__EQ_.cljs$core$IFn$_invoke$arity$3 = (function (_AMPERSAND_form,_AMPERSAND_env,x){
return true;
});

cljs.core$macros._GT__EQ_.cljs$core$IFn$_invoke$arity$4 = (function (_AMPERSAND_form,_AMPERSAND_env,x,y){
return cljs.core$macros.bool_expr.call(null,cljs.core._conj.call(null,cljs.core._conj.call(null,(function (){var x__23746__auto__ = x;
return cljs.core._conj.call(null,(function (){var x__23746__auto____$1 = y;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto____$1);
})(),x__23746__auto__);
})(),"(~{} >= ~{})"),new cljs.core.Symbol(null,"js*","js*",-1134233646,null)));
});

cljs.core$macros._GT__EQ_.cljs$core$IFn$_invoke$arity$variadic = (function (_AMPERSAND_form,_AMPERSAND_env,x,y,more){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","and","cljs.core$macros/and",48320334,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros",">=","cljs.core$macros/>=",527849062,null)),(function (){var x__23746__auto__ = x;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = y;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros",">=","cljs.core$macros/>=",527849062,null)),(function (){var x__23746__auto__ = y;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),more)));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
});

cljs.core$macros._GT__EQ_.cljs$lang$applyTo = (function (seq28686){
var G__28687 = cljs.core.first.call(null,seq28686);
var seq28686__$1 = cljs.core.next.call(null,seq28686);
var G__28688 = cljs.core.first.call(null,seq28686__$1);
var seq28686__$2 = cljs.core.next.call(null,seq28686__$1);
var G__28689 = cljs.core.first.call(null,seq28686__$2);
var seq28686__$3 = cljs.core.next.call(null,seq28686__$2);
var G__28690 = cljs.core.first.call(null,seq28686__$3);
var seq28686__$4 = cljs.core.next.call(null,seq28686__$3);
return cljs.core$macros._GT__EQ_.cljs$core$IFn$_invoke$arity$variadic(G__28687,G__28688,G__28689,G__28690,seq28686__$4);
});

cljs.core$macros._GT__EQ_.cljs$lang$maxFixedArity = (4);

cljs.core$macros._GT__EQ_.cljs$lang$macro = true;
cljs.core$macros._EQ__EQ_ = (function cljs$core$macros$_EQ__EQ_(var_args){
var args28697 = [];
var len__23982__auto___28705 = arguments.length;
var i__23983__auto___28706 = (0);
while(true){
if((i__23983__auto___28706 < len__23982__auto___28705)){
args28697.push((arguments[i__23983__auto___28706]));

var G__28707 = (i__23983__auto___28706 + (1));
i__23983__auto___28706 = G__28707;
continue;
} else {
}
break;
}

var G__28704 = args28697.length;
switch (G__28704) {
case 3:
return cljs.core$macros._EQ__EQ_.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
case 4:
return cljs.core$macros._EQ__EQ_.cljs$core$IFn$_invoke$arity$4((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]));

break;
default:
var argseq__24001__auto__ = (new cljs.core.IndexedSeq(args28697.slice((4)),(0),null));
return cljs.core$macros._EQ__EQ_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]),argseq__24001__auto__);

}
});

cljs.core$macros._EQ__EQ_.cljs$core$IFn$_invoke$arity$3 = (function (_AMPERSAND_form,_AMPERSAND_env,x){
return true;
});

cljs.core$macros._EQ__EQ_.cljs$core$IFn$_invoke$arity$4 = (function (_AMPERSAND_form,_AMPERSAND_env,x,y){
return cljs.core$macros.bool_expr.call(null,cljs.core._conj.call(null,cljs.core._conj.call(null,(function (){var x__23746__auto__ = x;
return cljs.core._conj.call(null,(function (){var x__23746__auto____$1 = y;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto____$1);
})(),x__23746__auto__);
})(),"(~{} === ~{})"),new cljs.core.Symbol(null,"js*","js*",-1134233646,null)));
});

cljs.core$macros._EQ__EQ_.cljs$core$IFn$_invoke$arity$variadic = (function (_AMPERSAND_form,_AMPERSAND_env,x,y,more){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","and","cljs.core$macros/and",48320334,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","==","cljs.core$macros/==",-818551413,null)),(function (){var x__23746__auto__ = x;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = y;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","==","cljs.core$macros/==",-818551413,null)),(function (){var x__23746__auto__ = y;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),more)));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
});

cljs.core$macros._EQ__EQ_.cljs$lang$applyTo = (function (seq28698){
var G__28699 = cljs.core.first.call(null,seq28698);
var seq28698__$1 = cljs.core.next.call(null,seq28698);
var G__28700 = cljs.core.first.call(null,seq28698__$1);
var seq28698__$2 = cljs.core.next.call(null,seq28698__$1);
var G__28701 = cljs.core.first.call(null,seq28698__$2);
var seq28698__$3 = cljs.core.next.call(null,seq28698__$2);
var G__28702 = cljs.core.first.call(null,seq28698__$3);
var seq28698__$4 = cljs.core.next.call(null,seq28698__$3);
return cljs.core$macros._EQ__EQ_.cljs$core$IFn$_invoke$arity$variadic(G__28699,G__28700,G__28701,G__28702,seq28698__$4);
});

cljs.core$macros._EQ__EQ_.cljs$lang$maxFixedArity = (4);

cljs.core$macros._EQ__EQ_.cljs$lang$macro = true;
cljs.core$macros.dec = (function cljs$core$macros$dec(_AMPERSAND_form,_AMPERSAND_env,x){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","-","cljs.core$macros/-",13526976,null)),(function (){var x__23746__auto__ = x;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,(1)))));
});

cljs.core$macros.dec.cljs$lang$macro = true;
cljs.core$macros.inc = (function cljs$core$macros$inc(_AMPERSAND_form,_AMPERSAND_env,x){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","+","cljs.core$macros/+",-18260342,null)),(function (){var x__23746__auto__ = x;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,(1)))));
});

cljs.core$macros.inc.cljs$lang$macro = true;
cljs.core$macros.zero_QMARK_ = (function cljs$core$macros$zero_QMARK_(_AMPERSAND_form,_AMPERSAND_env,x){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","==","cljs.core$macros/==",-818551413,null)),(function (){var x__23746__auto__ = x;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,(0)))));
});

cljs.core$macros.zero_QMARK_.cljs$lang$macro = true;
cljs.core$macros.pos_QMARK_ = (function cljs$core$macros$pos_QMARK_(_AMPERSAND_form,_AMPERSAND_env,x){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros",">","cljs.core$macros/>",1703297853,null)),(function (){var x__23746__auto__ = x;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,(0)))));
});

cljs.core$macros.pos_QMARK_.cljs$lang$macro = true;
cljs.core$macros.neg_QMARK_ = (function cljs$core$macros$neg_QMARK_(_AMPERSAND_form,_AMPERSAND_env,x){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","<","cljs.core$macros/<",371512596,null)),(function (){var x__23746__auto__ = x;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,(0)))));
});

cljs.core$macros.neg_QMARK_.cljs$lang$macro = true;
cljs.core$macros.max = (function cljs$core$macros$max(var_args){
var args28711 = [];
var len__23982__auto___28719 = arguments.length;
var i__23983__auto___28720 = (0);
while(true){
if((i__23983__auto___28720 < len__23982__auto___28719)){
args28711.push((arguments[i__23983__auto___28720]));

var G__28721 = (i__23983__auto___28720 + (1));
i__23983__auto___28720 = G__28721;
continue;
} else {
}
break;
}

var G__28718 = args28711.length;
switch (G__28718) {
case 3:
return cljs.core$macros.max.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
case 4:
return cljs.core$macros.max.cljs$core$IFn$_invoke$arity$4((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]));

break;
default:
var argseq__24001__auto__ = (new cljs.core.IndexedSeq(args28711.slice((4)),(0),null));
return cljs.core$macros.max.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]),argseq__24001__auto__);

}
});

cljs.core$macros.max.cljs$core$IFn$_invoke$arity$3 = (function (_AMPERSAND_form,_AMPERSAND_env,x){
return x;
});

cljs.core$macros.max.cljs$core$IFn$_invoke$arity$4 = (function (_AMPERSAND_form,_AMPERSAND_env,x,y){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","let","cljs.core$macros/let",-160286726,null)),(function (){var x__23746__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"x__28709__auto__","x__28709__auto__",-758760955,null)),(function (){var x__23746__auto__ = x;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"y__28710__auto__","y__28710__auto__",1103378491,null)),(function (){var x__23746__auto__ = y;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})()))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"js*","js*",-1134233646,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,"((~{} > ~{}) ? ~{} : ~{})"),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"x__28709__auto__","x__28709__auto__",-758760955,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"y__28710__auto__","y__28710__auto__",1103378491,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"x__28709__auto__","x__28709__auto__",-758760955,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"y__28710__auto__","y__28710__auto__",1103378491,null)))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
});

cljs.core$macros.max.cljs$core$IFn$_invoke$arity$variadic = (function (_AMPERSAND_form,_AMPERSAND_env,x,y,more){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","max","cljs.core$macros/max",1176150699,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","max","cljs.core$macros/max",1176150699,null)),(function (){var x__23746__auto__ = x;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = y;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),more)));
});

cljs.core$macros.max.cljs$lang$applyTo = (function (seq28712){
var G__28713 = cljs.core.first.call(null,seq28712);
var seq28712__$1 = cljs.core.next.call(null,seq28712);
var G__28714 = cljs.core.first.call(null,seq28712__$1);
var seq28712__$2 = cljs.core.next.call(null,seq28712__$1);
var G__28715 = cljs.core.first.call(null,seq28712__$2);
var seq28712__$3 = cljs.core.next.call(null,seq28712__$2);
var G__28716 = cljs.core.first.call(null,seq28712__$3);
var seq28712__$4 = cljs.core.next.call(null,seq28712__$3);
return cljs.core$macros.max.cljs$core$IFn$_invoke$arity$variadic(G__28713,G__28714,G__28715,G__28716,seq28712__$4);
});

cljs.core$macros.max.cljs$lang$maxFixedArity = (4);

cljs.core$macros.max.cljs$lang$macro = true;
cljs.core$macros.min = (function cljs$core$macros$min(var_args){
var args28725 = [];
var len__23982__auto___28733 = arguments.length;
var i__23983__auto___28734 = (0);
while(true){
if((i__23983__auto___28734 < len__23982__auto___28733)){
args28725.push((arguments[i__23983__auto___28734]));

var G__28735 = (i__23983__auto___28734 + (1));
i__23983__auto___28734 = G__28735;
continue;
} else {
}
break;
}

var G__28732 = args28725.length;
switch (G__28732) {
case 3:
return cljs.core$macros.min.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
case 4:
return cljs.core$macros.min.cljs$core$IFn$_invoke$arity$4((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]));

break;
default:
var argseq__24001__auto__ = (new cljs.core.IndexedSeq(args28725.slice((4)),(0),null));
return cljs.core$macros.min.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]),argseq__24001__auto__);

}
});

cljs.core$macros.min.cljs$core$IFn$_invoke$arity$3 = (function (_AMPERSAND_form,_AMPERSAND_env,x){
return x;
});

cljs.core$macros.min.cljs$core$IFn$_invoke$arity$4 = (function (_AMPERSAND_form,_AMPERSAND_env,x,y){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","let","cljs.core$macros/let",-160286726,null)),(function (){var x__23746__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"x__28723__auto__","x__28723__auto__",-1264213694,null)),(function (){var x__23746__auto__ = x;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"y__28724__auto__","y__28724__auto__",112217514,null)),(function (){var x__23746__auto__ = y;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})()))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"js*","js*",-1134233646,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,"((~{} < ~{}) ? ~{} : ~{})"),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"x__28723__auto__","x__28723__auto__",-1264213694,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"y__28724__auto__","y__28724__auto__",112217514,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"x__28723__auto__","x__28723__auto__",-1264213694,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"y__28724__auto__","y__28724__auto__",112217514,null)))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
});

cljs.core$macros.min.cljs$core$IFn$_invoke$arity$variadic = (function (_AMPERSAND_form,_AMPERSAND_env,x,y,more){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","min","cljs.core$macros/min",1499775161,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","min","cljs.core$macros/min",1499775161,null)),(function (){var x__23746__auto__ = x;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = y;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),more)));
});

cljs.core$macros.min.cljs$lang$applyTo = (function (seq28726){
var G__28727 = cljs.core.first.call(null,seq28726);
var seq28726__$1 = cljs.core.next.call(null,seq28726);
var G__28728 = cljs.core.first.call(null,seq28726__$1);
var seq28726__$2 = cljs.core.next.call(null,seq28726__$1);
var G__28729 = cljs.core.first.call(null,seq28726__$2);
var seq28726__$3 = cljs.core.next.call(null,seq28726__$2);
var G__28730 = cljs.core.first.call(null,seq28726__$3);
var seq28726__$4 = cljs.core.next.call(null,seq28726__$3);
return cljs.core$macros.min.cljs$core$IFn$_invoke$arity$variadic(G__28727,G__28728,G__28729,G__28730,seq28726__$4);
});

cljs.core$macros.min.cljs$lang$maxFixedArity = (4);

cljs.core$macros.min.cljs$lang$macro = true;
cljs.core$macros.js_mod = (function cljs$core$macros$js_mod(_AMPERSAND_form,_AMPERSAND_env,num,div){
return cljs.core._conj.call(null,cljs.core._conj.call(null,(function (){var x__23746__auto__ = num;
return cljs.core._conj.call(null,(function (){var x__23746__auto____$1 = div;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto____$1);
})(),x__23746__auto__);
})(),"(~{} % ~{})"),new cljs.core.Symbol(null,"js*","js*",-1134233646,null));
});

cljs.core$macros.js_mod.cljs$lang$macro = true;
cljs.core$macros.bit_not = (function cljs$core$macros$bit_not(_AMPERSAND_form,_AMPERSAND_env,x){
return cljs.core._conj.call(null,cljs.core._conj.call(null,(function (){var x__23746__auto__ = x;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),"(~ ~{})"),new cljs.core.Symbol(null,"js*","js*",-1134233646,null));
});

cljs.core$macros.bit_not.cljs$lang$macro = true;
cljs.core$macros.bit_and = (function cljs$core$macros$bit_and(var_args){
var args28737 = [];
var len__23982__auto___28745 = arguments.length;
var i__23983__auto___28746 = (0);
while(true){
if((i__23983__auto___28746 < len__23982__auto___28745)){
args28737.push((arguments[i__23983__auto___28746]));

var G__28747 = (i__23983__auto___28746 + (1));
i__23983__auto___28746 = G__28747;
continue;
} else {
}
break;
}

var G__28744 = args28737.length;
switch (G__28744) {
case 4:
return cljs.core$macros.bit_and.cljs$core$IFn$_invoke$arity$4((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]));

break;
default:
var argseq__24001__auto__ = (new cljs.core.IndexedSeq(args28737.slice((4)),(0),null));
return cljs.core$macros.bit_and.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]),argseq__24001__auto__);

}
});

cljs.core$macros.bit_and.cljs$core$IFn$_invoke$arity$4 = (function (_AMPERSAND_form,_AMPERSAND_env,x,y){
return cljs.core._conj.call(null,cljs.core._conj.call(null,(function (){var x__23746__auto__ = x;
return cljs.core._conj.call(null,(function (){var x__23746__auto____$1 = y;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto____$1);
})(),x__23746__auto__);
})(),"(~{} & ~{})"),new cljs.core.Symbol(null,"js*","js*",-1134233646,null));
});

cljs.core$macros.bit_and.cljs$core$IFn$_invoke$arity$variadic = (function (_AMPERSAND_form,_AMPERSAND_env,x,y,more){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","bit-and","cljs.core$macros/bit-and",-1069060797,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","bit-and","cljs.core$macros/bit-and",-1069060797,null)),(function (){var x__23746__auto__ = x;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = y;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),more)));
});

cljs.core$macros.bit_and.cljs$lang$applyTo = (function (seq28738){
var G__28739 = cljs.core.first.call(null,seq28738);
var seq28738__$1 = cljs.core.next.call(null,seq28738);
var G__28740 = cljs.core.first.call(null,seq28738__$1);
var seq28738__$2 = cljs.core.next.call(null,seq28738__$1);
var G__28741 = cljs.core.first.call(null,seq28738__$2);
var seq28738__$3 = cljs.core.next.call(null,seq28738__$2);
var G__28742 = cljs.core.first.call(null,seq28738__$3);
var seq28738__$4 = cljs.core.next.call(null,seq28738__$3);
return cljs.core$macros.bit_and.cljs$core$IFn$_invoke$arity$variadic(G__28739,G__28740,G__28741,G__28742,seq28738__$4);
});

cljs.core$macros.bit_and.cljs$lang$maxFixedArity = (4);

cljs.core$macros.bit_and.cljs$lang$macro = true;
cljs.core$macros.unsafe_bit_and = (function cljs$core$macros$unsafe_bit_and(var_args){
var args28749 = [];
var len__23982__auto___28757 = arguments.length;
var i__23983__auto___28758 = (0);
while(true){
if((i__23983__auto___28758 < len__23982__auto___28757)){
args28749.push((arguments[i__23983__auto___28758]));

var G__28759 = (i__23983__auto___28758 + (1));
i__23983__auto___28758 = G__28759;
continue;
} else {
}
break;
}

var G__28756 = args28749.length;
switch (G__28756) {
case 4:
return cljs.core$macros.unsafe_bit_and.cljs$core$IFn$_invoke$arity$4((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]));

break;
default:
var argseq__24001__auto__ = (new cljs.core.IndexedSeq(args28749.slice((4)),(0),null));
return cljs.core$macros.unsafe_bit_and.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]),argseq__24001__auto__);

}
});

cljs.core$macros.unsafe_bit_and.cljs$core$IFn$_invoke$arity$4 = (function (_AMPERSAND_form,_AMPERSAND_env,x,y){
return cljs.core$macros.bool_expr.call(null,cljs.core._conj.call(null,cljs.core._conj.call(null,(function (){var x__23746__auto__ = x;
return cljs.core._conj.call(null,(function (){var x__23746__auto____$1 = y;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto____$1);
})(),x__23746__auto__);
})(),"(~{} & ~{})"),new cljs.core.Symbol(null,"js*","js*",-1134233646,null)));
});

cljs.core$macros.unsafe_bit_and.cljs$core$IFn$_invoke$arity$variadic = (function (_AMPERSAND_form,_AMPERSAND_env,x,y,more){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","unsafe-bit-and","cljs.core$macros/unsafe-bit-and",1803731600,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","unsafe-bit-and","cljs.core$macros/unsafe-bit-and",1803731600,null)),(function (){var x__23746__auto__ = x;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = y;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),more)));
});

cljs.core$macros.unsafe_bit_and.cljs$lang$applyTo = (function (seq28750){
var G__28751 = cljs.core.first.call(null,seq28750);
var seq28750__$1 = cljs.core.next.call(null,seq28750);
var G__28752 = cljs.core.first.call(null,seq28750__$1);
var seq28750__$2 = cljs.core.next.call(null,seq28750__$1);
var G__28753 = cljs.core.first.call(null,seq28750__$2);
var seq28750__$3 = cljs.core.next.call(null,seq28750__$2);
var G__28754 = cljs.core.first.call(null,seq28750__$3);
var seq28750__$4 = cljs.core.next.call(null,seq28750__$3);
return cljs.core$macros.unsafe_bit_and.cljs$core$IFn$_invoke$arity$variadic(G__28751,G__28752,G__28753,G__28754,seq28750__$4);
});

cljs.core$macros.unsafe_bit_and.cljs$lang$maxFixedArity = (4);

cljs.core$macros.unsafe_bit_and.cljs$lang$macro = true;
cljs.core$macros.bit_or = (function cljs$core$macros$bit_or(var_args){
var args28761 = [];
var len__23982__auto___28769 = arguments.length;
var i__23983__auto___28770 = (0);
while(true){
if((i__23983__auto___28770 < len__23982__auto___28769)){
args28761.push((arguments[i__23983__auto___28770]));

var G__28771 = (i__23983__auto___28770 + (1));
i__23983__auto___28770 = G__28771;
continue;
} else {
}
break;
}

var G__28768 = args28761.length;
switch (G__28768) {
case 4:
return cljs.core$macros.bit_or.cljs$core$IFn$_invoke$arity$4((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]));

break;
default:
var argseq__24001__auto__ = (new cljs.core.IndexedSeq(args28761.slice((4)),(0),null));
return cljs.core$macros.bit_or.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]),argseq__24001__auto__);

}
});

cljs.core$macros.bit_or.cljs$core$IFn$_invoke$arity$4 = (function (_AMPERSAND_form,_AMPERSAND_env,x,y){
return cljs.core._conj.call(null,cljs.core._conj.call(null,(function (){var x__23746__auto__ = x;
return cljs.core._conj.call(null,(function (){var x__23746__auto____$1 = y;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto____$1);
})(),x__23746__auto__);
})(),"(~{} | ~{})"),new cljs.core.Symbol(null,"js*","js*",-1134233646,null));
});

cljs.core$macros.bit_or.cljs$core$IFn$_invoke$arity$variadic = (function (_AMPERSAND_form,_AMPERSAND_env,x,y,more){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","bit-or","cljs.core$macros/bit-or",1463236165,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","bit-or","cljs.core$macros/bit-or",1463236165,null)),(function (){var x__23746__auto__ = x;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = y;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),more)));
});

cljs.core$macros.bit_or.cljs$lang$applyTo = (function (seq28762){
var G__28763 = cljs.core.first.call(null,seq28762);
var seq28762__$1 = cljs.core.next.call(null,seq28762);
var G__28764 = cljs.core.first.call(null,seq28762__$1);
var seq28762__$2 = cljs.core.next.call(null,seq28762__$1);
var G__28765 = cljs.core.first.call(null,seq28762__$2);
var seq28762__$3 = cljs.core.next.call(null,seq28762__$2);
var G__28766 = cljs.core.first.call(null,seq28762__$3);
var seq28762__$4 = cljs.core.next.call(null,seq28762__$3);
return cljs.core$macros.bit_or.cljs$core$IFn$_invoke$arity$variadic(G__28763,G__28764,G__28765,G__28766,seq28762__$4);
});

cljs.core$macros.bit_or.cljs$lang$maxFixedArity = (4);

cljs.core$macros.bit_or.cljs$lang$macro = true;
cljs.core$macros.int$ = (function cljs$core$macros$int(_AMPERSAND_form,_AMPERSAND_env,x){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","bit-or","cljs.core$macros/bit-or",1463236165,null)),(function (){var x__23746__auto__ = x;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,(0)))));
});

cljs.core$macros.int$.cljs$lang$macro = true;
cljs.core$macros.bit_xor = (function cljs$core$macros$bit_xor(var_args){
var args28773 = [];
var len__23982__auto___28781 = arguments.length;
var i__23983__auto___28782 = (0);
while(true){
if((i__23983__auto___28782 < len__23982__auto___28781)){
args28773.push((arguments[i__23983__auto___28782]));

var G__28783 = (i__23983__auto___28782 + (1));
i__23983__auto___28782 = G__28783;
continue;
} else {
}
break;
}

var G__28780 = args28773.length;
switch (G__28780) {
case 4:
return cljs.core$macros.bit_xor.cljs$core$IFn$_invoke$arity$4((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]));

break;
default:
var argseq__24001__auto__ = (new cljs.core.IndexedSeq(args28773.slice((4)),(0),null));
return cljs.core$macros.bit_xor.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]),argseq__24001__auto__);

}
});

cljs.core$macros.bit_xor.cljs$core$IFn$_invoke$arity$4 = (function (_AMPERSAND_form,_AMPERSAND_env,x,y){
return cljs.core._conj.call(null,cljs.core._conj.call(null,(function (){var x__23746__auto__ = x;
return cljs.core._conj.call(null,(function (){var x__23746__auto____$1 = y;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto____$1);
})(),x__23746__auto__);
})(),"(~{} ^ ~{})"),new cljs.core.Symbol(null,"js*","js*",-1134233646,null));
});

cljs.core$macros.bit_xor.cljs$core$IFn$_invoke$arity$variadic = (function (_AMPERSAND_form,_AMPERSAND_env,x,y,more){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","bit-xor","cljs.core$macros/bit-xor",1284619191,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","bit-xor","cljs.core$macros/bit-xor",1284619191,null)),(function (){var x__23746__auto__ = x;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = y;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),more)));
});

cljs.core$macros.bit_xor.cljs$lang$applyTo = (function (seq28774){
var G__28775 = cljs.core.first.call(null,seq28774);
var seq28774__$1 = cljs.core.next.call(null,seq28774);
var G__28776 = cljs.core.first.call(null,seq28774__$1);
var seq28774__$2 = cljs.core.next.call(null,seq28774__$1);
var G__28777 = cljs.core.first.call(null,seq28774__$2);
var seq28774__$3 = cljs.core.next.call(null,seq28774__$2);
var G__28778 = cljs.core.first.call(null,seq28774__$3);
var seq28774__$4 = cljs.core.next.call(null,seq28774__$3);
return cljs.core$macros.bit_xor.cljs$core$IFn$_invoke$arity$variadic(G__28775,G__28776,G__28777,G__28778,seq28774__$4);
});

cljs.core$macros.bit_xor.cljs$lang$maxFixedArity = (4);

cljs.core$macros.bit_xor.cljs$lang$macro = true;
cljs.core$macros.bit_and_not = (function cljs$core$macros$bit_and_not(var_args){
var args28785 = [];
var len__23982__auto___28793 = arguments.length;
var i__23983__auto___28794 = (0);
while(true){
if((i__23983__auto___28794 < len__23982__auto___28793)){
args28785.push((arguments[i__23983__auto___28794]));

var G__28795 = (i__23983__auto___28794 + (1));
i__23983__auto___28794 = G__28795;
continue;
} else {
}
break;
}

var G__28792 = args28785.length;
switch (G__28792) {
case 4:
return cljs.core$macros.bit_and_not.cljs$core$IFn$_invoke$arity$4((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]));

break;
default:
var argseq__24001__auto__ = (new cljs.core.IndexedSeq(args28785.slice((4)),(0),null));
return cljs.core$macros.bit_and_not.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]),argseq__24001__auto__);

}
});

cljs.core$macros.bit_and_not.cljs$core$IFn$_invoke$arity$4 = (function (_AMPERSAND_form,_AMPERSAND_env,x,y){
return cljs.core._conj.call(null,cljs.core._conj.call(null,(function (){var x__23746__auto__ = x;
return cljs.core._conj.call(null,(function (){var x__23746__auto____$1 = y;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto____$1);
})(),x__23746__auto__);
})(),"(~{} & ~~{})"),new cljs.core.Symbol(null,"js*","js*",-1134233646,null));
});

cljs.core$macros.bit_and_not.cljs$core$IFn$_invoke$arity$variadic = (function (_AMPERSAND_form,_AMPERSAND_env,x,y,more){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","bit-and-not","cljs.core$macros/bit-and-not",-537076037,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","bit-and-not","cljs.core$macros/bit-and-not",-537076037,null)),(function (){var x__23746__auto__ = x;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = y;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),more)));
});

cljs.core$macros.bit_and_not.cljs$lang$applyTo = (function (seq28786){
var G__28787 = cljs.core.first.call(null,seq28786);
var seq28786__$1 = cljs.core.next.call(null,seq28786);
var G__28788 = cljs.core.first.call(null,seq28786__$1);
var seq28786__$2 = cljs.core.next.call(null,seq28786__$1);
var G__28789 = cljs.core.first.call(null,seq28786__$2);
var seq28786__$3 = cljs.core.next.call(null,seq28786__$2);
var G__28790 = cljs.core.first.call(null,seq28786__$3);
var seq28786__$4 = cljs.core.next.call(null,seq28786__$3);
return cljs.core$macros.bit_and_not.cljs$core$IFn$_invoke$arity$variadic(G__28787,G__28788,G__28789,G__28790,seq28786__$4);
});

cljs.core$macros.bit_and_not.cljs$lang$maxFixedArity = (4);

cljs.core$macros.bit_and_not.cljs$lang$macro = true;
cljs.core$macros.bit_clear = (function cljs$core$macros$bit_clear(_AMPERSAND_form,_AMPERSAND_env,x,n){
return cljs.core._conj.call(null,cljs.core._conj.call(null,(function (){var x__23746__auto__ = x;
return cljs.core._conj.call(null,(function (){var x__23746__auto____$1 = n;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto____$1);
})(),x__23746__auto__);
})(),"(~{} & ~(1 << ~{}))"),new cljs.core.Symbol(null,"js*","js*",-1134233646,null));
});

cljs.core$macros.bit_clear.cljs$lang$macro = true;
cljs.core$macros.bit_flip = (function cljs$core$macros$bit_flip(_AMPERSAND_form,_AMPERSAND_env,x,n){
return cljs.core._conj.call(null,cljs.core._conj.call(null,(function (){var x__23746__auto__ = x;
return cljs.core._conj.call(null,(function (){var x__23746__auto____$1 = n;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto____$1);
})(),x__23746__auto__);
})(),"(~{} ^ (1 << ~{}))"),new cljs.core.Symbol(null,"js*","js*",-1134233646,null));
});

cljs.core$macros.bit_flip.cljs$lang$macro = true;
cljs.core$macros.bit_test = (function cljs$core$macros$bit_test(_AMPERSAND_form,_AMPERSAND_env,x,n){
return cljs.core$macros.bool_expr.call(null,cljs.core._conj.call(null,cljs.core._conj.call(null,(function (){var x__23746__auto__ = x;
return cljs.core._conj.call(null,(function (){var x__23746__auto____$1 = n;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto____$1);
})(),x__23746__auto__);
})(),"((~{} & (1 << ~{})) != 0)"),new cljs.core.Symbol(null,"js*","js*",-1134233646,null)));
});

cljs.core$macros.bit_test.cljs$lang$macro = true;
cljs.core$macros.bit_shift_left = (function cljs$core$macros$bit_shift_left(_AMPERSAND_form,_AMPERSAND_env,x,n){
return cljs.core._conj.call(null,cljs.core._conj.call(null,(function (){var x__23746__auto__ = x;
return cljs.core._conj.call(null,(function (){var x__23746__auto____$1 = n;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto____$1);
})(),x__23746__auto__);
})(),"(~{} << ~{})"),new cljs.core.Symbol(null,"js*","js*",-1134233646,null));
});

cljs.core$macros.bit_shift_left.cljs$lang$macro = true;
cljs.core$macros.bit_shift_right = (function cljs$core$macros$bit_shift_right(_AMPERSAND_form,_AMPERSAND_env,x,n){
return cljs.core._conj.call(null,cljs.core._conj.call(null,(function (){var x__23746__auto__ = x;
return cljs.core._conj.call(null,(function (){var x__23746__auto____$1 = n;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto____$1);
})(),x__23746__auto__);
})(),"(~{} >> ~{})"),new cljs.core.Symbol(null,"js*","js*",-1134233646,null));
});

cljs.core$macros.bit_shift_right.cljs$lang$macro = true;
cljs.core$macros.bit_shift_right_zero_fill = (function cljs$core$macros$bit_shift_right_zero_fill(_AMPERSAND_form,_AMPERSAND_env,x,n){
return cljs.core._conj.call(null,cljs.core._conj.call(null,(function (){var x__23746__auto__ = x;
return cljs.core._conj.call(null,(function (){var x__23746__auto____$1 = n;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto____$1);
})(),x__23746__auto__);
})(),"(~{} >>> ~{})"),new cljs.core.Symbol(null,"js*","js*",-1134233646,null));
});

cljs.core$macros.bit_shift_right_zero_fill.cljs$lang$macro = true;
cljs.core$macros.unsigned_bit_shift_right = (function cljs$core$macros$unsigned_bit_shift_right(_AMPERSAND_form,_AMPERSAND_env,x,n){
return cljs.core._conj.call(null,cljs.core._conj.call(null,(function (){var x__23746__auto__ = x;
return cljs.core._conj.call(null,(function (){var x__23746__auto____$1 = n;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto____$1);
})(),x__23746__auto__);
})(),"(~{} >>> ~{})"),new cljs.core.Symbol(null,"js*","js*",-1134233646,null));
});

cljs.core$macros.unsigned_bit_shift_right.cljs$lang$macro = true;
cljs.core$macros.bit_set = (function cljs$core$macros$bit_set(_AMPERSAND_form,_AMPERSAND_env,x,n){
return cljs.core._conj.call(null,cljs.core._conj.call(null,(function (){var x__23746__auto__ = x;
return cljs.core._conj.call(null,(function (){var x__23746__auto____$1 = n;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto____$1);
})(),x__23746__auto__);
})(),"(~{} | (1 << ~{}))"),new cljs.core.Symbol(null,"js*","js*",-1134233646,null));
});

cljs.core$macros.bit_set.cljs$lang$macro = true;
cljs.core$macros.mask = (function cljs$core$macros$mask(_AMPERSAND_form,_AMPERSAND_env,hash,shift){
return cljs.core._conj.call(null,cljs.core._conj.call(null,(function (){var x__23746__auto__ = hash;
return cljs.core._conj.call(null,(function (){var x__23746__auto____$1 = shift;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto____$1);
})(),x__23746__auto__);
})(),"((~{} >>> ~{}) & 0x01f)"),new cljs.core.Symbol(null,"js*","js*",-1134233646,null));
});

cljs.core$macros.mask.cljs$lang$macro = true;
cljs.core$macros.bitpos = (function cljs$core$macros$bitpos(_AMPERSAND_form,_AMPERSAND_env,hash,shift){
return cljs.core._conj.call(null,cljs.core._conj.call(null,(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","mask","cljs.core$macros/mask",1575319768,null)),(function (){var x__23746__auto__ = hash;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = shift;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),"(1 << ~{})"),new cljs.core.Symbol(null,"js*","js*",-1134233646,null));
});

cljs.core$macros.bitpos.cljs$lang$macro = true;
cljs.core$macros.caching_hash = (function cljs$core$macros$caching_hash(_AMPERSAND_form,_AMPERSAND_env,coll,hash_fn,hash_key){
if((hash_key instanceof cljs.core.Symbol)){
} else {
throw (new Error([cljs.core.str("Assert failed: "),cljs.core.str("hash-key is substituted twice"),cljs.core.str("\n"),cljs.core.str("(clojure.core/symbol? hash-key)")].join('')));
}

return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","let","cljs.core$macros/let",-160286726,null)),(function (){var x__23746__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"h__28797__auto__","h__28797__auto__",-1587023143,null)),(function (){var x__23746__auto__ = hash_key;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})()))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","if-not","cljs.core$macros/if-not",-1825285737,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","nil?","cljs.core$macros/nil?",83624258,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"h__28797__auto__","h__28797__auto__",-1587023143,null)))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"h__28797__auto__","h__28797__auto__",-1587023143,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","let","cljs.core$macros/let",-160286726,null)),(function (){var x__23746__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"h__28797__auto__","h__28797__auto__",-1587023143,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,(function (){var x__23746__auto__ = hash_fn;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = coll;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})()))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"set!","set!",250714521,null)),(function (){var x__23746__auto__ = hash_key;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"h__28797__auto__","h__28797__auto__",-1587023143,null)))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"h__28797__auto__","h__28797__auto__",-1587023143,null)))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
});

cljs.core$macros.caching_hash.cljs$lang$macro = true;
cljs.core$macros.do_curried = (function cljs$core$macros$do_curried(name,doc,meta,args,body){
var cargs = cljs.core.vec.call(null,cljs.core.butlast.call(null,args));
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","defn","cljs.core$macros/defn",-728332354,null)),(function (){var x__23746__auto__ = name;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = doc;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = meta;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,(function (){var x__23746__auto__ = cargs;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","fn","cljs.core$macros/fn",-187522821,null)),(function (){var x__23746__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"x__28798__auto__","x__28798__auto__",-2136452291,null))))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,(function (){var x__23746__auto__ = name;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),cargs,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"x__28798__auto__","x__28798__auto__",-2136452291,null)))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,(function (){var x__23746__auto__ = args;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),body)));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
});
/**
 * Builds another arity of the fn that returns a fn awaiting the last
 *   param
 */
cljs.core$macros.defcurried = (function cljs$core$macros$defcurried(var_args){
var args__23989__auto__ = [];
var len__23982__auto___28806 = arguments.length;
var i__23983__auto___28807 = (0);
while(true){
if((i__23983__auto___28807 < len__23982__auto___28806)){
args__23989__auto__.push((arguments[i__23983__auto___28807]));

var G__28808 = (i__23983__auto___28807 + (1));
i__23983__auto___28807 = G__28808;
continue;
} else {
}
break;
}

var argseq__23990__auto__ = ((((6) < args__23989__auto__.length))?(new cljs.core.IndexedSeq(args__23989__auto__.slice((6)),(0),null)):null);
return cljs.core$macros.defcurried.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]),(arguments[(4)]),(arguments[(5)]),argseq__23990__auto__);
});

cljs.core$macros.defcurried.cljs$core$IFn$_invoke$arity$variadic = (function (_AMPERSAND_form,_AMPERSAND_env,name,doc,meta,args,body){
return cljs.core$macros.do_curried.call(null,name,doc,meta,args,body);
});

cljs.core$macros.defcurried.cljs$lang$maxFixedArity = (6);

cljs.core$macros.defcurried.cljs$lang$applyTo = (function (seq28799){
var G__28800 = cljs.core.first.call(null,seq28799);
var seq28799__$1 = cljs.core.next.call(null,seq28799);
var G__28801 = cljs.core.first.call(null,seq28799__$1);
var seq28799__$2 = cljs.core.next.call(null,seq28799__$1);
var G__28802 = cljs.core.first.call(null,seq28799__$2);
var seq28799__$3 = cljs.core.next.call(null,seq28799__$2);
var G__28803 = cljs.core.first.call(null,seq28799__$3);
var seq28799__$4 = cljs.core.next.call(null,seq28799__$3);
var G__28804 = cljs.core.first.call(null,seq28799__$4);
var seq28799__$5 = cljs.core.next.call(null,seq28799__$4);
var G__28805 = cljs.core.first.call(null,seq28799__$5);
var seq28799__$6 = cljs.core.next.call(null,seq28799__$5);
return cljs.core$macros.defcurried.cljs$core$IFn$_invoke$arity$variadic(G__28800,G__28801,G__28802,G__28803,G__28804,G__28805,seq28799__$6);
});

cljs.core$macros.defcurried.cljs$lang$macro = true;
cljs.core$macros.do_rfn = (function cljs$core$macros$do_rfn(f1,k,fkv){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","fn","cljs.core$macros/fn",-187522821,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,(function (){var x__23746__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,(function (){var x__23746__auto__ = f1;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = clojure.walk.postwalk.call(null,(function (p1__28809_SHARP_){
if(cljs.core.sequential_QMARK_.call(null,p1__28809_SHARP_)){
return ((cljs.core.vector_QMARK_.call(null,p1__28809_SHARP_))?cljs.core.vec:cljs.core.identity).call(null,cljs.core.remove.call(null,cljs.core.PersistentHashSet.fromArray([k], true),p1__28809_SHARP_));
} else {
return p1__28809_SHARP_;
}
}),fkv);
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = fkv;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
});
/**
 * Builds 3-arity reducing fn given names of wrapped fn and key, and k/v impl.
 */
cljs.core$macros.rfn = (function cljs$core$macros$rfn(_AMPERSAND_form,_AMPERSAND_env,p__28810,fkv){
var vec__28812 = p__28810;
var f1 = cljs.core.nth.call(null,vec__28812,(0),null);
var k = cljs.core.nth.call(null,vec__28812,(1),null);
return cljs.core$macros.do_rfn.call(null,f1,k,fkv);
});

cljs.core$macros.rfn.cljs$lang$macro = true;
cljs.core$macros.protocol_prefix = (function cljs$core$macros$protocol_prefix(psym){
return [cljs.core.str([cljs.core.str(psym)].join('').replace((new RegExp("\\.","g")),"$").replace("/","$")),cljs.core.str("$")].join('');
});
cljs.core$macros.base_type = new cljs.core.PersistentArrayMap(null, 8, [null,"null",new cljs.core.Symbol(null,"object","object",-1179821820,null),"object",new cljs.core.Symbol(null,"string","string",-349010059,null),"string",new cljs.core.Symbol(null,"number","number",-1084057331,null),"number",new cljs.core.Symbol(null,"array","array",-440182315,null),"array",new cljs.core.Symbol(null,"function","function",-486723946,null),"function",new cljs.core.Symbol(null,"boolean","boolean",-278886877,null),"boolean",new cljs.core.Symbol(null,"default","default",-347290801,null),"_"], null);
cljs.core$macros.js_base_type = new cljs.core.PersistentArrayMap(null, 6, [new cljs.core.Symbol("js","Boolean","js/Boolean",1661145260,null),"boolean",new cljs.core.Symbol("js","String","js/String",-2070054036,null),"string",new cljs.core.Symbol("js","Array","js/Array",-423508366,null),"array",new cljs.core.Symbol("js","Object","js/Object",61215323,null),"object",new cljs.core.Symbol("js","Number","js/Number",-508133572,null),"number",new cljs.core.Symbol("js","Function","js/Function",-749892063,null),"function"], null);
/**
 * reify is a macro with the following structure:
 * 
 *  (reify options* specs*)
 * 
 *   Currently there are no options.
 * 
 *   Each spec consists of the protocol name followed by zero
 *   or more method bodies:
 * 
 *   protocol
 *   (methodName [args+] body)*
 * 
 *   Methods should be supplied for all methods of the desired
 *   protocol(s). You can also define overrides for Object methods. Note that
 *   the first parameter must be supplied to correspond to the target object
 *   ('this' in JavaScript parlance). Note also that recur calls
 *   to the method head should *not* pass the target object, it will be supplied
 *   automatically and can not be substituted.
 * 
 *   recur works to method heads The method bodies of reify are lexical
 *   closures, and can refer to the surrounding local scope:
 * 
 *   (str (let [f "foo"]
 *     (reify Object
 *       (toString [this] f))))
 *   == "foo"
 * 
 *   (seq (let [f "foo"]
 *     (reify ISeqable
 *       (-seq [this] (-seq f)))))
 *   == (\f \o \o))
 * 
 *   reify always implements IMeta and IWithMeta and transfers meta
 *   data of the form to the created object.
 * 
 *   (meta ^{:k :v} (reify Object (toString [this] "foo")))
 *   == {:k :v}
 */
cljs.core$macros.reify = (function cljs$core$macros$reify(var_args){
var args__23989__auto__ = [];
var len__23982__auto___28816 = arguments.length;
var i__23983__auto___28817 = (0);
while(true){
if((i__23983__auto___28817 < len__23982__auto___28816)){
args__23989__auto__.push((arguments[i__23983__auto___28817]));

var G__28818 = (i__23983__auto___28817 + (1));
i__23983__auto___28817 = G__28818;
continue;
} else {
}
break;
}

var argseq__23990__auto__ = ((((2) < args__23989__auto__.length))?(new cljs.core.IndexedSeq(args__23989__auto__.slice((2)),(0),null)):null);
return cljs.core$macros.reify.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__23990__auto__);
});

cljs.core$macros.reify.cljs$core$IFn$_invoke$arity$variadic = (function (_AMPERSAND_form,_AMPERSAND_env,impls){
var t = cljs.core.with_meta.call(null,cljs.core.gensym.call(null,[cljs.core.str("t_"),cljs.core.str(clojure.string.replace.call(null,[cljs.core.str(cljs.core.munge.call(null,cljs.analyzer._STAR_cljs_ns_STAR_))].join(''),".","$"))].join('')),new cljs.core.PersistentArrayMap(null, 1, [new cljs.core.Keyword(null,"anonymous","anonymous",447897231),true], null));
var meta_sym = cljs.core.gensym.call(null,"meta");
var this_sym = cljs.core.gensym.call(null,"_");
var locals = cljs.core.keys.call(null,new cljs.core.Keyword(null,"locals","locals",535295783).cljs$core$IFn$_invoke$arity$1(_AMPERSAND_env));
var ns = new cljs.core.Keyword(null,"name","name",1843675177).cljs$core$IFn$_invoke$arity$1(new cljs.core.Keyword(null,"ns","ns",441598760).cljs$core$IFn$_invoke$arity$1(_AMPERSAND_env));
var munge = cljs.compiler.munge;
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"do","do",1686842252,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","when-not","cljs.core$macros/when-not",-764302244,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","exists?","cljs.core$macros/exists?",-1828590389,null)),(function (){var x__23746__auto__ = cljs.core.symbol.call(null,[cljs.core.str(ns)].join(''),[cljs.core.str(t)].join(''));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","deftype","cljs.core$macros/deftype",1799045688,null)),(function (){var x__23746__auto__ = t;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,locals,(function (){var x__23746__auto__ = meta_sym;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})()))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","IWithMeta","cljs.core/IWithMeta",-1981666051,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"-with-meta","-with-meta",-1610713823,null)),(function (){var x__23746__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,(function (){var x__23746__auto__ = this_sym;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = meta_sym;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})()))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"new","new",-444906321,null)),(function (){var x__23746__auto__ = t;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),locals,(function (){var x__23746__auto__ = meta_sym;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","IMeta","cljs.core/IMeta",-1459057517,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"-meta","-meta",494863156,null)),(function (){var x__23746__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,(function (){var x__23746__auto__ = this_sym;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})()))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = meta_sym;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),impls)));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"new","new",-444906321,null)),(function (){var x__23746__auto__ = t;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),locals,(function (){var x__23746__auto__ = cljs.analyzer.elide_reader_meta.call(null,cljs.core.meta.call(null,_AMPERSAND_form));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
});

cljs.core$macros.reify.cljs$lang$maxFixedArity = (2);

cljs.core$macros.reify.cljs$lang$applyTo = (function (seq28813){
var G__28814 = cljs.core.first.call(null,seq28813);
var seq28813__$1 = cljs.core.next.call(null,seq28813);
var G__28815 = cljs.core.first.call(null,seq28813__$1);
var seq28813__$2 = cljs.core.next.call(null,seq28813__$1);
return cljs.core$macros.reify.cljs$core$IFn$_invoke$arity$variadic(G__28814,G__28815,seq28813__$2);
});

cljs.core$macros.reify.cljs$lang$macro = true;
/**
 * Identical to reify but mutates its first argument.
 */
cljs.core$macros.specify_BANG_ = (function cljs$core$macros$specify_BANG_(var_args){
var args__23989__auto__ = [];
var len__23982__auto___28823 = arguments.length;
var i__23983__auto___28824 = (0);
while(true){
if((i__23983__auto___28824 < len__23982__auto___28823)){
args__23989__auto__.push((arguments[i__23983__auto___28824]));

var G__28825 = (i__23983__auto___28824 + (1));
i__23983__auto___28824 = G__28825;
continue;
} else {
}
break;
}

var argseq__23990__auto__ = ((((3) < args__23989__auto__.length))?(new cljs.core.IndexedSeq(args__23989__auto__.slice((3)),(0),null)):null);
return cljs.core$macros.specify_BANG_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),argseq__23990__auto__);
});

cljs.core$macros.specify_BANG_.cljs$core$IFn$_invoke$arity$variadic = (function (_AMPERSAND_form,_AMPERSAND_env,expr,impls){
var x = cljs.core.with_meta.call(null,cljs.core.gensym.call(null,"x"),new cljs.core.PersistentArrayMap(null, 1, [new cljs.core.Keyword(null,"extend","extend",1836484006),new cljs.core.Keyword(null,"instance","instance",-2121349050)], null));
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","let","cljs.core$macros/let",-160286726,null)),(function (){var x__23746__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,(function (){var x__23746__auto__ = x;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = expr;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})()))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","extend-type","cljs.core$macros/extend-type",1713295201,null)),(function (){var x__23746__auto__ = x;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),impls)));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = x;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
});

cljs.core$macros.specify_BANG_.cljs$lang$maxFixedArity = (3);

cljs.core$macros.specify_BANG_.cljs$lang$applyTo = (function (seq28819){
var G__28820 = cljs.core.first.call(null,seq28819);
var seq28819__$1 = cljs.core.next.call(null,seq28819);
var G__28821 = cljs.core.first.call(null,seq28819__$1);
var seq28819__$2 = cljs.core.next.call(null,seq28819__$1);
var G__28822 = cljs.core.first.call(null,seq28819__$2);
var seq28819__$3 = cljs.core.next.call(null,seq28819__$2);
return cljs.core$macros.specify_BANG_.cljs$core$IFn$_invoke$arity$variadic(G__28820,G__28821,G__28822,seq28819__$3);
});

cljs.core$macros.specify_BANG_.cljs$lang$macro = true;
/**
 * Identical to specify! but does not mutate its first argument. The first
 *   argument must be an ICloneable instance.
 */
cljs.core$macros.specify = (function cljs$core$macros$specify(var_args){
var args__23989__auto__ = [];
var len__23982__auto___28830 = arguments.length;
var i__23983__auto___28831 = (0);
while(true){
if((i__23983__auto___28831 < len__23982__auto___28830)){
args__23989__auto__.push((arguments[i__23983__auto___28831]));

var G__28832 = (i__23983__auto___28831 + (1));
i__23983__auto___28831 = G__28832;
continue;
} else {
}
break;
}

var argseq__23990__auto__ = ((((3) < args__23989__auto__.length))?(new cljs.core.IndexedSeq(args__23989__auto__.slice((3)),(0),null)):null);
return cljs.core$macros.specify.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),argseq__23990__auto__);
});

cljs.core$macros.specify.cljs$core$IFn$_invoke$arity$variadic = (function (_AMPERSAND_form,_AMPERSAND_env,expr,impls){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","specify!","cljs.core/specify!",-585401629,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","clone","cljs.core/clone",1417120092,null)),(function (){var x__23746__auto__ = expr;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),impls)));
});

cljs.core$macros.specify.cljs$lang$maxFixedArity = (3);

cljs.core$macros.specify.cljs$lang$applyTo = (function (seq28826){
var G__28827 = cljs.core.first.call(null,seq28826);
var seq28826__$1 = cljs.core.next.call(null,seq28826);
var G__28828 = cljs.core.first.call(null,seq28826__$1);
var seq28826__$2 = cljs.core.next.call(null,seq28826__$1);
var G__28829 = cljs.core.first.call(null,seq28826__$2);
var seq28826__$3 = cljs.core.next.call(null,seq28826__$2);
return cljs.core$macros.specify.cljs$core$IFn$_invoke$arity$variadic(G__28827,G__28828,G__28829,seq28826__$3);
});

cljs.core$macros.specify.cljs$lang$macro = true;
cljs.core$macros.js_this = (function cljs$core$macros$js_this(_AMPERSAND_form,_AMPERSAND_env){
return cljs.core._conj.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,"this"),new cljs.core.Symbol(null,"js*","js*",-1134233646,null));
});

cljs.core$macros.js_this.cljs$lang$macro = true;
/**
 * Defines a scope where JavaScript's implicit "this" is bound to the name provided.
 */
cljs.core$macros.this_as = (function cljs$core$macros$this_as(var_args){
var args__23989__auto__ = [];
var len__23982__auto___28837 = arguments.length;
var i__23983__auto___28838 = (0);
while(true){
if((i__23983__auto___28838 < len__23982__auto___28837)){
args__23989__auto__.push((arguments[i__23983__auto___28838]));

var G__28839 = (i__23983__auto___28838 + (1));
i__23983__auto___28838 = G__28839;
continue;
} else {
}
break;
}

var argseq__23990__auto__ = ((((3) < args__23989__auto__.length))?(new cljs.core.IndexedSeq(args__23989__auto__.slice((3)),(0),null)):null);
return cljs.core$macros.this_as.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),argseq__23990__auto__);
});

cljs.core$macros.this_as.cljs$core$IFn$_invoke$arity$variadic = (function (_AMPERSAND_form,_AMPERSAND_env,name,body){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","let","cljs.core$macros/let",-160286726,null)),(function (){var x__23746__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,(function (){var x__23746__auto__ = name;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","js-this","cljs.core$macros/js-this",353597180,null)))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})()))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),body)));
});

cljs.core$macros.this_as.cljs$lang$maxFixedArity = (3);

cljs.core$macros.this_as.cljs$lang$applyTo = (function (seq28833){
var G__28834 = cljs.core.first.call(null,seq28833);
var seq28833__$1 = cljs.core.next.call(null,seq28833);
var G__28835 = cljs.core.first.call(null,seq28833__$1);
var seq28833__$2 = cljs.core.next.call(null,seq28833__$1);
var G__28836 = cljs.core.first.call(null,seq28833__$2);
var seq28833__$3 = cljs.core.next.call(null,seq28833__$2);
return cljs.core$macros.this_as.cljs$core$IFn$_invoke$arity$variadic(G__28834,G__28835,G__28836,seq28833__$3);
});

cljs.core$macros.this_as.cljs$lang$macro = true;
cljs.core$macros.to_property = (function cljs$core$macros$to_property(sym){
return cljs.core.symbol.call(null,[cljs.core.str("-"),cljs.core.str(sym)].join(''));
});
cljs.core$macros.warn_and_update_protocol = (function cljs$core$macros$warn_and_update_protocol(p,type,env){
if(cljs.core._EQ_.call(null,new cljs.core.Symbol(null,"Object","Object",61210754,null),p)){
return null;
} else {
var temp__4655__auto__ = cljs.analyzer.resolve_existing_var.call(null,cljs.core.dissoc.call(null,env,new cljs.core.Keyword(null,"locals","locals",535295783)),p);
if(cljs.core.truth_(temp__4655__auto__)){
var var$ = temp__4655__auto__;
if(cljs.core.truth_(new cljs.core.Keyword(null,"protocol-symbol","protocol-symbol",1279552198).cljs$core$IFn$_invoke$arity$1(var$))){
} else {
cljs.analyzer.warning.call(null,new cljs.core.Keyword(null,"invalid-protocol-symbol","invalid-protocol-symbol",86246948),env,new cljs.core.PersistentArrayMap(null, 1, [new cljs.core.Keyword(null,"protocol","protocol",652470118),p], null));
}

if(cljs.core.truth_((function (){var and__22900__auto__ = new cljs.core.Keyword(null,"protocol-deprecated","protocol-deprecated",103233497).cljs$core$IFn$_invoke$arity$1(cljs.analyzer._STAR_cljs_warnings_STAR_);
if(cljs.core.truth_(and__22900__auto__)){
var and__22900__auto____$1 = new cljs.core.Keyword(null,"deprecated","deprecated",1498275348).cljs$core$IFn$_invoke$arity$1(var$);
if(cljs.core.truth_(and__22900__auto____$1)){
return cljs.core.not.call(null,new cljs.core.Keyword(null,"deprecation-nowarn","deprecation-nowarn",-1762828044).cljs$core$IFn$_invoke$arity$1(cljs.core.meta.call(null,p)));
} else {
return and__22900__auto____$1;
}
} else {
return and__22900__auto__;
}
})())){
cljs.analyzer.warning.call(null,new cljs.core.Keyword(null,"protocol-deprecated","protocol-deprecated",103233497),env,new cljs.core.PersistentArrayMap(null, 1, [new cljs.core.Keyword(null,"protocol","protocol",652470118),p], null));
} else {
}

if(cljs.core.truth_(new cljs.core.Keyword(null,"protocol-symbol","protocol-symbol",1279552198).cljs$core$IFn$_invoke$arity$1(var$))){
return cljs.core.swap_BANG_.call(null,cljs.env._STAR_compiler_STAR_,cljs.core.update_in,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword("cljs.analyzer","namespaces","cljs.analyzer/namespaces",-260788927)], null),((function (var$,temp__4655__auto__){
return (function (ns){
return cljs.core.update_in.call(null,ns,new cljs.core.PersistentVector(null, 4, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword(null,"ns","ns",441598760).cljs$core$IFn$_invoke$arity$1(var$),new cljs.core.Keyword(null,"defs","defs",1398449717),cljs.core.symbol.call(null,cljs.core.name.call(null,p)),new cljs.core.Keyword(null,"impls","impls",-1314014853)], null),cljs.core.conj,type);
});})(var$,temp__4655__auto__))
);
} else {
return null;
}
} else {
if(cljs.core.truth_(new cljs.core.Keyword(null,"undeclared","undeclared",1446667347).cljs$core$IFn$_invoke$arity$1(cljs.analyzer._STAR_cljs_warnings_STAR_))){
return cljs.analyzer.warning.call(null,new cljs.core.Keyword(null,"undeclared-protocol-symbol","undeclared-protocol-symbol",462882867),env,new cljs.core.PersistentArrayMap(null, 1, [new cljs.core.Keyword(null,"protocol","protocol",652470118),p], null));
} else {
return null;
}
}
}
});
cljs.core$macros.resolve_var = (function cljs$core$macros$resolve_var(env,sym){
var ret = new cljs.core.Keyword(null,"name","name",1843675177).cljs$core$IFn$_invoke$arity$1(cljs.analyzer.resolve_var.call(null,cljs.core.dissoc.call(null,env,new cljs.core.Keyword(null,"locals","locals",535295783)),sym));
if(cljs.core.truth_(ret)){
} else {
throw (new Error([cljs.core.str("Assert failed: "),cljs.core.str([cljs.core.str("Can't resolve: "),cljs.core.str(sym)].join('')),cljs.core.str("\n"),cljs.core.str("ret")].join('')));
}

return ret;
});
cljs.core$macros.__GT_impl_map = (function cljs$core$macros$__GT_impl_map(impls){
var ret = cljs.core.PersistentArrayMap.EMPTY;
var s = impls;
while(true){
if(cljs.core.seq.call(null,s)){
var G__28840 = cljs.core.assoc.call(null,ret,cljs.core.first.call(null,s),cljs.core.take_while.call(null,cljs.core.seq_QMARK_,cljs.core.next.call(null,s)));
var G__28841 = cljs.core.drop_while.call(null,cljs.core.seq_QMARK_,cljs.core.next.call(null,s));
ret = G__28840;
s = G__28841;
continue;
} else {
return ret;
}
break;
}
});
cljs.core$macros.base_assign_impls = (function cljs$core$macros$base_assign_impls(env,resolve,tsym,type,p__28842){
var vec__28846 = p__28842;
var p = cljs.core.nth.call(null,vec__28846,(0),null);
var sigs = cljs.core.nth.call(null,vec__28846,(1),null);
cljs.core$macros.warn_and_update_protocol.call(null,p,tsym,env);

var psym = resolve.call(null,p);
var pfn_prefix = cljs.core.subs.call(null,[cljs.core.str(psym)].join(''),(0),([cljs.core.str(psym)].join('').indexOf("/") + (1)));
return cljs.core.cons.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","aset","cljs.core$macros/aset",-693176374,null)),(function (){var x__23746__auto__ = psym;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = type;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,true)))),cljs.core.map.call(null,((function (psym,pfn_prefix,vec__28846,p,sigs){
return (function (p__28847){
var vec__28848 = p__28847;
var f = cljs.core.nth.call(null,vec__28848,(0),null);
var meths = cljs.core.nthnext.call(null,vec__28848,(1));
var form = vec__28848;
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","aset","cljs.core$macros/aset",-693176374,null)),(function (){var x__23746__auto__ = cljs.core.symbol.call(null,[cljs.core.str(pfn_prefix),cljs.core.str(f)].join(''));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = type;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.with_meta.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","fn","cljs.core$macros/fn",-187522821,null)),meths))),cljs.core.meta.call(null,form));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
});})(psym,pfn_prefix,vec__28846,p,sigs))
,sigs));
});
if(typeof cljs.core$macros.extend_prefix !== 'undefined'){
} else {
cljs.core$macros.extend_prefix = (function (){var method_table__23837__auto__ = cljs.core.atom.call(null,cljs.core.PersistentArrayMap.EMPTY);
var prefer_table__23838__auto__ = cljs.core.atom.call(null,cljs.core.PersistentArrayMap.EMPTY);
var method_cache__23839__auto__ = cljs.core.atom.call(null,cljs.core.PersistentArrayMap.EMPTY);
var cached_hierarchy__23840__auto__ = cljs.core.atom.call(null,cljs.core.PersistentArrayMap.EMPTY);
var hierarchy__23841__auto__ = cljs.core.get.call(null,cljs.core.PersistentArrayMap.EMPTY,new cljs.core.Keyword(null,"hierarchy","hierarchy",-1053470341),cljs.core.get_global_hierarchy.call(null));
return (new cljs.core.MultiFn(cljs.core.symbol.call(null,"cljs.core$macros","extend-prefix"),((function (method_table__23837__auto__,prefer_table__23838__auto__,method_cache__23839__auto__,cached_hierarchy__23840__auto__,hierarchy__23841__auto__){
return (function (tsym,sym){
return new cljs.core.Keyword(null,"extend","extend",1836484006).cljs$core$IFn$_invoke$arity$1(cljs.core.meta.call(null,tsym));
});})(method_table__23837__auto__,prefer_table__23838__auto__,method_cache__23839__auto__,cached_hierarchy__23840__auto__,hierarchy__23841__auto__))
,new cljs.core.Keyword(null,"default","default",-1987822328),hierarchy__23841__auto__,method_table__23837__auto__,prefer_table__23838__auto__,method_cache__23839__auto__,cached_hierarchy__23840__auto__));
})();
}
cljs.core._add_method.call(null,cljs.core$macros.extend_prefix,new cljs.core.Keyword(null,"instance","instance",-2121349050),(function (tsym,sym){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"..","..",-300507420,null)),(function (){var x__23746__auto__ = tsym;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core$macros.to_property.call(null,sym);
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
}));
cljs.core._add_method.call(null,cljs.core$macros.extend_prefix,new cljs.core.Keyword(null,"default","default",-1987822328),(function (tsym,sym){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"..","..",-300507420,null)),(function (){var x__23746__auto__ = tsym;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"-prototype","-prototype",-450831903,null)),(function (){var x__23746__auto__ = cljs.core$macros.to_property.call(null,sym);
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
}));
cljs.core$macros.adapt_obj_params = (function cljs$core$macros$adapt_obj_params(type,p__28849){
var vec__28852 = p__28849;
var vec__28853 = cljs.core.nth.call(null,vec__28852,(0),null);
var this$ = cljs.core.nth.call(null,vec__28853,(0),null);
var args = cljs.core.nthnext.call(null,vec__28853,(1));
var sig = vec__28853;
var body = cljs.core.nthnext.call(null,vec__28852,(1));
var x__23746__auto__ = cljs.core.vec.call(null,args);
return cljs.core._conj.call(null,(function (){var x__23746__auto____$1 = cljs.core.list_STAR_.call(null,new cljs.core.Symbol(null,"this-as","this-as",-848995740,null),cljs.core.vary_meta.call(null,this$,cljs.core.assoc,new cljs.core.Keyword(null,"tag","tag",-1290361223),type),body);
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto____$1);
})(),x__23746__auto__);
});
cljs.core$macros.adapt_ifn_params = (function cljs$core$macros$adapt_ifn_params(type,p__28854){
var vec__28857 = p__28854;
var vec__28858 = cljs.core.nth.call(null,vec__28857,(0),null);
var this$ = cljs.core.nth.call(null,vec__28858,(0),null);
var args = cljs.core.nthnext.call(null,vec__28858,(1));
var sig = vec__28858;
var body = cljs.core.nthnext.call(null,vec__28857,(1));
var self_sym = cljs.core.with_meta.call(null,new cljs.core.Symbol(null,"self__","self__",-153190816,null),new cljs.core.PersistentArrayMap(null, 1, [new cljs.core.Keyword(null,"tag","tag",-1290361223),type], null));
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,(function (){var x__23746__auto__ = cljs.core.vec.call(null,cljs.core.cons.call(null,self_sym,args));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","this-as","cljs.core$macros/this-as",-799075148,null)),(function (){var x__23746__auto__ = self_sym;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","let","cljs.core$macros/let",-160286726,null)),(function (){var x__23746__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,(function (){var x__23746__auto__ = this$;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = self_sym;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})()))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),body)));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
});
cljs.core$macros.adapt_ifn_invoke_params = (function cljs$core$macros$adapt_ifn_invoke_params(type,p__28859){
var vec__28862 = p__28859;
var vec__28863 = cljs.core.nth.call(null,vec__28862,(0),null);
var this$ = cljs.core.nth.call(null,vec__28863,(0),null);
var args = cljs.core.nthnext.call(null,vec__28863,(1));
var sig = vec__28863;
var body = cljs.core.nthnext.call(null,vec__28862,(1));
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,(function (){var x__23746__auto__ = cljs.core.vec.call(null,args);
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","this-as","cljs.core$macros/this-as",-799075148,null)),(function (){var x__23746__auto__ = cljs.core.vary_meta.call(null,this$,cljs.core.assoc,new cljs.core.Keyword(null,"tag","tag",-1290361223),type);
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),body)));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
});
cljs.core$macros.adapt_proto_params = (function cljs$core$macros$adapt_proto_params(type,p__28864){
var vec__28867 = p__28864;
var vec__28868 = cljs.core.nth.call(null,vec__28867,(0),null);
var this$ = cljs.core.nth.call(null,vec__28868,(0),null);
var args = cljs.core.nthnext.call(null,vec__28868,(1));
var sig = vec__28868;
var body = cljs.core.nthnext.call(null,vec__28867,(1));
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,(function (){var x__23746__auto__ = cljs.core.vec.call(null,cljs.core.cons.call(null,cljs.core.vary_meta.call(null,this$,cljs.core.assoc,new cljs.core.Keyword(null,"tag","tag",-1290361223),type),args));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","this-as","cljs.core$macros/this-as",-799075148,null)),(function (){var x__23746__auto__ = this$;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),body)));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
});
cljs.core$macros.add_obj_methods = (function cljs$core$macros$add_obj_methods(type,type_sym,sigs){
return cljs.core.map.call(null,(function (p__28873){
var vec__28874 = p__28873;
var f = cljs.core.nth.call(null,vec__28874,(0),null);
var meths = cljs.core.nthnext.call(null,vec__28874,(1));
var form = vec__28874;
var vec__28875 = ((cljs.core.vector_QMARK_.call(null,cljs.core.first.call(null,meths)))?new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [f,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.rest.call(null,form)], null)], null):new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [f,meths], null));
var f__$1 = cljs.core.nth.call(null,vec__28875,(0),null);
var meths__$1 = cljs.core.nth.call(null,vec__28875,(1),null);
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"set!","set!",250714521,null)),(function (){var x__23746__auto__ = cljs.core$macros.extend_prefix.call(null,type_sym,f__$1);
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.with_meta.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","fn","cljs.core$macros/fn",-187522821,null)),cljs.core.map.call(null,((function (vec__28875,f__$1,meths__$1,vec__28874,f,meths,form){
return (function (p1__28869_SHARP_){
return cljs.core$macros.adapt_obj_params.call(null,type,p1__28869_SHARP_);
});})(vec__28875,f__$1,meths__$1,vec__28874,f,meths,form))
,meths__$1)))),cljs.core.meta.call(null,form));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
}),sigs);
});
cljs.core$macros.ifn_invoke_methods = (function cljs$core$macros$ifn_invoke_methods(type,type_sym,p__28877){
var vec__28879 = p__28877;
var f = cljs.core.nth.call(null,vec__28879,(0),null);
var meths = cljs.core.nthnext.call(null,vec__28879,(1));
var form = vec__28879;
return cljs.core.map.call(null,((function (vec__28879,f,meths,form){
return (function (meth){
var arity = cljs.core.count.call(null,cljs.core.first.call(null,meth));
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"set!","set!",250714521,null)),(function (){var x__23746__auto__ = cljs.core$macros.extend_prefix.call(null,type_sym,cljs.core.symbol.call(null,[cljs.core.str("cljs$core$IFn$_invoke$arity$"),cljs.core.str(arity)].join('')));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.with_meta.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","fn","cljs.core$macros/fn",-187522821,null)),(function (){var x__23746__auto__ = meth;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})()))),cljs.core.meta.call(null,form));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
});})(vec__28879,f,meths,form))
,cljs.core.map.call(null,((function (vec__28879,f,meths,form){
return (function (p1__28876_SHARP_){
return cljs.core$macros.adapt_ifn_invoke_params.call(null,type,p1__28876_SHARP_);
});})(vec__28879,f,meths,form))
,meths));
});
cljs.core$macros.add_ifn_methods = (function cljs$core$macros$add_ifn_methods(type,type_sym,p__28881){
var vec__28883 = p__28881;
var f = cljs.core.nth.call(null,vec__28883,(0),null);
var meths = cljs.core.nthnext.call(null,vec__28883,(1));
var form = vec__28883;
var meths__$1 = cljs.core.map.call(null,((function (vec__28883,f,meths,form){
return (function (p1__28880_SHARP_){
return cljs.core$macros.adapt_ifn_params.call(null,type,p1__28880_SHARP_);
});})(vec__28883,f,meths,form))
,meths);
var this_sym = cljs.core.with_meta.call(null,new cljs.core.Symbol(null,"self__","self__",-153190816,null),new cljs.core.PersistentArrayMap(null, 1, [new cljs.core.Keyword(null,"tag","tag",-1290361223),type], null));
var argsym = cljs.core.gensym.call(null,"args");
return cljs.core.concat.call(null,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"set!","set!",250714521,null)),(function (){var x__23746__auto__ = cljs.core$macros.extend_prefix.call(null,type_sym,new cljs.core.Symbol(null,"call","call",1120531661,null));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.with_meta.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","fn","cljs.core$macros/fn",-187522821,null)),meths__$1))),cljs.core.meta.call(null,form));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})()))),cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"set!","set!",250714521,null)),(function (){var x__23746__auto__ = cljs.core$macros.extend_prefix.call(null,type_sym,new cljs.core.Symbol(null,"apply","apply",-1334050276,null));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.with_meta.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","fn","cljs.core$macros/fn",-187522821,null)),(function (){var x__23746__auto__ = new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [this_sym,argsym], null);
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","this-as","cljs.core$macros/this-as",-799075148,null)),(function (){var x__23746__auto__ = this_sym;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,".apply",".apply",-1176201338,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,".-call",".-call",1760541695,null)),(function (){var x__23746__auto__ = this_sym;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = this_sym;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,".concat",".concat",1180408684,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","array","cljs.core$macros/array",49650437,null)),(function (){var x__23746__auto__ = this_sym;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","aclone","cljs.core/aclone",-758078968,null)),(function (){var x__23746__auto__ = argsym;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})()))),cljs.core.meta.call(null,form));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())))], null),cljs.core$macros.ifn_invoke_methods.call(null,type,type_sym,form));
});
cljs.core$macros.add_proto_methods_STAR_ = (function cljs$core$macros$add_proto_methods_STAR_(pprefix,type,type_sym,p__28884){
var vec__28888 = p__28884;
var f = cljs.core.nth.call(null,vec__28888,(0),null);
var meths = cljs.core.nthnext.call(null,vec__28888,(1));
var form = vec__28888;
var pf = [cljs.core.str(pprefix),cljs.core.str(cljs.core.name.call(null,f))].join('');
if(cljs.core.vector_QMARK_.call(null,cljs.core.first.call(null,meths))){
var meth = meths;
return new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"set!","set!",250714521,null)),(function (){var x__23746__auto__ = cljs.core$macros.extend_prefix.call(null,type_sym,[cljs.core.str(pf),cljs.core.str("$arity$"),cljs.core.str(cljs.core.count.call(null,cljs.core.first.call(null,meth)))].join(''));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.with_meta.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","fn","cljs.core$macros/fn",-187522821,null)),cljs.core$macros.adapt_proto_params.call(null,type,meth)))),cljs.core.meta.call(null,form));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())))], null);
} else {
return cljs.core.map.call(null,((function (pf,vec__28888,f,meths,form){
return (function (p__28889){
var vec__28890 = p__28889;
var sig = cljs.core.nth.call(null,vec__28890,(0),null);
var body = cljs.core.nthnext.call(null,vec__28890,(1));
var meth = vec__28890;
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"set!","set!",250714521,null)),(function (){var x__23746__auto__ = cljs.core$macros.extend_prefix.call(null,type_sym,[cljs.core.str(pf),cljs.core.str("$arity$"),cljs.core.str(cljs.core.count.call(null,sig))].join(''));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.with_meta.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","fn","cljs.core$macros/fn",-187522821,null)),(function (){var x__23746__auto__ = cljs.core$macros.adapt_proto_params.call(null,type,meth);
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})()))),cljs.core.meta.call(null,form));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
});})(pf,vec__28888,f,meths,form))
,meths);
}
});
cljs.core$macros.proto_assign_impls = (function cljs$core$macros$proto_assign_impls(env,resolve,type_sym,type,p__28891){
var vec__28893 = p__28891;
var p = cljs.core.nth.call(null,vec__28893,(0),null);
var sigs = cljs.core.nth.call(null,vec__28893,(1),null);
cljs.core$macros.warn_and_update_protocol.call(null,p,type,env);

var psym = resolve.call(null,p);
var pprefix = cljs.core$macros.protocol_prefix.call(null,psym);
var skip_flag = cljs.core.set.call(null,new cljs.core.Keyword(null,"skip-protocol-flag","skip-protocol-flag",-1426798630).cljs$core$IFn$_invoke$arity$1(cljs.core.meta.call(null,type_sym)));
if(cljs.core._EQ_.call(null,p,new cljs.core.Symbol(null,"Object","Object",61210754,null))){
return cljs.core$macros.add_obj_methods.call(null,type,type_sym,sigs);
} else {
return cljs.core.concat.call(null,(cljs.core.truth_(skip_flag.call(null,psym))?null:new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"set!","set!",250714521,null)),(function (){var x__23746__auto__ = cljs.core$macros.extend_prefix.call(null,type_sym,pprefix);
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,true))))], null)),cljs.core.mapcat.call(null,((function (psym,pprefix,skip_flag,vec__28893,p,sigs){
return (function (sig){
if(cljs.core._EQ_.call(null,psym,new cljs.core.Symbol("cljs.core","IFn","cljs.core/IFn",-920223129,null))){
return cljs.core$macros.add_ifn_methods.call(null,type,type_sym,sig);
} else {
return cljs.core$macros.add_proto_methods_STAR_.call(null,pprefix,type,type_sym,sig);
}
});})(psym,pprefix,skip_flag,vec__28893,p,sigs))
,sigs));
}
});
cljs.core$macros.validate_impl_sigs = (function cljs$core$macros$validate_impl_sigs(env,p,method){
if(cljs.core._EQ_.call(null,p,new cljs.core.Symbol(null,"Object","Object",61210754,null))){
return null;
} else {
var var$ = cljs.analyzer.resolve_var.call(null,cljs.core.dissoc.call(null,env,new cljs.core.Keyword(null,"locals","locals",535295783)),p);
var minfo = new cljs.core.Keyword(null,"methods","methods",453930866).cljs$core$IFn$_invoke$arity$1(new cljs.core.Keyword(null,"protocol-info","protocol-info",1471745843).cljs$core$IFn$_invoke$arity$1(var$));
var method_name = cljs.core.first.call(null,method);
var __GT_name = cljs.core.comp.call(null,cljs.core.symbol,cljs.core.name);
var vec__28895 = ((cljs.core.vector_QMARK_.call(null,cljs.core.second.call(null,method)))?new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [__GT_name.call(null,method_name),new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.second.call(null,method)], null)], null):new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [__GT_name.call(null,method_name),cljs.core.map.call(null,cljs.core.first,cljs.core.rest.call(null,method))], null));
var fname = cljs.core.nth.call(null,vec__28895,(0),null);
var sigs = cljs.core.nth.call(null,vec__28895,(1),null);
var decmeths = cljs.core.get.call(null,minfo,fname,new cljs.core.Keyword("cljs.core$macros","not-found","cljs.core$macros/not-found",-1226326556));
if(cljs.core._EQ_.call(null,decmeths,new cljs.core.Keyword("cljs.core$macros","not-found","cljs.core$macros/not-found",-1226326556))){
cljs.analyzer.warning.call(null,new cljs.core.Keyword(null,"protocol-invalid-method","protocol-invalid-method",522647516),env,new cljs.core.PersistentArrayMap(null, 3, [new cljs.core.Keyword(null,"protocol","protocol",652470118),p,new cljs.core.Keyword(null,"fname","fname",1500291491),fname,new cljs.core.Keyword(null,"no-such-method","no-such-method",1087422840),true], null));
} else {
}

if(cljs.core.truth_(cljs.core.namespace.call(null,method_name))){
var method_var_28896 = cljs.analyzer.resolve_var.call(null,cljs.core.dissoc.call(null,env,new cljs.core.Keyword(null,"locals","locals",535295783)),method_name,cljs.analyzer.confirm_var_exist_warning);
if(cljs.core._EQ_.call(null,new cljs.core.Keyword(null,"name","name",1843675177).cljs$core$IFn$_invoke$arity$1(var$),new cljs.core.Keyword(null,"protocol","protocol",652470118).cljs$core$IFn$_invoke$arity$1(method_var_28896))){
} else {
cljs.analyzer.warning.call(null,new cljs.core.Keyword(null,"protocol-invalid-method","protocol-invalid-method",522647516),env,new cljs.core.PersistentArrayMap(null, 3, [new cljs.core.Keyword(null,"protocol","protocol",652470118),p,new cljs.core.Keyword(null,"fname","fname",1500291491),method_name,new cljs.core.Keyword(null,"no-such-method","no-such-method",1087422840),true], null));
}
} else {
}

var sigs__$1 = sigs;
var seen = cljs.core.PersistentHashSet.EMPTY;
while(true){
if(cljs.core.seq.call(null,sigs__$1)){
var sig = cljs.core.first.call(null,sigs__$1);
var c = cljs.core.count.call(null,sig);
if(cljs.core.contains_QMARK_.call(null,seen,c)){
cljs.analyzer.warning.call(null,new cljs.core.Keyword(null,"protocol-duped-method","protocol-duped-method",15128166),env,new cljs.core.PersistentArrayMap(null, 2, [new cljs.core.Keyword(null,"protocol","protocol",652470118),p,new cljs.core.Keyword(null,"fname","fname",1500291491),fname], null));
} else {
}

if((cljs.core.not_EQ_.call(null,decmeths,new cljs.core.Keyword("cljs.core$macros","not-found","cljs.core$macros/not-found",-1226326556))) && (cljs.core.not.call(null,cljs.core.some.call(null,cljs.core.PersistentHashSet.fromArray([c], true),cljs.core.map.call(null,cljs.core.count,decmeths))))){
cljs.analyzer.warning.call(null,new cljs.core.Keyword(null,"protocol-invalid-method","protocol-invalid-method",522647516),env,new cljs.core.PersistentArrayMap(null, 3, [new cljs.core.Keyword(null,"protocol","protocol",652470118),p,new cljs.core.Keyword(null,"fname","fname",1500291491),fname,new cljs.core.Keyword(null,"invalid-arity","invalid-arity",1335461949),c], null));
} else {
}

var G__28897 = cljs.core.next.call(null,sigs__$1);
var G__28898 = cljs.core.conj.call(null,seen,c);
sigs__$1 = G__28897;
seen = G__28898;
continue;
} else {
return null;
}
break;
}
}
});
cljs.core$macros.validate_impls = (function cljs$core$macros$validate_impls(env,impls){
var protos = cljs.core.PersistentHashSet.EMPTY;
var impls__$1 = impls;
while(true){
if(cljs.core.seq.call(null,impls__$1)){
var proto = cljs.core.first.call(null,impls__$1);
var methods$ = cljs.core.take_while.call(null,cljs.core.seq_QMARK_,cljs.core.next.call(null,impls__$1));
var impls__$2 = cljs.core.drop_while.call(null,cljs.core.seq_QMARK_,cljs.core.next.call(null,impls__$1));
if(cljs.core.contains_QMARK_.call(null,protos,proto)){
cljs.analyzer.warning.call(null,new cljs.core.Keyword(null,"protocol-multiple-impls","protocol-multiple-impls",794179260),env,new cljs.core.PersistentArrayMap(null, 1, [new cljs.core.Keyword(null,"protocol","protocol",652470118),proto], null));
} else {
}

var seen_28901 = cljs.core.PersistentHashSet.EMPTY;
var methods_28902__$1 = methods$;
while(true){
if(cljs.core.seq.call(null,methods_28902__$1)){
var vec__28900_28903 = cljs.core.first.call(null,methods_28902__$1);
var fname_28904 = cljs.core.nth.call(null,vec__28900_28903,(0),null);
var method_28905 = vec__28900_28903;
if(cljs.core.contains_QMARK_.call(null,seen_28901,fname_28904)){
cljs.analyzer.warning.call(null,new cljs.core.Keyword(null,"extend-type-invalid-method-shape","extend-type-invalid-method-shape",1424103549),env,new cljs.core.PersistentArrayMap(null, 2, [new cljs.core.Keyword(null,"protocol","protocol",652470118),proto,new cljs.core.Keyword(null,"method","method",55703592),fname_28904], null));
} else {
}

cljs.core$macros.validate_impl_sigs.call(null,env,proto,method_28905);

var G__28906 = cljs.core.conj.call(null,seen_28901,fname_28904);
var G__28907 = cljs.core.next.call(null,methods_28902__$1);
seen_28901 = G__28906;
methods_28902__$1 = G__28907;
continue;
} else {
}
break;
}

var G__28908 = cljs.core.conj.call(null,protos,proto);
var G__28909 = impls__$2;
protos = G__28908;
impls__$1 = G__28909;
continue;
} else {
return null;
}
break;
}
});
cljs.core$macros.type_hint_first_arg = (function cljs$core$macros$type_hint_first_arg(type_sym,argv){
return cljs.core.assoc.call(null,argv,(0),cljs.core.vary_meta.call(null,argv.call(null,(0)),cljs.core.assoc,new cljs.core.Keyword(null,"tag","tag",-1290361223),type_sym));
});
cljs.core$macros.type_hint_single_arity_sig = (function cljs$core$macros$type_hint_single_arity_sig(type_sym,sig){
return cljs.core.list_STAR_.call(null,cljs.core.first.call(null,sig),cljs.core$macros.type_hint_first_arg.call(null,type_sym,cljs.core.second.call(null,sig)),cljs.core.nnext.call(null,sig));
});
cljs.core$macros.type_hint_multi_arity_sig = (function cljs$core$macros$type_hint_multi_arity_sig(type_sym,sig){
return cljs.core.list_STAR_.call(null,cljs.core$macros.type_hint_first_arg.call(null,type_sym,cljs.core.first.call(null,sig)),cljs.core.next.call(null,sig));
});
cljs.core$macros.type_hint_multi_arity_sigs = (function cljs$core$macros$type_hint_multi_arity_sigs(type_sym,sigs){
return cljs.core.list_STAR_.call(null,cljs.core.first.call(null,sigs),cljs.core.map.call(null,cljs.core.partial.call(null,cljs.core$macros.type_hint_multi_arity_sig,type_sym),cljs.core.rest.call(null,sigs)));
});
cljs.core$macros.type_hint_sigs = (function cljs$core$macros$type_hint_sigs(type_sym,sig){
if(cljs.core.vector_QMARK_.call(null,cljs.core.second.call(null,sig))){
return cljs.core$macros.type_hint_single_arity_sig.call(null,type_sym,sig);
} else {
return cljs.core$macros.type_hint_multi_arity_sigs.call(null,type_sym,sig);
}
});
cljs.core$macros.type_hint_impl_map = (function cljs$core$macros$type_hint_impl_map(type_sym,impl_map){
return cljs.core.reduce_kv.call(null,(function (m,proto,sigs){
return cljs.core.assoc.call(null,m,proto,cljs.core.map.call(null,cljs.core.partial.call(null,cljs.core$macros.type_hint_sigs,type_sym),sigs));
}),cljs.core.PersistentArrayMap.EMPTY,impl_map);
});
/**
 * Extend a type to a series of protocols. Useful when you are
 *   supplying the definitions explicitly inline. Propagates the
 *   type as a type hint on the first argument of all fns.
 * 
 *   type-sym may be
 * 
 * * default, meaning the definitions will apply for any value,
 *   unless an extend-type exists for one of the more specific
 *   cases below.
 * * nil, meaning the definitions will apply for the nil value.
 * * any of object, boolean, number, string, array, or function,
 *   indicating the definitions will apply for values of the
 *   associated base JavaScript types. Note that, for example,
 *   string should be used instead of js/String.
 * * a JavaScript type not covered by the previous list, such
 *   as js/RegExp.
 * * a type defined by deftype or defrecord.
 * 
 *   (extend-type MyType
 *  ICounted
 *  (-count [c] ...)
 *  Foo
 *  (bar [x y] ...)
 *  (baz ([x] ...) ([x y & zs] ...))
 */
cljs.core$macros.extend_type = (function cljs$core$macros$extend_type(var_args){
var args__23989__auto__ = [];
var len__23982__auto___28916 = arguments.length;
var i__23983__auto___28917 = (0);
while(true){
if((i__23983__auto___28917 < len__23982__auto___28916)){
args__23989__auto__.push((arguments[i__23983__auto___28917]));

var G__28918 = (i__23983__auto___28917 + (1));
i__23983__auto___28917 = G__28918;
continue;
} else {
}
break;
}

var argseq__23990__auto__ = ((((3) < args__23989__auto__.length))?(new cljs.core.IndexedSeq(args__23989__auto__.slice((3)),(0),null)):null);
return cljs.core$macros.extend_type.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),argseq__23990__auto__);
});

cljs.core$macros.extend_type.cljs$core$IFn$_invoke$arity$variadic = (function (_AMPERSAND_form,_AMPERSAND_env,type_sym,impls){
var env = _AMPERSAND_env;
var _ = cljs.core$macros.validate_impls.call(null,env,impls);
var resolve = cljs.core.partial.call(null,cljs.core$macros.resolve_var,env);
var impl_map = cljs.core$macros.__GT_impl_map.call(null,impls);
var impl_map__$1 = (cljs.core.truth_(new cljs.core.PersistentHashSet(null, new cljs.core.PersistentArrayMap(null, 2, [new cljs.core.Symbol(null,"boolean","boolean",-278886877,null),null,new cljs.core.Symbol(null,"number","number",-1084057331,null),null], null), null).call(null,type_sym))?cljs.core$macros.type_hint_impl_map.call(null,type_sym,impl_map):impl_map);
var vec__28915 = (function (){var temp__4655__auto__ = cljs.core$macros.base_type.call(null,type_sym);
if(cljs.core.truth_(temp__4655__auto__)){
var type = temp__4655__auto__;
return new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [type,cljs.core$macros.base_assign_impls], null);
} else {
return new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [resolve.call(null,type_sym),cljs.core$macros.proto_assign_impls], null);
}
})();
var type = cljs.core.nth.call(null,vec__28915,(0),null);
var assign_impls = cljs.core.nth.call(null,vec__28915,(1),null);
if(cljs.core.truth_((function (){var and__22900__auto__ = new cljs.core.Keyword(null,"extending-base-js-type","extending-base-js-type",432787264).cljs$core$IFn$_invoke$arity$1(cljs.analyzer._STAR_cljs_warnings_STAR_);
if(cljs.core.truth_(and__22900__auto__)){
return cljs.core$macros.js_base_type.call(null,type_sym);
} else {
return and__22900__auto__;
}
})())){
cljs.analyzer.warning.call(null,new cljs.core.Keyword(null,"extending-base-js-type","extending-base-js-type",432787264),env,new cljs.core.PersistentArrayMap(null, 2, [new cljs.core.Keyword(null,"current-symbol","current-symbol",-932381075),type_sym,new cljs.core.Keyword(null,"suggested-symbol","suggested-symbol",-1329631875),cljs.core$macros.js_base_type.call(null,type_sym)], null));
} else {
}

return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"do","do",1686842252,null)),cljs.core.mapcat.call(null,((function (env,_,resolve,impl_map,impl_map__$1,vec__28915,type,assign_impls){
return (function (p1__28910_SHARP_){
return assign_impls.call(null,env,resolve,type_sym,type,p1__28910_SHARP_);
});})(env,_,resolve,impl_map,impl_map__$1,vec__28915,type,assign_impls))
,impl_map__$1))));
});

cljs.core$macros.extend_type.cljs$lang$maxFixedArity = (3);

cljs.core$macros.extend_type.cljs$lang$applyTo = (function (seq28911){
var G__28912 = cljs.core.first.call(null,seq28911);
var seq28911__$1 = cljs.core.next.call(null,seq28911);
var G__28913 = cljs.core.first.call(null,seq28911__$1);
var seq28911__$2 = cljs.core.next.call(null,seq28911__$1);
var G__28914 = cljs.core.first.call(null,seq28911__$2);
var seq28911__$3 = cljs.core.next.call(null,seq28911__$2);
return cljs.core$macros.extend_type.cljs$core$IFn$_invoke$arity$variadic(G__28912,G__28913,G__28914,seq28911__$3);
});

cljs.core$macros.extend_type.cljs$lang$macro = true;
cljs.core$macros.prepare_protocol_masks = (function cljs$core$macros$prepare_protocol_masks(env,impls){
var resolve = cljs.core.partial.call(null,cljs.core$macros.resolve_var,env);
var impl_map = cljs.core$macros.__GT_impl_map.call(null,impls);
var fpp_pbs = cljs.core.seq.call(null,cljs.core.keep.call(null,cljs.core$macros.fast_path_protocols,cljs.core.map.call(null,resolve,cljs.core.keys.call(null,impl_map))));
if(fpp_pbs){
var fpps = cljs.core.into.call(null,cljs.core.PersistentHashSet.EMPTY,cljs.core.filter.call(null,cljs.core.partial.call(null,cljs.core.contains_QMARK_,cljs.core$macros.fast_path_protocols),cljs.core.map.call(null,resolve,cljs.core.keys.call(null,impl_map))));
var parts = (function (){var parts = cljs.core.group_by.call(null,cljs.core.first,fpp_pbs);
var parts__$1 = cljs.core.into.call(null,cljs.core.PersistentArrayMap.EMPTY,cljs.core.map.call(null,cljs.core.juxt.call(null,cljs.core.key,cljs.core.comp.call(null,cljs.core.partial.call(null,cljs.core.map,cljs.core.peek),cljs.core.val)),parts));
return cljs.core.into.call(null,cljs.core.PersistentArrayMap.EMPTY,cljs.core.map.call(null,cljs.core.juxt.call(null,cljs.core.key,cljs.core.comp.call(null,cljs.core.partial.call(null,cljs.core.reduce,cljs.core.bit_or),cljs.core.val)),parts__$1));
})();
return new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [fpps,cljs.core.reduce.call(null,((function (fpps,parts,resolve,impl_map,fpp_pbs){
return (function (ps,p){
return cljs.core.update_in.call(null,ps,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [p], null),cljs.core.fnil.call(null,cljs.core.identity,(0)));
});})(fpps,parts,resolve,impl_map,fpp_pbs))
,parts,cljs.core.range.call(null,cljs.core$macros.fast_path_protocol_partitions_count))], null);
} else {
return null;
}
});
cljs.core$macros.annotate_specs = (function cljs$core$macros$annotate_specs(annots,v,p__28920){
var vec__28922 = p__28920;
var f = cljs.core.nth.call(null,vec__28922,(0),null);
var sigs = cljs.core.nth.call(null,vec__28922,(1),null);
return cljs.core.conj.call(null,v,cljs.core.vary_meta.call(null,cljs.core.cons.call(null,f,cljs.core.map.call(null,((function (vec__28922,f,sigs){
return (function (p1__28919_SHARP_){
return cljs.core.cons.call(null,cljs.core.second.call(null,p1__28919_SHARP_),cljs.core.nnext.call(null,p1__28919_SHARP_));
});})(vec__28922,f,sigs))
,sigs)),cljs.core.merge,annots));
});
cljs.core$macros.dt__GT_et = (function cljs$core$macros$dt__GT_et(var_args){
var args28923 = [];
var len__23982__auto___28926 = arguments.length;
var i__23983__auto___28927 = (0);
while(true){
if((i__23983__auto___28927 < len__23982__auto___28926)){
args28923.push((arguments[i__23983__auto___28927]));

var G__28928 = (i__23983__auto___28927 + (1));
i__23983__auto___28927 = G__28928;
continue;
} else {
}
break;
}

var G__28925 = args28923.length;
switch (G__28925) {
case 3:
return cljs.core$macros.dt__GT_et.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
case 4:
return cljs.core$macros.dt__GT_et.cljs$core$IFn$_invoke$arity$4((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]));

break;
default:
throw (new Error([cljs.core.str("Invalid arity: "),cljs.core.str(args28923.length)].join('')));

}
});

cljs.core$macros.dt__GT_et.cljs$core$IFn$_invoke$arity$3 = (function (type,specs,fields){
return cljs.core$macros.dt__GT_et.call(null,type,specs,fields,false);
});

cljs.core$macros.dt__GT_et.cljs$core$IFn$_invoke$arity$4 = (function (type,specs,fields,inline){
var annots = new cljs.core.PersistentArrayMap(null, 3, [new cljs.core.Keyword("cljs.analyzer","type","cljs.analyzer/type",478749742),type,new cljs.core.Keyword("cljs.analyzer","protocol-impl","cljs.analyzer/protocol-impl",-1523935409),true,new cljs.core.Keyword("cljs.analyzer","protocol-inline","cljs.analyzer/protocol-inline",-1611519026),inline], null);
var ret = cljs.core.PersistentVector.EMPTY;
var specs__$1 = specs;
while(true){
if(cljs.core.seq.call(null,specs__$1)){
var p = cljs.core.first.call(null,specs__$1);
var ret__$1 = cljs.core.into.call(null,cljs.core.conj.call(null,ret,p),cljs.core.reduce.call(null,cljs.core.partial.call(null,cljs.core$macros.annotate_specs,annots),cljs.core.PersistentVector.EMPTY,cljs.core.group_by.call(null,cljs.core.first,cljs.core.take_while.call(null,cljs.core.seq_QMARK_,cljs.core.next.call(null,specs__$1)))));
var specs__$2 = cljs.core.drop_while.call(null,cljs.core.seq_QMARK_,cljs.core.next.call(null,specs__$1));
var G__28930 = ret__$1;
var G__28931 = specs__$2;
ret = G__28930;
specs__$1 = G__28931;
continue;
} else {
return ret;
}
break;
}
});

cljs.core$macros.dt__GT_et.cljs$lang$maxFixedArity = 4;
cljs.core$macros.collect_protocols = (function cljs$core$macros$collect_protocols(impls,env){
return cljs.core.into.call(null,cljs.core.PersistentHashSet.EMPTY,cljs.core.map.call(null,(function (p1__28932_SHARP_){
return new cljs.core.Keyword(null,"name","name",1843675177).cljs$core$IFn$_invoke$arity$1(cljs.analyzer.resolve_var.call(null,cljs.core.dissoc.call(null,env,new cljs.core.Keyword(null,"locals","locals",535295783)),p1__28932_SHARP_));
}),cljs.core.filter.call(null,cljs.core.symbol_QMARK_,impls)));
});
cljs.core$macros.build_positional_factory = (function cljs$core$macros$build_positional_factory(rsym,rname,fields){
var fn_name = cljs.core.with_meta.call(null,cljs.core.symbol.call(null,[cljs.core.str(new cljs.core.Symbol(null,"->","->",-2139605430,null)),cljs.core.str(rsym)].join('')),cljs.core.assoc.call(null,cljs.core.meta.call(null,rsym),new cljs.core.Keyword(null,"factory","factory",63933746),new cljs.core.Keyword(null,"positional","positional",-203580463)));
var field_values = (cljs.core.truth_(new cljs.core.Keyword(null,"internal-ctor","internal-ctor",937392560).cljs$core$IFn$_invoke$arity$1(cljs.core.meta.call(null,rsym)))?cljs.core.conj.call(null,fields,null,null,null):fields);
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","defn","cljs.core$macros/defn",-728332354,null)),(function (){var x__23746__auto__ = fn_name;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,fields))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"new","new",-444906321,null)),(function (){var x__23746__auto__ = rname;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),field_values)));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
});
cljs.core$macros.validate_fields = (function cljs$core$macros$validate_fields(case$,name,fields){
if(cljs.core.vector_QMARK_.call(null,fields)){
return null;
} else {
throw (new Error([cljs.core.str(case$),cljs.core.str(" "),cljs.core.str(name),cljs.core.str(", no fields vector given.")].join('')));
}
});
/**
 * (deftype name [fields*]  options* specs*)
 * 
 *   Currently there are no options.
 * 
 *   Each spec consists of a protocol or interface name followed by zero
 *   or more method bodies:
 * 
 *   protocol-or-Object
 *   (methodName [args*] body)*
 * 
 *   The type will have the (by default, immutable) fields named by
 *   fields, which can have type hints. Protocols and methods
 *   are optional. The only methods that can be supplied are those
 *   declared in the protocols/interfaces.  Note that method bodies are
 *   not closures, the local environment includes only the named fields,
 *   and those fields can be accessed directly. Fields can be qualified
 *   with the metadata :mutable true at which point (set! afield aval) will be
 *   supported in method bodies. Note well that mutable fields are extremely
 *   difficult to use correctly, and are present only to facilitate the building
 *   of higherlevel constructs, such as ClojureScript's reference types, in
 *   ClojureScript itself. They are for experts only - if the semantics and
 *   implications of :mutable are not immediately apparent to you, you should not
 *   be using them.
 * 
 *   Method definitions take the form:
 * 
 *   (methodname [args*] body)
 * 
 *   The argument and return types can be hinted on the arg and
 *   methodname symbols. If not supplied, they will be inferred, so type
 *   hints should be reserved for disambiguation.
 * 
 *   Methods should be supplied for all methods of the desired
 *   protocol(s). You can also define overrides for methods of Object. Note that
 *   a parameter must be supplied to correspond to the target object
 *   ('this' in JavaScript parlance). Note also that recur calls to the method
 *   head should *not* pass the target object, it will be supplied
 *   automatically and can not be substituted.
 * 
 *   In the method bodies, the (unqualified) name can be used to name the
 *   class (for calls to new, instance? etc).
 * 
 *   One constructor will be defined, taking the designated fields.  Note
 *   that the field names __meta and __extmap are currently reserved and
 *   should not be used when defining your own types.
 * 
 *   Given (deftype TypeName ...), a factory function called ->TypeName
 *   will be defined, taking positional parameters for the fields
 */
cljs.core$macros.deftype = (function cljs$core$macros$deftype(var_args){
var args__23989__auto__ = [];
var len__23982__auto___28942 = arguments.length;
var i__23983__auto___28943 = (0);
while(true){
if((i__23983__auto___28943 < len__23982__auto___28942)){
args__23989__auto__.push((arguments[i__23983__auto___28943]));

var G__28944 = (i__23983__auto___28943 + (1));
i__23983__auto___28943 = G__28944;
continue;
} else {
}
break;
}

var argseq__23990__auto__ = ((((4) < args__23989__auto__.length))?(new cljs.core.IndexedSeq(args__23989__auto__.slice((4)),(0),null)):null);
return cljs.core$macros.deftype.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]),argseq__23990__auto__);
});

cljs.core$macros.deftype.cljs$core$IFn$_invoke$arity$variadic = (function (_AMPERSAND_form,_AMPERSAND_env,t,fields,impls){
cljs.core$macros.validate_fields.call(null,"deftype",t,fields);

var env = _AMPERSAND_env;
var r = new cljs.core.Keyword(null,"name","name",1843675177).cljs$core$IFn$_invoke$arity$1(cljs.analyzer.resolve_var.call(null,cljs.core.dissoc.call(null,env,new cljs.core.Keyword(null,"locals","locals",535295783)),t));
var vec__28941 = cljs.core$macros.prepare_protocol_masks.call(null,env,impls);
var fpps = cljs.core.nth.call(null,vec__28941,(0),null);
var pmasks = cljs.core.nth.call(null,vec__28941,(1),null);
var protocols = cljs.core$macros.collect_protocols.call(null,impls,env);
var t__$1 = cljs.core.vary_meta.call(null,t,cljs.core.assoc,new cljs.core.Keyword(null,"protocols","protocols",-5615896),protocols,new cljs.core.Keyword(null,"skip-protocol-flag","skip-protocol-flag",-1426798630),fpps);
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"do","do",1686842252,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"deftype*","deftype*",962659890,null)),(function (){var x__23746__auto__ = t__$1;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = fields;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = pmasks;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = ((cljs.core.seq.call(null,impls))?cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","extend-type","cljs.core$macros/extend-type",1713295201,null)),(function (){var x__23746__auto__ = t__$1;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),cljs.core$macros.dt__GT_et.call(null,t__$1,impls,fields)))):null);
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"set!","set!",250714521,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,".-getBasis",".-getBasis",-1306451468,null)),(function (){var x__23746__auto__ = t__$1;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","fn","cljs.core$macros/fn",-187522821,null)),(function (){var x__23746__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"quote","quote",1377916282,null)),(function (){var x__23746__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,fields))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"set!","set!",250714521,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,".-cljs$lang$type",".-cljs$lang$type",-1029307724,null)),(function (){var x__23746__auto__ = t__$1;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,true))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"set!","set!",250714521,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,".-cljs$lang$ctorStr",".-cljs$lang$ctorStr",-1820706991,null)),(function (){var x__23746__auto__ = t__$1;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = [cljs.core.str(r)].join('');
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"set!","set!",250714521,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,".-cljs$lang$ctorPrWriter",".-cljs$lang$ctorPrWriter",255834464,null)),(function (){var x__23746__auto__ = t__$1;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","fn","cljs.core$macros/fn",-187522821,null)),(function (){var x__23746__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"this__28933__auto__","this__28933__auto__",-492192728,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"writer__28934__auto__","writer__28934__auto__",1702984093,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"opt__28935__auto__","opt__28935__auto__",231748887,null))))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","-write","cljs.core/-write",527220517,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"writer__28934__auto__","writer__28934__auto__",1702984093,null)),(function (){var x__23746__auto__ = [cljs.core.str(r)].join('');
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core$macros.build_positional_factory.call(null,t__$1,r,fields);
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = t__$1;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
});

cljs.core$macros.deftype.cljs$lang$maxFixedArity = (4);

cljs.core$macros.deftype.cljs$lang$applyTo = (function (seq28936){
var G__28937 = cljs.core.first.call(null,seq28936);
var seq28936__$1 = cljs.core.next.call(null,seq28936);
var G__28938 = cljs.core.first.call(null,seq28936__$1);
var seq28936__$2 = cljs.core.next.call(null,seq28936__$1);
var G__28939 = cljs.core.first.call(null,seq28936__$2);
var seq28936__$3 = cljs.core.next.call(null,seq28936__$2);
var G__28940 = cljs.core.first.call(null,seq28936__$3);
var seq28936__$4 = cljs.core.next.call(null,seq28936__$3);
return cljs.core$macros.deftype.cljs$core$IFn$_invoke$arity$variadic(G__28937,G__28938,G__28939,G__28940,seq28936__$4);
});

cljs.core$macros.deftype.cljs$lang$macro = true;
/**
 * Do not use this directly - use defrecord
 */
cljs.core$macros.emit_defrecord = (function cljs$core$macros$emit_defrecord(env,tagname,rname,fields,impls){
var hinted_fields = fields;
var fields__$1 = cljs.core.vec.call(null,cljs.core.map.call(null,((function (hinted_fields){
return (function (p1__28945_SHARP_){
return cljs.core.with_meta.call(null,p1__28945_SHARP_,null);
});})(hinted_fields))
,fields));
var base_fields = fields__$1;
var pr_open = [cljs.core.str("#"),cljs.core.str(cljs.core.namespace.call(null,rname)),cljs.core.str("."),cljs.core.str(cljs.core.name.call(null,rname)),cljs.core.str("{")].join('');
var fields__$2 = cljs.core.conj.call(null,fields__$1,new cljs.core.Symbol(null,"__meta","__meta",-946752628,null),new cljs.core.Symbol(null,"__extmap","__extmap",-1435580931,null),cljs.core.with_meta.call(null,new cljs.core.Symbol(null,"__hash","__hash",-1328796629,null),new cljs.core.PersistentArrayMap(null, 1, [new cljs.core.Keyword(null,"mutable","mutable",875778266),true], null)));
var gs = cljs.core.gensym.call(null);
var ksym = cljs.core.gensym.call(null,"k");
var impls__$1 = cljs.core.concat.call(null,impls,new cljs.core.PersistentVector(null, 28, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Symbol(null,"IRecord","IRecord",-903221169,null),new cljs.core.Symbol(null,"ICloneable","ICloneable",1882653160,null),cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"-clone","-clone",227130084,null)),(function (){var x__23746__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"this__28946__auto__","this__28946__auto__",752107907,null))))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"new","new",-444906321,null)),(function (){var x__23746__auto__ = tagname;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),fields__$2)));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})()))),new cljs.core.Symbol(null,"IHash","IHash",-1495374645,null),cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"-hash","-hash",-630070274,null)),(function (){var x__23746__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"this__28947__auto__","this__28947__auto__",1544792509,null))))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","caching-hash","cljs.core$macros/caching-hash",-1892393069,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"this__28947__auto__","this__28947__auto__",1544792509,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"hash-imap","hash-imap",-1047446478,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"__hash","__hash",-1328796629,null)))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})()))),new cljs.core.Symbol(null,"IEquiv","IEquiv",-1912850869,null),cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"-equiv","-equiv",320124272,null)),(function (){var x__23746__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"this__28948__auto__","this__28948__auto__",544635711,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"other__28949__auto__","other__28949__auto__",-1423308628,null))))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"if","if",1181717262,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","and","cljs.core$macros/and",48320334,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"other__28949__auto__","other__28949__auto__",-1423308628,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","identical?","cljs.core$macros/identical?",815580547,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,".-constructor",".-constructor",279801701,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"this__28948__auto__","this__28948__auto__",544635711,null)))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,".-constructor",".-constructor",279801701,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"other__28949__auto__","other__28949__auto__",-1423308628,null)))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","equiv-map","cljs.core/equiv-map",-1185609892,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"this__28948__auto__","this__28948__auto__",544635711,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"other__28949__auto__","other__28949__auto__",-1423308628,null)))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,true),cljs.core._conj.call(null,cljs.core.List.EMPTY,false))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})()))),new cljs.core.Symbol(null,"IMeta","IMeta",1095313672,null),cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"-meta","-meta",494863156,null)),(function (){var x__23746__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"this__28950__auto__","this__28950__auto__",-1650852723,null))))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"__meta","__meta",-946752628,null))))),new cljs.core.Symbol(null,"IWithMeta","IWithMeta",-509493158,null),cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"-with-meta","-with-meta",-1610713823,null)),(function (){var x__23746__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"this__28951__auto__","this__28951__auto__",1684340654,null)),(function (){var x__23746__auto__ = gs;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})()))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"new","new",-444906321,null)),(function (){var x__23746__auto__ = tagname;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),cljs.core.replace.call(null,new cljs.core.PersistentArrayMap(null, 1, [new cljs.core.Symbol(null,"__meta","__meta",-946752628,null),gs], null),fields__$2))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})()))),new cljs.core.Symbol(null,"ILookup","ILookup",784647298,null),cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"-lookup","-lookup",-1438393944,null)),(function (){var x__23746__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"this__28952__auto__","this__28952__auto__",-981859144,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"k__28953__auto__","k__28953__auto__",959853654,null))))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","-lookup","cljs.core/-lookup",-1845674443,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"this__28952__auto__","this__28952__auto__",-981859144,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"k__28953__auto__","k__28953__auto__",959853654,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,null))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})()))),cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"-lookup","-lookup",-1438393944,null)),(function (){var x__23746__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"this__28954__auto__","this__28954__auto__",446320820,null)),(function (){var x__23746__auto__ = ksym;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"else__28955__auto__","else__28955__auto__",-1779055345,null))))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","case","cljs.core$macros/case",-2131866965,null)),(function (){var x__23746__auto__ = ksym;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),cljs.core.mapcat.call(null,((function (gs,ksym,hinted_fields,fields__$1,base_fields,pr_open,fields__$2){
return (function (f){
return new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.keyword.call(null,f),f], null);
});})(gs,ksym,hinted_fields,fields__$1,base_fields,pr_open,fields__$2))
,base_fields),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","get","cljs.core/get",-296075407,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"__extmap","__extmap",-1435580931,null)),(function (){var x__23746__auto__ = ksym;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"else__28955__auto__","else__28955__auto__",-1779055345,null)))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})()))),new cljs.core.Symbol(null,"ICounted","ICounted",-1705786327,null),cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"-count","-count",416049189,null)),(function (){var x__23746__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"this__28956__auto__","this__28956__auto__",1591096738,null))))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","+","cljs.core$macros/+",-18260342,null)),(function (){var x__23746__auto__ = cljs.core.count.call(null,base_fields);
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","count","cljs.core/count",-921270233,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"__extmap","__extmap",-1435580931,null)))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})()))),new cljs.core.Symbol(null,"ICollection","ICollection",-686709190,null),cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"-conj","-conj",1373798691,null)),(function (){var x__23746__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"this__28957__auto__","this__28957__auto__",1952019530,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"entry__28958__auto__","entry__28958__auto__",-165289641,null))))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"if","if",1181717262,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","vector?","cljs.core/vector?",-1550392028,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"entry__28958__auto__","entry__28958__auto__",-165289641,null)))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","-assoc","cljs.core/-assoc",-814539323,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"this__28957__auto__","this__28957__auto__",1952019530,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","-nth","cljs.core/-nth",504234802,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"entry__28958__auto__","entry__28958__auto__",-165289641,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,(0)))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","-nth","cljs.core/-nth",504234802,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"entry__28958__auto__","entry__28958__auto__",-165289641,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,(1)))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","reduce","cljs.core/reduce",2025430439,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","-conj","cljs.core/-conj",2040622670,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"this__28957__auto__","this__28957__auto__",1952019530,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"entry__28958__auto__","entry__28958__auto__",-165289641,null)))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})()))),new cljs.core.Symbol(null,"IAssociative","IAssociative",-1306431882,null),cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"-assoc","-assoc",-416089758,null)),(function (){var x__23746__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"this__28959__auto__","this__28959__auto__",-837220863,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"k__28960__auto__","k__28960__auto__",651383168,null)),(function (){var x__23746__auto__ = gs;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})()))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","condp","cljs.core$macros/condp",431619047,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","keyword-identical?","cljs.core/keyword-identical?",1598491177,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"k__28960__auto__","k__28960__auto__",651383168,null)),cljs.core.mapcat.call(null,((function (gs,ksym,hinted_fields,fields__$1,base_fields,pr_open,fields__$2){
return (function (fld){
return new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.keyword.call(null,fld),cljs.core.list_STAR_.call(null,new cljs.core.Symbol(null,"new","new",-444906321,null),tagname,cljs.core.replace.call(null,cljs.core.PersistentArrayMap.fromArray([fld,gs,new cljs.core.Symbol(null,"__hash","__hash",-1328796629,null),null], true, false),fields__$2))], null);
});})(gs,ksym,hinted_fields,fields__$1,base_fields,pr_open,fields__$2))
,base_fields),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"new","new",-444906321,null)),(function (){var x__23746__auto__ = tagname;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),cljs.core.remove.call(null,new cljs.core.PersistentHashSet(null, new cljs.core.PersistentArrayMap(null, 2, [new cljs.core.Symbol(null,"__hash","__hash",-1328796629,null),null,new cljs.core.Symbol(null,"__extmap","__extmap",-1435580931,null),null], null), null),fields__$2),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","assoc","cljs.core/assoc",322326297,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"__extmap","__extmap",-1435580931,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"k__28960__auto__","k__28960__auto__",651383168,null)),(function (){var x__23746__auto__ = gs;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,null))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})()))),new cljs.core.Symbol(null,"IMap","IMap",992876629,null),cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"-dissoc","-dissoc",1638079447,null)),(function (){var x__23746__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"this__28961__auto__","this__28961__auto__",1763460914,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"k__28962__auto__","k__28962__auto__",-1728122866,null))))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"if","if",1181717262,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","contains?","cljs.core/contains?",-976526835,null)),(function (){var x__23746__auto__ = cljs.core.apply.call(null,cljs.core.hash_set,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core.map.call(null,cljs.core.keyword,base_fields)))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"k__28962__auto__","k__28962__auto__",-1728122866,null)))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","dissoc","cljs.core/dissoc",-432349815,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","with-meta","cljs.core/with-meta",749126446,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","into","cljs.core/into",1879938733,null)),(function (){var x__23746__auto__ = cljs.core.apply.call(null,cljs.core.array_map,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"this__28961__auto__","this__28961__auto__",1763460914,null)))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"__meta","__meta",-946752628,null)))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"k__28962__auto__","k__28962__auto__",-1728122866,null)))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"new","new",-444906321,null)),(function (){var x__23746__auto__ = tagname;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),cljs.core.remove.call(null,new cljs.core.PersistentHashSet(null, new cljs.core.PersistentArrayMap(null, 2, [new cljs.core.Symbol(null,"__hash","__hash",-1328796629,null),null,new cljs.core.Symbol(null,"__extmap","__extmap",-1435580931,null),null], null), null),fields__$2),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","not-empty","cljs.core/not-empty",540057011,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","dissoc","cljs.core/dissoc",-432349815,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"__extmap","__extmap",-1435580931,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"k__28962__auto__","k__28962__auto__",-1728122866,null)))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,null))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})()))),new cljs.core.Symbol(null,"ISeqable","ISeqable",1349682102,null),cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"-seq","-seq",1019896831,null)),(function (){var x__23746__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"this__28964__auto__","this__28964__auto__",-1999969274,null))))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","seq","cljs.core/seq",-1649497689,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","concat","cljs.core/concat",-1133584918,null)),(function (){var x__23746__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core.map.call(null,((function (gs,ksym,hinted_fields,fields__$1,base_fields,pr_open,fields__$2){
return (function (p1__28963_SHARP_){
return cljs.core._conj.call(null,(function (){var x__23746__auto__ = cljs.core.keyword.call(null,p1__28963_SHARP_);
return cljs.core._conj.call(null,(function (){var x__23746__auto____$1 = p1__28963_SHARP_;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto____$1);
})(),x__23746__auto__);
})(),new cljs.core.Symbol("cljs.core$macros","vector","cljs.core$macros/vector",912237829,null));
});})(gs,ksym,hinted_fields,fields__$1,base_fields,pr_open,fields__$2))
,base_fields)))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"__extmap","__extmap",-1435580931,null)))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})()))),new cljs.core.Symbol(null,"IIterable","IIterable",577191430,null),cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"-iterator","-iterator",310937281,null)),(function (){var x__23746__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,(function (){var x__23746__auto__ = gs;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})()))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"RecordIter.","RecordIter.",-265283060,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,(0)),(function (){var x__23746__auto__ = gs;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.count.call(null,base_fields);
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core.map.call(null,cljs.core.keyword,base_fields)))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","-iterator","cljs.core/-iterator",1833427494,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"__extmap","__extmap",-1435580931,null)))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})()))),new cljs.core.Symbol(null,"IPrintWithWriter","IPrintWithWriter",-1205316154,null),cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"-pr-writer","-pr-writer",-445354136,null)),(function (){var x__23746__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"this__28966__auto__","this__28966__auto__",-1863860027,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"writer__28967__auto__","writer__28967__auto__",539249262,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"opts__28968__auto__","opts__28968__auto__",792854752,null))))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","let","cljs.core$macros/let",-160286726,null)),(function (){var x__23746__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"pr-pair__28969__auto__","pr-pair__28969__auto__",1612356456,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","fn","cljs.core$macros/fn",-187522821,null)),(function (){var x__23746__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"keyval__28970__auto__","keyval__28970__auto__",-852386521,null))))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","pr-sequential-writer","cljs.core/pr-sequential-writer",-1101677821,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"writer__28967__auto__","writer__28967__auto__",539249262,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","pr-writer","cljs.core/pr-writer",133956070,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,""),cljs.core._conj.call(null,cljs.core.List.EMPTY," "),cljs.core._conj.call(null,cljs.core.List.EMPTY,""),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"opts__28968__auto__","opts__28968__auto__",792854752,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"keyval__28970__auto__","keyval__28970__auto__",-852386521,null)))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})()))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","pr-sequential-writer","cljs.core/pr-sequential-writer",-1101677821,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"writer__28967__auto__","writer__28967__auto__",539249262,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"pr-pair__28969__auto__","pr-pair__28969__auto__",1612356456,null)),(function (){var x__23746__auto__ = pr_open;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,", "),cljs.core._conj.call(null,cljs.core.List.EMPTY,"}"),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"opts__28968__auto__","opts__28968__auto__",792854752,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","concat","cljs.core/concat",-1133584918,null)),(function (){var x__23746__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core.map.call(null,((function (gs,ksym,hinted_fields,fields__$1,base_fields,pr_open,fields__$2){
return (function (p1__28965_SHARP_){
return cljs.core._conj.call(null,(function (){var x__23746__auto__ = cljs.core.keyword.call(null,p1__28965_SHARP_);
return cljs.core._conj.call(null,(function (){var x__23746__auto____$1 = p1__28965_SHARP_;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto____$1);
})(),x__23746__auto__);
})(),new cljs.core.Symbol("cljs.core$macros","vector","cljs.core$macros/vector",912237829,null));
});})(gs,ksym,hinted_fields,fields__$1,base_fields,pr_open,fields__$2))
,base_fields)))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"__extmap","__extmap",-1435580931,null)))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())))], null));
var vec__28972 = cljs.core$macros.prepare_protocol_masks.call(null,env,impls__$1);
var fpps = cljs.core.nth.call(null,vec__28972,(0),null);
var pmasks = cljs.core.nth.call(null,vec__28972,(1),null);
var protocols = cljs.core$macros.collect_protocols.call(null,impls__$1,env);
var tagname__$1 = cljs.core.vary_meta.call(null,tagname,cljs.core.assoc,new cljs.core.Keyword(null,"protocols","protocols",-5615896),protocols,new cljs.core.Keyword(null,"skip-protocol-flag","skip-protocol-flag",-1426798630),fpps);
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"do","do",1686842252,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"defrecord*","defrecord*",-1936366207,null)),(function (){var x__23746__auto__ = tagname__$1;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = hinted_fields;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = pmasks;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","extend-type","cljs.core$macros/extend-type",1713295201,null)),(function (){var x__23746__auto__ = tagname__$1;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),cljs.core$macros.dt__GT_et.call(null,tagname__$1,impls__$1,fields__$2,true))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
});
cljs.core$macros.build_map_factory = (function cljs$core$macros$build_map_factory(rsym,rname,fields){
var fn_name = cljs.core.with_meta.call(null,cljs.core.symbol.call(null,[cljs.core.str(new cljs.core.Symbol(null,"map->","map->",-999714600,null)),cljs.core.str(rsym)].join('')),cljs.core.assoc.call(null,cljs.core.meta.call(null,rsym),new cljs.core.Keyword(null,"factory","factory",63933746),new cljs.core.Keyword(null,"map","map",1371690461)));
var ms = cljs.core.gensym.call(null);
var ks = cljs.core.map.call(null,cljs.core.keyword,fields);
var getters = cljs.core.map.call(null,((function (fn_name,ms,ks){
return (function (k){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,(function (){var x__23746__auto__ = k;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = ms;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
});})(fn_name,ms,ks))
,ks);
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","defn","cljs.core$macros/defn",-728332354,null)),(function (){var x__23746__auto__ = fn_name;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,(function (){var x__23746__auto__ = ms;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})()))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"new","new",-444906321,null)),(function (){var x__23746__auto__ = rname;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),getters,cljs.core._conj.call(null,cljs.core.List.EMPTY,null),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","dissoc","cljs.core/dissoc",-432349815,null)),(function (){var x__23746__auto__ = ms;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),ks)));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,null))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
});
/**
 * (defrecord name [fields*]  options* specs*)
 * 
 *   Currently there are no options.
 * 
 *   Each spec consists of a protocol or interface name followed by zero
 *   or more method bodies:
 * 
 *   protocol-or-Object
 *   (methodName [args*] body)*
 * 
 *   The record will have the (immutable) fields named by
 *   fields, which can have type hints. Protocols and methods
 *   are optional. The only methods that can be supplied are those
 *   declared in the protocols.  Note that method bodies are
 *   not closures, the local environment includes only the named fields,
 *   and those fields can be accessed directly.
 * 
 *   Method definitions take the form:
 * 
 *   (methodname [args*] body)
 * 
 *   The argument and return types can be hinted on the arg and
 *   methodname symbols. If not supplied, they will be inferred, so type
 *   hints should be reserved for disambiguation.
 * 
 *   Methods should be supplied for all methods of the desired
 *   protocol(s). You can also define overrides for
 *   methods of Object. Note that a parameter must be supplied to
 *   correspond to the target object ('this' in JavaScript parlance). Note also
 *   that recur calls to the method head should *not* pass the target object, it
 *   will be supplied automatically and can not be substituted.
 * 
 *   In the method bodies, the (unqualified) name can be used to name the
 *   class (for calls to new, instance? etc).
 * 
 *   The type will have implementations of several ClojureScript
 *   protocol generated automatically: IMeta/IWithMeta (metadata support) and
 *   IMap, etc.
 * 
 *   In addition, defrecord will define type-and-value-based =,
 *   and will define ClojureScript IHash and IEquiv.
 * 
 *   Two constructors will be defined, one taking the designated fields
 *   followed by a metadata map (nil for none) and an extension field
 *   map (nil for none), and one taking only the fields (using nil for
 *   meta and extension fields). Note that the field names __meta
 *   and __extmap are currently reserved and should not be used when
 *   defining your own records.
 * 
 *   Given (defrecord TypeName ...), two factory functions will be
 *   defined: ->TypeName, taking positional parameters for the fields,
 *   and map->TypeName, taking a map of keywords to field values.
 */
cljs.core$macros.defrecord = (function cljs$core$macros$defrecord(var_args){
var args__23989__auto__ = [];
var len__23982__auto___28980 = arguments.length;
var i__23983__auto___28981 = (0);
while(true){
if((i__23983__auto___28981 < len__23982__auto___28980)){
args__23989__auto__.push((arguments[i__23983__auto___28981]));

var G__28982 = (i__23983__auto___28981 + (1));
i__23983__auto___28981 = G__28982;
continue;
} else {
}
break;
}

var argseq__23990__auto__ = ((((4) < args__23989__auto__.length))?(new cljs.core.IndexedSeq(args__23989__auto__.slice((4)),(0),null)):null);
return cljs.core$macros.defrecord.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]),argseq__23990__auto__);
});

cljs.core$macros.defrecord.cljs$core$IFn$_invoke$arity$variadic = (function (_AMPERSAND_form,_AMPERSAND_env,rsym,fields,impls){
cljs.core$macros.validate_fields.call(null,"defrecord",rsym,fields);

var rsym__$1 = cljs.core.vary_meta.call(null,rsym,cljs.core.assoc,new cljs.core.Keyword(null,"internal-ctor","internal-ctor",937392560),true);
var r = cljs.core.vary_meta.call(null,new cljs.core.Keyword(null,"name","name",1843675177).cljs$core$IFn$_invoke$arity$1(cljs.analyzer.resolve_var.call(null,cljs.core.dissoc.call(null,_AMPERSAND_env,new cljs.core.Keyword(null,"locals","locals",535295783)),rsym__$1)),cljs.core.assoc,new cljs.core.Keyword(null,"internal-ctor","internal-ctor",937392560),true);
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","let","cljs.core$macros/let",-160286726,null)),(function (){var x__23746__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core$macros.emit_defrecord.call(null,_AMPERSAND_env,rsym__$1,r,fields,impls);
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"set!","set!",250714521,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,".-getBasis",".-getBasis",-1306451468,null)),(function (){var x__23746__auto__ = r;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","fn","cljs.core$macros/fn",-187522821,null)),(function (){var x__23746__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"quote","quote",1377916282,null)),(function (){var x__23746__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,fields))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"set!","set!",250714521,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,".-cljs$lang$type",".-cljs$lang$type",-1029307724,null)),(function (){var x__23746__auto__ = r;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,true))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"set!","set!",250714521,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,".-cljs$lang$ctorPrSeq",".-cljs$lang$ctorPrSeq",41132414,null)),(function (){var x__23746__auto__ = r;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","fn","cljs.core$macros/fn",-187522821,null)),(function (){var x__23746__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"this__28973__auto__","this__28973__auto__",1090692603,null))))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","list","cljs.core/list",-1331406371,null)),(function (){var x__23746__auto__ = [cljs.core.str(r)].join('');
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"set!","set!",250714521,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,".-cljs$lang$ctorPrWriter",".-cljs$lang$ctorPrWriter",255834464,null)),(function (){var x__23746__auto__ = r;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","fn","cljs.core$macros/fn",-187522821,null)),(function (){var x__23746__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"this__28973__auto__","this__28973__auto__",1090692603,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"writer__28974__auto__","writer__28974__auto__",-1429561819,null))))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","-write","cljs.core/-write",527220517,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"writer__28974__auto__","writer__28974__auto__",-1429561819,null)),(function (){var x__23746__auto__ = [cljs.core.str(r)].join('');
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core$macros.build_positional_factory.call(null,rsym__$1,r,fields);
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core$macros.build_map_factory.call(null,rsym__$1,r,fields);
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = r;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
});

cljs.core$macros.defrecord.cljs$lang$maxFixedArity = (4);

cljs.core$macros.defrecord.cljs$lang$applyTo = (function (seq28975){
var G__28976 = cljs.core.first.call(null,seq28975);
var seq28975__$1 = cljs.core.next.call(null,seq28975);
var G__28977 = cljs.core.first.call(null,seq28975__$1);
var seq28975__$2 = cljs.core.next.call(null,seq28975__$1);
var G__28978 = cljs.core.first.call(null,seq28975__$2);
var seq28975__$3 = cljs.core.next.call(null,seq28975__$2);
var G__28979 = cljs.core.first.call(null,seq28975__$3);
var seq28975__$4 = cljs.core.next.call(null,seq28975__$3);
return cljs.core$macros.defrecord.cljs$core$IFn$_invoke$arity$variadic(G__28976,G__28977,G__28978,G__28979,seq28975__$4);
});

cljs.core$macros.defrecord.cljs$lang$macro = true;
/**
 * A protocol is a named set of named methods and their signatures:
 * 
 *   (defprotocol AProtocolName
 *  ;optional doc string
 *  "A doc string for AProtocol abstraction"
 * 
 *   ;method signatures
 *  (bar [this a b] "bar docs")
 *  (baz [this a] [this a b] [this a b c] "baz docs"))
 * 
 *   No implementations are provided. Docs can be specified for the
 *   protocol overall and for each method. The above yields a set of
 *   polymorphic functions and a protocol object. All are
 *   namespace-qualified by the ns enclosing the definition The resulting
 *   functions dispatch on the type of their first argument, which is
 *   required and corresponds to the implicit target object ('this' in
 *   JavaScript parlance). defprotocol is dynamic, has no special compile-time
 *   effect, and defines no new types.
 * 
 *   (defprotocol P
 *  (foo [this])
 *  (bar-me [this] [this y]))
 * 
 *   (deftype Foo [a b c]
 *  P
 *  (foo [this] a)
 *  (bar-me [this] b)
 *  (bar-me [this y] (+ c y)))
 * 
 *   (bar-me (Foo. 1 2 3) 42)
 *   => 45
 * 
 *   (foo
 *  (let [x 42]
 *    (reify P
 *      (foo [this] 17)
 *      (bar-me [this] x)
 *      (bar-me [this y] x))))
 *   => 17
 */
cljs.core$macros.defprotocol = (function cljs$core$macros$defprotocol(var_args){
var args__23989__auto__ = [];
var len__23982__auto___29000 = arguments.length;
var i__23983__auto___29001 = (0);
while(true){
if((i__23983__auto___29001 < len__23982__auto___29000)){
args__23989__auto__.push((arguments[i__23983__auto___29001]));

var G__29002 = (i__23983__auto___29001 + (1));
i__23983__auto___29001 = G__29002;
continue;
} else {
}
break;
}

var argseq__23990__auto__ = ((((3) < args__23989__auto__.length))?(new cljs.core.IndexedSeq(args__23989__auto__.slice((3)),(0),null)):null);
return cljs.core$macros.defprotocol.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),argseq__23990__auto__);
});

cljs.core$macros.defprotocol.cljs$core$IFn$_invoke$arity$variadic = (function (_AMPERSAND_form,_AMPERSAND_env,psym,doc_PLUS_methods){
var p = new cljs.core.Keyword(null,"name","name",1843675177).cljs$core$IFn$_invoke$arity$1(cljs.analyzer.resolve_var.call(null,cljs.core.dissoc.call(null,_AMPERSAND_env,new cljs.core.Keyword(null,"locals","locals",535295783)),psym));
var vec__28989 = ((typeof cljs.core.first.call(null,doc_PLUS_methods) === 'string')?new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.first.call(null,doc_PLUS_methods),cljs.core.next.call(null,doc_PLUS_methods)], null):new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [null,doc_PLUS_methods], null));
var doc = cljs.core.nth.call(null,vec__28989,(0),null);
var methods$ = cljs.core.nth.call(null,vec__28989,(1),null);
var psym__$1 = cljs.core.vary_meta.call(null,psym,cljs.core.assoc,new cljs.core.Keyword(null,"doc","doc",1913296891),doc,new cljs.core.Keyword(null,"protocol-symbol","protocol-symbol",1279552198),true);
var ns_name = new cljs.core.Keyword(null,"name","name",1843675177).cljs$core$IFn$_invoke$arity$1(new cljs.core.Keyword(null,"ns","ns",441598760).cljs$core$IFn$_invoke$arity$1(_AMPERSAND_env));
var fqn = ((function (p,vec__28989,doc,methods$,psym__$1,ns_name){
return (function (n){
return cljs.core.symbol.call(null,[cljs.core.str(ns_name),cljs.core.str("."),cljs.core.str(n)].join(''));
});})(p,vec__28989,doc,methods$,psym__$1,ns_name))
;
var prefix = cljs.core$macros.protocol_prefix.call(null,p);
var _ = (function (){var seq__28990 = cljs.core.seq.call(null,methods$);
var chunk__28991 = null;
var count__28992 = (0);
var i__28993 = (0);
while(true){
if((i__28993 < count__28992)){
var vec__28994 = cljs.core._nth.call(null,chunk__28991,i__28993);
var mname = cljs.core.nth.call(null,vec__28994,(0),null);
var arities = cljs.core.nthnext.call(null,vec__28994,(1));
if(cljs.core.truth_(cljs.core.some.call(null,new cljs.core.PersistentHashSet(null, new cljs.core.PersistentArrayMap(null, 1, [(0),null], null), null),cljs.core.map.call(null,cljs.core.count,cljs.core.filter.call(null,cljs.core.vector_QMARK_,arities))))){
throw (new Error([cljs.core.str("Invalid protocol, "),cljs.core.str(psym__$1),cljs.core.str(" defines method "),cljs.core.str(mname),cljs.core.str(" with arity 0")].join('')));
} else {
}

var G__29003 = seq__28990;
var G__29004 = chunk__28991;
var G__29005 = count__28992;
var G__29006 = (i__28993 + (1));
seq__28990 = G__29003;
chunk__28991 = G__29004;
count__28992 = G__29005;
i__28993 = G__29006;
continue;
} else {
var temp__4657__auto__ = cljs.core.seq.call(null,seq__28990);
if(temp__4657__auto__){
var seq__28990__$1 = temp__4657__auto__;
if(cljs.core.chunked_seq_QMARK_.call(null,seq__28990__$1)){
var c__23723__auto__ = cljs.core.chunk_first.call(null,seq__28990__$1);
var G__29007 = cljs.core.chunk_rest.call(null,seq__28990__$1);
var G__29008 = c__23723__auto__;
var G__29009 = cljs.core.count.call(null,c__23723__auto__);
var G__29010 = (0);
seq__28990 = G__29007;
chunk__28991 = G__29008;
count__28992 = G__29009;
i__28993 = G__29010;
continue;
} else {
var vec__28995 = cljs.core.first.call(null,seq__28990__$1);
var mname = cljs.core.nth.call(null,vec__28995,(0),null);
var arities = cljs.core.nthnext.call(null,vec__28995,(1));
if(cljs.core.truth_(cljs.core.some.call(null,new cljs.core.PersistentHashSet(null, new cljs.core.PersistentArrayMap(null, 1, [(0),null], null), null),cljs.core.map.call(null,cljs.core.count,cljs.core.filter.call(null,cljs.core.vector_QMARK_,arities))))){
throw (new Error([cljs.core.str("Invalid protocol, "),cljs.core.str(psym__$1),cljs.core.str(" defines method "),cljs.core.str(mname),cljs.core.str(" with arity 0")].join('')));
} else {
}

var G__29011 = cljs.core.next.call(null,seq__28990__$1);
var G__29012 = null;
var G__29013 = (0);
var G__29014 = (0);
seq__28990 = G__29011;
chunk__28991 = G__29012;
count__28992 = G__29013;
i__28993 = G__29014;
continue;
}
} else {
return null;
}
}
break;
}
})();
var expand_sig = ((function (p,vec__28989,doc,methods$,psym__$1,ns_name,fqn,prefix,_){
return (function (fname,slot,sig){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,(function (){var x__23746__auto__ = sig;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"if","if",1181717262,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","and","cljs.core$macros/and",48320334,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","not","cljs.core/not",100665144,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","nil?","cljs.core$macros/nil?",83624258,null)),(function (){var x__23746__auto__ = cljs.core.first.call(null,sig);
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","not","cljs.core/not",100665144,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","nil?","cljs.core$macros/nil?",83624258,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,".",".",1975675962,null)),(function (){var x__23746__auto__ = cljs.core.first.call(null,sig);
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.symbol.call(null,[cljs.core.str("-"),cljs.core.str(slot)].join(''));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,".",".",1975675962,null)),(function (){var x__23746__auto__ = cljs.core.first.call(null,sig);
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = slot;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),sig)));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","let","cljs.core$macros/let",-160286726,null)),(function (){var x__23746__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"x__28983__auto__","x__28983__auto__",1982187037,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"if","if",1181717262,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","nil?","cljs.core$macros/nil?",83624258,null)),(function (){var x__23746__auto__ = cljs.core.first.call(null,sig);
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,null),(function (){var x__23746__auto__ = cljs.core.first.call(null,sig);
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"m__28984__auto__","m__28984__auto__",2025035808,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","aget","cljs.core$macros/aget",1976136178,null)),(function (){var x__23746__auto__ = fqn.call(null,fname);
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("goog","typeOf","goog/typeOf",539097255,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"x__28983__auto__","x__28983__auto__",1982187037,null)))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})()))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","if-not","cljs.core$macros/if-not",-1825285737,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","nil?","cljs.core$macros/nil?",83624258,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"m__28984__auto__","m__28984__auto__",2025035808,null)))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"m__28984__auto__","m__28984__auto__",2025035808,null)),sig)));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","let","cljs.core$macros/let",-160286726,null)),(function (){var x__23746__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"m__28984__auto__","m__28984__auto__",2025035808,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","aget","cljs.core$macros/aget",1976136178,null)),(function (){var x__23746__auto__ = fqn.call(null,fname);
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,"_"))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})()))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","if-not","cljs.core$macros/if-not",-1825285737,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","nil?","cljs.core$macros/nil?",83624258,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"m__28984__auto__","m__28984__auto__",2025035808,null)))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"m__28984__auto__","m__28984__auto__",2025035808,null)),sig)));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"throw","throw",595905694,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","missing-protocol","cljs.core/missing-protocol",531539732,null)),(function (){var x__23746__auto__ = [cljs.core.str(psym__$1),cljs.core.str("."),cljs.core.str(fname)].join('');
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.first.call(null,sig);
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
});})(p,vec__28989,doc,methods$,psym__$1,ns_name,fqn,prefix,_))
;
var psym__$2 = cljs.core.vary_meta.call(null,cljs.core.vary_meta.call(null,psym__$1,cljs.core.update_in,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword(null,"jsdoc","jsdoc",1745183516)], null),cljs.core.conj,"@interface"),cljs.core.assoc_in,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword(null,"protocol-info","protocol-info",1471745843),new cljs.core.Keyword(null,"methods","methods",453930866)], null),cljs.core.into.call(null,cljs.core.PersistentArrayMap.EMPTY,cljs.core.map.call(null,((function (p,vec__28989,doc,methods$,psym__$1,ns_name,fqn,prefix,_,expand_sig){
return (function (p__28996){
var vec__28997 = p__28996;
var fname = cljs.core.nth.call(null,vec__28997,(0),null);
var sigs = cljs.core.nthnext.call(null,vec__28997,(1));
var doc__$1 = (function (){var doc__$1 = cljs.core.last.call(null,sigs);
if(typeof doc__$1 === 'string'){
return doc__$1;
} else {
return null;
}
})();
var sigs__$1 = cljs.core.take_while.call(null,cljs.core.vector_QMARK_,sigs);
return new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.vary_meta.call(null,fname,cljs.core.assoc,new cljs.core.Keyword(null,"doc","doc",1913296891),doc__$1),cljs.core.vec.call(null,sigs__$1)], null);
});})(p,vec__28989,doc,methods$,psym__$1,ns_name,fqn,prefix,_,expand_sig))
,methods$)));
var method = ((function (p,vec__28989,doc,methods$,psym__$1,ns_name,fqn,prefix,_,expand_sig,psym__$2){
return (function (p__28998){
var vec__28999 = p__28998;
var fname = cljs.core.nth.call(null,vec__28999,(0),null);
var sigs = cljs.core.nthnext.call(null,vec__28999,(1));
var doc__$1 = (function (){var doc__$1 = cljs.core.last.call(null,sigs);
if(typeof doc__$1 === 'string'){
return doc__$1;
} else {
return null;
}
})();
var sigs__$1 = cljs.core.take_while.call(null,cljs.core.vector_QMARK_,sigs);
var amp = (cljs.core.truth_(cljs.core.some.call(null,new cljs.core.PersistentHashSet(null, new cljs.core.PersistentArrayMap(null, 1, [new cljs.core.Symbol(null,"&","&",-2144855648,null),null], null), null),cljs.core.apply.call(null,cljs.core.concat,sigs__$1)))?cljs.analyzer.warning.call(null,new cljs.core.Keyword(null,"protocol-with-variadic-method","protocol-with-variadic-method",-693368178),_AMPERSAND_env,new cljs.core.PersistentArrayMap(null, 2, [new cljs.core.Keyword(null,"protocol","protocol",652470118),psym__$2,new cljs.core.Keyword(null,"name","name",1843675177),fname], null)):null);
var slot = cljs.core.symbol.call(null,[cljs.core.str(prefix),cljs.core.str(cljs.core.name.call(null,fname))].join(''));
var fname__$1 = cljs.core.vary_meta.call(null,fname,cljs.core.assoc,new cljs.core.Keyword(null,"protocol","protocol",652470118),p,new cljs.core.Keyword(null,"doc","doc",1913296891),doc__$1);
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","defn","cljs.core$macros/defn",-728332354,null)),(function (){var x__23746__auto__ = fname__$1;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),cljs.core.map.call(null,((function (doc__$1,sigs__$1,amp,slot,fname__$1,vec__28999,fname,sigs,p,vec__28989,doc,methods$,psym__$1,ns_name,fqn,prefix,_,expand_sig,psym__$2){
return (function (sig){
return expand_sig.call(null,fname__$1,cljs.core.symbol.call(null,[cljs.core.str(slot),cljs.core.str("$arity$"),cljs.core.str(cljs.core.count.call(null,sig))].join('')),sig);
});})(doc__$1,sigs__$1,amp,slot,fname__$1,vec__28999,fname,sigs,p,vec__28989,doc,methods$,psym__$1,ns_name,fqn,prefix,_,expand_sig,psym__$2))
,sigs__$1))));
});})(p,vec__28989,doc,methods$,psym__$1,ns_name,fqn,prefix,_,expand_sig,psym__$2))
;
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"do","do",1686842252,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"set!","set!",250714521,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"*unchecked-if*","*unchecked-if*",1542408350,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,true))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"def","def",597100991,null)),(function (){var x__23746__auto__ = psym__$2;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"js*","js*",-1134233646,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,"function(){}"))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),cljs.core.map.call(null,method,methods$),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"set!","set!",250714521,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"*unchecked-if*","*unchecked-if*",1542408350,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,false))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
});

cljs.core$macros.defprotocol.cljs$lang$maxFixedArity = (3);

cljs.core$macros.defprotocol.cljs$lang$applyTo = (function (seq28985){
var G__28986 = cljs.core.first.call(null,seq28985);
var seq28985__$1 = cljs.core.next.call(null,seq28985);
var G__28987 = cljs.core.first.call(null,seq28985__$1);
var seq28985__$2 = cljs.core.next.call(null,seq28985__$1);
var G__28988 = cljs.core.first.call(null,seq28985__$2);
var seq28985__$3 = cljs.core.next.call(null,seq28985__$2);
return cljs.core$macros.defprotocol.cljs$core$IFn$_invoke$arity$variadic(G__28986,G__28987,G__28988,seq28985__$3);
});

cljs.core$macros.defprotocol.cljs$lang$macro = true;
/**
 * EXPERIMENTAL
 */
cljs.core$macros.implements_QMARK_ = (function cljs$core$macros$implements_QMARK_(_AMPERSAND_form,_AMPERSAND_env,psym,x){
var p = new cljs.core.Keyword(null,"name","name",1843675177).cljs$core$IFn$_invoke$arity$1(cljs.analyzer.resolve_var.call(null,cljs.core.dissoc.call(null,_AMPERSAND_env,new cljs.core.Keyword(null,"locals","locals",535295783)),psym));
var prefix = cljs.core$macros.protocol_prefix.call(null,p);
var xsym = cljs.core$macros.bool_expr.call(null,cljs.core.gensym.call(null));
var vec__29016 = cljs.core$macros.fast_path_protocols.call(null,p);
var part = cljs.core.nth.call(null,vec__29016,(0),null);
var bit = cljs.core.nth.call(null,vec__29016,(1),null);
var msym = cljs.core.symbol.call(null,[cljs.core.str("-cljs$lang$protocol_mask$partition"),cljs.core.str(part),cljs.core.str("$")].join(''));
if(!((x instanceof cljs.core.Symbol))){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","let","cljs.core$macros/let",-160286726,null)),(function (){var x__23746__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,(function (){var x__23746__auto__ = xsym;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = x;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})()))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"if","if",1181717262,null)),(function (){var x__23746__auto__ = xsym;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"if","if",1181717262,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","or","cljs.core$macros/or",1346243648,null)),(function (){var x__23746__auto__ = (cljs.core.truth_(bit)?cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","unsafe-bit-and","cljs.core$macros/unsafe-bit-and",1803731600,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,".",".",1975675962,null)),(function (){var x__23746__auto__ = xsym;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = msym;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = bit;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})()))):false);
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core$macros.bool_expr.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,".",".",1975675962,null)),(function (){var x__23746__auto__ = xsym;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.symbol.call(null,[cljs.core.str("-"),cljs.core.str(prefix)].join(''));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})()))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,true),cljs.core._conj.call(null,cljs.core.List.EMPTY,false))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,false))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
} else {
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","if-not","cljs.core$macros/if-not",-1825285737,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","nil?","cljs.core$macros/nil?",83624258,null)),(function (){var x__23746__auto__ = x;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"if","if",1181717262,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","or","cljs.core$macros/or",1346243648,null)),(function (){var x__23746__auto__ = (cljs.core.truth_(bit)?cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","unsafe-bit-and","cljs.core$macros/unsafe-bit-and",1803731600,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,".",".",1975675962,null)),(function (){var x__23746__auto__ = x;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = msym;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = bit;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})()))):false);
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core$macros.bool_expr.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,".",".",1975675962,null)),(function (){var x__23746__auto__ = x;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.symbol.call(null,[cljs.core.str("-"),cljs.core.str(prefix)].join(''));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})()))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,true),cljs.core._conj.call(null,cljs.core.List.EMPTY,false))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,false))));
}
});

cljs.core$macros.implements_QMARK_.cljs$lang$macro = true;
/**
 * Returns true if x satisfies the protocol
 */
cljs.core$macros.satisfies_QMARK_ = (function cljs$core$macros$satisfies_QMARK_(_AMPERSAND_form,_AMPERSAND_env,psym,x){
var p = new cljs.core.Keyword(null,"name","name",1843675177).cljs$core$IFn$_invoke$arity$1(cljs.analyzer.resolve_var.call(null,cljs.core.dissoc.call(null,_AMPERSAND_env,new cljs.core.Keyword(null,"locals","locals",535295783)),psym));
var prefix = cljs.core$macros.protocol_prefix.call(null,p);
var xsym = cljs.core$macros.bool_expr.call(null,cljs.core.gensym.call(null));
var vec__29018 = cljs.core$macros.fast_path_protocols.call(null,p);
var part = cljs.core.nth.call(null,vec__29018,(0),null);
var bit = cljs.core.nth.call(null,vec__29018,(1),null);
var msym = cljs.core.symbol.call(null,[cljs.core.str("-cljs$lang$protocol_mask$partition"),cljs.core.str(part),cljs.core.str("$")].join(''));
if(!((x instanceof cljs.core.Symbol))){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","let","cljs.core$macros/let",-160286726,null)),(function (){var x__23746__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,(function (){var x__23746__auto__ = xsym;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = x;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})()))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","if-not","cljs.core$macros/if-not",-1825285737,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","nil?","cljs.core$macros/nil?",83624258,null)),(function (){var x__23746__auto__ = xsym;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"if","if",1181717262,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","or","cljs.core$macros/or",1346243648,null)),(function (){var x__23746__auto__ = (cljs.core.truth_(bit)?cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","unsafe-bit-and","cljs.core$macros/unsafe-bit-and",1803731600,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,".",".",1975675962,null)),(function (){var x__23746__auto__ = xsym;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = msym;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = bit;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})()))):false);
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core$macros.bool_expr.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,".",".",1975675962,null)),(function (){var x__23746__auto__ = xsym;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.symbol.call(null,[cljs.core.str("-"),cljs.core.str(prefix)].join(''));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})()))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,true),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"if","if",1181717262,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","coercive-not","cljs.core$macros/coercive-not",115999987,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,".",".",1975675962,null)),(function (){var x__23746__auto__ = xsym;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = msym;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","native-satisfies?","cljs.core/native-satisfies?",1482305036,null)),(function (){var x__23746__auto__ = psym;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = xsym;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,false))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","native-satisfies?","cljs.core/native-satisfies?",1482305036,null)),(function (){var x__23746__auto__ = psym;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = xsym;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
} else {
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","if-not","cljs.core$macros/if-not",-1825285737,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","nil?","cljs.core$macros/nil?",83624258,null)),(function (){var x__23746__auto__ = x;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"if","if",1181717262,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","or","cljs.core$macros/or",1346243648,null)),(function (){var x__23746__auto__ = (cljs.core.truth_(bit)?cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","unsafe-bit-and","cljs.core$macros/unsafe-bit-and",1803731600,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,".",".",1975675962,null)),(function (){var x__23746__auto__ = x;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = msym;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = bit;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})()))):false);
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core$macros.bool_expr.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,".",".",1975675962,null)),(function (){var x__23746__auto__ = x;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.symbol.call(null,[cljs.core.str("-"),cljs.core.str(prefix)].join(''));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})()))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,true),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"if","if",1181717262,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","coercive-not","cljs.core$macros/coercive-not",115999987,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,".",".",1975675962,null)),(function (){var x__23746__auto__ = x;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = msym;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","native-satisfies?","cljs.core/native-satisfies?",1482305036,null)),(function (){var x__23746__auto__ = psym;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = x;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,false))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","native-satisfies?","cljs.core/native-satisfies?",1482305036,null)),(function (){var x__23746__auto__ = psym;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = x;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
}
});

cljs.core$macros.satisfies_QMARK_.cljs$lang$macro = true;
/**
 * Takes a body of expressions that returns an ISeq or nil, and yields
 *   a ISeqable object that will invoke the body only the first time seq
 *   is called, and will cache the result and return it on all subsequent
 *   seq calls.
 */
cljs.core$macros.lazy_seq = (function cljs$core$macros$lazy_seq(var_args){
var args__23989__auto__ = [];
var len__23982__auto___29022 = arguments.length;
var i__23983__auto___29023 = (0);
while(true){
if((i__23983__auto___29023 < len__23982__auto___29022)){
args__23989__auto__.push((arguments[i__23983__auto___29023]));

var G__29024 = (i__23983__auto___29023 + (1));
i__23983__auto___29023 = G__29024;
continue;
} else {
}
break;
}

var argseq__23990__auto__ = ((((2) < args__23989__auto__.length))?(new cljs.core.IndexedSeq(args__23989__auto__.slice((2)),(0),null)):null);
return cljs.core$macros.lazy_seq.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__23990__auto__);
});

cljs.core$macros.lazy_seq.cljs$core$IFn$_invoke$arity$variadic = (function (_AMPERSAND_form,_AMPERSAND_env,body){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"new","new",-444906321,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","LazySeq","cljs.core/LazySeq",1986389673,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,null),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","fn","cljs.core$macros/fn",-187522821,null)),(function (){var x__23746__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),body)));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,null),cljs.core._conj.call(null,cljs.core.List.EMPTY,null))));
});

cljs.core$macros.lazy_seq.cljs$lang$maxFixedArity = (2);

cljs.core$macros.lazy_seq.cljs$lang$applyTo = (function (seq29019){
var G__29020 = cljs.core.first.call(null,seq29019);
var seq29019__$1 = cljs.core.next.call(null,seq29019);
var G__29021 = cljs.core.first.call(null,seq29019__$1);
var seq29019__$2 = cljs.core.next.call(null,seq29019__$1);
return cljs.core$macros.lazy_seq.cljs$core$IFn$_invoke$arity$variadic(G__29020,G__29021,seq29019__$2);
});

cljs.core$macros.lazy_seq.cljs$lang$macro = true;
/**
 * Takes a body of expressions and yields a Delay object that will
 *   invoke the body only the first time it is forced (with force or deref/@), and
 *   will cache the result and return it on all subsequent force
 *   calls.
 */
cljs.core$macros.delay = (function cljs$core$macros$delay(var_args){
var args__23989__auto__ = [];
var len__23982__auto___29028 = arguments.length;
var i__23983__auto___29029 = (0);
while(true){
if((i__23983__auto___29029 < len__23982__auto___29028)){
args__23989__auto__.push((arguments[i__23983__auto___29029]));

var G__29030 = (i__23983__auto___29029 + (1));
i__23983__auto___29029 = G__29030;
continue;
} else {
}
break;
}

var argseq__23990__auto__ = ((((2) < args__23989__auto__.length))?(new cljs.core.IndexedSeq(args__23989__auto__.slice((2)),(0),null)):null);
return cljs.core$macros.delay.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__23990__auto__);
});

cljs.core$macros.delay.cljs$core$IFn$_invoke$arity$variadic = (function (_AMPERSAND_form,_AMPERSAND_env,body){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"new","new",-444906321,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","Delay","cljs.core/Delay",-21574999,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","fn","cljs.core$macros/fn",-187522821,null)),(function (){var x__23746__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),body)));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,null))));
});

cljs.core$macros.delay.cljs$lang$maxFixedArity = (2);

cljs.core$macros.delay.cljs$lang$applyTo = (function (seq29025){
var G__29026 = cljs.core.first.call(null,seq29025);
var seq29025__$1 = cljs.core.next.call(null,seq29025);
var G__29027 = cljs.core.first.call(null,seq29025__$1);
var seq29025__$2 = cljs.core.next.call(null,seq29025__$1);
return cljs.core$macros.delay.cljs$core$IFn$_invoke$arity$variadic(G__29026,G__29027,seq29025__$2);
});

cljs.core$macros.delay.cljs$lang$macro = true;
/**
 * binding => var-symbol temp-value-expr
 * 
 *   Temporarily redefines vars while executing the body.  The
 *   temp-value-exprs will be evaluated and each resulting value will
 *   replace in parallel the root value of its var.  After the body is
 *   executed, the root values of all the vars will be set back to their
 *   old values. Useful for mocking out functions during testing.
 */
cljs.core$macros.with_redefs = (function cljs$core$macros$with_redefs(var_args){
var args__23989__auto__ = [];
var len__23982__auto___29037 = arguments.length;
var i__23983__auto___29038 = (0);
while(true){
if((i__23983__auto___29038 < len__23982__auto___29037)){
args__23989__auto__.push((arguments[i__23983__auto___29038]));

var G__29039 = (i__23983__auto___29038 + (1));
i__23983__auto___29038 = G__29039;
continue;
} else {
}
break;
}

var argseq__23990__auto__ = ((((3) < args__23989__auto__.length))?(new cljs.core.IndexedSeq(args__23989__auto__.slice((3)),(0),null)):null);
return cljs.core$macros.with_redefs.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),argseq__23990__auto__);
});

cljs.core$macros.with_redefs.cljs$core$IFn$_invoke$arity$variadic = (function (_AMPERSAND_form,_AMPERSAND_env,bindings,body){
var names = cljs.core.take_nth.call(null,(2),bindings);
var vals = cljs.core.take_nth.call(null,(2),cljs.core.drop.call(null,(1),bindings));
var tempnames = cljs.core.map.call(null,cljs.core.comp.call(null,cljs.core.gensym,cljs.core.name),names);
var binds = cljs.core.map.call(null,cljs.core.vector,names,vals);
var resets = cljs.core.reverse.call(null,cljs.core.map.call(null,cljs.core.vector,names,tempnames));
var bind_value = ((function (names,vals,tempnames,binds,resets){
return (function (p__29035){
var vec__29036 = p__29035;
var k = cljs.core.nth.call(null,vec__29036,(0),null);
var v = cljs.core.nth.call(null,vec__29036,(1),null);
return cljs.core._conj.call(null,(function (){var x__23746__auto__ = k;
return cljs.core._conj.call(null,(function (){var x__23746__auto____$1 = v;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto____$1);
})(),x__23746__auto__);
})(),new cljs.core.Symbol(null,"set!","set!",250714521,null));
});})(names,vals,tempnames,binds,resets))
;
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","let","cljs.core$macros/let",-160286726,null)),(function (){var x__23746__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core.interleave.call(null,tempnames,names)))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),cljs.core.map.call(null,bind_value,binds),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"try","try",-1273693247,null)),body,(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"finally","finally",-1065347064,null)),cljs.core.map.call(null,bind_value,resets))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
});

cljs.core$macros.with_redefs.cljs$lang$maxFixedArity = (3);

cljs.core$macros.with_redefs.cljs$lang$applyTo = (function (seq29031){
var G__29032 = cljs.core.first.call(null,seq29031);
var seq29031__$1 = cljs.core.next.call(null,seq29031);
var G__29033 = cljs.core.first.call(null,seq29031__$1);
var seq29031__$2 = cljs.core.next.call(null,seq29031__$1);
var G__29034 = cljs.core.first.call(null,seq29031__$2);
var seq29031__$3 = cljs.core.next.call(null,seq29031__$2);
return cljs.core$macros.with_redefs.cljs$core$IFn$_invoke$arity$variadic(G__29032,G__29033,G__29034,seq29031__$3);
});

cljs.core$macros.with_redefs.cljs$lang$macro = true;
/**
 * binding => var-symbol init-expr
 * 
 *   Creates new bindings for the (already-existing) vars, with the
 *   supplied initial values, executes the exprs in an implicit do, then
 *   re-establishes the bindings that existed before.  The new bindings
 *   are made in parallel (unlike let); all init-exprs are evaluated
 *   before the vars are bound to their new values.
 */
cljs.core$macros.binding = (function cljs$core$macros$binding(var_args){
var args__23989__auto__ = [];
var len__23982__auto___29044 = arguments.length;
var i__23983__auto___29045 = (0);
while(true){
if((i__23983__auto___29045 < len__23982__auto___29044)){
args__23989__auto__.push((arguments[i__23983__auto___29045]));

var G__29046 = (i__23983__auto___29045 + (1));
i__23983__auto___29045 = G__29046;
continue;
} else {
}
break;
}

var argseq__23990__auto__ = ((((3) < args__23989__auto__.length))?(new cljs.core.IndexedSeq(args__23989__auto__.slice((3)),(0),null)):null);
return cljs.core$macros.binding.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),argseq__23990__auto__);
});

cljs.core$macros.binding.cljs$core$IFn$_invoke$arity$variadic = (function (_AMPERSAND_form,_AMPERSAND_env,bindings,body){
var names = cljs.core.take_nth.call(null,(2),bindings);
cljs.analyzer.confirm_bindings.call(null,_AMPERSAND_env,names);

return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","with-redefs","cljs.core$macros/with-redefs",1489217801,null)),(function (){var x__23746__auto__ = bindings;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),body)));
});

cljs.core$macros.binding.cljs$lang$maxFixedArity = (3);

cljs.core$macros.binding.cljs$lang$applyTo = (function (seq29040){
var G__29041 = cljs.core.first.call(null,seq29040);
var seq29040__$1 = cljs.core.next.call(null,seq29040);
var G__29042 = cljs.core.first.call(null,seq29040__$1);
var seq29040__$2 = cljs.core.next.call(null,seq29040__$1);
var G__29043 = cljs.core.first.call(null,seq29040__$2);
var seq29040__$3 = cljs.core.next.call(null,seq29040__$2);
return cljs.core$macros.binding.cljs$core$IFn$_invoke$arity$variadic(G__29041,G__29042,G__29043,seq29040__$3);
});

cljs.core$macros.binding.cljs$lang$macro = true;
/**
 * Takes a binary predicate, an expression, and a set of clauses.
 *   Each clause can take the form of either:
 * 
 *   test-expr result-expr
 * 
 *   test-expr :>> result-fn
 * 
 *   Note :>> is an ordinary keyword.
 * 
 *   For each clause, (pred test-expr expr) is evaluated. If it returns
 *   logical true, the clause is a match. If a binary clause matches, the
 *   result-expr is returned, if a ternary clause matches, its result-fn,
 *   which must be a unary function, is called with the result of the
 *   predicate as its argument, the result of that call being the return
 *   value of condp. A single default expression can follow the clauses,
 *   and its value will be returned if no clause matches. If no default
 *   expression is provided and no clause matches, an
 *   IllegalArgumentException is thrown.
 */
cljs.core$macros.condp = (function cljs$core$macros$condp(var_args){
var args__23989__auto__ = [];
var len__23982__auto___29057 = arguments.length;
var i__23983__auto___29058 = (0);
while(true){
if((i__23983__auto___29058 < len__23982__auto___29057)){
args__23989__auto__.push((arguments[i__23983__auto___29058]));

var G__29059 = (i__23983__auto___29058 + (1));
i__23983__auto___29058 = G__29059;
continue;
} else {
}
break;
}

var argseq__23990__auto__ = ((((4) < args__23989__auto__.length))?(new cljs.core.IndexedSeq(args__23989__auto__.slice((4)),(0),null)):null);
return cljs.core$macros.condp.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]),argseq__23990__auto__);
});

cljs.core$macros.condp.cljs$core$IFn$_invoke$arity$variadic = (function (_AMPERSAND_form,_AMPERSAND_env,pred,expr,clauses){
var gpred = cljs.core.gensym.call(null,"pred__");
var gexpr = cljs.core.gensym.call(null,"expr__");
var emit = ((function (gpred,gexpr){
return (function cljs$core$macros$emit(pred__$1,expr__$1,args){
var vec__29055 = cljs.core.split_at.call(null,((cljs.core._EQ_.call(null,new cljs.core.Keyword(null,">>",">>",-277509267),cljs.core.second.call(null,args)))?(3):(2)),args);
var vec__29056 = cljs.core.nth.call(null,vec__29055,(0),null);
var a = cljs.core.nth.call(null,vec__29056,(0),null);
var b = cljs.core.nth.call(null,vec__29056,(1),null);
var c = cljs.core.nth.call(null,vec__29056,(2),null);
var clause = vec__29056;
var more = cljs.core.nth.call(null,vec__29055,(1),null);
var n = cljs.core.count.call(null,clause);
if(cljs.core._EQ_.call(null,(0),n)){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"throw","throw",595905694,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("js","Error.","js/Error.",750655924,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","str","cljs.core/str",-1971828991,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,"No matching clause: "),(function (){var x__23746__auto__ = expr__$1;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
} else {
if(cljs.core._EQ_.call(null,(1),n)){
return a;
} else {
if(cljs.core._EQ_.call(null,(2),n)){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"if","if",1181717262,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,(function (){var x__23746__auto__ = pred__$1;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = a;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = expr__$1;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = b;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs$core$macros$emit.call(null,pred__$1,expr__$1,more);
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
} else {
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","if-let","cljs.core$macros/if-let",1291543946,null)),(function (){var x__23746__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"p__29047__auto__","p__29047__auto__",1230375621,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,(function (){var x__23746__auto__ = pred__$1;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = a;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = expr__$1;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})()))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,(function (){var x__23746__auto__ = c;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"p__29047__auto__","p__29047__auto__",1230375621,null)))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs$core$macros$emit.call(null,pred__$1,expr__$1,more);
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));

}
}
}
});})(gpred,gexpr))
;
var gres = cljs.core.gensym.call(null,"res__");
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","let","cljs.core$macros/let",-160286726,null)),(function (){var x__23746__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,(function (){var x__23746__auto__ = gpred;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = pred;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = gexpr;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = expr;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})()))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = emit.call(null,gpred,gexpr,clauses);
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
});

cljs.core$macros.condp.cljs$lang$maxFixedArity = (4);

cljs.core$macros.condp.cljs$lang$applyTo = (function (seq29048){
var G__29049 = cljs.core.first.call(null,seq29048);
var seq29048__$1 = cljs.core.next.call(null,seq29048);
var G__29050 = cljs.core.first.call(null,seq29048__$1);
var seq29048__$2 = cljs.core.next.call(null,seq29048__$1);
var G__29051 = cljs.core.first.call(null,seq29048__$2);
var seq29048__$3 = cljs.core.next.call(null,seq29048__$2);
var G__29052 = cljs.core.first.call(null,seq29048__$3);
var seq29048__$4 = cljs.core.next.call(null,seq29048__$3);
return cljs.core$macros.condp.cljs$core$IFn$_invoke$arity$variadic(G__29049,G__29050,G__29051,G__29052,seq29048__$4);
});

cljs.core$macros.condp.cljs$lang$macro = true;
cljs.core$macros.assoc_test = (function cljs$core$macros$assoc_test(m,test,expr,env){
if(cljs.core.contains_QMARK_.call(null,m,test)){
throw (new Error([cljs.core.str("Duplicate case test constant '"),cljs.core.str(test),cljs.core.str("'"),cljs.core.str((cljs.core.truth_(new cljs.core.Keyword(null,"line","line",212345235).cljs$core$IFn$_invoke$arity$1(env))?[cljs.core.str(" on line "),cljs.core.str(new cljs.core.Keyword(null,"line","line",212345235).cljs$core$IFn$_invoke$arity$1(env)),cljs.core.str(" "),cljs.core.str(cljs.analyzer._STAR_cljs_file_STAR_)].join(''):null))].join('')));
} else {
return cljs.core.assoc.call(null,m,test,expr);
}
});
cljs.core$macros.const_QMARK_ = (function cljs$core$macros$const_QMARK_(env,x){
var m = (function (){var and__22900__auto__ = cljs.core.list_QMARK_.call(null,x);
if(and__22900__auto__){
return cljs.analyzer.resolve_var.call(null,env,cljs.core.last.call(null,x));
} else {
return and__22900__auto__;
}
})();
if(cljs.core.truth_(m)){
return cljs.core.get.call(null,m,new cljs.core.Keyword(null,"const","const",1709929842));
} else {
return null;
}
});
/**
 * Takes an expression, and a set of clauses.
 * 
 *   Each clause can take the form of either:
 * 
 *   test-constant result-expr
 * 
 *   (test-constant1 ... test-constantN)  result-expr
 * 
 *   The test-constants are not evaluated. They must be compile-time
 *   literals, and need not be quoted.  If the expression is equal to a
 *   test-constant, the corresponding result-expr is returned. A single
 *   default expression can follow the clauses, and its value will be
 *   returned if no clause matches. If no default expression is provided
 *   and no clause matches, an Error is thrown.
 * 
 *   Unlike cond and condp, case does a constant-time dispatch, the
 *   clauses are not considered sequentially.  All manner of constant
 *   expressions are acceptable in case, including numbers, strings,
 *   symbols, keywords, and (ClojureScript) composites thereof. Note that since
 *   lists are used to group multiple constants that map to the same
 *   expression, a vector can be used to match a list if needed. The
 *   test-constants need not be all of the same type.
 */
cljs.core$macros.case$ = (function cljs$core$macros$case(var_args){
var args__23989__auto__ = [];
var len__23982__auto___29074 = arguments.length;
var i__23983__auto___29075 = (0);
while(true){
if((i__23983__auto___29075 < len__23982__auto___29074)){
args__23989__auto__.push((arguments[i__23983__auto___29075]));

var G__29076 = (i__23983__auto___29075 + (1));
i__23983__auto___29075 = G__29076;
continue;
} else {
}
break;
}

var argseq__23990__auto__ = ((((3) < args__23989__auto__.length))?(new cljs.core.IndexedSeq(args__23989__auto__.slice((3)),(0),null)):null);
return cljs.core$macros.case$.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),argseq__23990__auto__);
});

cljs.core$macros.case$.cljs$core$IFn$_invoke$arity$variadic = (function (_AMPERSAND_form,_AMPERSAND_env,e,clauses){
var default$ = ((cljs.core.odd_QMARK_.call(null,cljs.core.count.call(null,clauses)))?cljs.core.last.call(null,clauses):cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"throw","throw",595905694,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("js","Error.","js/Error.",750655924,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","str","cljs.core/str",-1971828991,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,"No matching clause: "),(function (){var x__23746__auto__ = e;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})()))));
var env = _AMPERSAND_env;
var pairs = cljs.core.reduce.call(null,((function (default$,env){
return (function (m,p__29068){
var vec__29069 = p__29068;
var test = cljs.core.nth.call(null,vec__29069,(0),null);
var expr = cljs.core.nth.call(null,vec__29069,(1),null);
if(cljs.core.seq_QMARK_.call(null,test)){
return cljs.core.reduce.call(null,((function (vec__29069,test,expr,default$,env){
return (function (m__$1,test__$1){
var test__$2 = (((test__$1 instanceof cljs.core.Symbol))?cljs.core._conj.call(null,(function (){var x__23746__auto__ = test__$1;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),new cljs.core.Symbol(null,"quote","quote",1377916282,null)):test__$1);
return cljs.core$macros.assoc_test.call(null,m__$1,test__$2,expr,env);
});})(vec__29069,test,expr,default$,env))
,m,test);
} else {
if((test instanceof cljs.core.Symbol)){
return cljs.core$macros.assoc_test.call(null,m,cljs.core._conj.call(null,(function (){var x__23746__auto__ = test;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),new cljs.core.Symbol(null,"quote","quote",1377916282,null)),expr,env);
} else {
return cljs.core$macros.assoc_test.call(null,m,test,expr,env);

}
}
});})(default$,env))
,cljs.core.PersistentArrayMap.EMPTY,cljs.core.partition.call(null,(2),clauses));
var esym = cljs.core.gensym.call(null);
var tests = cljs.core.keys.call(null,pairs);
if(cljs.core.every_QMARK_.call(null,cljs.core.some_fn.call(null,cljs.core.number_QMARK_,cljs.core.string_QMARK_,cljs.core.fnil.call(null,cljs.core.char_QMARK_,new cljs.core.Keyword(null,"nonchar","nonchar",-421759703)),((function (default$,env,pairs,esym,tests){
return (function (p1__29060_SHARP_){
return cljs.core$macros.const_QMARK_.call(null,env,p1__29060_SHARP_);
});})(default$,env,pairs,esym,tests))
),tests)){
var no_default = ((cljs.core.odd_QMARK_.call(null,cljs.core.count.call(null,clauses)))?cljs.core.butlast.call(null,clauses):clauses);
var tests__$1 = cljs.core.mapv.call(null,((function (no_default,default$,env,pairs,esym,tests){
return (function (p1__29061_SHARP_){
if(cljs.core.seq_QMARK_.call(null,p1__29061_SHARP_)){
return cljs.core.vec.call(null,p1__29061_SHARP_);
} else {
return new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [p1__29061_SHARP_], null);
}
});})(no_default,default$,env,pairs,esym,tests))
,cljs.core.take_nth.call(null,(2),no_default));
var thens = cljs.core.vec.call(null,cljs.core.take_nth.call(null,(2),cljs.core.drop.call(null,(1),no_default)));
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","let","cljs.core$macros/let",-160286726,null)),(function (){var x__23746__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,(function (){var x__23746__auto__ = esym;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = e;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})()))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"case*","case*",-1938255072,null)),(function (){var x__23746__auto__ = esym;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = tests__$1;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = thens;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = default$;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
} else {
if(cljs.core.every_QMARK_.call(null,cljs.core.keyword_QMARK_,tests)){
var tests__$1 = cljs.core.mapv.call(null,((function (default$,env,pairs,esym,tests){
return (function (p1__29063_SHARP_){
if(cljs.core.seq_QMARK_.call(null,p1__29063_SHARP_)){
return cljs.core.vec.call(null,p1__29063_SHARP_);
} else {
return new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [p1__29063_SHARP_], null);
}
});})(default$,env,pairs,esym,tests))
,cljs.core.vec.call(null,cljs.core.map.call(null,((function (default$,env,pairs,esym,tests){
return (function (p1__29062_SHARP_){
return [cljs.core.str(p1__29062_SHARP_)].join('').substring((1));
});})(default$,env,pairs,esym,tests))
,tests)));
var thens = cljs.core.vec.call(null,cljs.core.vals.call(null,pairs));
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","let","cljs.core$macros/let",-160286726,null)),(function (){var x__23746__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,(function (){var x__23746__auto__ = esym;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"if","if",1181717262,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","keyword?","cljs.core$macros/keyword?",1362730141,null)),(function (){var x__23746__auto__ = e;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,".-fqn",".-fqn",1246113027,null)),(function (){var x__23746__auto__ = e;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,null))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})()))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"case*","case*",-1938255072,null)),(function (){var x__23746__auto__ = esym;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = tests__$1;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = thens;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = default$;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
} else {
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","let","cljs.core$macros/let",-160286726,null)),(function (){var x__23746__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,(function (){var x__23746__auto__ = esym;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = e;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})()))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","cond","cljs.core$macros/cond",1626318471,null)),cljs.core.mapcat.call(null,((function (default$,env,pairs,esym,tests){
return (function (p__29072){
var vec__29073 = p__29072;
var m = cljs.core.nth.call(null,vec__29073,(0),null);
var c = cljs.core.nth.call(null,vec__29073,(1),null);
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","=","cljs.core/=",-1891498332,null)),(function (){var x__23746__auto__ = m;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = esym;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = c;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
});})(default$,env,pairs,esym,tests))
,pairs),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Keyword(null,"else","else",-1508377146)),(function (){var x__23746__auto__ = default$;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));

}
}
});

cljs.core$macros.case$.cljs$lang$maxFixedArity = (3);

cljs.core$macros.case$.cljs$lang$applyTo = (function (seq29064){
var G__29065 = cljs.core.first.call(null,seq29064);
var seq29064__$1 = cljs.core.next.call(null,seq29064);
var G__29066 = cljs.core.first.call(null,seq29064__$1);
var seq29064__$2 = cljs.core.next.call(null,seq29064__$1);
var G__29067 = cljs.core.first.call(null,seq29064__$2);
var seq29064__$3 = cljs.core.next.call(null,seq29064__$2);
return cljs.core$macros.case$.cljs$core$IFn$_invoke$arity$variadic(G__29065,G__29066,G__29067,seq29064__$3);
});

cljs.core$macros.case$.cljs$lang$macro = true;
/**
 * Evaluates expr and throws an exception if it does not evaluate to
 *   logical true.
 */
cljs.core$macros.assert = (function cljs$core$macros$assert(var_args){
var args29077 = [];
var len__23982__auto___29080 = arguments.length;
var i__23983__auto___29081 = (0);
while(true){
if((i__23983__auto___29081 < len__23982__auto___29080)){
args29077.push((arguments[i__23983__auto___29081]));

var G__29082 = (i__23983__auto___29081 + (1));
i__23983__auto___29081 = G__29082;
continue;
} else {
}
break;
}

var G__29079 = args29077.length;
switch (G__29079) {
case 3:
return cljs.core$macros.assert.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
case 4:
return cljs.core$macros.assert.cljs$core$IFn$_invoke$arity$4((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]));

break;
default:
throw (new Error([cljs.core.str("Invalid arity: "),cljs.core.str((args29077.length - (2)))].join('')));

}
});

cljs.core$macros.assert.cljs$core$IFn$_invoke$arity$3 = (function (_AMPERSAND_form,_AMPERSAND_env,x){
if(cljs.core.truth_(cljs.core._STAR_assert_STAR_)){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","when-not","cljs.core$macros/when-not",-764302244,null)),(function (){var x__23746__auto__ = x;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"throw","throw",595905694,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("js","Error.","js/Error.",750655924,null)),(function (){var x__23746__auto__ = [cljs.core.str("Assert failed: "),cljs.core.str(cljs.core.pr_str.call(null,x))].join('');
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
} else {
return null;
}
});

cljs.core$macros.assert.cljs$core$IFn$_invoke$arity$4 = (function (_AMPERSAND_form,_AMPERSAND_env,x,message){
if(cljs.core.truth_(cljs.core._STAR_assert_STAR_)){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","when-not","cljs.core$macros/when-not",-764302244,null)),(function (){var x__23746__auto__ = x;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"throw","throw",595905694,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("js","Error.","js/Error.",750655924,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","str","cljs.core/str",-1971828991,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,"Assert failed: "),(function (){var x__23746__auto__ = message;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,"\n"),(function (){var x__23746__auto__ = cljs.core.pr_str.call(null,x);
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
} else {
return null;
}
});

cljs.core$macros.assert.cljs$lang$maxFixedArity = 4;

cljs.core$macros.assert.cljs$lang$macro = true;
/**
 * List comprehension. Takes a vector of one or more
 * binding-form/collection-expr pairs, each followed by zero or more
 * modifiers, and yields a lazy sequence of evaluations of expr.
 * Collections are iterated in a nested fashion, rightmost fastest,
 * and nested coll-exprs can refer to bindings created in prior
 * binding-forms.  Supported modifiers are: :let [binding-form expr ...],
 * :while test, :when test.
 * 
 *   (take 100 (for [x (range 100000000) y (range 1000000) :while (< y x)]  [x y]))
 */
cljs.core$macros.for$ = (function cljs$core$macros$for(_AMPERSAND_form,_AMPERSAND_env,seq_exprs,body_expr){
if(cljs.core.vector_QMARK_.call(null,seq_exprs)){
} else {
throw cljs.core.ex_info.call(null,"for requires a vector for its binding",cljs.core.PersistentArrayMap.EMPTY);
}

if(cljs.core.even_QMARK_.call(null,cljs.core.count.call(null,seq_exprs))){
} else {
throw cljs.core.ex_info.call(null,"for requires an even number of forms in binding vector",cljs.core.PersistentArrayMap.EMPTY);
}


var to_groups = (function (seq_exprs__$1){
return cljs.core.reduce.call(null,(function (groups,p__29120){
var vec__29121 = p__29120;
var k = cljs.core.nth.call(null,vec__29121,(0),null);
var v = cljs.core.nth.call(null,vec__29121,(1),null);
if((k instanceof cljs.core.Keyword)){
return cljs.core.conj.call(null,cljs.core.pop.call(null,groups),cljs.core.conj.call(null,cljs.core.peek.call(null,groups),new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [k,v], null)));
} else {
return cljs.core.conj.call(null,groups,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [k,v], null));
}
}),cljs.core.PersistentVector.EMPTY,cljs.core.partition.call(null,(2),seq_exprs__$1));
});
var err = ((function (to_groups){
return (function() { 
var G__29151__delegate = function (msg){
throw cljs.core.ex_info.call(null,cljs.core.apply.call(null,cljs.core.str,msg),cljs.core.PersistentArrayMap.EMPTY);
};
var G__29151 = function (var_args){
var msg = null;
if (arguments.length > 0) {
var G__29152__i = 0, G__29152__a = new Array(arguments.length -  0);
while (G__29152__i < G__29152__a.length) {G__29152__a[G__29152__i] = arguments[G__29152__i + 0]; ++G__29152__i;}
  msg = new cljs.core.IndexedSeq(G__29152__a,0);
} 
return G__29151__delegate.call(this,msg);};
G__29151.cljs$lang$maxFixedArity = 0;
G__29151.cljs$lang$applyTo = (function (arglist__29153){
var msg = cljs.core.seq(arglist__29153);
return G__29151__delegate(msg);
});
G__29151.cljs$core$IFn$_invoke$arity$variadic = G__29151__delegate;
return G__29151;
})()
;})(to_groups))
;
var emit_bind = ((function (to_groups,err){
return (function cljs$core$macros$for_$_emit_bind(p__29122){
var vec__29137 = p__29122;
var vec__29138 = cljs.core.nth.call(null,vec__29137,(0),null);
var bind = cljs.core.nth.call(null,vec__29138,(0),null);
var expr = cljs.core.nth.call(null,vec__29138,(1),null);
var mod_pairs = cljs.core.nthnext.call(null,vec__29138,(2));
var vec__29139 = cljs.core.nthnext.call(null,vec__29137,(1));
var vec__29140 = cljs.core.nth.call(null,vec__29139,(0),null);
var _ = cljs.core.nth.call(null,vec__29140,(0),null);
var next_expr = cljs.core.nth.call(null,vec__29140,(1),null);
var next_groups = vec__29139;
var giter = cljs.core.gensym.call(null,"iter__");
var gxs = cljs.core.gensym.call(null,"s__");
var do_mod = ((function (giter,gxs,vec__29137,vec__29138,bind,expr,mod_pairs,vec__29139,vec__29140,_,next_expr,next_groups,to_groups,err){
return (function cljs$core$macros$for_$_emit_bind_$_do_mod(p__29141){
var vec__29144 = p__29141;
var vec__29145 = cljs.core.nth.call(null,vec__29144,(0),null);
var k = cljs.core.nth.call(null,vec__29145,(0),null);
var v = cljs.core.nth.call(null,vec__29145,(1),null);
var pair = vec__29145;
var etc = cljs.core.nthnext.call(null,vec__29144,(1));
if(cljs.core._EQ_.call(null,k,new cljs.core.Keyword(null,"let","let",-1282412701))){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","let","cljs.core$macros/let",-160286726,null)),(function (){var x__23746__auto__ = v;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs$core$macros$for_$_emit_bind_$_do_mod.call(null,etc);
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
} else {
if(cljs.core._EQ_.call(null,k,new cljs.core.Keyword(null,"while","while",963117786))){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","when","cljs.core$macros/when",328457725,null)),(function (){var x__23746__auto__ = v;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs$core$macros$for_$_emit_bind_$_do_mod.call(null,etc);
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
} else {
if(cljs.core._EQ_.call(null,k,new cljs.core.Keyword(null,"when","when",-576417306))){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"if","if",1181717262,null)),(function (){var x__23746__auto__ = v;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs$core$macros$for_$_emit_bind_$_do_mod.call(null,etc);
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"recur","recur",1202958259,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","rest","cljs.core/rest",-285075455,null)),(function (){var x__23746__auto__ = gxs;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
} else {
if((k instanceof cljs.core.Keyword)){
return err.call(null,"Invalid 'for' keyword ",k);
} else {
if(cljs.core.truth_(next_groups)){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","let","cljs.core$macros/let",-160286726,null)),(function (){var x__23746__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"iterys__29084__auto__","iterys__29084__auto__",-226288285,null)),(function (){var x__23746__auto__ = cljs$core$macros$for_$_emit_bind.call(null,next_groups);
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"fs__29085__auto__","fs__29085__auto__",364501858,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","seq","cljs.core/seq",-1649497689,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"iterys__29084__auto__","iterys__29084__auto__",-226288285,null)),(function (){var x__23746__auto__ = next_expr;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})()))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"if","if",1181717262,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"fs__29085__auto__","fs__29085__auto__",364501858,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","concat","cljs.core/concat",-1133584918,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"fs__29085__auto__","fs__29085__auto__",364501858,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,(function (){var x__23746__auto__ = giter;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","rest","cljs.core/rest",-285075455,null)),(function (){var x__23746__auto__ = gxs;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"recur","recur",1202958259,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","rest","cljs.core/rest",-285075455,null)),(function (){var x__23746__auto__ = gxs;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
} else {
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","cons","cljs.core/cons",96507417,null)),(function (){var x__23746__auto__ = body_expr;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,(function (){var x__23746__auto__ = giter;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","rest","cljs.core/rest",-285075455,null)),(function (){var x__23746__auto__ = gxs;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));

}
}
}
}
}
});})(giter,gxs,vec__29137,vec__29138,bind,expr,mod_pairs,vec__29139,vec__29140,_,next_expr,next_groups,to_groups,err))
;
if(cljs.core.truth_(next_groups)){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","fn","cljs.core$macros/fn",-187522821,null)),(function (){var x__23746__auto__ = giter;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,(function (){var x__23746__auto__ = gxs;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})()))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","lazy-seq","cljs.core$macros/lazy-seq",806482650,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","loop","cljs.core$macros/loop",1731108390,null)),(function (){var x__23746__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,(function (){var x__23746__auto__ = gxs;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = gxs;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})()))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","when-first","cljs.core$macros/when-first",-840670160,null)),(function (){var x__23746__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,(function (){var x__23746__auto__ = bind;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = gxs;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})()))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = do_mod.call(null,mod_pairs);
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
} else {
var gi = cljs.core.gensym.call(null,"i__");
var gb = cljs.core.gensym.call(null,"b__");
var do_cmod = ((function (gi,gb,giter,gxs,do_mod,vec__29137,vec__29138,bind,expr,mod_pairs,vec__29139,vec__29140,_,next_expr,next_groups,to_groups,err){
return (function cljs$core$macros$for_$_emit_bind_$_do_cmod(p__29146){
var vec__29149 = p__29146;
var vec__29150 = cljs.core.nth.call(null,vec__29149,(0),null);
var k = cljs.core.nth.call(null,vec__29150,(0),null);
var v = cljs.core.nth.call(null,vec__29150,(1),null);
var pair = vec__29150;
var etc = cljs.core.nthnext.call(null,vec__29149,(1));
if(cljs.core._EQ_.call(null,k,new cljs.core.Keyword(null,"let","let",-1282412701))){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","let","cljs.core$macros/let",-160286726,null)),(function (){var x__23746__auto__ = v;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs$core$macros$for_$_emit_bind_$_do_cmod.call(null,etc);
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
} else {
if(cljs.core._EQ_.call(null,k,new cljs.core.Keyword(null,"while","while",963117786))){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","when","cljs.core$macros/when",328457725,null)),(function (){var x__23746__auto__ = v;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs$core$macros$for_$_emit_bind_$_do_cmod.call(null,etc);
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
} else {
if(cljs.core._EQ_.call(null,k,new cljs.core.Keyword(null,"when","when",-576417306))){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"if","if",1181717262,null)),(function (){var x__23746__auto__ = v;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs$core$macros$for_$_emit_bind_$_do_cmod.call(null,etc);
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"recur","recur",1202958259,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","unchecked-inc","cljs.core$macros/unchecked-inc",-1615365330,null)),(function (){var x__23746__auto__ = gi;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
} else {
if((k instanceof cljs.core.Keyword)){
return err.call(null,"Invalid 'for' keyword ",k);
} else {
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"do","do",1686842252,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","chunk-append","cljs.core/chunk-append",-243671470,null)),(function (){var x__23746__auto__ = gb;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = body_expr;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"recur","recur",1202958259,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","unchecked-inc","cljs.core$macros/unchecked-inc",-1615365330,null)),(function (){var x__23746__auto__ = gi;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));

}
}
}
}
});})(gi,gb,giter,gxs,do_mod,vec__29137,vec__29138,bind,expr,mod_pairs,vec__29139,vec__29140,_,next_expr,next_groups,to_groups,err))
;
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","fn","cljs.core$macros/fn",-187522821,null)),(function (){var x__23746__auto__ = giter;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,(function (){var x__23746__auto__ = gxs;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})()))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","lazy-seq","cljs.core$macros/lazy-seq",806482650,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","loop","cljs.core$macros/loop",1731108390,null)),(function (){var x__23746__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,(function (){var x__23746__auto__ = gxs;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = gxs;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})()))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","when-let","cljs.core$macros/when-let",-2004472648,null)),(function (){var x__23746__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,(function (){var x__23746__auto__ = gxs;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","seq","cljs.core/seq",-1649497689,null)),(function (){var x__23746__auto__ = gxs;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})()))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"if","if",1181717262,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","chunked-seq?","cljs.core/chunked-seq?",-712922369,null)),(function (){var x__23746__auto__ = gxs;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","let","cljs.core$macros/let",-160286726,null)),(function (){var x__23746__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"c__29086__auto__","c__29086__auto__",1498552744,null)),(function (){var x__23746__auto__ = cljs.core.with_meta.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","chunk-first","cljs.core/chunk-first",-1157877305,null)),(function (){var x__23746__auto__ = gxs;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})()))),cljs.core.apply.call(null,cljs.core.array_map,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Keyword(null,"file","file",-1269645878)),cljs.core._conj.call(null,cljs.core.List.EMPTY,"/Users/clumsyjedi/workspace/clack/.cljs_node_repl/cljs/core.cljc"),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Keyword(null,"line","line",212345235)),cljs.core._conj.call(null,cljs.core.List.EMPTY,2279),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Keyword(null,"column","column",2078222095)),cljs.core._conj.call(null,cljs.core.List.EMPTY,52),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Keyword(null,"end-line","end-line",1837326455)),cljs.core._conj.call(null,cljs.core.List.EMPTY,2279),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Keyword(null,"end-column","end-column",1425389514)),cljs.core._conj.call(null,cljs.core.List.EMPTY,82),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Keyword(null,"tag","tag",-1290361223)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","not-native","cljs.core/not-native",-1716909265,null)))))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"size__29087__auto__","size__29087__auto__",-38728934,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","count","cljs.core/count",-921270233,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"c__29086__auto__","c__29086__auto__",1498552744,null)))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = gb;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","chunk-buffer","cljs.core/chunk-buffer",14093626,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"size__29087__auto__","size__29087__auto__",-38728934,null)))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})()))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"if","if",1181717262,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","coercive-boolean","cljs.core$macros/coercive-boolean",-450758280,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","loop","cljs.core$macros/loop",1731108390,null)),(function (){var x__23746__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,(function (){var x__23746__auto__ = gi;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,(0))))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"if","if",1181717262,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","<","cljs.core$macros/<",371512596,null)),(function (){var x__23746__auto__ = gi;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"size__29087__auto__","size__29087__auto__",-38728934,null)))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","let","cljs.core$macros/let",-160286726,null)),(function (){var x__23746__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,(function (){var x__23746__auto__ = bind;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","-nth","cljs.core/-nth",504234802,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"c__29086__auto__","c__29086__auto__",1498552744,null)),(function (){var x__23746__auto__ = gi;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})()))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = do_cmod.call(null,mod_pairs);
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,true))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","chunk-cons","cljs.core/chunk-cons",-250075688,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","chunk","cljs.core/chunk",847936424,null)),(function (){var x__23746__auto__ = gb;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,(function (){var x__23746__auto__ = giter;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","chunk-rest","cljs.core/chunk-rest",-398161143,null)),(function (){var x__23746__auto__ = gxs;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","chunk-cons","cljs.core/chunk-cons",-250075688,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","chunk","cljs.core/chunk",847936424,null)),(function (){var x__23746__auto__ = gb;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,null))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","let","cljs.core$macros/let",-160286726,null)),(function (){var x__23746__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,(function (){var x__23746__auto__ = bind;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","first","cljs.core/first",-752535972,null)),(function (){var x__23746__auto__ = gxs;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})()))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = do_mod.call(null,mod_pairs);
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
}
});})(to_groups,err))
;
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","let","cljs.core$macros/let",-160286726,null)),(function (){var x__23746__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"iter__29088__auto__","iter__29088__auto__",419308406,null)),(function (){var x__23746__auto__ = emit_bind.call(null,to_groups.call(null,seq_exprs));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})()))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"iter__29088__auto__","iter__29088__auto__",419308406,null)),(function (){var x__23746__auto__ = cljs.core.second.call(null,seq_exprs);
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
});

cljs.core$macros.for$.cljs$lang$macro = true;
/**
 * Repeatedly executes body (presumably for side-effects) with
 *   bindings and filtering as provided by "for".  Does not retain
 *   the head of the sequence. Returns nil.
 */
cljs.core$macros.doseq = (function cljs$core$macros$doseq(var_args){
var args__23989__auto__ = [];
var len__23982__auto___29159 = arguments.length;
var i__23983__auto___29160 = (0);
while(true){
if((i__23983__auto___29160 < len__23982__auto___29159)){
args__23989__auto__.push((arguments[i__23983__auto___29160]));

var G__29161 = (i__23983__auto___29160 + (1));
i__23983__auto___29160 = G__29161;
continue;
} else {
}
break;
}

var argseq__23990__auto__ = ((((3) < args__23989__auto__.length))?(new cljs.core.IndexedSeq(args__23989__auto__.slice((3)),(0),null)):null);
return cljs.core$macros.doseq.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),argseq__23990__auto__);
});

cljs.core$macros.doseq.cljs$core$IFn$_invoke$arity$variadic = (function (_AMPERSAND_form,_AMPERSAND_env,seq_exprs,body){
if(cljs.core.vector_QMARK_.call(null,seq_exprs)){
} else {
throw cljs.core.ex_info.call(null,"doseq requires a vector for its binding",cljs.core.PersistentArrayMap.EMPTY);
}

if(cljs.core.even_QMARK_.call(null,cljs.core.count.call(null,seq_exprs))){
} else {
throw cljs.core.ex_info.call(null,"doseq requires an even number of forms in binding vector",cljs.core.PersistentArrayMap.EMPTY);
}


var err = (function() { 
var G__29162__delegate = function (msg){
throw cljs.core.ex_info.call(null,cljs.core.apply.call(null,cljs.core.str,msg),cljs.core.PersistentArrayMap.EMPTY);
};
var G__29162 = function (var_args){
var msg = null;
if (arguments.length > 0) {
var G__29163__i = 0, G__29163__a = new Array(arguments.length -  0);
while (G__29163__i < G__29163__a.length) {G__29163__a[G__29163__i] = arguments[G__29163__i + 0]; ++G__29163__i;}
  msg = new cljs.core.IndexedSeq(G__29163__a,0);
} 
return G__29162__delegate.call(this,msg);};
G__29162.cljs$lang$maxFixedArity = 0;
G__29162.cljs$lang$applyTo = (function (arglist__29164){
var msg = cljs.core.seq(arglist__29164);
return G__29162__delegate(msg);
});
G__29162.cljs$core$IFn$_invoke$arity$variadic = G__29162__delegate;
return G__29162;
})()
;
var step = ((function (err){
return (function cljs$core$macros$step(recform,exprs){
if(cljs.core.not.call(null,exprs)){
return new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [true,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"do","do",1686842252,null)),body)))], null);
} else {
var k = cljs.core.first.call(null,exprs);
var v = cljs.core.second.call(null,exprs);
var seqsym = cljs.core.gensym.call(null,"seq__");
var recform__$1 = (((k instanceof cljs.core.Keyword))?recform:cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"recur","recur",1202958259,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","next","cljs.core/next",-1291438473,null)),(function (){var x__23746__auto__ = seqsym;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,null),cljs.core._conj.call(null,cljs.core.List.EMPTY,(0)),cljs.core._conj.call(null,cljs.core.List.EMPTY,(0))))));
var steppair = cljs$core$macros$step.call(null,recform__$1,cljs.core.nnext.call(null,exprs));
var needrec = steppair.call(null,(0));
var subform = steppair.call(null,(1));
if(cljs.core._EQ_.call(null,k,new cljs.core.Keyword(null,"let","let",-1282412701))){
return new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [needrec,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","let","cljs.core$macros/let",-160286726,null)),(function (){var x__23746__auto__ = v;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = subform;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())))], null);
} else {
if(cljs.core._EQ_.call(null,k,new cljs.core.Keyword(null,"while","while",963117786))){
return new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [false,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","when","cljs.core$macros/when",328457725,null)),(function (){var x__23746__auto__ = v;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = subform;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(cljs.core.truth_(needrec)?new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [recform__$1], null):null))))], null);
} else {
if(cljs.core._EQ_.call(null,k,new cljs.core.Keyword(null,"when","when",-576417306))){
return new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [false,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"if","if",1181717262,null)),(function (){var x__23746__auto__ = v;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"do","do",1686842252,null)),(function (){var x__23746__auto__ = subform;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(cljs.core.truth_(needrec)?new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [recform__$1], null):null))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = recform__$1;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())))], null);
} else {
if((k instanceof cljs.core.Keyword)){
return err.call(null,"Invalid 'doseq' keyword",k);
} else {
var chunksym = cljs.core.with_meta.call(null,cljs.core.gensym.call(null,"chunk__"),new cljs.core.PersistentArrayMap(null, 1, [new cljs.core.Keyword(null,"tag","tag",-1290361223),new cljs.core.Symbol(null,"not-native","not-native",-236392494,null)], null));
var countsym = cljs.core.gensym.call(null,"count__");
var isym = cljs.core.gensym.call(null,"i__");
var recform_chunk = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"recur","recur",1202958259,null)),(function (){var x__23746__auto__ = seqsym;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = chunksym;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = countsym;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","unchecked-inc","cljs.core$macros/unchecked-inc",-1615365330,null)),(function (){var x__23746__auto__ = isym;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
var steppair_chunk = cljs$core$macros$step.call(null,recform_chunk,cljs.core.nnext.call(null,exprs));
var subform_chunk = steppair_chunk.call(null,(1));
return new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [true,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","loop","cljs.core$macros/loop",1731108390,null)),(function (){var x__23746__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,(function (){var x__23746__auto__ = seqsym;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","seq","cljs.core/seq",-1649497689,null)),(function (){var x__23746__auto__ = v;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = chunksym;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,null),(function (){var x__23746__auto__ = countsym;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,(0)),(function (){var x__23746__auto__ = isym;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,(0))))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"if","if",1181717262,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","coercive-boolean","cljs.core$macros/coercive-boolean",-450758280,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","<","cljs.core$macros/<",371512596,null)),(function (){var x__23746__auto__ = isym;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = countsym;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","let","cljs.core$macros/let",-160286726,null)),(function (){var x__23746__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,(function (){var x__23746__auto__ = k;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","-nth","cljs.core/-nth",504234802,null)),(function (){var x__23746__auto__ = chunksym;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = isym;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})()))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = subform_chunk;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(cljs.core.truth_(needrec)?new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [recform_chunk], null):null))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","when-let","cljs.core$macros/when-let",-2004472648,null)),(function (){var x__23746__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,(function (){var x__23746__auto__ = seqsym;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","seq","cljs.core/seq",-1649497689,null)),(function (){var x__23746__auto__ = seqsym;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})()))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"if","if",1181717262,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","chunked-seq?","cljs.core/chunked-seq?",-712922369,null)),(function (){var x__23746__auto__ = seqsym;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","let","cljs.core$macros/let",-160286726,null)),(function (){var x__23746__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"c__29154__auto__","c__29154__auto__",-1035472210,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","chunk-first","cljs.core/chunk-first",-1157877305,null)),(function (){var x__23746__auto__ = seqsym;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})()))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"recur","recur",1202958259,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","chunk-rest","cljs.core/chunk-rest",-398161143,null)),(function (){var x__23746__auto__ = seqsym;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"c__29154__auto__","c__29154__auto__",-1035472210,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","count","cljs.core/count",-921270233,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"c__29154__auto__","c__29154__auto__",-1035472210,null)))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,(0)))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","let","cljs.core$macros/let",-160286726,null)),(function (){var x__23746__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,(function (){var x__23746__auto__ = k;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","first","cljs.core/first",-752535972,null)),(function (){var x__23746__auto__ = seqsym;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})()))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = subform;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(cljs.core.truth_(needrec)?new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [recform__$1], null):null))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())))], null);

}
}
}
}
}
});})(err))
;
return cljs.core.nth.call(null,step.call(null,null,cljs.core.seq.call(null,seq_exprs)),(1));
});

cljs.core$macros.doseq.cljs$lang$maxFixedArity = (3);

cljs.core$macros.doseq.cljs$lang$applyTo = (function (seq29155){
var G__29156 = cljs.core.first.call(null,seq29155);
var seq29155__$1 = cljs.core.next.call(null,seq29155);
var G__29157 = cljs.core.first.call(null,seq29155__$1);
var seq29155__$2 = cljs.core.next.call(null,seq29155__$1);
var G__29158 = cljs.core.first.call(null,seq29155__$2);
var seq29155__$3 = cljs.core.next.call(null,seq29155__$2);
return cljs.core$macros.doseq.cljs$core$IFn$_invoke$arity$variadic(G__29156,G__29157,G__29158,seq29155__$3);
});

cljs.core$macros.doseq.cljs$lang$macro = true;
cljs.core$macros.array = (function cljs$core$macros$array(var_args){
var args__23989__auto__ = [];
var len__23982__auto___29168 = arguments.length;
var i__23983__auto___29169 = (0);
while(true){
if((i__23983__auto___29169 < len__23982__auto___29168)){
args__23989__auto__.push((arguments[i__23983__auto___29169]));

var G__29170 = (i__23983__auto___29169 + (1));
i__23983__auto___29169 = G__29170;
continue;
} else {
}
break;
}

var argseq__23990__auto__ = ((((2) < args__23989__auto__.length))?(new cljs.core.IndexedSeq(args__23989__auto__.slice((2)),(0),null)):null);
return cljs.core$macros.array.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__23990__auto__);
});

cljs.core$macros.array.cljs$core$IFn$_invoke$arity$variadic = (function (_AMPERSAND_form,_AMPERSAND_env,rest){
var xs_str = cljs.core.apply.call(null,cljs.core.str,cljs.core.interpose.call(null,",",cljs.core.take.call(null,cljs.core.count.call(null,rest),cljs.core.repeat.call(null,"~{}"))));
return cljs.core.vary_meta.call(null,cljs.core.list_STAR_.call(null,new cljs.core.Symbol(null,"js*","js*",-1134233646,null),[cljs.core.str("["),cljs.core.str(xs_str),cljs.core.str("]")].join(''),rest),cljs.core.assoc,new cljs.core.Keyword(null,"tag","tag",-1290361223),new cljs.core.Symbol(null,"array","array",-440182315,null));
});

cljs.core$macros.array.cljs$lang$maxFixedArity = (2);

cljs.core$macros.array.cljs$lang$applyTo = (function (seq29165){
var G__29166 = cljs.core.first.call(null,seq29165);
var seq29165__$1 = cljs.core.next.call(null,seq29165);
var G__29167 = cljs.core.first.call(null,seq29165__$1);
var seq29165__$2 = cljs.core.next.call(null,seq29165__$1);
return cljs.core$macros.array.cljs$core$IFn$_invoke$arity$variadic(G__29166,G__29167,seq29165__$2);
});

cljs.core$macros.array.cljs$lang$macro = true;
cljs.core$macros.make_array = (function cljs$core$macros$make_array(var_args){
var args29174 = [];
var len__23982__auto___29182 = arguments.length;
var i__23983__auto___29183 = (0);
while(true){
if((i__23983__auto___29183 < len__23982__auto___29182)){
args29174.push((arguments[i__23983__auto___29183]));

var G__29184 = (i__23983__auto___29183 + (1));
i__23983__auto___29183 = G__29184;
continue;
} else {
}
break;
}

var G__29181 = args29174.length;
switch (G__29181) {
case 3:
return cljs.core$macros.make_array.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
case 4:
return cljs.core$macros.make_array.cljs$core$IFn$_invoke$arity$4((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]));

break;
default:
var argseq__24001__auto__ = (new cljs.core.IndexedSeq(args29174.slice((4)),(0),null));
return cljs.core$macros.make_array.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]),argseq__24001__auto__);

}
});

cljs.core$macros.make_array.cljs$core$IFn$_invoke$arity$3 = (function (_AMPERSAND_form,_AMPERSAND_env,size){
return cljs.core.vary_meta.call(null,((typeof size === 'number')?cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","array","cljs.core$macros/array",49650437,null)),cljs.core.take.call(null,size,cljs.core.repeat.call(null,null))))):cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("js","Array.","js/Array.",1235645307,null)),(function (){var x__23746__auto__ = size;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())))),cljs.core.assoc,new cljs.core.Keyword(null,"tag","tag",-1290361223),new cljs.core.Symbol(null,"array","array",-440182315,null));
});

cljs.core$macros.make_array.cljs$core$IFn$_invoke$arity$4 = (function (_AMPERSAND_form,_AMPERSAND_env,type,size){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","make-array","cljs.core/make-array",-1802166799,null)),(function (){var x__23746__auto__ = size;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
});

cljs.core$macros.make_array.cljs$core$IFn$_invoke$arity$variadic = (function (_AMPERSAND_form,_AMPERSAND_env,type,size,more_sizes){
return cljs.core.vary_meta.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","let","cljs.core$macros/let",-160286726,null)),(function (){var x__23746__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"dims__29171__auto__","dims__29171__auto__",-71020262,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","list","cljs.core$macros/list",-1408486806,null)),more_sizes)));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"dimarray__29172__auto__","dimarray__29172__auto__",976948453,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","make-array","cljs.core/make-array",-1802166799,null)),(function (){var x__23746__auto__ = size;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})()))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","dotimes","cljs.core$macros/dotimes",-1407597661,null)),(function (){var x__23746__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"i__29173__auto__","i__29173__auto__",-1661040464,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","alength","cljs.core$macros/alength",-683052937,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"dimarray__29172__auto__","dimarray__29172__auto__",976948453,null)))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})()))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","aset","cljs.core$macros/aset",-693176374,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"dimarray__29172__auto__","dimarray__29172__auto__",976948453,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"i__29173__auto__","i__29173__auto__",-1661040464,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","apply","cljs.core/apply",1757277831,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","make-array","cljs.core/make-array",-1802166799,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,null),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"dims__29171__auto__","dims__29171__auto__",-71020262,null)))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"dimarray__29172__auto__","dimarray__29172__auto__",976948453,null))))),cljs.core.assoc,new cljs.core.Keyword(null,"tag","tag",-1290361223),new cljs.core.Symbol(null,"array","array",-440182315,null));
});

cljs.core$macros.make_array.cljs$lang$applyTo = (function (seq29175){
var G__29176 = cljs.core.first.call(null,seq29175);
var seq29175__$1 = cljs.core.next.call(null,seq29175);
var G__29177 = cljs.core.first.call(null,seq29175__$1);
var seq29175__$2 = cljs.core.next.call(null,seq29175__$1);
var G__29178 = cljs.core.first.call(null,seq29175__$2);
var seq29175__$3 = cljs.core.next.call(null,seq29175__$2);
var G__29179 = cljs.core.first.call(null,seq29175__$3);
var seq29175__$4 = cljs.core.next.call(null,seq29175__$3);
return cljs.core$macros.make_array.cljs$core$IFn$_invoke$arity$variadic(G__29176,G__29177,G__29178,G__29179,seq29175__$4);
});

cljs.core$macros.make_array.cljs$lang$maxFixedArity = (4);

cljs.core$macros.make_array.cljs$lang$macro = true;
cljs.core$macros.list = (function cljs$core$macros$list(var_args){
var args29187 = [];
var len__23982__auto___29194 = arguments.length;
var i__23983__auto___29195 = (0);
while(true){
if((i__23983__auto___29195 < len__23982__auto___29194)){
args29187.push((arguments[i__23983__auto___29195]));

var G__29196 = (i__23983__auto___29195 + (1));
i__23983__auto___29195 = G__29196;
continue;
} else {
}
break;
}

var G__29193 = args29187.length;
switch (G__29193) {
case 2:
return cljs.core$macros.list.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
default:
var argseq__24001__auto__ = (new cljs.core.IndexedSeq(args29187.slice((3)),(0),null));
return cljs.core$macros.list.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),argseq__24001__auto__);

}
});

cljs.core$macros.list.cljs$core$IFn$_invoke$arity$2 = (function (_AMPERSAND_form,_AMPERSAND_env){
return cljs.core.list(new cljs.core.Symbol(null,".-EMPTY",".-EMPTY",-471586691,null),new cljs.core.Symbol("cljs.core","List","cljs.core/List",1708954352,null));
});

cljs.core$macros.list.cljs$core$IFn$_invoke$arity$variadic = (function (_AMPERSAND_form,_AMPERSAND_env,x,xs){
if(cljs.core._EQ_.call(null,new cljs.core.Keyword(null,"constant","constant",-379609303),new cljs.core.Keyword(null,"op","op",-1882987955).cljs$core$IFn$_invoke$arity$1(cljs.analyzer.analyze.call(null,_AMPERSAND_env,x)))){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","-conj","cljs.core/-conj",2040622670,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","list","cljs.core$macros/list",-1408486806,null)),xs)));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = x;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
} else {
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","let","cljs.core$macros/let",-160286726,null)),(function (){var x__23746__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"x__29186__auto__","x__29186__auto__",-1865779582,null)),(function (){var x__23746__auto__ = x;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})()))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","-conj","cljs.core/-conj",2040622670,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","list","cljs.core$macros/list",-1408486806,null)),xs)));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"x__29186__auto__","x__29186__auto__",-1865779582,null)))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
}
});

cljs.core$macros.list.cljs$lang$applyTo = (function (seq29188){
var G__29189 = cljs.core.first.call(null,seq29188);
var seq29188__$1 = cljs.core.next.call(null,seq29188);
var G__29190 = cljs.core.first.call(null,seq29188__$1);
var seq29188__$2 = cljs.core.next.call(null,seq29188__$1);
var G__29191 = cljs.core.first.call(null,seq29188__$2);
var seq29188__$3 = cljs.core.next.call(null,seq29188__$2);
return cljs.core$macros.list.cljs$core$IFn$_invoke$arity$variadic(G__29189,G__29190,G__29191,seq29188__$3);
});

cljs.core$macros.list.cljs$lang$maxFixedArity = (3);

cljs.core$macros.list.cljs$lang$macro = true;
cljs.core$macros.vector = (function cljs$core$macros$vector(var_args){
var args29198 = [];
var len__23982__auto___29204 = arguments.length;
var i__23983__auto___29205 = (0);
while(true){
if((i__23983__auto___29205 < len__23982__auto___29204)){
args29198.push((arguments[i__23983__auto___29205]));

var G__29206 = (i__23983__auto___29205 + (1));
i__23983__auto___29205 = G__29206;
continue;
} else {
}
break;
}

var G__29203 = args29198.length;
switch (G__29203) {
case 2:
return cljs.core$macros.vector.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
default:
var argseq__24001__auto__ = (new cljs.core.IndexedSeq(args29198.slice((2)),(0),null));
return cljs.core$macros.vector.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__24001__auto__);

}
});

cljs.core$macros.vector.cljs$core$IFn$_invoke$arity$2 = (function (_AMPERSAND_form,_AMPERSAND_env){
return cljs.core.list(new cljs.core.Symbol(null,".-EMPTY",".-EMPTY",-471586691,null),new cljs.core.Symbol("cljs.core","PersistentVector","cljs.core/PersistentVector",-1211028272,null));
});

cljs.core$macros.vector.cljs$core$IFn$_invoke$arity$variadic = (function (_AMPERSAND_form,_AMPERSAND_env,xs){
var cnt = cljs.core.count.call(null,xs);
if((cnt < (32))){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","PersistentVector.","cljs.core/PersistentVector.",-1074647876,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,null),(function (){var x__23746__auto__ = cnt;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,(5)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,".-EMPTY-NODE",".-EMPTY-NODE",-1333332641,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","PersistentVector","cljs.core/PersistentVector",-1211028272,null)))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","array","cljs.core$macros/array",49650437,null)),xs)));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,null))));
} else {
return cljs.core.vary_meta.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,".fromArray",".fromArray",1053499311,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","PersistentVector","cljs.core/PersistentVector",-1211028272,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","array","cljs.core$macros/array",49650437,null)),xs)));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,true)))),cljs.core.assoc,new cljs.core.Keyword(null,"tag","tag",-1290361223),new cljs.core.Symbol("cljs.core","PersistentVector","cljs.core/PersistentVector",-1211028272,null));
}
});

cljs.core$macros.vector.cljs$lang$applyTo = (function (seq29199){
var G__29200 = cljs.core.first.call(null,seq29199);
var seq29199__$1 = cljs.core.next.call(null,seq29199);
var G__29201 = cljs.core.first.call(null,seq29199__$1);
var seq29199__$2 = cljs.core.next.call(null,seq29199__$1);
return cljs.core$macros.vector.cljs$core$IFn$_invoke$arity$variadic(G__29200,G__29201,seq29199__$2);
});

cljs.core$macros.vector.cljs$lang$maxFixedArity = (2);

cljs.core$macros.vector.cljs$lang$macro = true;
cljs.core$macros.array_map = (function cljs$core$macros$array_map(var_args){
var args29210 = [];
var len__23982__auto___29216 = arguments.length;
var i__23983__auto___29217 = (0);
while(true){
if((i__23983__auto___29217 < len__23982__auto___29216)){
args29210.push((arguments[i__23983__auto___29217]));

var G__29218 = (i__23983__auto___29217 + (1));
i__23983__auto___29217 = G__29218;
continue;
} else {
}
break;
}

var G__29215 = args29210.length;
switch (G__29215) {
case 2:
return cljs.core$macros.array_map.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
default:
var argseq__24001__auto__ = (new cljs.core.IndexedSeq(args29210.slice((2)),(0),null));
return cljs.core$macros.array_map.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__24001__auto__);

}
});

cljs.core$macros.array_map.cljs$core$IFn$_invoke$arity$2 = (function (_AMPERSAND_form,_AMPERSAND_env){
return cljs.core.list(new cljs.core.Symbol(null,".-EMPTY",".-EMPTY",-471586691,null),new cljs.core.Symbol("cljs.core","PersistentArrayMap","cljs.core/PersistentArrayMap",1025194468,null));
});

cljs.core$macros.array_map.cljs$core$IFn$_invoke$arity$variadic = (function (_AMPERSAND_form,_AMPERSAND_env,kvs){
var keys = cljs.core.map.call(null,cljs.core.first,cljs.core.partition.call(null,(2),kvs));
if((cljs.core.every_QMARK_.call(null,((function (keys){
return (function (p1__29208_SHARP_){
return cljs.core._EQ_.call(null,new cljs.core.Keyword(null,"op","op",-1882987955).cljs$core$IFn$_invoke$arity$1(p1__29208_SHARP_),new cljs.core.Keyword(null,"constant","constant",-379609303));
});})(keys))
,cljs.core.map.call(null,((function (keys){
return (function (p1__29209_SHARP_){
return cljs.analyzer.analyze.call(null,_AMPERSAND_env,p1__29209_SHARP_);
});})(keys))
,keys))) && (cljs.core._EQ_.call(null,cljs.core.count.call(null,cljs.core.into.call(null,cljs.core.PersistentHashSet.EMPTY,keys)),cljs.core.count.call(null,keys)))){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","PersistentArrayMap.","cljs.core/PersistentArrayMap.",-471979341,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,null),(function (){var x__23746__auto__ = (cljs.core.count.call(null,kvs) / (2));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","array","cljs.core$macros/array",49650437,null)),kvs)));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,null))));
} else {
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,".fromArray",".fromArray",1053499311,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","PersistentArrayMap","cljs.core/PersistentArrayMap",1025194468,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","array","cljs.core$macros/array",49650437,null)),kvs)));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,true),cljs.core._conj.call(null,cljs.core.List.EMPTY,false))));
}
});

cljs.core$macros.array_map.cljs$lang$applyTo = (function (seq29211){
var G__29212 = cljs.core.first.call(null,seq29211);
var seq29211__$1 = cljs.core.next.call(null,seq29211);
var G__29213 = cljs.core.first.call(null,seq29211__$1);
var seq29211__$2 = cljs.core.next.call(null,seq29211__$1);
return cljs.core$macros.array_map.cljs$core$IFn$_invoke$arity$variadic(G__29212,G__29213,seq29211__$2);
});

cljs.core$macros.array_map.cljs$lang$maxFixedArity = (2);

cljs.core$macros.array_map.cljs$lang$macro = true;
cljs.core$macros.hash_map = (function cljs$core$macros$hash_map(var_args){
var args29220 = [];
var len__23982__auto___29226 = arguments.length;
var i__23983__auto___29227 = (0);
while(true){
if((i__23983__auto___29227 < len__23982__auto___29226)){
args29220.push((arguments[i__23983__auto___29227]));

var G__29228 = (i__23983__auto___29227 + (1));
i__23983__auto___29227 = G__29228;
continue;
} else {
}
break;
}

var G__29225 = args29220.length;
switch (G__29225) {
case 2:
return cljs.core$macros.hash_map.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
default:
var argseq__24001__auto__ = (new cljs.core.IndexedSeq(args29220.slice((2)),(0),null));
return cljs.core$macros.hash_map.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__24001__auto__);

}
});

cljs.core$macros.hash_map.cljs$core$IFn$_invoke$arity$2 = (function (_AMPERSAND_form,_AMPERSAND_env){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,".-EMPTY",".-EMPTY",-471586691,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","PersistentHashMap","cljs.core/PersistentHashMap",-454120575,null)))));
});

cljs.core$macros.hash_map.cljs$core$IFn$_invoke$arity$variadic = (function (_AMPERSAND_form,_AMPERSAND_env,kvs){
var pairs = cljs.core.partition.call(null,(2),kvs);
var ks = cljs.core.map.call(null,cljs.core.first,pairs);
var vs = cljs.core.map.call(null,cljs.core.second,pairs);
return cljs.core.vary_meta.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,".fromArrays",".fromArrays",1110244209,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","PersistentHashMap","cljs.core/PersistentHashMap",-454120575,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","array","cljs.core$macros/array",49650437,null)),ks)));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","array","cljs.core$macros/array",49650437,null)),vs)));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})()))),cljs.core.assoc,new cljs.core.Keyword(null,"tag","tag",-1290361223),new cljs.core.Symbol("cljs.core","PersistentHashMap","cljs.core/PersistentHashMap",-454120575,null));
});

cljs.core$macros.hash_map.cljs$lang$applyTo = (function (seq29221){
var G__29222 = cljs.core.first.call(null,seq29221);
var seq29221__$1 = cljs.core.next.call(null,seq29221);
var G__29223 = cljs.core.first.call(null,seq29221__$1);
var seq29221__$2 = cljs.core.next.call(null,seq29221__$1);
return cljs.core$macros.hash_map.cljs$core$IFn$_invoke$arity$variadic(G__29222,G__29223,seq29221__$2);
});

cljs.core$macros.hash_map.cljs$lang$maxFixedArity = (2);

cljs.core$macros.hash_map.cljs$lang$macro = true;
cljs.core$macros.hash_set = (function cljs$core$macros$hash_set(var_args){
var args29232 = [];
var len__23982__auto___29238 = arguments.length;
var i__23983__auto___29239 = (0);
while(true){
if((i__23983__auto___29239 < len__23982__auto___29238)){
args29232.push((arguments[i__23983__auto___29239]));

var G__29240 = (i__23983__auto___29239 + (1));
i__23983__auto___29239 = G__29240;
continue;
} else {
}
break;
}

var G__29237 = args29232.length;
switch (G__29237) {
case 2:
return cljs.core$macros.hash_set.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
default:
var argseq__24001__auto__ = (new cljs.core.IndexedSeq(args29232.slice((2)),(0),null));
return cljs.core$macros.hash_set.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__24001__auto__);

}
});

cljs.core$macros.hash_set.cljs$core$IFn$_invoke$arity$2 = (function (_AMPERSAND_form,_AMPERSAND_env){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,".-EMPTY",".-EMPTY",-471586691,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","PersistentHashSet","cljs.core/PersistentHashSet",-967232330,null)))));
});

cljs.core$macros.hash_set.cljs$core$IFn$_invoke$arity$variadic = (function (_AMPERSAND_form,_AMPERSAND_env,xs){
if(((cljs.core.count.call(null,xs) <= (8))) && (cljs.core.every_QMARK_.call(null,(function (p1__29230_SHARP_){
return cljs.core._EQ_.call(null,new cljs.core.Keyword(null,"op","op",-1882987955).cljs$core$IFn$_invoke$arity$1(p1__29230_SHARP_),new cljs.core.Keyword(null,"constant","constant",-379609303));
}),cljs.core.map.call(null,(function (p1__29231_SHARP_){
return cljs.analyzer.analyze.call(null,_AMPERSAND_env,p1__29231_SHARP_);
}),xs))) && (cljs.core._EQ_.call(null,cljs.core.count.call(null,cljs.core.into.call(null,cljs.core.PersistentHashSet.EMPTY,xs)),cljs.core.count.call(null,xs)))){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","PersistentHashSet.","cljs.core/PersistentHashSet.",300313251,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,null),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","PersistentArrayMap.","cljs.core/PersistentArrayMap.",-471979341,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,null),(function (){var x__23746__auto__ = cljs.core.count.call(null,xs);
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","array","cljs.core$macros/array",49650437,null)),cljs.core.interleave.call(null,xs,cljs.core.repeat.call(null,null)))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,null))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,null))));
} else {
return cljs.core.vary_meta.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,".fromArray",".fromArray",1053499311,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","PersistentHashSet","cljs.core/PersistentHashSet",-967232330,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","array","cljs.core$macros/array",49650437,null)),xs)));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,true)))),cljs.core.assoc,new cljs.core.Keyword(null,"tag","tag",-1290361223),new cljs.core.Symbol("cljs.core","PersistentHashSet","cljs.core/PersistentHashSet",-967232330,null));
}
});

cljs.core$macros.hash_set.cljs$lang$applyTo = (function (seq29233){
var G__29234 = cljs.core.first.call(null,seq29233);
var seq29233__$1 = cljs.core.next.call(null,seq29233);
var G__29235 = cljs.core.first.call(null,seq29233__$1);
var seq29233__$2 = cljs.core.next.call(null,seq29233__$1);
return cljs.core$macros.hash_set.cljs$core$IFn$_invoke$arity$variadic(G__29234,G__29235,seq29233__$2);
});

cljs.core$macros.hash_set.cljs$lang$maxFixedArity = (2);

cljs.core$macros.hash_set.cljs$lang$macro = true;
cljs.core$macros.js_obj_STAR_ = (function cljs$core$macros$js_obj_STAR_(kvs){
var kvs_str = cljs.core.apply.call(null,cljs.core.str,cljs.core.interpose.call(null,",",cljs.core.take.call(null,cljs.core.count.call(null,kvs),cljs.core.repeat.call(null,"~{}:~{}"))));
return cljs.core.vary_meta.call(null,cljs.core.list_STAR_.call(null,new cljs.core.Symbol(null,"js*","js*",-1134233646,null),[cljs.core.str("{"),cljs.core.str(kvs_str),cljs.core.str("}")].join(''),cljs.core.apply.call(null,cljs.core.concat,kvs)),cljs.core.assoc,new cljs.core.Keyword(null,"tag","tag",-1290361223),new cljs.core.Symbol(null,"object","object",-1179821820,null));
});
cljs.core$macros.js_obj = (function cljs$core$macros$js_obj(var_args){
var args__23989__auto__ = [];
var len__23982__auto___29251 = arguments.length;
var i__23983__auto___29252 = (0);
while(true){
if((i__23983__auto___29252 < len__23982__auto___29251)){
args__23989__auto__.push((arguments[i__23983__auto___29252]));

var G__29253 = (i__23983__auto___29252 + (1));
i__23983__auto___29252 = G__29253;
continue;
} else {
}
break;
}

var argseq__23990__auto__ = ((((2) < args__23989__auto__.length))?(new cljs.core.IndexedSeq(args__23989__auto__.slice((2)),(0),null)):null);
return cljs.core$macros.js_obj.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__23990__auto__);
});

cljs.core$macros.js_obj.cljs$core$IFn$_invoke$arity$variadic = (function (_AMPERSAND_form,_AMPERSAND_env,rest){
var sym_or_str_QMARK_ = (function (x){
return ((x instanceof cljs.core.Symbol)) || (typeof x === 'string');
});
var filter_on_keys = ((function (sym_or_str_QMARK_){
return (function (f,coll){
return cljs.core.into.call(null,cljs.core.PersistentArrayMap.EMPTY,cljs.core.filter.call(null,((function (sym_or_str_QMARK_){
return (function (p__29245){
var vec__29246 = p__29245;
var k = cljs.core.nth.call(null,vec__29246,(0),null);
var _ = cljs.core.nth.call(null,vec__29246,(1),null);
return f.call(null,k);
});})(sym_or_str_QMARK_))
,coll));
});})(sym_or_str_QMARK_))
;
var kvs = cljs.core.into.call(null,cljs.core.PersistentArrayMap.EMPTY,cljs.core.map.call(null,cljs.core.vec,cljs.core.partition.call(null,(2),rest)));
var sym_pairs = filter_on_keys.call(null,cljs.core.symbol_QMARK_,kvs);
var expr__GT_local = cljs.core.zipmap.call(null,cljs.core.filter.call(null,cljs.core.complement.call(null,sym_or_str_QMARK_),cljs.core.keys.call(null,kvs)),cljs.core.repeatedly.call(null,cljs.core.gensym));
var obj = cljs.core.gensym.call(null,"obj");
if(cljs.core.empty_QMARK_.call(null,rest)){
return cljs.core$macros.js_obj_STAR_.call(null,cljs.core.List.EMPTY);
} else {
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","let","cljs.core$macros/let",-160286726,null)),(function (){var x__23746__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core.apply.call(null,cljs.core.concat,clojure.set.map_invert.call(null,expr__GT_local)),(function (){var x__23746__auto__ = obj;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core$macros.js_obj_STAR_.call(null,filter_on_keys.call(null,cljs.core.string_QMARK_,kvs));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})()))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),cljs.core.map.call(null,((function (sym_or_str_QMARK_,filter_on_keys,kvs,sym_pairs,expr__GT_local,obj){
return (function (p__29247){
var vec__29248 = p__29247;
var k = cljs.core.nth.call(null,vec__29248,(0),null);
var v = cljs.core.nth.call(null,vec__29248,(1),null);
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","aset","cljs.core$macros/aset",-693176374,null)),(function (){var x__23746__auto__ = obj;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = k;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = v;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
});})(sym_or_str_QMARK_,filter_on_keys,kvs,sym_pairs,expr__GT_local,obj))
,sym_pairs),cljs.core.map.call(null,((function (sym_or_str_QMARK_,filter_on_keys,kvs,sym_pairs,expr__GT_local,obj){
return (function (p__29249){
var vec__29250 = p__29249;
var k = cljs.core.nth.call(null,vec__29250,(0),null);
var v = cljs.core.nth.call(null,vec__29250,(1),null);
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","aset","cljs.core$macros/aset",-693176374,null)),(function (){var x__23746__auto__ = obj;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = v;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.get.call(null,kvs,k);
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
});})(sym_or_str_QMARK_,filter_on_keys,kvs,sym_pairs,expr__GT_local,obj))
,expr__GT_local),(function (){var x__23746__auto__ = obj;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
}
});

cljs.core$macros.js_obj.cljs$lang$maxFixedArity = (2);

cljs.core$macros.js_obj.cljs$lang$applyTo = (function (seq29242){
var G__29243 = cljs.core.first.call(null,seq29242);
var seq29242__$1 = cljs.core.next.call(null,seq29242);
var G__29244 = cljs.core.first.call(null,seq29242__$1);
var seq29242__$2 = cljs.core.next.call(null,seq29242__$1);
return cljs.core$macros.js_obj.cljs$core$IFn$_invoke$arity$variadic(G__29243,G__29244,seq29242__$2);
});

cljs.core$macros.js_obj.cljs$lang$macro = true;
cljs.core$macros.alength = (function cljs$core$macros$alength(_AMPERSAND_form,_AMPERSAND_env,a){
return cljs.core.vary_meta.call(null,cljs.core._conj.call(null,cljs.core._conj.call(null,(function (){var x__23746__auto__ = a;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),"~{}.length"),new cljs.core.Symbol(null,"js*","js*",-1134233646,null)),cljs.core.assoc,new cljs.core.Keyword(null,"tag","tag",-1290361223),new cljs.core.Symbol(null,"number","number",-1084057331,null));
});

cljs.core$macros.alength.cljs$lang$macro = true;
/**
 * Maps an expression across an array a, using an index named idx, and
 *   return value named ret, initialized to a clone of a, then setting
 *   each element of ret to the evaluation of expr, returning the new
 *   array ret.
 */
cljs.core$macros.amap = (function cljs$core$macros$amap(_AMPERSAND_form,_AMPERSAND_env,a,idx,ret,expr){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","let","cljs.core$macros/let",-160286726,null)),(function (){var x__23746__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"a__29254__auto__","a__29254__auto__",475772868,null)),(function (){var x__23746__auto__ = a;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = ret;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","aclone","cljs.core/aclone",-758078968,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"a__29254__auto__","a__29254__auto__",475772868,null)))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})()))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","loop","cljs.core$macros/loop",1731108390,null)),(function (){var x__23746__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,(function (){var x__23746__auto__ = idx;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,(0))))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"if","if",1181717262,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","<","cljs.core$macros/<",371512596,null)),(function (){var x__23746__auto__ = idx;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","alength","cljs.core$macros/alength",-683052937,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"a__29254__auto__","a__29254__auto__",475772868,null)))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"do","do",1686842252,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","aset","cljs.core$macros/aset",-693176374,null)),(function (){var x__23746__auto__ = ret;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = idx;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = expr;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"recur","recur",1202958259,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","inc","cljs.core$macros/inc",876629257,null)),(function (){var x__23746__auto__ = idx;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = ret;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
});

cljs.core$macros.amap.cljs$lang$macro = true;
/**
 * Reduces an expression across an array a, using an index named idx,
 *   and return value named ret, initialized to init, setting ret to the
 *   evaluation of expr at each step, returning ret.
 */
cljs.core$macros.areduce = (function cljs$core$macros$areduce(_AMPERSAND_form,_AMPERSAND_env,a,idx,ret,init,expr){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","let","cljs.core$macros/let",-160286726,null)),(function (){var x__23746__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"a__29255__auto__","a__29255__auto__",-1959903987,null)),(function (){var x__23746__auto__ = a;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})()))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","loop","cljs.core$macros/loop",1731108390,null)),(function (){var x__23746__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,(function (){var x__23746__auto__ = idx;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,(0)),(function (){var x__23746__auto__ = ret;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = init;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})()))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"if","if",1181717262,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","<","cljs.core$macros/<",371512596,null)),(function (){var x__23746__auto__ = idx;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","alength","cljs.core$macros/alength",-683052937,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"a__29255__auto__","a__29255__auto__",-1959903987,null)))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"recur","recur",1202958259,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","inc","cljs.core$macros/inc",876629257,null)),(function (){var x__23746__auto__ = idx;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = expr;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = ret;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
});

cljs.core$macros.areduce.cljs$lang$macro = true;
/**
 * bindings => name n
 * 
 *   Repeatedly executes body (presumably for side-effects) with name
 *   bound to integers from 0 through n-1.
 */
cljs.core$macros.dotimes = (function cljs$core$macros$dotimes(var_args){
var args__23989__auto__ = [];
var len__23982__auto___29261 = arguments.length;
var i__23983__auto___29262 = (0);
while(true){
if((i__23983__auto___29262 < len__23982__auto___29261)){
args__23989__auto__.push((arguments[i__23983__auto___29262]));

var G__29263 = (i__23983__auto___29262 + (1));
i__23983__auto___29262 = G__29263;
continue;
} else {
}
break;
}

var argseq__23990__auto__ = ((((3) < args__23989__auto__.length))?(new cljs.core.IndexedSeq(args__23989__auto__.slice((3)),(0),null)):null);
return cljs.core$macros.dotimes.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),argseq__23990__auto__);
});

cljs.core$macros.dotimes.cljs$core$IFn$_invoke$arity$variadic = (function (_AMPERSAND_form,_AMPERSAND_env,bindings,body){
var i = cljs.core.first.call(null,bindings);
var n = cljs.core.second.call(null,bindings);
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","let","cljs.core$macros/let",-160286726,null)),(function (){var x__23746__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"n__29256__auto__","n__29256__auto__",-1423565393,null)),(function (){var x__23746__auto__ = n;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})()))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","loop","cljs.core$macros/loop",1731108390,null)),(function (){var x__23746__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,(function (){var x__23746__auto__ = i;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,(0))))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","when","cljs.core$macros/when",328457725,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","<","cljs.core$macros/<",371512596,null)),(function (){var x__23746__auto__ = i;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"n__29256__auto__","n__29256__auto__",-1423565393,null)))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),body,(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"recur","recur",1202958259,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","inc","cljs.core$macros/inc",876629257,null)),(function (){var x__23746__auto__ = i;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
});

cljs.core$macros.dotimes.cljs$lang$maxFixedArity = (3);

cljs.core$macros.dotimes.cljs$lang$applyTo = (function (seq29257){
var G__29258 = cljs.core.first.call(null,seq29257);
var seq29257__$1 = cljs.core.next.call(null,seq29257);
var G__29259 = cljs.core.first.call(null,seq29257__$1);
var seq29257__$2 = cljs.core.next.call(null,seq29257__$1);
var G__29260 = cljs.core.first.call(null,seq29257__$2);
var seq29257__$3 = cljs.core.next.call(null,seq29257__$2);
return cljs.core$macros.dotimes.cljs$core$IFn$_invoke$arity$variadic(G__29258,G__29259,G__29260,seq29257__$3);
});

cljs.core$macros.dotimes.cljs$lang$macro = true;
/**
 * Throws an exception if the given option map contains keys not listed
 *   as valid, else returns nil.
 */
cljs.core$macros.check_valid_options = (function cljs$core$macros$check_valid_options(var_args){
var args__23989__auto__ = [];
var len__23982__auto___29267 = arguments.length;
var i__23983__auto___29268 = (0);
while(true){
if((i__23983__auto___29268 < len__23982__auto___29267)){
args__23989__auto__.push((arguments[i__23983__auto___29268]));

var G__29269 = (i__23983__auto___29268 + (1));
i__23983__auto___29268 = G__29269;
continue;
} else {
}
break;
}

var argseq__23990__auto__ = ((((1) < args__23989__auto__.length))?(new cljs.core.IndexedSeq(args__23989__auto__.slice((1)),(0),null)):null);
return cljs.core$macros.check_valid_options.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),argseq__23990__auto__);
});

cljs.core$macros.check_valid_options.cljs$core$IFn$_invoke$arity$variadic = (function (options,valid_keys){
if(cljs.core.seq.call(null,cljs.core.apply.call(null,cljs.core.disj,cljs.core.apply.call(null,cljs.core.hash_set,cljs.core.keys.call(null,options)),valid_keys))){
throw cljs.core.apply.call(null,cljs.core.str,"Only these options are valid: ",cljs.core.first.call(null,valid_keys),cljs.core.map.call(null,(function (p1__29264_SHARP_){
return [cljs.core.str(", "),cljs.core.str(p1__29264_SHARP_)].join('');
}),cljs.core.rest.call(null,valid_keys)));
} else {
return null;
}
});

cljs.core$macros.check_valid_options.cljs$lang$maxFixedArity = (1);

cljs.core$macros.check_valid_options.cljs$lang$applyTo = (function (seq29265){
var G__29266 = cljs.core.first.call(null,seq29265);
var seq29265__$1 = cljs.core.next.call(null,seq29265);
return cljs.core$macros.check_valid_options.cljs$core$IFn$_invoke$arity$variadic(G__29266,seq29265__$1);
});
/**
 * Creates a new multimethod with the associated dispatch function.
 *   The docstring and attribute-map are optional.
 * 
 *   Options are key-value pairs and may be one of:
 *  :default    the default dispatch value, defaults to :default
 *  :hierarchy  the isa? hierarchy to use for dispatching
 *              defaults to the global hierarchy
 */
cljs.core$macros.defmulti = (function cljs$core$macros$defmulti(var_args){
var args__23989__auto__ = [];
var len__23982__auto___29279 = arguments.length;
var i__23983__auto___29280 = (0);
while(true){
if((i__23983__auto___29280 < len__23982__auto___29279)){
args__23989__auto__.push((arguments[i__23983__auto___29280]));

var G__29281 = (i__23983__auto___29280 + (1));
i__23983__auto___29280 = G__29281;
continue;
} else {
}
break;
}

var argseq__23990__auto__ = ((((3) < args__23989__auto__.length))?(new cljs.core.IndexedSeq(args__23989__auto__.slice((3)),(0),null)):null);
return cljs.core$macros.defmulti.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),argseq__23990__auto__);
});

cljs.core$macros.defmulti.cljs$core$IFn$_invoke$arity$variadic = (function (_AMPERSAND_form,_AMPERSAND_env,mm_name,options){
var docstring = ((typeof cljs.core.first.call(null,options) === 'string')?cljs.core.first.call(null,options):null);
var options__$1 = ((typeof cljs.core.first.call(null,options) === 'string')?cljs.core.next.call(null,options):options);
var m = ((cljs.core.map_QMARK_.call(null,cljs.core.first.call(null,options__$1)))?cljs.core.first.call(null,options__$1):cljs.core.PersistentArrayMap.EMPTY);
var options__$2 = ((cljs.core.map_QMARK_.call(null,cljs.core.first.call(null,options__$1)))?cljs.core.next.call(null,options__$1):options__$1);
var dispatch_fn = cljs.core.first.call(null,options__$2);
var options__$3 = cljs.core.next.call(null,options__$2);
var m__$1 = (cljs.core.truth_(docstring)?cljs.core.assoc.call(null,m,new cljs.core.Keyword(null,"doc","doc",1913296891),docstring):m);
var m__$2 = (cljs.core.truth_(cljs.core.meta.call(null,mm_name))?cljs.core.conj.call(null,cljs.core.meta.call(null,mm_name),m__$1):m__$1);
var mm_ns = [cljs.core.str(new cljs.core.Keyword(null,"name","name",1843675177).cljs$core$IFn$_invoke$arity$1(new cljs.core.Keyword(null,"ns","ns",441598760).cljs$core$IFn$_invoke$arity$1(_AMPERSAND_env)))].join('');
if(cljs.core._EQ_.call(null,cljs.core.count.call(null,options__$3),(1))){
throw (new Error("The syntax for defmulti has changed. Example: (defmulti name dispatch-fn :default dispatch-value)"));
} else {
}

var options__$4 = cljs.core.apply.call(null,cljs.core.hash_map,options__$3);
var default$ = cljs.core.get.call(null,options__$4,new cljs.core.Keyword(null,"default","default",-1987822328),new cljs.core.Keyword(null,"default","default",-1987822328));
cljs.core$macros.check_valid_options.call(null,options__$4,new cljs.core.Keyword(null,"default","default",-1987822328),new cljs.core.Keyword(null,"hierarchy","hierarchy",-1053470341));

return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","defonce","cljs.core$macros/defonce",-1096231613,null)),(function (){var x__23746__auto__ = cljs.core.with_meta.call(null,mm_name,m__$2);
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","let","cljs.core$macros/let",-160286726,null)),(function (){var x__23746__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"method-table__29270__auto__","method-table__29270__auto__",751828027,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","atom","cljs.core/atom",1943839529,null)),(function (){var x__23746__auto__ = cljs.core.apply.call(null,cljs.core.array_map,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"prefer-table__29271__auto__","prefer-table__29271__auto__",321027517,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","atom","cljs.core/atom",1943839529,null)),(function (){var x__23746__auto__ = cljs.core.apply.call(null,cljs.core.array_map,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"method-cache__29272__auto__","method-cache__29272__auto__",1741569186,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","atom","cljs.core/atom",1943839529,null)),(function (){var x__23746__auto__ = cljs.core.apply.call(null,cljs.core.array_map,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"cached-hierarchy__29273__auto__","cached-hierarchy__29273__auto__",-1472046074,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","atom","cljs.core/atom",1943839529,null)),(function (){var x__23746__auto__ = cljs.core.apply.call(null,cljs.core.array_map,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"hierarchy__29274__auto__","hierarchy__29274__auto__",-2109759226,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","get","cljs.core/get",-296075407,null)),(function (){var x__23746__auto__ = options__$4;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Keyword(null,"hierarchy","hierarchy",-1053470341)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","get-global-hierarchy","cljs.core/get-global-hierarchy",48052871,null)))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})()))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","MultiFn.","cljs.core/MultiFn.",1073941573,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","symbol","cljs.core/symbol",195265748,null)),(function (){var x__23746__auto__ = mm_ns;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.name.call(null,mm_name);
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = dispatch_fn;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = default$;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"hierarchy__29274__auto__","hierarchy__29274__auto__",-2109759226,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"method-table__29270__auto__","method-table__29270__auto__",751828027,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"prefer-table__29271__auto__","prefer-table__29271__auto__",321027517,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"method-cache__29272__auto__","method-cache__29272__auto__",1741569186,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"cached-hierarchy__29273__auto__","cached-hierarchy__29273__auto__",-1472046074,null)))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
});

cljs.core$macros.defmulti.cljs$lang$maxFixedArity = (3);

cljs.core$macros.defmulti.cljs$lang$applyTo = (function (seq29275){
var G__29276 = cljs.core.first.call(null,seq29275);
var seq29275__$1 = cljs.core.next.call(null,seq29275);
var G__29277 = cljs.core.first.call(null,seq29275__$1);
var seq29275__$2 = cljs.core.next.call(null,seq29275__$1);
var G__29278 = cljs.core.first.call(null,seq29275__$2);
var seq29275__$3 = cljs.core.next.call(null,seq29275__$2);
return cljs.core$macros.defmulti.cljs$core$IFn$_invoke$arity$variadic(G__29276,G__29277,G__29278,seq29275__$3);
});

cljs.core$macros.defmulti.cljs$lang$macro = true;
/**
 * Creates and installs a new method of multimethod associated with dispatch-value. 
 */
cljs.core$macros.defmethod = (function cljs$core$macros$defmethod(var_args){
var args__23989__auto__ = [];
var len__23982__auto___29287 = arguments.length;
var i__23983__auto___29288 = (0);
while(true){
if((i__23983__auto___29288 < len__23982__auto___29287)){
args__23989__auto__.push((arguments[i__23983__auto___29288]));

var G__29289 = (i__23983__auto___29288 + (1));
i__23983__auto___29288 = G__29289;
continue;
} else {
}
break;
}

var argseq__23990__auto__ = ((((4) < args__23989__auto__.length))?(new cljs.core.IndexedSeq(args__23989__auto__.slice((4)),(0),null)):null);
return cljs.core$macros.defmethod.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]),argseq__23990__auto__);
});

cljs.core$macros.defmethod.cljs$core$IFn$_invoke$arity$variadic = (function (_AMPERSAND_form,_AMPERSAND_env,multifn,dispatch_val,fn_tail){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","-add-method","cljs.core/-add-method",571092113,null)),(function (){var x__23746__auto__ = cljs.core.with_meta.call(null,multifn,new cljs.core.PersistentArrayMap(null, 1, [new cljs.core.Keyword(null,"tag","tag",-1290361223),new cljs.core.Symbol("cljs.core","MultiFn","cljs.core/MultiFn",1487419554,null)], null));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = dispatch_val;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","fn","cljs.core$macros/fn",-187522821,null)),fn_tail)));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
});

cljs.core$macros.defmethod.cljs$lang$maxFixedArity = (4);

cljs.core$macros.defmethod.cljs$lang$applyTo = (function (seq29282){
var G__29283 = cljs.core.first.call(null,seq29282);
var seq29282__$1 = cljs.core.next.call(null,seq29282);
var G__29284 = cljs.core.first.call(null,seq29282__$1);
var seq29282__$2 = cljs.core.next.call(null,seq29282__$1);
var G__29285 = cljs.core.first.call(null,seq29282__$2);
var seq29282__$3 = cljs.core.next.call(null,seq29282__$2);
var G__29286 = cljs.core.first.call(null,seq29282__$3);
var seq29282__$4 = cljs.core.next.call(null,seq29282__$3);
return cljs.core$macros.defmethod.cljs$core$IFn$_invoke$arity$variadic(G__29283,G__29284,G__29285,G__29286,seq29282__$4);
});

cljs.core$macros.defmethod.cljs$lang$macro = true;
/**
 * Evaluates expr and prints the time it took. Returns the value of expr.
 */
cljs.core$macros.time = (function cljs$core$macros$time(_AMPERSAND_form,_AMPERSAND_env,expr){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","let","cljs.core$macros/let",-160286726,null)),(function (){var x__23746__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"start__29290__auto__","start__29290__auto__",2133457676,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","system-time","cljs.core/system-time",1562011930,null)))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"ret__29291__auto__","ret__29291__auto__",-1107892640,null)),(function (){var x__23746__auto__ = expr;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})()))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","prn","cljs.core/prn",1725204552,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","str","cljs.core/str",-1971828991,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,"Elapsed time: "),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,".toFixed",".toFixed",-895046938,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","-","cljs.core$macros/-",13526976,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","system-time","cljs.core/system-time",1562011930,null)))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"start__29290__auto__","start__29290__auto__",2133457676,null)))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,(6)))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY," msecs"))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"ret__29291__auto__","ret__29291__auto__",-1107892640,null)))));
});

cljs.core$macros.time.cljs$lang$macro = true;
/**
 * Runs expr iterations times in the context of a let expression with
 *   the given bindings, then prints out the bindings and the expr
 *   followed by number of iterations and total time. The optional
 *   argument print-fn, defaulting to println, sets function used to
 *   print the result. expr's string representation will be produced
 *   using pr-str in any case.
 */
cljs.core$macros.simple_benchmark = (function cljs$core$macros$simple_benchmark(var_args){
var args__23989__auto__ = [];
var len__23982__auto___29306 = arguments.length;
var i__23983__auto___29307 = (0);
while(true){
if((i__23983__auto___29307 < len__23982__auto___29306)){
args__23989__auto__.push((arguments[i__23983__auto___29307]));

var G__29308 = (i__23983__auto___29307 + (1));
i__23983__auto___29307 = G__29308;
continue;
} else {
}
break;
}

var argseq__23990__auto__ = ((((5) < args__23989__auto__.length))?(new cljs.core.IndexedSeq(args__23989__auto__.slice((5)),(0),null)):null);
return cljs.core$macros.simple_benchmark.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]),(arguments[(4)]),argseq__23990__auto__);
});

cljs.core$macros.simple_benchmark.cljs$core$IFn$_invoke$arity$variadic = (function (_AMPERSAND_form,_AMPERSAND_env,bindings,expr,iterations,p__29303){
var map__29304 = p__29303;
var map__29304__$1 = ((((!((map__29304 == null)))?((((map__29304.cljs$lang$protocol_mask$partition0$ & (64))) || (map__29304.cljs$core$ISeq$))?true:false):false))?cljs.core.apply.call(null,cljs.core.hash_map,map__29304):map__29304);
var print_fn = cljs.core.get.call(null,map__29304__$1,new cljs.core.Keyword(null,"print-fn","print-fn",-1720960489),new cljs.core.Symbol(null,"println","println",-733595439,null));
var bs_str = cljs.core.pr_str.call(null,bindings);
var expr_str = cljs.core.pr_str.call(null,expr);
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","let","cljs.core$macros/let",-160286726,null)),(function (){var x__23746__auto__ = bindings;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","let","cljs.core$macros/let",-160286726,null)),(function (){var x__23746__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"start__29292__auto__","start__29292__auto__",-2087439511,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,".getTime",".getTime",-1048557777,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("js","Date.","js/Date.",384205255,null)))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"ret__29293__auto__","ret__29293__auto__",1403172492,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","dotimes","cljs.core$macros/dotimes",-1407597661,null)),(function (){var x__23746__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"___29294__auto__","___29294__auto__",-512423939,null)),(function (){var x__23746__auto__ = iterations;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})()))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = expr;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"end__29295__auto__","end__29295__auto__",2051050657,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,".getTime",".getTime",-1048557777,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("js","Date.","js/Date.",384205255,null)))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"elapsed__29296__auto__","elapsed__29296__auto__",-322230105,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","-","cljs.core$macros/-",13526976,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"end__29295__auto__","end__29295__auto__",2051050657,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"start__29292__auto__","start__29292__auto__",-2087439511,null)))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})()))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,(function (){var x__23746__auto__ = print_fn;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","str","cljs.core$macros/str",-2019499702,null)),(function (){var x__23746__auto__ = bs_str;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,", "),(function (){var x__23746__auto__ = expr_str;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,", "),(function (){var x__23746__auto__ = iterations;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY," runs, "),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"elapsed__29296__auto__","elapsed__29296__auto__",-322230105,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY," msecs"))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
});

cljs.core$macros.simple_benchmark.cljs$lang$maxFixedArity = (5);

cljs.core$macros.simple_benchmark.cljs$lang$applyTo = (function (seq29297){
var G__29298 = cljs.core.first.call(null,seq29297);
var seq29297__$1 = cljs.core.next.call(null,seq29297);
var G__29299 = cljs.core.first.call(null,seq29297__$1);
var seq29297__$2 = cljs.core.next.call(null,seq29297__$1);
var G__29300 = cljs.core.first.call(null,seq29297__$2);
var seq29297__$3 = cljs.core.next.call(null,seq29297__$2);
var G__29301 = cljs.core.first.call(null,seq29297__$3);
var seq29297__$4 = cljs.core.next.call(null,seq29297__$3);
var G__29302 = cljs.core.first.call(null,seq29297__$4);
var seq29297__$5 = cljs.core.next.call(null,seq29297__$4);
return cljs.core$macros.simple_benchmark.cljs$core$IFn$_invoke$arity$variadic(G__29298,G__29299,G__29300,G__29301,G__29302,seq29297__$5);
});

cljs.core$macros.simple_benchmark.cljs$lang$macro = true;
cljs.core$macros.cs = cljs.core.into.call(null,cljs.core.PersistentVector.EMPTY,cljs.core.map.call(null,cljs.core.comp.call(null,cljs.core.gensym,cljs.core.str,cljs.core.char$),cljs.core.range.call(null,(97),(118))));
cljs.core$macros.gen_apply_to_helper = (function cljs$core$macros$gen_apply_to_helper(var_args){
var args29309 = [];
var len__23982__auto___29312 = arguments.length;
var i__23983__auto___29313 = (0);
while(true){
if((i__23983__auto___29313 < len__23982__auto___29312)){
args29309.push((arguments[i__23983__auto___29313]));

var G__29314 = (i__23983__auto___29313 + (1));
i__23983__auto___29313 = G__29314;
continue;
} else {
}
break;
}

var G__29311 = args29309.length;
switch (G__29311) {
case 0:
return cljs.core$macros.gen_apply_to_helper.cljs$core$IFn$_invoke$arity$0();

break;
case 1:
return cljs.core$macros.gen_apply_to_helper.cljs$core$IFn$_invoke$arity$1((arguments[(0)]));

break;
default:
throw (new Error([cljs.core.str("Invalid arity: "),cljs.core.str(args29309.length)].join('')));

}
});

cljs.core$macros.gen_apply_to_helper.cljs$core$IFn$_invoke$arity$0 = (function (){
return cljs.core$macros.gen_apply_to_helper.call(null,(1));
});

cljs.core$macros.gen_apply_to_helper.cljs$core$IFn$_invoke$arity$1 = (function (n){
var prop = cljs.core.symbol.call(null,[cljs.core.str("-cljs$core$IFn$_invoke$arity$"),cljs.core.str(n)].join(''));
var f = cljs.core.symbol.call(null,[cljs.core.str("cljs$core$IFn$_invoke$arity$"),cljs.core.str(n)].join(''));
if((n <= (20))){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","let","cljs.core$macros/let",-160286726,null)),(function (){var x__23746__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,(function (){var x__23746__auto__ = cljs.core$macros.cs.call(null,(n - (1)));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","-first","cljs.core/-first",545297391,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"args","args",-1338879193,null)))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"args","args",-1338879193,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","-rest","cljs.core/-rest",-1829241664,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"args","args",-1338879193,null)))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})()))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"if","if",1181717262,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","==","cljs.core$macros/==",-818551413,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"argc","argc",187692008,null)),(function (){var x__23746__auto__ = n;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"if","if",1181717262,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,".",".",1975675962,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"f","f",43394975,null)),(function (){var x__23746__auto__ = prop;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,".",".",1975675962,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"f","f",43394975,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,(function (){var x__23746__auto__ = f;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),cljs.core.take.call(null,n,cljs.core$macros.cs))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"f","f",43394975,null)),cljs.core.take.call(null,n,cljs.core$macros.cs))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core$macros.gen_apply_to_helper.call(null,(n + (1)));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
} else {
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"throw","throw",595905694,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("js","Error.","js/Error.",750655924,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,"Only up to 20 arguments supported on functions"))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
}
});

cljs.core$macros.gen_apply_to_helper.cljs$lang$maxFixedArity = 1;
cljs.core$macros.gen_apply_to = (function cljs$core$macros$gen_apply_to(_AMPERSAND_form,_AMPERSAND_env){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"do","do",1686842252,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"set!","set!",250714521,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"*unchecked-if*","*unchecked-if*",1542408350,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,true))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","defn","cljs.core$macros/defn",-728332354,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"apply-to","apply-to",-1858571928,null)),(function (){var x__23746__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"f","f",43394975,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"argc","argc",187692008,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"args","args",-1338879193,null))))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","let","cljs.core$macros/let",-160286726,null)),(function (){var x__23746__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"args","args",-1338879193,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","seq","cljs.core/seq",-1649497689,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"args","args",-1338879193,null)))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})()))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"if","if",1181717262,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","zero?","cljs.core$macros/zero?",-65998367,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"argc","argc",187692008,null)))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"f","f",43394975,null)))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core$macros.gen_apply_to_helper.call(null);
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"set!","set!",250714521,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"*unchecked-if*","*unchecked-if*",1542408350,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,false))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
});

cljs.core$macros.gen_apply_to.cljs$lang$macro = true;
/**
 * Evaluates exprs in a context in which *print-fn* is bound to .append
 *   on a fresh StringBuffer.  Returns the string created by any nested
 *   printing calls.
 */
cljs.core$macros.with_out_str = (function cljs$core$macros$with_out_str(var_args){
var args__23989__auto__ = [];
var len__23982__auto___29321 = arguments.length;
var i__23983__auto___29322 = (0);
while(true){
if((i__23983__auto___29322 < len__23982__auto___29321)){
args__23989__auto__.push((arguments[i__23983__auto___29322]));

var G__29323 = (i__23983__auto___29322 + (1));
i__23983__auto___29322 = G__29323;
continue;
} else {
}
break;
}

var argseq__23990__auto__ = ((((2) < args__23989__auto__.length))?(new cljs.core.IndexedSeq(args__23989__auto__.slice((2)),(0),null)):null);
return cljs.core$macros.with_out_str.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__23990__auto__);
});

cljs.core$macros.with_out_str.cljs$core$IFn$_invoke$arity$variadic = (function (_AMPERSAND_form,_AMPERSAND_env,body){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","let","cljs.core$macros/let",-160286726,null)),(function (){var x__23746__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"sb__29316__auto__","sb__29316__auto__",-1747738980,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("js","goog.string.StringBuffer.","js/goog.string.StringBuffer.",-1043451650,null)))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})()))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","binding","cljs.core$macros/binding",1855847304,null)),(function (){var x__23746__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","*print-newline*","cljs.core/*print-newline*",6231625,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,true),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","*print-fn*","cljs.core/*print-fn*",1342365176,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","fn","cljs.core$macros/fn",-187522821,null)),(function (){var x__23746__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"x__29317__auto__","x__29317__auto__",951923363,null))))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,".append",".append",1595439852,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"sb__29316__auto__","sb__29316__auto__",-1747738980,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"x__29317__auto__","x__29317__auto__",951923363,null)))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})()))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),body)));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","str","cljs.core/str",-1971828991,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"sb__29316__auto__","sb__29316__auto__",-1747738980,null)))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
});

cljs.core$macros.with_out_str.cljs$lang$maxFixedArity = (2);

cljs.core$macros.with_out_str.cljs$lang$applyTo = (function (seq29318){
var G__29319 = cljs.core.first.call(null,seq29318);
var seq29318__$1 = cljs.core.next.call(null,seq29318);
var G__29320 = cljs.core.first.call(null,seq29318__$1);
var seq29318__$2 = cljs.core.next.call(null,seq29318__$1);
return cljs.core$macros.with_out_str.cljs$core$IFn$_invoke$arity$variadic(G__29319,G__29320,seq29318__$2);
});

cljs.core$macros.with_out_str.cljs$lang$macro = true;
/**
 * Expands to code which yields a lazy sequence of the concatenation
 *   of the supplied colls.  Each coll expr is not evaluated until it is
 *   needed.
 * 
 *   (lazy-cat xs ys zs) === (concat (lazy-seq xs) (lazy-seq ys) (lazy-seq zs))
 */
cljs.core$macros.lazy_cat = (function cljs$core$macros$lazy_cat(var_args){
var args__23989__auto__ = [];
var len__23982__auto___29328 = arguments.length;
var i__23983__auto___29329 = (0);
while(true){
if((i__23983__auto___29329 < len__23982__auto___29328)){
args__23989__auto__.push((arguments[i__23983__auto___29329]));

var G__29330 = (i__23983__auto___29329 + (1));
i__23983__auto___29329 = G__29330;
continue;
} else {
}
break;
}

var argseq__23990__auto__ = ((((2) < args__23989__auto__.length))?(new cljs.core.IndexedSeq(args__23989__auto__.slice((2)),(0),null)):null);
return cljs.core$macros.lazy_cat.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__23990__auto__);
});

cljs.core$macros.lazy_cat.cljs$core$IFn$_invoke$arity$variadic = (function (_AMPERSAND_form,_AMPERSAND_env,colls){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","concat","cljs.core/concat",-1133584918,null)),cljs.core.map.call(null,(function (p1__29324_SHARP_){
return cljs.core._conj.call(null,(function (){var x__23746__auto__ = p1__29324_SHARP_;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),new cljs.core.Symbol("cljs.core$macros","lazy-seq","cljs.core$macros/lazy-seq",806482650,null));
}),colls))));
});

cljs.core$macros.lazy_cat.cljs$lang$maxFixedArity = (2);

cljs.core$macros.lazy_cat.cljs$lang$applyTo = (function (seq29325){
var G__29326 = cljs.core.first.call(null,seq29325);
var seq29325__$1 = cljs.core.next.call(null,seq29325);
var G__29327 = cljs.core.first.call(null,seq29325__$1);
var seq29325__$2 = cljs.core.next.call(null,seq29325__$1);
return cljs.core$macros.lazy_cat.cljs$core$IFn$_invoke$arity$variadic(G__29326,G__29327,seq29325__$2);
});

cljs.core$macros.lazy_cat.cljs$lang$macro = true;
cljs.core$macros.js_str = (function cljs$core$macros$js_str(_AMPERSAND_form,_AMPERSAND_env,s){
return cljs.core._conj.call(null,cljs.core._conj.call(null,(function (){var x__23746__auto__ = s;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),"''+~{}"),new cljs.core.Symbol(null,"js*","js*",-1134233646,null));
});

cljs.core$macros.js_str.cljs$lang$macro = true;
cljs.core$macros.es6_iterable = (function cljs$core$macros$es6_iterable(_AMPERSAND_form,_AMPERSAND_env,ty){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","aset","cljs.core$macros/aset",-693176374,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,".-prototype",".-prototype",-1562038608,null)),(function (){var x__23746__auto__ = ty;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","ITER_SYMBOL","cljs.core/ITER_SYMBOL",-2091399233,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","fn","cljs.core$macros/fn",-187522821,null)),(function (){var x__23746__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","this-as","cljs.core$macros/this-as",-799075148,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"this__29331__auto__","this__29331__auto__",-1724905564,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","es6-iterator","cljs.core/es6-iterator",856007913,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"this__29331__auto__","this__29331__auto__",-1724905564,null)))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
});

cljs.core$macros.es6_iterable.cljs$lang$macro = true;
/**
 * Returns a map of the intern mappings for the namespace.
 */
cljs.core$macros.ns_interns = (function cljs$core$macros$ns_interns(_AMPERSAND_form,_AMPERSAND_env,p__29332){
var vec__29338 = p__29332;
var quote = cljs.core.nth.call(null,vec__29338,(0),null);
var ns = cljs.core.nth.call(null,vec__29338,(1),null);
if((cljs.core._EQ_.call(null,quote,new cljs.core.Symbol(null,"quote","quote",1377916282,null))) && ((ns instanceof cljs.core.Symbol))){
} else {
throw (new Error([cljs.core.str("Assert failed: "),cljs.core.str("Argument to ns-interns must be a quoted symbol"),cljs.core.str("\n"),cljs.core.str("(core/and (= quote (quote quote)) (core/symbol? ns))")].join('')));
}

return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","into","cljs.core/into",1879938733,null)),(function (){var x__23746__auto__ = cljs.core.apply.call(null,cljs.core.array_map,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core.map.call(null,((function (vec__29338,quote,ns){
return (function (p__29341){
var vec__29342 = p__29341;
var sym = cljs.core.nth.call(null,vec__29342,(0),null);
var _ = cljs.core.nth.call(null,vec__29342,(1),null);
return cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","symbol","cljs.core/symbol",195265748,null)),(function (){var x__23746__auto__ = cljs.core.name.call(null,sym);
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"var","var",870848730,null)),(function (){var x__23746__auto__ = cljs.core.symbol.call(null,cljs.core.name.call(null,ns),cljs.core.name.call(null,sym));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})()))));
});})(vec__29338,quote,ns))
,cljs.core.get_in.call(null,cljs.core.deref.call(null,cljs.env._STAR_compiler_STAR_),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword("cljs.analyzer","namespaces","cljs.analyzer/namespaces",-260788927),ns,new cljs.core.Keyword(null,"defs","defs",1398449717)], null)))))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
});

cljs.core$macros.ns_interns.cljs$lang$macro = true;
/**
 * Removes the mappings for the symbol from the namespace.
 */
cljs.core$macros.ns_unmap = (function cljs$core$macros$ns_unmap(_AMPERSAND_form,_AMPERSAND_env,p__29343,p__29344){
var vec__29347 = p__29343;
var quote0 = cljs.core.nth.call(null,vec__29347,(0),null);
var ns = cljs.core.nth.call(null,vec__29347,(1),null);
var vec__29348 = p__29344;
var quote1 = cljs.core.nth.call(null,vec__29348,(0),null);
var sym = cljs.core.nth.call(null,vec__29348,(1),null);
if((cljs.core._EQ_.call(null,quote0,new cljs.core.Symbol(null,"quote","quote",1377916282,null))) && ((ns instanceof cljs.core.Symbol)) && (cljs.core._EQ_.call(null,quote1,new cljs.core.Symbol(null,"quote","quote",1377916282,null))) && ((sym instanceof cljs.core.Symbol))){
} else {
throw (new Error([cljs.core.str("Assert failed: "),cljs.core.str("Arguments to ns-unmap must be quoted symbols"),cljs.core.str("\n"),cljs.core.str("(core/and (= quote0 (quote quote)) (core/symbol? ns) (= quote1 (quote quote)) (core/symbol? sym))")].join('')));
}

cljs.core.swap_BANG_.call(null,cljs.env._STAR_compiler_STAR_,cljs.core.update_in,new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword("cljs.analyzer","namespaces","cljs.analyzer/namespaces",-260788927),ns,new cljs.core.Keyword(null,"defs","defs",1398449717)], null),cljs.core.dissoc,sym);

return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","js-delete","cljs.core$macros/js-delete",387769082,null)),(function (){var x__23746__auto__ = cljs.compiler.munge.call(null,ns);
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.compiler.munge.call(null,[cljs.core.str(sym)].join(''));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
});

cljs.core$macros.ns_unmap.cljs$lang$macro = true;
/**
 * Non-atomically swaps the value of the volatile as if:
 * (apply f current-value-of-vol args). Returns the value that
 * was swapped in.
 */
cljs.core$macros.vswap_BANG_ = (function cljs$core$macros$vswap_BANG_(var_args){
var args__23989__auto__ = [];
var len__23982__auto___29354 = arguments.length;
var i__23983__auto___29355 = (0);
while(true){
if((i__23983__auto___29355 < len__23982__auto___29354)){
args__23989__auto__.push((arguments[i__23983__auto___29355]));

var G__29356 = (i__23983__auto___29355 + (1));
i__23983__auto___29355 = G__29356;
continue;
} else {
}
break;
}

var argseq__23990__auto__ = ((((4) < args__23989__auto__.length))?(new cljs.core.IndexedSeq(args__23989__auto__.slice((4)),(0),null)):null);
return cljs.core$macros.vswap_BANG_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]),argseq__23990__auto__);
});

cljs.core$macros.vswap_BANG_.cljs$core$IFn$_invoke$arity$variadic = (function (_AMPERSAND_form,_AMPERSAND_env,vol,f,args){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","-vreset!","cljs.core/-vreset!",-1186516972,null)),(function (){var x__23746__auto__ = vol;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,(function (){var x__23746__auto__ = f;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","-deref","cljs.core/-deref",-1260480154,null)),(function (){var x__23746__auto__ = vol;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),args)));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
});

cljs.core$macros.vswap_BANG_.cljs$lang$maxFixedArity = (4);

cljs.core$macros.vswap_BANG_.cljs$lang$applyTo = (function (seq29349){
var G__29350 = cljs.core.first.call(null,seq29349);
var seq29349__$1 = cljs.core.next.call(null,seq29349);
var G__29351 = cljs.core.first.call(null,seq29349__$1);
var seq29349__$2 = cljs.core.next.call(null,seq29349__$1);
var G__29352 = cljs.core.first.call(null,seq29349__$2);
var seq29349__$3 = cljs.core.next.call(null,seq29349__$2);
var G__29353 = cljs.core.first.call(null,seq29349__$3);
var seq29349__$4 = cljs.core.next.call(null,seq29349__$3);
return cljs.core$macros.vswap_BANG_.cljs$core$IFn$_invoke$arity$variadic(G__29350,G__29351,G__29352,G__29353,seq29349__$4);
});

cljs.core$macros.vswap_BANG_.cljs$lang$macro = true;
cljs.core$macros.load_file_STAR_ = (function cljs$core$macros$load_file_STAR_(_AMPERSAND_form,_AMPERSAND_env,f){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,".",".",1975675962,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("js","goog","js/goog",-70605150,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"nodeGlobalRequire","nodeGlobalRequire",167018599,null)),(function (){var x__23746__auto__ = f;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
});

cljs.core$macros.load_file_STAR_.cljs$lang$macro = true;
/**
 * If form represents a macro form, returns its expansion,
 *   else returns form.
 */
cljs.core$macros.macroexpand_1 = (function cljs$core$macros$macroexpand_1(_AMPERSAND_form,_AMPERSAND_env,quoted){
if(cljs.core._EQ_.call(null,cljs.core.first.call(null,quoted),new cljs.core.Symbol(null,"quote","quote",1377916282,null))){
} else {
throw (new Error([cljs.core.str("Assert failed: "),cljs.core.str("Argument to macroexpand-1 must be quoted"),cljs.core.str("\n"),cljs.core.str("(core/= (core/first quoted) (quote quote))")].join('')));
}

var form = cljs.core.second.call(null,quoted);
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"quote","quote",1377916282,null)),(function (){var x__23746__auto__ = cljs.analyzer.macroexpand_1.call(null,_AMPERSAND_env,form);
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
});

cljs.core$macros.macroexpand_1.cljs$lang$macro = true;
/**
 * Repeatedly calls macroexpand-1 on form until it no longer
 *   represents a macro form, then returns it.  Note neither
 *   macroexpand-1 nor macroexpand expand macros in subforms.
 */
cljs.core$macros.macroexpand = (function cljs$core$macros$macroexpand(_AMPERSAND_form,_AMPERSAND_env,quoted){
if(cljs.core._EQ_.call(null,cljs.core.first.call(null,quoted),new cljs.core.Symbol(null,"quote","quote",1377916282,null))){
} else {
throw (new Error([cljs.core.str("Assert failed: "),cljs.core.str("Argument to macroexpand must be quoted"),cljs.core.str("\n"),cljs.core.str("(core/= (core/first quoted) (quote quote))")].join('')));
}

var form = cljs.core.second.call(null,quoted);
var env = _AMPERSAND_env;
var form__$1 = form;
var form_SINGLEQUOTE_ = cljs.analyzer.macroexpand_1.call(null,env,form__$1);
while(true){
if(!((form__$1 === form_SINGLEQUOTE_))){
var G__29357 = form_SINGLEQUOTE_;
var G__29358 = cljs.analyzer.macroexpand_1.call(null,env,form_SINGLEQUOTE_);
form__$1 = G__29357;
form_SINGLEQUOTE_ = G__29358;
continue;
} else {
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"quote","quote",1377916282,null)),(function (){var x__23746__auto__ = form_SINGLEQUOTE_;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
}
break;
}
});

cljs.core$macros.macroexpand.cljs$lang$macro = true;
cljs.core$macros.multi_arity_fn_QMARK_ = (function cljs$core$macros$multi_arity_fn_QMARK_(fdecl){
return ((1) < cljs.core.count.call(null,fdecl));
});
cljs.core$macros.variadic_fn_QMARK_ = (function cljs$core$macros$variadic_fn_QMARK_(fdecl){
var and__22900__auto__ = cljs.core._EQ_.call(null,(1),cljs.core.count.call(null,fdecl));
if(and__22900__auto__){
return cljs.core.some.call(null,new cljs.core.PersistentHashSet(null, new cljs.core.PersistentArrayMap(null, 1, [new cljs.core.Symbol(null,"&","&",-2144855648,null),null], null), null),cljs.core.ffirst.call(null,fdecl));
} else {
return and__22900__auto__;
}
});
cljs.core$macros.variadic_fn_STAR_ = (function cljs$core$macros$variadic_fn_STAR_(var_args){
var args29359 = [];
var len__23982__auto___29364 = arguments.length;
var i__23983__auto___29365 = (0);
while(true){
if((i__23983__auto___29365 < len__23982__auto___29364)){
args29359.push((arguments[i__23983__auto___29365]));

var G__29366 = (i__23983__auto___29365 + (1));
i__23983__auto___29365 = G__29366;
continue;
} else {
}
break;
}

var G__29361 = args29359.length;
switch (G__29361) {
case 2:
return cljs.core$macros.variadic_fn_STAR_.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core$macros.variadic_fn_STAR_.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error([cljs.core.str("Invalid arity: "),cljs.core.str(args29359.length)].join('')));

}
});

cljs.core$macros.variadic_fn_STAR_.cljs$core$IFn$_invoke$arity$2 = (function (sym,method){
return cljs.core$macros.variadic_fn_STAR_.call(null,sym,method,true);
});

cljs.core$macros.variadic_fn_STAR_.cljs$core$IFn$_invoke$arity$3 = (function (sym,p__29362,solo){
var vec__29363 = p__29362;
var arglist = cljs.core.nth.call(null,vec__29363,(0),null);
var body = cljs.core.nthnext.call(null,vec__29363,(1));
var method = vec__29363;
var sig = cljs.core.remove.call(null,new cljs.core.PersistentHashSet(null, new cljs.core.PersistentArrayMap(null, 1, [new cljs.core.Symbol(null,"&","&",-2144855648,null),null], null), null),arglist);
var restarg = cljs.core.gensym.call(null,"seq");
var get_delegate = ((function (sig,restarg,vec__29363,arglist,body,method){
return (function cljs$core$macros$get_delegate(){
return new cljs.core.Symbol(null,"cljs$core$IFn$_invoke$arity$variadic","cljs$core$IFn$_invoke$arity$variadic",-378825034,null);
});})(sig,restarg,vec__29363,arglist,body,method))
;
var get_delegate_prop = ((function (sig,restarg,vec__29363,arglist,body,method){
return (function cljs$core$macros$get_delegate_prop(){
return cljs.core.symbol.call(null,[cljs.core.str("-"),cljs.core.str(get_delegate.call(null))].join(''));
});})(sig,restarg,vec__29363,arglist,body,method))
;
var param_bind = ((function (sig,restarg,vec__29363,arglist,body,method){
return (function cljs$core$macros$param_bind(param){
return cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,(function (){var x__23746__auto__ = param;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,(function (){var x__23746__auto__ = cljs.core.with_meta.call(null,new cljs.core.Symbol("cljs.core","first","cljs.core/first",-752535972,null),cljs.core.apply.call(null,cljs.core.array_map,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Keyword(null,"file","file",-1269645878)),cljs.core._conj.call(null,cljs.core.List.EMPTY,"/Users/clumsyjedi/workspace/clack/.cljs_node_repl/cljs/core.cljc"),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Keyword(null,"line","line",212345235)),cljs.core._conj.call(null,cljs.core.List.EMPTY,2725),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Keyword(null,"column","column",2078222095)),cljs.core._conj.call(null,cljs.core.List.EMPTY,49),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Keyword(null,"end-line","end-line",1837326455)),cljs.core._conj.call(null,cljs.core.List.EMPTY,2725),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Keyword(null,"end-column","end-column",1425389514)),cljs.core._conj.call(null,cljs.core.List.EMPTY,54),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Keyword("cljs.analyzer","no-resolve","cljs.analyzer/no-resolve",-1872351017)),cljs.core._conj.call(null,cljs.core.List.EMPTY,true))))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = restarg;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = restarg;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,(function (){var x__23746__auto__ = cljs.core.with_meta.call(null,new cljs.core.Symbol("cljs.core","next","cljs.core/next",-1291438473,null),cljs.core.apply.call(null,cljs.core.array_map,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Keyword(null,"file","file",-1269645878)),cljs.core._conj.call(null,cljs.core.List.EMPTY,"/Users/clumsyjedi/workspace/clack/.cljs_node_repl/cljs/core.cljc"),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Keyword(null,"line","line",212345235)),cljs.core._conj.call(null,cljs.core.List.EMPTY,2726),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Keyword(null,"column","column",2078222095)),cljs.core._conj.call(null,cljs.core.List.EMPTY,51),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Keyword(null,"end-line","end-line",1837326455)),cljs.core._conj.call(null,cljs.core.List.EMPTY,2726),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Keyword(null,"end-column","end-column",1425389514)),cljs.core._conj.call(null,cljs.core.List.EMPTY,55),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Keyword("cljs.analyzer","no-resolve","cljs.analyzer/no-resolve",-1872351017)),cljs.core._conj.call(null,cljs.core.List.EMPTY,true))))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = restarg;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})()))));
});})(sig,restarg,vec__29363,arglist,body,method))
;
var apply_to = ((function (sig,restarg,vec__29363,arglist,body,method){
return (function cljs$core$macros$apply_to(){
if(((1) < cljs.core.count.call(null,sig))){
var params = cljs.core.repeatedly.call(null,(cljs.core.count.call(null,sig) - (1)),cljs.core.gensym);
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","fn","cljs.core$macros/fn",-187522821,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,(function (){var x__23746__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,(function (){var x__23746__auto__ = restarg;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})()))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","let","cljs.core$macros/let",-160286726,null)),(function (){var x__23746__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core.mapcat.call(null,param_bind,params)))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,".",".",1975675962,null)),(function (){var x__23746__auto__ = sym;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,(function (){var x__23746__auto__ = get_delegate.call(null);
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),params,(function (){var x__23746__auto__ = restarg;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
} else {
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","fn","cljs.core$macros/fn",-187522821,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,(function (){var x__23746__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,(function (){var x__23746__auto__ = restarg;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})()))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,".",".",1975675962,null)),(function (){var x__23746__auto__ = sym;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,(function (){var x__23746__auto__ = get_delegate.call(null);
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","seq","cljs.core/seq",-1649497689,null)),(function (){var x__23746__auto__ = restarg;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
}
});})(sig,restarg,vec__29363,arglist,body,method))
;
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"do","do",1686842252,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"set!","set!",250714521,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,".",".",1975675962,null)),(function (){var x__23746__auto__ = sym;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = get_delegate_prop.call(null);
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","fn","cljs.core$macros/fn",-187522821,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,(function (){var x__23746__auto__ = cljs.core.vec.call(null,sig);
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),body)));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(cljs.core.truth_(solo)?cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"set!","set!",250714521,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,".",".",1975675962,null)),(function (){var x__23746__auto__ = sym;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"-cljs$lang$maxFixedArity","-cljs$lang$maxFixedArity",-1481434279,null)))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = (cljs.core.count.call(null,sig) - (1));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())))):null),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"set!","set!",250714521,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,".",".",1975675962,null)),(function (){var x__23746__auto__ = sym;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"-cljs$lang$applyTo","-cljs$lang$applyTo",-225535181,null)))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = apply_to.call(null);
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
});

cljs.core$macros.variadic_fn_STAR_.cljs$lang$maxFixedArity = 3;
cljs.core$macros.copy_arguments = (function cljs$core$macros$copy_arguments(_AMPERSAND_form,_AMPERSAND_env,dest){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","let","cljs.core$macros/let",-160286726,null)),(function (){var x__23746__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"len__29368__auto__","len__29368__auto__",-963188240,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","alength","cljs.core$macros/alength",-683052937,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","js-arguments","cljs.core$macros/js-arguments",390128540,null)))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})()))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","loop","cljs.core$macros/loop",1731108390,null)),(function (){var x__23746__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"i__29369__auto__","i__29369__auto__",1406087151,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,(0))))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","when","cljs.core$macros/when",328457725,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","<","cljs.core$macros/<",371512596,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"i__29369__auto__","i__29369__auto__",1406087151,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"len__29368__auto__","len__29368__auto__",-963188240,null)))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,".push",".push",-1497267248,null)),(function (){var x__23746__auto__ = dest;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","aget","cljs.core$macros/aget",1976136178,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","js-arguments","cljs.core$macros/js-arguments",390128540,null)))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"i__29369__auto__","i__29369__auto__",1406087151,null)))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"recur","recur",1202958259,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","inc","cljs.core$macros/inc",876629257,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"i__29369__auto__","i__29369__auto__",1406087151,null)))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
});

cljs.core$macros.copy_arguments.cljs$lang$macro = true;
cljs.core$macros.variadic_fn = (function cljs$core$macros$variadic_fn(name,meta,p__29372){
var vec__29375 = p__29372;
var vec__29376 = cljs.core.nth.call(null,vec__29375,(0),null);
var arglist = cljs.core.nth.call(null,vec__29376,(0),null);
var body = cljs.core.nthnext.call(null,vec__29376,(1));
var method = vec__29376;
var fdecl = vec__29375;
var dest_args = ((function (vec__29375,vec__29376,arglist,body,method,fdecl){
return (function cljs$core$macros$variadic_fn_$_dest_args(c){
return cljs.core.map.call(null,((function (vec__29375,vec__29376,arglist,body,method,fdecl){
return (function (n){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","aget","cljs.core$macros/aget",1976136178,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","js-arguments","cljs.core$macros/js-arguments",390128540,null)))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = n;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
});})(vec__29375,vec__29376,arglist,body,method,fdecl))
,cljs.core.range.call(null,c));
});})(vec__29375,vec__29376,arglist,body,method,fdecl))
;
var rname = cljs.core.symbol.call(null,[cljs.core.str(cljs.analyzer._STAR_cljs_ns_STAR_)].join(''),[cljs.core.str(name)].join(''));
var sig = cljs.core.remove.call(null,new cljs.core.PersistentHashSet(null, new cljs.core.PersistentArrayMap(null, 1, [new cljs.core.Symbol(null,"&","&",-2144855648,null),null], null), null),arglist);
var c_1 = (cljs.core.count.call(null,sig) - (1));
var meta__$1 = cljs.core.assoc.call(null,meta,new cljs.core.Keyword(null,"top-fn","top-fn",-2056129173),new cljs.core.PersistentArrayMap(null, 5, [new cljs.core.Keyword(null,"variadic","variadic",882626057),true,new cljs.core.Keyword(null,"max-fixed-arity","max-fixed-arity",-690205543),c_1,new cljs.core.Keyword(null,"method-params","method-params",-980792179),new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [sig], null),new cljs.core.Keyword(null,"arglists","arglists",1661989754),(function (){var x__23746__auto__ = arglist;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),new cljs.core.Keyword(null,"arglists-meta","arglists-meta",1944829838),cljs.core.doall.call(null,cljs.core.map.call(null,meta,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [arglist], null)))], null));
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"do","do",1686842252,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"def","def",597100991,null)),(function (){var x__23746__auto__ = cljs.core.with_meta.call(null,name,meta__$1);
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","fn","cljs.core$macros/fn",-187522821,null)),(function (){var x__23746__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"var_args","var_args",1214280389,null))))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","let","cljs.core$macros/let",-160286726,null)),(function (){var x__23746__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"args__29370__auto__","args__29370__auto__",-1692959252,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","array","cljs.core$macros/array",49650437,null)))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})()))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","copy-arguments","cljs.core$macros/copy-arguments",-1675962356,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"args__29370__auto__","args__29370__auto__",-1692959252,null)))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","let","cljs.core$macros/let",-160286726,null)),(function (){var x__23746__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"argseq__29371__auto__","argseq__29371__auto__",-203382651,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","when","cljs.core$macros/when",328457725,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","<","cljs.core$macros/<",371512596,null)),(function (){var x__23746__auto__ = c_1;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","alength","cljs.core$macros/alength",-683052937,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"args__29370__auto__","args__29370__auto__",-1692959252,null)))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"new","new",-444906321,null)),(function (){var x__23746__auto__ = cljs.core.with_meta.call(null,new cljs.core.Symbol("cljs.core","IndexedSeq","cljs.core/IndexedSeq",-228688698,null),cljs.core.apply.call(null,cljs.core.array_map,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Keyword(null,"file","file",-1269645878)),cljs.core._conj.call(null,cljs.core.List.EMPTY,"/Users/clumsyjedi/workspace/clack/.cljs_node_repl/cljs/core.cljc"),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Keyword(null,"line","line",212345235)),cljs.core._conj.call(null,cljs.core.List.EMPTY,2773),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Keyword(null,"column","column",2078222095)),cljs.core._conj.call(null,cljs.core.List.EMPTY,55),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Keyword(null,"end-line","end-line",1837326455)),cljs.core._conj.call(null,cljs.core.List.EMPTY,2773),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Keyword(null,"end-column","end-column",1425389514)),cljs.core._conj.call(null,cljs.core.List.EMPTY,75),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Keyword("cljs.analyzer","no-resolve","cljs.analyzer/no-resolve",-1872351017)),cljs.core._conj.call(null,cljs.core.List.EMPTY,true))))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,".slice",".slice",1874048374,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"args__29370__auto__","args__29370__auto__",-1692959252,null)),(function (){var x__23746__auto__ = c_1;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,(0)),cljs.core._conj.call(null,cljs.core.List.EMPTY,null))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})()))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,".",".",1975675962,null)),(function (){var x__23746__auto__ = rname;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"cljs$core$IFn$_invoke$arity$variadic","cljs$core$IFn$_invoke$arity$variadic",-378825034,null)),dest_args.call(null,c_1),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"argseq__29371__auto__","argseq__29371__auto__",-203382651,null)))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core$macros.variadic_fn_STAR_.call(null,rname,method);
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
});
cljs.core$macros.multi_arity_fn = (function cljs$core$macros$multi_arity_fn(name,meta,fdecl){
var dest_args = (function cljs$core$macros$multi_arity_fn_$_dest_args(c){
return cljs.core.map.call(null,(function (n){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","aget","cljs.core$macros/aget",1976136178,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","js-arguments","cljs.core$macros/js-arguments",390128540,null)))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = n;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
}),cljs.core.range.call(null,c));
});
var fixed_arity = (function cljs$core$macros$multi_arity_fn_$_fixed_arity(rname,sig){
var c = cljs.core.count.call(null,sig);
return new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [c,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,".",".",1975675962,null)),(function (){var x__23746__auto__ = rname;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,(function (){var x__23746__auto__ = cljs.core.symbol.call(null,[cljs.core.str("cljs$core$IFn$_invoke$arity$"),cljs.core.str(c)].join(''));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),dest_args.call(null,c))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())))], null);
});
var fn_method = (function cljs$core$macros$multi_arity_fn_$_fn_method(p__29389){
var vec__29391 = p__29389;
var sig = cljs.core.nth.call(null,vec__29391,(0),null);
var body = cljs.core.nthnext.call(null,vec__29391,(1));
var method = vec__29391;
if(cljs.core.truth_(cljs.core.some.call(null,new cljs.core.PersistentHashSet(null, new cljs.core.PersistentArrayMap(null, 1, [new cljs.core.Symbol(null,"&","&",-2144855648,null),null], null), null),sig))){
return cljs.core$macros.variadic_fn_STAR_.call(null,name,method,false);
} else {
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"set!","set!",250714521,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,".",".",1975675962,null)),(function (){var x__23746__auto__ = name;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.symbol.call(null,[cljs.core.str("-cljs$core$IFn$_invoke$arity$"),cljs.core.str(cljs.core.count.call(null,sig))].join(''));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","fn","cljs.core$macros/fn",-187522821,null)),(function (){var x__23746__auto__ = method;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
}
});
var rname = cljs.core.symbol.call(null,[cljs.core.str(cljs.analyzer._STAR_cljs_ns_STAR_)].join(''),[cljs.core.str(name)].join(''));
var arglists = cljs.core.map.call(null,cljs.core.first,fdecl);
var varsig_QMARK_ = ((function (rname,arglists){
return (function (p1__29377_SHARP_){
return cljs.core.some.call(null,new cljs.core.PersistentHashSet(null, new cljs.core.PersistentArrayMap(null, 1, [new cljs.core.Symbol(null,"&","&",-2144855648,null),null], null), null),p1__29377_SHARP_);
});})(rname,arglists))
;
var variadic = cljs.core.boolean$.call(null,cljs.core.some.call(null,varsig_QMARK_,arglists));
var sigs = cljs.core.remove.call(null,varsig_QMARK_,arglists);
var maxfa = cljs.core.apply.call(null,cljs.core.max,cljs.core.concat.call(null,cljs.core.map.call(null,cljs.core.count,sigs),new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [(cljs.core.count.call(null,cljs.core.first.call(null,cljs.core.filter.call(null,varsig_QMARK_,arglists))) - (2))], null)));
var meta__$1 = cljs.core.assoc.call(null,meta,new cljs.core.Keyword(null,"top-fn","top-fn",-2056129173),new cljs.core.PersistentArrayMap(null, 5, [new cljs.core.Keyword(null,"variadic","variadic",882626057),variadic,new cljs.core.Keyword(null,"max-fixed-arity","max-fixed-arity",-690205543),maxfa,new cljs.core.Keyword(null,"method-params","method-params",-980792179),sigs,new cljs.core.Keyword(null,"arglists","arglists",1661989754),arglists,new cljs.core.Keyword(null,"arglists-meta","arglists-meta",1944829838),cljs.core.doall.call(null,cljs.core.map.call(null,meta,arglists))], null));
var args_sym = cljs.core.gensym.call(null,"args");
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"do","do",1686842252,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"def","def",597100991,null)),(function (){var x__23746__auto__ = cljs.core.with_meta.call(null,name,meta__$1);
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","fn","cljs.core$macros/fn",-187522821,null)),(function (){var x__23746__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"var_args","var_args",1214280389,null))))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","let","cljs.core$macros/let",-160286726,null)),(function (){var x__23746__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,(function (){var x__23746__auto__ = args_sym;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","array","cljs.core$macros/array",49650437,null)))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})()))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","copy-arguments","cljs.core$macros/copy-arguments",-1675962356,null)),(function (){var x__23746__auto__ = args_sym;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","case","cljs.core$macros/case",-2131866965,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","alength","cljs.core$macros/alength",-683052937,null)),(function (){var x__23746__auto__ = args_sym;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),cljs.core.mapcat.call(null,((function (rname,arglists,varsig_QMARK_,variadic,sigs,maxfa,meta__$1,args_sym){
return (function (p1__29378_SHARP_){
return fixed_arity.call(null,rname,p1__29378_SHARP_);
});})(rname,arglists,varsig_QMARK_,variadic,sigs,maxfa,meta__$1,args_sym))
,sigs),(function (){var x__23746__auto__ = ((variadic)?cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","let","cljs.core$macros/let",-160286726,null)),(function (){var x__23746__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"argseq__29379__auto__","argseq__29379__auto__",1304666724,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"new","new",-444906321,null)),(function (){var x__23746__auto__ = cljs.core.with_meta.call(null,new cljs.core.Symbol("cljs.core","IndexedSeq","cljs.core/IndexedSeq",-228688698,null),cljs.core.apply.call(null,cljs.core.array_map,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Keyword(null,"file","file",-1269645878)),cljs.core._conj.call(null,cljs.core.List.EMPTY,"/Users/clumsyjedi/workspace/clack/.cljs_node_repl/cljs/core.cljc"),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Keyword(null,"line","line",212345235)),cljs.core._conj.call(null,cljs.core.List.EMPTY,2830),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Keyword(null,"column","column",2078222095)),cljs.core._conj.call(null,cljs.core.List.EMPTY,58),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Keyword(null,"end-line","end-line",1837326455)),cljs.core._conj.call(null,cljs.core.List.EMPTY,2830),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Keyword(null,"end-column","end-column",1425389514)),cljs.core._conj.call(null,cljs.core.List.EMPTY,78),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Keyword("cljs.analyzer","no-resolve","cljs.analyzer/no-resolve",-1872351017)),cljs.core._conj.call(null,cljs.core.List.EMPTY,true))))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,".slice",".slice",1874048374,null)),(function (){var x__23746__auto__ = args_sym;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = maxfa;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,(0)),cljs.core._conj.call(null,cljs.core.List.EMPTY,null))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})()))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,".",".",1975675962,null)),(function (){var x__23746__auto__ = rname;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"cljs$core$IFn$_invoke$arity$variadic","cljs$core$IFn$_invoke$arity$variadic",-378825034,null)),dest_args.call(null,maxfa),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"argseq__29379__auto__","argseq__29379__auto__",1304666724,null)))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})()))):(cljs.core.truth_(new cljs.core.Keyword(null,"macro","macro",-867863404).cljs$core$IFn$_invoke$arity$1(meta__$1))?cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"throw","throw",595905694,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("js","Error.","js/Error.",750655924,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","str","cljs.core$macros/str",-2019499702,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,"Invalid arity: "),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","-","cljs.core$macros/-",13526976,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","alength","cljs.core$macros/alength",-683052937,null)),(function (){var x__23746__auto__ = args_sym;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,(2)))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})()))):cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"throw","throw",595905694,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("js","Error.","js/Error.",750655924,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","str","cljs.core$macros/str",-2019499702,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,"Invalid arity: "),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","alength","cljs.core$macros/alength",-683052937,null)),(function (){var x__23746__auto__ = args_sym;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),cljs.core.map.call(null,fn_method,fdecl),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"set!","set!",250714521,null)),(function (){var x__23746__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,".",".",1975675962,null)),(function (){var x__23746__auto__ = name;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"-cljs$lang$maxFixedArity","-cljs$lang$maxFixedArity",-1481434279,null)))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),(function (){var x__23746__auto__ = maxfa;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})())));
});
/**
 * Same as (def name (core/fn [params* ] exprs*)) or (def
 *  name (core/fn ([params* ] exprs*)+)) with any doc-string or attrs added
 *  to the var metadata. prepost-map defines a map with optional keys
 *  :pre and :post that contain collections of pre or post conditions.
 * @param {...*} var_args
 */
cljs.core$macros.defn = (function() { 
var cljs$core$macros$defn__delegate = function (_AMPERSAND_form,_AMPERSAND_env,name,fdecl){
if((name instanceof cljs.core.Symbol)){
} else {
throw (new Error("First argument to defn must be a symbol"));
}

var m = ((typeof cljs.core.first.call(null,fdecl) === 'string')?new cljs.core.PersistentArrayMap(null, 1, [new cljs.core.Keyword(null,"doc","doc",1913296891),cljs.core.first.call(null,fdecl)], null):cljs.core.PersistentArrayMap.EMPTY);
var fdecl__$1 = ((typeof cljs.core.first.call(null,fdecl) === 'string')?cljs.core.next.call(null,fdecl):fdecl);
var m__$1 = ((cljs.core.map_QMARK_.call(null,cljs.core.first.call(null,fdecl__$1)))?cljs.core.conj.call(null,m,cljs.core.first.call(null,fdecl__$1)):m);
var fdecl__$2 = ((cljs.core.map_QMARK_.call(null,cljs.core.first.call(null,fdecl__$1)))?cljs.core.next.call(null,fdecl__$1):fdecl__$1);
var fdecl__$3 = ((cljs.core.vector_QMARK_.call(null,cljs.core.first.call(null,fdecl__$2)))?(function (){var x__23746__auto__ = fdecl__$2;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})():fdecl__$2);
var m__$2 = ((cljs.core.map_QMARK_.call(null,cljs.core.last.call(null,fdecl__$3)))?cljs.core.conj.call(null,m__$1,cljs.core.last.call(null,fdecl__$3)):m__$1);
var fdecl__$4 = ((cljs.core.map_QMARK_.call(null,cljs.core.last.call(null,fdecl__$3)))?cljs.core.butlast.call(null,fdecl__$3):fdecl__$3);
var m__$3 = cljs.core.conj.call(null,new cljs.core.PersistentArrayMap(null, 1, [new cljs.core.Keyword(null,"arglists","arglists",1661989754),cljs.core._conj.call(null,(function (){var x__23746__auto__ = cljs.core$macros.sigs.call(null,fdecl__$4);
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),new cljs.core.Symbol(null,"quote","quote",1377916282,null))], null),m__$2);
var m__$4 = cljs.core.conj.call(null,(cljs.core.truth_(cljs.core.meta.call(null,name))?cljs.core.meta.call(null,name):cljs.core.PersistentArrayMap.EMPTY),m__$3);
if(cljs.core.truth_(cljs.core$macros.multi_arity_fn_QMARK_.call(null,fdecl__$4))){
return cljs.core$macros.multi_arity_fn.call(null,name,(cljs.core.truth_(cljs.compiler.checking_types_QMARK_.call(null))?cljs.core.update_in.call(null,m__$4,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword(null,"jsdoc","jsdoc",1745183516)], null),cljs.core.conj,"@param {...*} var_args"):m__$4),fdecl__$4);
} else {
if(cljs.core.truth_(cljs.core$macros.variadic_fn_QMARK_.call(null,fdecl__$4))){
return cljs.core$macros.variadic_fn.call(null,name,(cljs.core.truth_(cljs.compiler.checking_types_QMARK_.call(null))?cljs.core.update_in.call(null,m__$4,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword(null,"jsdoc","jsdoc",1745183516)], null),cljs.core.conj,"@param {...*} var_args"):m__$4),fdecl__$4);
} else {
return cljs.core._conj.call(null,(function (){var x__23746__auto__ = cljs.core.with_meta.call(null,name,m__$4);
return cljs.core._conj.call(null,(function (){var x__23746__auto____$1 = cljs.core.cons.call(null,new cljs.core.Symbol("cljs.core$macros","fn","cljs.core$macros/fn",-187522821,null),fdecl__$4);
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto____$1);
})(),x__23746__auto__);
})(),new cljs.core.Symbol(null,"def","def",597100991,null));

}
}
};
var cljs$core$macros$defn = function (_AMPERSAND_form,_AMPERSAND_env,name,var_args){
var fdecl = null;
if (arguments.length > 3) {
var G__29392__i = 0, G__29392__a = new Array(arguments.length -  3);
while (G__29392__i < G__29392__a.length) {G__29392__a[G__29392__i] = arguments[G__29392__i + 3]; ++G__29392__i;}
  fdecl = new cljs.core.IndexedSeq(G__29392__a,0);
} 
return cljs$core$macros$defn__delegate.call(this,_AMPERSAND_form,_AMPERSAND_env,name,fdecl);};
cljs$core$macros$defn.cljs$lang$maxFixedArity = 3;
cljs$core$macros$defn.cljs$lang$applyTo = (function (arglist__29393){
var _AMPERSAND_form = cljs.core.first(arglist__29393);
arglist__29393 = cljs.core.next(arglist__29393);
var _AMPERSAND_env = cljs.core.first(arglist__29393);
arglist__29393 = cljs.core.next(arglist__29393);
var name = cljs.core.first(arglist__29393);
var fdecl = cljs.core.rest(arglist__29393);
return cljs$core$macros$defn__delegate(_AMPERSAND_form,_AMPERSAND_env,name,fdecl);
});
cljs$core$macros$defn.cljs$core$IFn$_invoke$arity$variadic = cljs$core$macros$defn__delegate;
return cljs$core$macros$defn;
})()
;
cljs.core$macros.defn.cljs$lang$macro = true;
/**
 * Like defn, but the resulting function name is declared as a
 *   macro and will be used as a macro by the compiler when it is
 *   called.
 */
cljs.core$macros.defmacro = (function cljs$core$macros$defmacro(var_args){
var args__23989__auto__ = [];
var len__23982__auto___29398 = arguments.length;
var i__23983__auto___29399 = (0);
while(true){
if((i__23983__auto___29399 < len__23982__auto___29398)){
args__23989__auto__.push((arguments[i__23983__auto___29399]));

var G__29400 = (i__23983__auto___29399 + (1));
i__23983__auto___29399 = G__29400;
continue;
} else {
}
break;
}

var argseq__23990__auto__ = ((((3) < args__23989__auto__.length))?(new cljs.core.IndexedSeq(args__23989__auto__.slice((3)),(0),null)):null);
return cljs.core$macros.defmacro.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),argseq__23990__auto__);
});

cljs.core$macros.defmacro.cljs$core$IFn$_invoke$arity$variadic = (function (_AMPERSAND_form,_AMPERSAND_env,name,args){
var prefix = (function (){var p = (function (){var x__23746__auto__ = cljs.core.vary_meta.call(null,name,cljs.core.assoc,new cljs.core.Keyword(null,"macro","macro",-867863404),true);
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})();
var args__$1 = args;
while(true){
var f = cljs.core.first.call(null,args__$1);
if(typeof f === 'string'){
var G__29401 = cljs.core.cons.call(null,f,p);
var G__29402 = cljs.core.next.call(null,args__$1);
p = G__29401;
args__$1 = G__29402;
continue;
} else {
if(cljs.core.map_QMARK_.call(null,f)){
var G__29403 = cljs.core.cons.call(null,f,p);
var G__29404 = cljs.core.next.call(null,args__$1);
p = G__29403;
args__$1 = G__29404;
continue;
} else {
return p;
}
}
break;
}
})();
var fdecl = (function (){var fd = args;
while(true){
if(typeof cljs.core.first.call(null,fd) === 'string'){
var G__29405 = cljs.core.next.call(null,fd);
fd = G__29405;
continue;
} else {
if(cljs.core.map_QMARK_.call(null,cljs.core.first.call(null,fd))){
var G__29406 = cljs.core.next.call(null,fd);
fd = G__29406;
continue;
} else {
return fd;
}
}
break;
}
})();
var fdecl__$1 = ((cljs.core.vector_QMARK_.call(null,cljs.core.first.call(null,fdecl)))?(function (){var x__23746__auto__ = fdecl;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})():fdecl);
var add_implicit_args = ((function (prefix,fdecl,fdecl__$1){
return (function (fd){
var args__$1 = cljs.core.first.call(null,fd);
return cljs.core.cons.call(null,cljs.core.vec.call(null,cljs.core.cons.call(null,new cljs.core.Symbol(null,"&form","&form",1482799337,null),cljs.core.cons.call(null,new cljs.core.Symbol(null,"&env","&env",-919163083,null),args__$1))),cljs.core.next.call(null,fd));
});})(prefix,fdecl,fdecl__$1))
;
var add_args = ((function (prefix,fdecl,fdecl__$1,add_implicit_args){
return (function (acc,ds){
while(true){
if((ds == null)){
return acc;
} else {
var d = cljs.core.first.call(null,ds);
if(cljs.core.map_QMARK_.call(null,d)){
return cljs.core.conj.call(null,acc,d);
} else {
var G__29407 = cljs.core.conj.call(null,acc,add_implicit_args.call(null,d));
var G__29408 = cljs.core.next.call(null,ds);
acc = G__29407;
ds = G__29408;
continue;
}
}
break;
}
});})(prefix,fdecl,fdecl__$1,add_implicit_args))
;
var fdecl__$2 = cljs.core.seq.call(null,add_args.call(null,cljs.core.PersistentVector.EMPTY,fdecl__$1));
var decl = (function (){var p = prefix;
var d = fdecl__$2;
while(true){
if(cljs.core.truth_(p)){
var G__29409 = cljs.core.next.call(null,p);
var G__29410 = cljs.core.cons.call(null,cljs.core.first.call(null,p),d);
p = G__29409;
d = G__29410;
continue;
} else {
return d;
}
break;
}
})();
return cljs.core._conj.call(null,(function (){var x__23746__auto__ = cljs.core.cons.call(null,new cljs.core.Symbol("cljs.core$macros","defn","cljs.core$macros/defn",-728332354,null),decl);
return cljs.core._conj.call(null,(function (){var x__23746__auto____$1 = cljs.core._conj.call(null,(function (){var x__23746__auto____$1 = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,".",".",1975675962,null)),(function (){var x__23746__auto____$1 = name;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto____$1);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"-cljs$lang$macro","-cljs$lang$macro",443600924,null)))));
return cljs.core._conj.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,true),x__23746__auto____$1);
})(),new cljs.core.Symbol(null,"set!","set!",250714521,null));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto____$1);
})(),x__23746__auto__);
})(),new cljs.core.Symbol(null,"do","do",1686842252,null));
});

cljs.core$macros.defmacro.cljs$lang$maxFixedArity = (3);

cljs.core$macros.defmacro.cljs$lang$applyTo = (function (seq29394){
var G__29395 = cljs.core.first.call(null,seq29394);
var seq29394__$1 = cljs.core.next.call(null,seq29394);
var G__29396 = cljs.core.first.call(null,seq29394__$1);
var seq29394__$2 = cljs.core.next.call(null,seq29394__$1);
var G__29397 = cljs.core.first.call(null,seq29394__$2);
var seq29394__$3 = cljs.core.next.call(null,seq29394__$2);
return cljs.core$macros.defmacro.cljs$core$IFn$_invoke$arity$variadic(G__29395,G__29396,G__29397,seq29394__$3);
});
cljs.core$macros.defmacro.cljs$lang$macro = true;

//# sourceMappingURL=core$macros.js.map