// Compiled by ClojureScript 1.8.51 {:target :nodejs}
goog.provide('cljs.nodejs');
goog.require('cljs.core');
cljs.nodejs.require = require;
cljs.nodejs.process = process;
cljs.nodejs.enable_util_print_BANG_ = (function cljs$nodejs$enable_util_print_BANG_(){
cljs.core._STAR_print_newline_STAR_ = false;

cljs.core._STAR_print_fn_STAR_ = (function() { 
var G__27854__delegate = function (args){
return console.log.apply(console,cljs.core.into_array.call(null,args));
};
var G__27854 = function (var_args){
var args = null;
if (arguments.length > 0) {
var G__27855__i = 0, G__27855__a = new Array(arguments.length -  0);
while (G__27855__i < G__27855__a.length) {G__27855__a[G__27855__i] = arguments[G__27855__i + 0]; ++G__27855__i;}
  args = new cljs.core.IndexedSeq(G__27855__a,0);
} 
return G__27854__delegate.call(this,args);};
G__27854.cljs$lang$maxFixedArity = 0;
G__27854.cljs$lang$applyTo = (function (arglist__27856){
var args = cljs.core.seq(arglist__27856);
return G__27854__delegate(args);
});
G__27854.cljs$core$IFn$_invoke$arity$variadic = G__27854__delegate;
return G__27854;
})()
;

cljs.core._STAR_print_err_fn_STAR_ = (function() { 
var G__27857__delegate = function (args){
return console.error.apply(console,cljs.core.into_array.call(null,args));
};
var G__27857 = function (var_args){
var args = null;
if (arguments.length > 0) {
var G__27858__i = 0, G__27858__a = new Array(arguments.length -  0);
while (G__27858__i < G__27858__a.length) {G__27858__a[G__27858__i] = arguments[G__27858__i + 0]; ++G__27858__i;}
  args = new cljs.core.IndexedSeq(G__27858__a,0);
} 
return G__27857__delegate.call(this,args);};
G__27857.cljs$lang$maxFixedArity = 0;
G__27857.cljs$lang$applyTo = (function (arglist__27859){
var args = cljs.core.seq(arglist__27859);
return G__27857__delegate(args);
});
G__27857.cljs$core$IFn$_invoke$arity$variadic = G__27857__delegate;
return G__27857;
})()
;

return null;
});

//# sourceMappingURL=nodejs.js.map