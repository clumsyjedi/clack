// Compiled by ClojureScript 1.8.51 {:target :nodejs}
goog.provide('cljs.compiler');
goog.require('cljs.core');
goog.require('goog.string');
goog.require('cljs.tools.reader');
goog.require('cljs.env');
goog.require('cljs.analyzer');
goog.require('cljs.source_map');
goog.require('goog.string.StringBuffer');
goog.require('clojure.string');
cljs.compiler.js_reserved = cljs.analyzer.js_reserved;
cljs.compiler._STAR_recompiled_STAR_ = null;
cljs.compiler._STAR_inputs_STAR_ = null;
cljs.compiler._STAR_source_map_data_STAR_ = null;
cljs.compiler._STAR_lexical_renames_STAR_ = cljs.core.PersistentArrayMap.EMPTY;
cljs.compiler.cljs_reserved_file_names = new cljs.core.PersistentHashSet(null, new cljs.core.PersistentArrayMap(null, 1, ["deps.cljs",null], null), null);
cljs.compiler.ns_first_segments = (function cljs$compiler$ns_first_segments(){
var get_first_ns_segment = (function cljs$compiler$ns_first_segments_$_get_first_ns_segment(ns){
return cljs.core.first.call(null,clojure.string.split.call(null,[cljs.core.str(ns)].join(''),/\./));
});
return cljs.core.map.call(null,get_first_ns_segment,cljs.core.keys.call(null,new cljs.core.Keyword("cljs.analyzer","namespaces","cljs.analyzer/namespaces",-260788927).cljs$core$IFn$_invoke$arity$1(cljs.core.deref.call(null,cljs.env._STAR_compiler_STAR_))));
});
cljs.compiler.shadow_depth = (function cljs$compiler$shadow_depth(s){
var map__31023 = s;
var map__31023__$1 = ((((!((map__31023 == null)))?((((map__31023.cljs$lang$protocol_mask$partition0$ & (64))) || (map__31023.cljs$core$ISeq$))?true:false):false))?cljs.core.apply.call(null,cljs.core.hash_map,map__31023):map__31023);
var name = cljs.core.get.call(null,map__31023__$1,new cljs.core.Keyword(null,"name","name",1843675177));
var info = cljs.core.get.call(null,map__31023__$1,new cljs.core.Keyword(null,"info","info",-317069002));
var d = (0);
var G__31026 = info;
var map__31027 = G__31026;
var map__31027__$1 = ((((!((map__31027 == null)))?((((map__31027.cljs$lang$protocol_mask$partition0$ & (64))) || (map__31027.cljs$core$ISeq$))?true:false):false))?cljs.core.apply.call(null,cljs.core.hash_map,map__31027):map__31027);
var shadow = cljs.core.get.call(null,map__31027__$1,new cljs.core.Keyword(null,"shadow","shadow",873231803));
var d__$1 = d;
var G__31026__$1 = G__31026;
while(true){
var d__$2 = d__$1;
var map__31029 = G__31026__$1;
var map__31029__$1 = ((((!((map__31029 == null)))?((((map__31029.cljs$lang$protocol_mask$partition0$ & (64))) || (map__31029.cljs$core$ISeq$))?true:false):false))?cljs.core.apply.call(null,cljs.core.hash_map,map__31029):map__31029);
var shadow__$1 = cljs.core.get.call(null,map__31029__$1,new cljs.core.Keyword(null,"shadow","shadow",873231803));
if(cljs.core.truth_(shadow__$1)){
var G__31031 = (d__$2 + (1));
var G__31032 = shadow__$1;
d__$1 = G__31031;
G__31026__$1 = G__31032;
continue;
} else {
if(cljs.core.truth_(cljs.core.some.call(null,cljs.core.PersistentHashSet.fromArray([[cljs.core.str(name)].join('')], true),cljs.compiler.ns_first_segments.call(null)))){
return (d__$2 + (1));
} else {
return d__$2;

}
}
break;
}
});
cljs.compiler.hash_scope = (function cljs$compiler$hash_scope(s){
return cljs.core.hash_combine.call(null,cljs.core._hash.call(null,new cljs.core.Keyword(null,"name","name",1843675177).cljs$core$IFn$_invoke$arity$1(s)),cljs.compiler.shadow_depth.call(null,s));
});
cljs.compiler.fn_self_name = (function cljs$compiler$fn_self_name(p__31033){
var map__31038 = p__31033;
var map__31038__$1 = ((((!((map__31038 == null)))?((((map__31038.cljs$lang$protocol_mask$partition0$ & (64))) || (map__31038.cljs$core$ISeq$))?true:false):false))?cljs.core.apply.call(null,cljs.core.hash_map,map__31038):map__31038);
var name_var = map__31038__$1;
var name = cljs.core.get.call(null,map__31038__$1,new cljs.core.Keyword(null,"name","name",1843675177));
var info = cljs.core.get.call(null,map__31038__$1,new cljs.core.Keyword(null,"info","info",-317069002));
var name__$1 = clojure.string.replace.call(null,[cljs.core.str(name)].join(''),"..","_DOT__DOT_");
var map__31040 = info;
var map__31040__$1 = ((((!((map__31040 == null)))?((((map__31040.cljs$lang$protocol_mask$partition0$ & (64))) || (map__31040.cljs$core$ISeq$))?true:false):false))?cljs.core.apply.call(null,cljs.core.hash_map,map__31040):map__31040);
var ns = cljs.core.get.call(null,map__31040__$1,new cljs.core.Keyword(null,"ns","ns",441598760));
var fn_scope = cljs.core.get.call(null,map__31040__$1,new cljs.core.Keyword(null,"fn-scope","fn-scope",-865664859));
var scoped_name = cljs.core.apply.call(null,cljs.core.str,cljs.core.interpose.call(null,"_$_",cljs.core.concat.call(null,cljs.core.map.call(null,cljs.core.comp.call(null,cljs.core.str,new cljs.core.Keyword(null,"name","name",1843675177)),fn_scope),new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [name__$1], null))));
return cljs.core.symbol.call(null,cljs.compiler.munge.call(null,[cljs.core.str(clojure.string.replace.call(null,[cljs.core.str(ns)].join(''),".","$")),cljs.core.str("$"),cljs.core.str(scoped_name)].join('')));
});
cljs.compiler.munge_reserved = (function cljs$compiler$munge_reserved(reserved){
return (function (s){
if(!((cljs.core.get.call(null,reserved,s) == null))){
return [cljs.core.str(s),cljs.core.str("$")].join('');
} else {
return s;
}
});
});
cljs.compiler.munge = (function cljs$compiler$munge(var_args){
var args31042 = [];
var len__23982__auto___31045 = arguments.length;
var i__23983__auto___31046 = (0);
while(true){
if((i__23983__auto___31046 < len__23982__auto___31045)){
args31042.push((arguments[i__23983__auto___31046]));

var G__31047 = (i__23983__auto___31046 + (1));
i__23983__auto___31046 = G__31047;
continue;
} else {
}
break;
}

var G__31044 = args31042.length;
switch (G__31044) {
case 1:
return cljs.compiler.munge.cljs$core$IFn$_invoke$arity$1((arguments[(0)]));

break;
case 2:
return cljs.compiler.munge.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
default:
throw (new Error([cljs.core.str("Invalid arity: "),cljs.core.str(args31042.length)].join('')));

}
});

cljs.compiler.munge.cljs$core$IFn$_invoke$arity$1 = (function (s){
return cljs.compiler.munge.call(null,s,cljs.compiler.js_reserved);
});

cljs.compiler.munge.cljs$core$IFn$_invoke$arity$2 = (function (s,reserved){
if(cljs.analyzer.cljs_map_QMARK_.call(null,s)){
var name_var = s;
var name = new cljs.core.Keyword(null,"name","name",1843675177).cljs$core$IFn$_invoke$arity$1(name_var);
var field = new cljs.core.Keyword(null,"field","field",-1302436500).cljs$core$IFn$_invoke$arity$1(name_var);
var info = new cljs.core.Keyword(null,"info","info",-317069002).cljs$core$IFn$_invoke$arity$1(name_var);
if(!((new cljs.core.Keyword(null,"fn-self-name","fn-self-name",1461143531).cljs$core$IFn$_invoke$arity$1(info) == null))){
return cljs.compiler.fn_self_name.call(null,s);
} else {
var depth = cljs.compiler.shadow_depth.call(null,s);
var code = cljs.compiler.hash_scope.call(null,s);
var renamed = cljs.core.get.call(null,cljs.compiler._STAR_lexical_renames_STAR_,code);
var name__$1 = ((field === true)?[cljs.core.str("self__."),cljs.core.str(name)].join(''):((!((renamed == null)))?renamed:name
));
var munged_name = cljs.compiler.munge.call(null,name__$1,reserved);
if((field === true) || ((depth === (0)))){
return munged_name;
} else {
return cljs.core.symbol.call(null,[cljs.core.str(munged_name),cljs.core.str("__$"),cljs.core.str(depth)].join(''));
}
}
} else {
var ss = clojure.string.replace.call(null,[cljs.core.str(s)].join(''),"..","_DOT__DOT_");
var ss__$1 = clojure.string.replace.call(null,ss,(new RegExp("\\/(.)")),".$1");
var rf = cljs.compiler.munge_reserved.call(null,reserved);
var ss__$2 = cljs.core.map.call(null,rf,clojure.string.split.call(null,ss__$1,/\./));
var ss__$3 = clojure.string.join.call(null,".",ss__$2);
var ms = cljs.core.munge.call(null,ss__$3);
if((s instanceof cljs.core.Symbol)){
return cljs.core.symbol.call(null,ms);
} else {
return ms;
}
}
});

cljs.compiler.munge.cljs$lang$maxFixedArity = 2;
cljs.compiler.comma_sep = (function cljs$compiler$comma_sep(xs){
return cljs.core.interpose.call(null,",",xs);
});
cljs.compiler.escape_char = (function cljs$compiler$escape_char(c){
var cp = goog.string.hashCode(c);
var G__31050 = cp;
switch (G__31050) {
case (34):
return "\\\"";

break;
case (92):
return "\\\\";

break;
case (8):
return "\\b";

break;
case (12):
return "\\f";

break;
case (10):
return "\\n";

break;
case (13):
return "\\r";

break;
case (9):
return "\\t";

break;
default:
if((((31) < cp)) && ((cp < (127)))){
return c;
} else {
var unpadded = cp.toString((16));
var pad = cljs.core.subs.call(null,"0000",unpadded.length);
return [cljs.core.str("\\u"),cljs.core.str(pad),cljs.core.str(unpadded)].join('');
}

}
});
cljs.compiler.escape_string = (function cljs$compiler$escape_string(s){
var sb = (new goog.string.StringBuffer());
var seq__31056_31060 = cljs.core.seq.call(null,s);
var chunk__31057_31061 = null;
var count__31058_31062 = (0);
var i__31059_31063 = (0);
while(true){
if((i__31059_31063 < count__31058_31062)){
var c_31064 = cljs.core._nth.call(null,chunk__31057_31061,i__31059_31063);
sb.append(cljs.compiler.escape_char.call(null,c_31064));

var G__31065 = seq__31056_31060;
var G__31066 = chunk__31057_31061;
var G__31067 = count__31058_31062;
var G__31068 = (i__31059_31063 + (1));
seq__31056_31060 = G__31065;
chunk__31057_31061 = G__31066;
count__31058_31062 = G__31067;
i__31059_31063 = G__31068;
continue;
} else {
var temp__4657__auto___31069 = cljs.core.seq.call(null,seq__31056_31060);
if(temp__4657__auto___31069){
var seq__31056_31070__$1 = temp__4657__auto___31069;
if(cljs.core.chunked_seq_QMARK_.call(null,seq__31056_31070__$1)){
var c__23723__auto___31071 = cljs.core.chunk_first.call(null,seq__31056_31070__$1);
var G__31072 = cljs.core.chunk_rest.call(null,seq__31056_31070__$1);
var G__31073 = c__23723__auto___31071;
var G__31074 = cljs.core.count.call(null,c__23723__auto___31071);
var G__31075 = (0);
seq__31056_31060 = G__31072;
chunk__31057_31061 = G__31073;
count__31058_31062 = G__31074;
i__31059_31063 = G__31075;
continue;
} else {
var c_31076 = cljs.core.first.call(null,seq__31056_31070__$1);
sb.append(cljs.compiler.escape_char.call(null,c_31076));

var G__31077 = cljs.core.next.call(null,seq__31056_31070__$1);
var G__31078 = null;
var G__31079 = (0);
var G__31080 = (0);
seq__31056_31060 = G__31077;
chunk__31057_31061 = G__31078;
count__31058_31062 = G__31079;
i__31059_31063 = G__31080;
continue;
}
} else {
}
}
break;
}

return sb.toString();
});
cljs.compiler.wrap_in_double_quotes = (function cljs$compiler$wrap_in_double_quotes(x){
return [cljs.core.str("\""),cljs.core.str(x),cljs.core.str("\"")].join('');
});
if(typeof cljs.compiler.emit_STAR_ !== 'undefined'){
} else {
cljs.compiler.emit_STAR_ = (function (){var method_table__23837__auto__ = cljs.core.atom.call(null,cljs.core.PersistentArrayMap.EMPTY);
var prefer_table__23838__auto__ = cljs.core.atom.call(null,cljs.core.PersistentArrayMap.EMPTY);
var method_cache__23839__auto__ = cljs.core.atom.call(null,cljs.core.PersistentArrayMap.EMPTY);
var cached_hierarchy__23840__auto__ = cljs.core.atom.call(null,cljs.core.PersistentArrayMap.EMPTY);
var hierarchy__23841__auto__ = cljs.core.get.call(null,cljs.core.PersistentArrayMap.EMPTY,new cljs.core.Keyword(null,"hierarchy","hierarchy",-1053470341),cljs.core.get_global_hierarchy.call(null));
return (new cljs.core.MultiFn(cljs.core.symbol.call(null,"cljs.compiler","emit*"),new cljs.core.Keyword(null,"op","op",-1882987955),new cljs.core.Keyword(null,"default","default",-1987822328),hierarchy__23841__auto__,method_table__23837__auto__,prefer_table__23838__auto__,method_cache__23839__auto__,cached_hierarchy__23840__auto__));
})();
}
cljs.compiler.emit = (function cljs$compiler$emit(ast){
var val__24507__auto__ = cljs.env._STAR_compiler_STAR_;
if((val__24507__auto__ == null)){
cljs.env._STAR_compiler_STAR_ = cljs.env.default_compiler_env.call(null);
} else {
}

try{if(cljs.core.truth_(cljs.compiler._STAR_source_map_data_STAR_)){
var map__31086_31091 = ast;
var map__31086_31092__$1 = ((((!((map__31086_31091 == null)))?((((map__31086_31091.cljs$lang$protocol_mask$partition0$ & (64))) || (map__31086_31091.cljs$core$ISeq$))?true:false):false))?cljs.core.apply.call(null,cljs.core.hash_map,map__31086_31091):map__31086_31091);
var env_31093 = cljs.core.get.call(null,map__31086_31092__$1,new cljs.core.Keyword(null,"env","env",-1815813235));
if(cljs.core.truth_(new cljs.core.Keyword(null,"line","line",212345235).cljs$core$IFn$_invoke$arity$1(env_31093))){
var map__31088_31094 = env_31093;
var map__31088_31095__$1 = ((((!((map__31088_31094 == null)))?((((map__31088_31094.cljs$lang$protocol_mask$partition0$ & (64))) || (map__31088_31094.cljs$core$ISeq$))?true:false):false))?cljs.core.apply.call(null,cljs.core.hash_map,map__31088_31094):map__31088_31094);
var line_31096 = cljs.core.get.call(null,map__31088_31095__$1,new cljs.core.Keyword(null,"line","line",212345235));
var column_31097 = cljs.core.get.call(null,map__31088_31095__$1,new cljs.core.Keyword(null,"column","column",2078222095));
cljs.core.swap_BANG_.call(null,cljs.compiler._STAR_source_map_data_STAR_,((function (map__31088_31094,map__31088_31095__$1,line_31096,column_31097,map__31086_31091,map__31086_31092__$1,env_31093,val__24507__auto__){
return (function (m){
var minfo = (function (){var G__31090 = new cljs.core.PersistentArrayMap(null, 2, [new cljs.core.Keyword(null,"gcol","gcol",309250807),new cljs.core.Keyword(null,"gen-col","gen-col",1901918303).cljs$core$IFn$_invoke$arity$1(m),new cljs.core.Keyword(null,"gline","gline",-1086242431),new cljs.core.Keyword(null,"gen-line","gen-line",589592125).cljs$core$IFn$_invoke$arity$1(m)], null);
if(cljs.core._EQ_.call(null,new cljs.core.Keyword(null,"op","op",-1882987955).cljs$core$IFn$_invoke$arity$1(ast),new cljs.core.Keyword(null,"var","var",-769682797))){
return cljs.core.assoc.call(null,G__31090,new cljs.core.Keyword(null,"name","name",1843675177),[cljs.core.str(new cljs.core.Keyword(null,"name","name",1843675177).cljs$core$IFn$_invoke$arity$1(new cljs.core.Keyword(null,"info","info",-317069002).cljs$core$IFn$_invoke$arity$1(ast)))].join(''));
} else {
return G__31090;
}
})();
return cljs.core.update_in.call(null,m,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword(null,"source-map","source-map",1706252311),(line_31096 - (1))], null),cljs.core.fnil.call(null,((function (minfo,map__31088_31094,map__31088_31095__$1,line_31096,column_31097,map__31086_31091,map__31086_31092__$1,env_31093,val__24507__auto__){
return (function (line__$1){
return cljs.core.update_in.call(null,line__$1,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [(cljs.core.truth_(column_31097)?(column_31097 - (1)):(0))], null),cljs.core.fnil.call(null,((function (minfo,map__31088_31094,map__31088_31095__$1,line_31096,column_31097,map__31086_31091,map__31086_31092__$1,env_31093,val__24507__auto__){
return (function (column__$1){
return cljs.core.conj.call(null,column__$1,minfo);
});})(minfo,map__31088_31094,map__31088_31095__$1,line_31096,column_31097,map__31086_31091,map__31086_31092__$1,env_31093,val__24507__auto__))
,cljs.core.PersistentVector.EMPTY));
});})(minfo,map__31088_31094,map__31088_31095__$1,line_31096,column_31097,map__31086_31091,map__31086_31092__$1,env_31093,val__24507__auto__))
,cljs.core.sorted_map.call(null)));
});})(map__31088_31094,map__31088_31095__$1,line_31096,column_31097,map__31086_31091,map__31086_31092__$1,env_31093,val__24507__auto__))
);
} else {
}
} else {
}

return cljs.compiler.emit_STAR_.call(null,ast);
}finally {if((val__24507__auto__ == null)){
cljs.env._STAR_compiler_STAR_ = null;
} else {
}
}});
cljs.compiler.emits = (function cljs$compiler$emits(var_args){
var args__23989__auto__ = [];
var len__23982__auto___31104 = arguments.length;
var i__23983__auto___31105 = (0);
while(true){
if((i__23983__auto___31105 < len__23982__auto___31104)){
args__23989__auto__.push((arguments[i__23983__auto___31105]));

var G__31106 = (i__23983__auto___31105 + (1));
i__23983__auto___31105 = G__31106;
continue;
} else {
}
break;
}

var argseq__23990__auto__ = ((((0) < args__23989__auto__.length))?(new cljs.core.IndexedSeq(args__23989__auto__.slice((0)),(0),null)):null);
return cljs.compiler.emits.cljs$core$IFn$_invoke$arity$variadic(argseq__23990__auto__);
});

cljs.compiler.emits.cljs$core$IFn$_invoke$arity$variadic = (function (xs){
var seq__31100_31107 = cljs.core.seq.call(null,xs);
var chunk__31101_31108 = null;
var count__31102_31109 = (0);
var i__31103_31110 = (0);
while(true){
if((i__31103_31110 < count__31102_31109)){
var x_31111 = cljs.core._nth.call(null,chunk__31101_31108,i__31103_31110);
if((x_31111 == null)){
} else {
if(cljs.analyzer.cljs_map_QMARK_.call(null,x_31111)){
cljs.compiler.emit.call(null,x_31111);
} else {
if(cljs.analyzer.cljs_seq_QMARK_.call(null,x_31111)){
cljs.core.apply.call(null,cljs.compiler.emits,x_31111);
} else {
if(goog.isFunction(x_31111)){
x_31111.call(null);
} else {
var s_31112 = cljs.core.print_str.call(null,x_31111);
if((cljs.compiler._STAR_source_map_data_STAR_ == null)){
} else {
cljs.core.swap_BANG_.call(null,cljs.compiler._STAR_source_map_data_STAR_,cljs.core.update_in,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword(null,"gen-col","gen-col",1901918303)], null),((function (seq__31100_31107,chunk__31101_31108,count__31102_31109,i__31103_31110,s_31112,x_31111){
return (function (p1__31098_SHARP_){
return (p1__31098_SHARP_ + cljs.core.count.call(null,s_31112));
});})(seq__31100_31107,chunk__31101_31108,count__31102_31109,i__31103_31110,s_31112,x_31111))
);
}

cljs.core.print.call(null,s_31112);

}
}
}
}

var G__31113 = seq__31100_31107;
var G__31114 = chunk__31101_31108;
var G__31115 = count__31102_31109;
var G__31116 = (i__31103_31110 + (1));
seq__31100_31107 = G__31113;
chunk__31101_31108 = G__31114;
count__31102_31109 = G__31115;
i__31103_31110 = G__31116;
continue;
} else {
var temp__4657__auto___31117 = cljs.core.seq.call(null,seq__31100_31107);
if(temp__4657__auto___31117){
var seq__31100_31118__$1 = temp__4657__auto___31117;
if(cljs.core.chunked_seq_QMARK_.call(null,seq__31100_31118__$1)){
var c__23723__auto___31119 = cljs.core.chunk_first.call(null,seq__31100_31118__$1);
var G__31120 = cljs.core.chunk_rest.call(null,seq__31100_31118__$1);
var G__31121 = c__23723__auto___31119;
var G__31122 = cljs.core.count.call(null,c__23723__auto___31119);
var G__31123 = (0);
seq__31100_31107 = G__31120;
chunk__31101_31108 = G__31121;
count__31102_31109 = G__31122;
i__31103_31110 = G__31123;
continue;
} else {
var x_31124 = cljs.core.first.call(null,seq__31100_31118__$1);
if((x_31124 == null)){
} else {
if(cljs.analyzer.cljs_map_QMARK_.call(null,x_31124)){
cljs.compiler.emit.call(null,x_31124);
} else {
if(cljs.analyzer.cljs_seq_QMARK_.call(null,x_31124)){
cljs.core.apply.call(null,cljs.compiler.emits,x_31124);
} else {
if(goog.isFunction(x_31124)){
x_31124.call(null);
} else {
var s_31125 = cljs.core.print_str.call(null,x_31124);
if((cljs.compiler._STAR_source_map_data_STAR_ == null)){
} else {
cljs.core.swap_BANG_.call(null,cljs.compiler._STAR_source_map_data_STAR_,cljs.core.update_in,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword(null,"gen-col","gen-col",1901918303)], null),((function (seq__31100_31107,chunk__31101_31108,count__31102_31109,i__31103_31110,s_31125,x_31124,seq__31100_31118__$1,temp__4657__auto___31117){
return (function (p1__31098_SHARP_){
return (p1__31098_SHARP_ + cljs.core.count.call(null,s_31125));
});})(seq__31100_31107,chunk__31101_31108,count__31102_31109,i__31103_31110,s_31125,x_31124,seq__31100_31118__$1,temp__4657__auto___31117))
);
}

cljs.core.print.call(null,s_31125);

}
}
}
}

var G__31126 = cljs.core.next.call(null,seq__31100_31118__$1);
var G__31127 = null;
var G__31128 = (0);
var G__31129 = (0);
seq__31100_31107 = G__31126;
chunk__31101_31108 = G__31127;
count__31102_31109 = G__31128;
i__31103_31110 = G__31129;
continue;
}
} else {
}
}
break;
}

return null;
});

cljs.compiler.emits.cljs$lang$maxFixedArity = (0);

cljs.compiler.emits.cljs$lang$applyTo = (function (seq31099){
return cljs.compiler.emits.cljs$core$IFn$_invoke$arity$variadic(cljs.core.seq.call(null,seq31099));
});
cljs.compiler.emitln = (function cljs$compiler$emitln(var_args){
var args__23989__auto__ = [];
var len__23982__auto___31134 = arguments.length;
var i__23983__auto___31135 = (0);
while(true){
if((i__23983__auto___31135 < len__23982__auto___31134)){
args__23989__auto__.push((arguments[i__23983__auto___31135]));

var G__31136 = (i__23983__auto___31135 + (1));
i__23983__auto___31135 = G__31136;
continue;
} else {
}
break;
}

var argseq__23990__auto__ = ((((0) < args__23989__auto__.length))?(new cljs.core.IndexedSeq(args__23989__auto__.slice((0)),(0),null)):null);
return cljs.compiler.emitln.cljs$core$IFn$_invoke$arity$variadic(argseq__23990__auto__);
});

cljs.compiler.emitln.cljs$core$IFn$_invoke$arity$variadic = (function (xs){
cljs.core.apply.call(null,cljs.compiler.emits,xs);

cljs.core.println.call(null);

if(cljs.core.truth_(cljs.compiler._STAR_source_map_data_STAR_)){
cljs.core.swap_BANG_.call(null,cljs.compiler._STAR_source_map_data_STAR_,(function (p__31131){
var map__31132 = p__31131;
var map__31132__$1 = ((((!((map__31132 == null)))?((((map__31132.cljs$lang$protocol_mask$partition0$ & (64))) || (map__31132.cljs$core$ISeq$))?true:false):false))?cljs.core.apply.call(null,cljs.core.hash_map,map__31132):map__31132);
var m = map__31132__$1;
var gen_line = cljs.core.get.call(null,map__31132__$1,new cljs.core.Keyword(null,"gen-line","gen-line",589592125));
return cljs.core.assoc.call(null,m,new cljs.core.Keyword(null,"gen-line","gen-line",589592125),(gen_line + (1)),new cljs.core.Keyword(null,"gen-col","gen-col",1901918303),(0));
}));
} else {
}

return null;
});

cljs.compiler.emitln.cljs$lang$maxFixedArity = (0);

cljs.compiler.emitln.cljs$lang$applyTo = (function (seq31130){
return cljs.compiler.emitln.cljs$core$IFn$_invoke$arity$variadic(cljs.core.seq.call(null,seq31130));
});
cljs.compiler.emit_str = (function cljs$compiler$emit_str(expr){
var sb__23898__auto__ = (new goog.string.StringBuffer());
var _STAR_print_newline_STAR_31139_31141 = cljs.core._STAR_print_newline_STAR_;
var _STAR_print_fn_STAR_31140_31142 = cljs.core._STAR_print_fn_STAR_;
cljs.core._STAR_print_newline_STAR_ = true;

cljs.core._STAR_print_fn_STAR_ = ((function (_STAR_print_newline_STAR_31139_31141,_STAR_print_fn_STAR_31140_31142,sb__23898__auto__){
return (function (x__23899__auto__){
return sb__23898__auto__.append(x__23899__auto__);
});})(_STAR_print_newline_STAR_31139_31141,_STAR_print_fn_STAR_31140_31142,sb__23898__auto__))
;

try{cljs.compiler.emit.call(null,expr);
}finally {cljs.core._STAR_print_fn_STAR_ = _STAR_print_fn_STAR_31140_31142;

cljs.core._STAR_print_newline_STAR_ = _STAR_print_newline_STAR_31139_31141;
}
return [cljs.core.str(sb__23898__auto__)].join('');
});
if(typeof cljs.compiler.emit_constant !== 'undefined'){
} else {
cljs.compiler.emit_constant = (function (){var method_table__23837__auto__ = cljs.core.atom.call(null,cljs.core.PersistentArrayMap.EMPTY);
var prefer_table__23838__auto__ = cljs.core.atom.call(null,cljs.core.PersistentArrayMap.EMPTY);
var method_cache__23839__auto__ = cljs.core.atom.call(null,cljs.core.PersistentArrayMap.EMPTY);
var cached_hierarchy__23840__auto__ = cljs.core.atom.call(null,cljs.core.PersistentArrayMap.EMPTY);
var hierarchy__23841__auto__ = cljs.core.get.call(null,cljs.core.PersistentArrayMap.EMPTY,new cljs.core.Keyword(null,"hierarchy","hierarchy",-1053470341),cljs.core.get_global_hierarchy.call(null));
return (new cljs.core.MultiFn(cljs.core.symbol.call(null,"cljs.compiler","emit-constant"),cljs.core.type,new cljs.core.Keyword(null,"default","default",-1987822328),hierarchy__23841__auto__,method_table__23837__auto__,prefer_table__23838__auto__,method_cache__23839__auto__,cached_hierarchy__23840__auto__));
})();
}
cljs.core._add_method.call(null,cljs.compiler.emit_constant,null,(function (x){
return cljs.compiler.emits.call(null,"null");
}));
cljs.core._add_method.call(null,cljs.compiler.emit_constant,Number,(function (x){
return cljs.compiler.emits.call(null,"(",x,")");
}));
cljs.core._add_method.call(null,cljs.compiler.emit_constant,String,(function (x){
return cljs.compiler.emits.call(null,cljs.compiler.wrap_in_double_quotes.call(null,cljs.compiler.escape_string.call(null,x)));
}));
cljs.core._add_method.call(null,cljs.compiler.emit_constant,Boolean,(function (x){
return cljs.compiler.emits.call(null,(cljs.core.truth_(x)?"true":"false"));
}));
cljs.core._add_method.call(null,cljs.compiler.emit_constant,RegExp,(function (x){
if(cljs.core._EQ_.call(null,"",[cljs.core.str(x)].join(''))){
return cljs.compiler.emits.call(null,"(new RegExp(\"\"))");
} else {
var vec__31143 = cljs.core.re_find.call(null,/^(?:\(\?([idmsux]*)\))?(.*)/,[cljs.core.str(x)].join(''));
var _ = cljs.core.nth.call(null,vec__31143,(0),null);
var flags = cljs.core.nth.call(null,vec__31143,(1),null);
var pattern = cljs.core.nth.call(null,vec__31143,(2),null);
return cljs.compiler.emits.call(null,pattern);
}
}));
cljs.compiler.emits_keyword = (function cljs$compiler$emits_keyword(kw){
var ns = cljs.core.namespace.call(null,kw);
var name = cljs.core.name.call(null,kw);
cljs.compiler.emits.call(null,"new cljs.core.Keyword(");

cljs.compiler.emit_constant.call(null,ns);

cljs.compiler.emits.call(null,",");

cljs.compiler.emit_constant.call(null,name);

cljs.compiler.emits.call(null,",");

cljs.compiler.emit_constant.call(null,(cljs.core.truth_(ns)?[cljs.core.str(ns),cljs.core.str("/"),cljs.core.str(name)].join(''):name));

cljs.compiler.emits.call(null,",");

cljs.compiler.emit_constant.call(null,cljs.core.hash.call(null,kw));

return cljs.compiler.emits.call(null,")");
});
cljs.compiler.emits_symbol = (function cljs$compiler$emits_symbol(sym){
var ns = cljs.core.namespace.call(null,sym);
var name = cljs.core.name.call(null,sym);
var symstr = ((!((ns == null)))?[cljs.core.str(ns),cljs.core.str("/"),cljs.core.str(name)].join(''):name);
cljs.compiler.emits.call(null,"new cljs.core.Symbol(");

cljs.compiler.emit_constant.call(null,ns);

cljs.compiler.emits.call(null,",");

cljs.compiler.emit_constant.call(null,name);

cljs.compiler.emits.call(null,",");

cljs.compiler.emit_constant.call(null,symstr);

cljs.compiler.emits.call(null,",");

cljs.compiler.emit_constant.call(null,cljs.core.hash.call(null,sym));

cljs.compiler.emits.call(null,",");

cljs.compiler.emit_constant.call(null,null);

return cljs.compiler.emits.call(null,")");
});
cljs.core._add_method.call(null,cljs.compiler.emit_constant,cljs.core.Keyword,(function (x){
if(cljs.core.truth_(new cljs.core.Keyword(null,"emit-constants","emit-constants",-476585410).cljs$core$IFn$_invoke$arity$1(new cljs.core.Keyword(null,"options","options",99638489).cljs$core$IFn$_invoke$arity$1(cljs.core.deref.call(null,cljs.env._STAR_compiler_STAR_))))){
var value = x.call(null,new cljs.core.Keyword("cljs.analyzer","constant-table","cljs.analyzer/constant-table",-114131889).cljs$core$IFn$_invoke$arity$1(cljs.core.deref.call(null,cljs.env._STAR_compiler_STAR_)));
return cljs.compiler.emits.call(null,"cljs.core.",value);
} else {
return cljs.compiler.emits_keyword.call(null,x);
}
}));
cljs.core._add_method.call(null,cljs.compiler.emit_constant,cljs.core.Symbol,(function (x){
if(cljs.core.truth_(new cljs.core.Keyword(null,"emit-constants","emit-constants",-476585410).cljs$core$IFn$_invoke$arity$1(new cljs.core.Keyword(null,"options","options",99638489).cljs$core$IFn$_invoke$arity$1(cljs.core.deref.call(null,cljs.env._STAR_compiler_STAR_))))){
var value = x.call(null,new cljs.core.Keyword("cljs.analyzer","constant-table","cljs.analyzer/constant-table",-114131889).cljs$core$IFn$_invoke$arity$1(cljs.core.deref.call(null,cljs.env._STAR_compiler_STAR_)));
return cljs.compiler.emits.call(null,"cljs.core.",value);
} else {
return cljs.compiler.emits_symbol.call(null,x);
}
}));
cljs.core._add_method.call(null,cljs.compiler.emit_constant,Date,(function (date){
return cljs.compiler.emits.call(null,"new Date(",date.getTime(),")");
}));
cljs.core._add_method.call(null,cljs.compiler.emit_constant,cljs.core.UUID,(function (uuid){
var uuid_str = uuid.toString();
return cljs.compiler.emits.call(null,"new cljs.core.UUID(\"",uuid_str,"\", ",cljs.core.hash.call(null,uuid_str),")");
}));
cljs.core._add_method.call(null,cljs.compiler.emit_STAR_,new cljs.core.Keyword(null,"no-op","no-op",-93046065),(function (m){
return null;
}));
cljs.core._add_method.call(null,cljs.compiler.emit_STAR_,new cljs.core.Keyword(null,"var","var",-769682797),(function (p__31145){
var map__31146 = p__31145;
var map__31146__$1 = ((((!((map__31146 == null)))?((((map__31146.cljs$lang$protocol_mask$partition0$ & (64))) || (map__31146.cljs$core$ISeq$))?true:false):false))?cljs.core.apply.call(null,cljs.core.hash_map,map__31146):map__31146);
var arg = map__31146__$1;
var info = cljs.core.get.call(null,map__31146__$1,new cljs.core.Keyword(null,"info","info",-317069002));
var env = cljs.core.get.call(null,map__31146__$1,new cljs.core.Keyword(null,"env","env",-1815813235));
var form = cljs.core.get.call(null,map__31146__$1,new cljs.core.Keyword(null,"form","form",-1624062471));
var var_name = new cljs.core.Keyword(null,"name","name",1843675177).cljs$core$IFn$_invoke$arity$1(info);
var info__$1 = ((cljs.core._EQ_.call(null,cljs.core.namespace.call(null,var_name),"js"))?(function (){var js_module_name = cljs.core.get_in.call(null,cljs.core.deref.call(null,cljs.env._STAR_compiler_STAR_),new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword(null,"js-module-index","js-module-index",2072061931),cljs.core.name.call(null,var_name)], null));
var or__22912__auto__ = js_module_name;
if(cljs.core.truth_(or__22912__auto__)){
return or__22912__auto__;
} else {
return cljs.core.name.call(null,var_name);
}
})():info);
if(cljs.core.truth_(new cljs.core.Keyword(null,"binding-form?","binding-form?",1728940169).cljs$core$IFn$_invoke$arity$1(arg))){
return cljs.compiler.emits.call(null,cljs.compiler.munge.call(null,arg));
} else {
if(cljs.core._EQ_.call(null,new cljs.core.Keyword(null,"statement","statement",-32780863),new cljs.core.Keyword(null,"context","context",-830191113).cljs$core$IFn$_invoke$arity$1(env))){
return null;
} else {
var env__25235__auto__ = env;
if(cljs.core._EQ_.call(null,new cljs.core.Keyword(null,"return","return",-1891502105),new cljs.core.Keyword(null,"context","context",-830191113).cljs$core$IFn$_invoke$arity$1(env__25235__auto__))){
cljs.compiler.emits.call(null,"return ");
} else {
}

cljs.compiler.emits.call(null,(function (){var G__31148 = info__$1;
if(cljs.core.not_EQ_.call(null,form,new cljs.core.Symbol("js","-Infinity","js/-Infinity",958706333,null))){
return cljs.compiler.munge.call(null,G__31148);
} else {
return G__31148;
}
})());

if(cljs.core._EQ_.call(null,new cljs.core.Keyword(null,"expr","expr",745722291),new cljs.core.Keyword(null,"context","context",-830191113).cljs$core$IFn$_invoke$arity$1(env__25235__auto__))){
return null;
} else {
return cljs.compiler.emitln.call(null,";");
}
}
}
}));
cljs.core._add_method.call(null,cljs.compiler.emit_STAR_,new cljs.core.Keyword(null,"var-special","var-special",1131576802),(function (p__31149){
var map__31150 = p__31149;
var map__31150__$1 = ((((!((map__31150 == null)))?((((map__31150.cljs$lang$protocol_mask$partition0$ & (64))) || (map__31150.cljs$core$ISeq$))?true:false):false))?cljs.core.apply.call(null,cljs.core.hash_map,map__31150):map__31150);
var arg = map__31150__$1;
var env = cljs.core.get.call(null,map__31150__$1,new cljs.core.Keyword(null,"env","env",-1815813235));
var var$ = cljs.core.get.call(null,map__31150__$1,new cljs.core.Keyword(null,"var","var",-769682797));
var sym = cljs.core.get.call(null,map__31150__$1,new cljs.core.Keyword(null,"sym","sym",-1444860305));
var meta = cljs.core.get.call(null,map__31150__$1,new cljs.core.Keyword(null,"meta","meta",1499536964));
if(cljs.analyzer.ast_QMARK_.call(null,sym)){
} else {
throw (new Error("Assert failed: (ana/ast? sym)"));
}

if(cljs.analyzer.ast_QMARK_.call(null,meta)){
} else {
throw (new Error("Assert failed: (ana/ast? meta)"));
}

var map__31152 = new cljs.core.Keyword(null,"info","info",-317069002).cljs$core$IFn$_invoke$arity$1(var$);
var map__31152__$1 = ((((!((map__31152 == null)))?((((map__31152.cljs$lang$protocol_mask$partition0$ & (64))) || (map__31152.cljs$core$ISeq$))?true:false):false))?cljs.core.apply.call(null,cljs.core.hash_map,map__31152):map__31152);
var name = cljs.core.get.call(null,map__31152__$1,new cljs.core.Keyword(null,"name","name",1843675177));
var env__25235__auto__ = env;
if(cljs.core._EQ_.call(null,new cljs.core.Keyword(null,"return","return",-1891502105),new cljs.core.Keyword(null,"context","context",-830191113).cljs$core$IFn$_invoke$arity$1(env__25235__auto__))){
cljs.compiler.emits.call(null,"return ");
} else {
}

cljs.compiler.emits.call(null,"new cljs.core.Var(function(){return ",cljs.compiler.munge.call(null,name),";},",sym,",",meta,")");

if(cljs.core._EQ_.call(null,new cljs.core.Keyword(null,"expr","expr",745722291),new cljs.core.Keyword(null,"context","context",-830191113).cljs$core$IFn$_invoke$arity$1(env__25235__auto__))){
return null;
} else {
return cljs.compiler.emitln.call(null,";");
}
}));
cljs.core._add_method.call(null,cljs.compiler.emit_STAR_,new cljs.core.Keyword(null,"meta","meta",1499536964),(function (p__31154){
var map__31155 = p__31154;
var map__31155__$1 = ((((!((map__31155 == null)))?((((map__31155.cljs$lang$protocol_mask$partition0$ & (64))) || (map__31155.cljs$core$ISeq$))?true:false):false))?cljs.core.apply.call(null,cljs.core.hash_map,map__31155):map__31155);
var expr = cljs.core.get.call(null,map__31155__$1,new cljs.core.Keyword(null,"expr","expr",745722291));
var meta = cljs.core.get.call(null,map__31155__$1,new cljs.core.Keyword(null,"meta","meta",1499536964));
var env = cljs.core.get.call(null,map__31155__$1,new cljs.core.Keyword(null,"env","env",-1815813235));
var env__25235__auto__ = env;
if(cljs.core._EQ_.call(null,new cljs.core.Keyword(null,"return","return",-1891502105),new cljs.core.Keyword(null,"context","context",-830191113).cljs$core$IFn$_invoke$arity$1(env__25235__auto__))){
cljs.compiler.emits.call(null,"return ");
} else {
}

cljs.compiler.emits.call(null,"cljs.core.with_meta(",expr,",",meta,")");

if(cljs.core._EQ_.call(null,new cljs.core.Keyword(null,"expr","expr",745722291),new cljs.core.Keyword(null,"context","context",-830191113).cljs$core$IFn$_invoke$arity$1(env__25235__auto__))){
return null;
} else {
return cljs.compiler.emitln.call(null,";");
}
}));
cljs.compiler.array_map_threshold = (8);
cljs.compiler.distinct_keys_QMARK_ = (function cljs$compiler$distinct_keys_QMARK_(keys){
return (cljs.core.every_QMARK_.call(null,(function (p1__31157_SHARP_){
return cljs.core._EQ_.call(null,new cljs.core.Keyword(null,"op","op",-1882987955).cljs$core$IFn$_invoke$arity$1(p1__31157_SHARP_),new cljs.core.Keyword(null,"constant","constant",-379609303));
}),keys)) && (cljs.core._EQ_.call(null,cljs.core.count.call(null,cljs.core.into.call(null,cljs.core.PersistentHashSet.EMPTY,keys)),cljs.core.count.call(null,keys)));
});
cljs.core._add_method.call(null,cljs.compiler.emit_STAR_,new cljs.core.Keyword(null,"map","map",1371690461),(function (p__31158){
var map__31159 = p__31158;
var map__31159__$1 = ((((!((map__31159 == null)))?((((map__31159.cljs$lang$protocol_mask$partition0$ & (64))) || (map__31159.cljs$core$ISeq$))?true:false):false))?cljs.core.apply.call(null,cljs.core.hash_map,map__31159):map__31159);
var env = cljs.core.get.call(null,map__31159__$1,new cljs.core.Keyword(null,"env","env",-1815813235));
var keys = cljs.core.get.call(null,map__31159__$1,new cljs.core.Keyword(null,"keys","keys",1068423698));
var vals = cljs.core.get.call(null,map__31159__$1,new cljs.core.Keyword(null,"vals","vals",768058733));
var env__25235__auto__ = env;
if(cljs.core._EQ_.call(null,new cljs.core.Keyword(null,"return","return",-1891502105),new cljs.core.Keyword(null,"context","context",-830191113).cljs$core$IFn$_invoke$arity$1(env__25235__auto__))){
cljs.compiler.emits.call(null,"return ");
} else {
}

if((cljs.core.count.call(null,keys) === (0))){
cljs.compiler.emits.call(null,"cljs.core.PersistentArrayMap.EMPTY");
} else {
if((cljs.core.count.call(null,keys) <= cljs.compiler.array_map_threshold)){
if(cljs.core.truth_(cljs.compiler.distinct_keys_QMARK_.call(null,keys))){
cljs.compiler.emits.call(null,"new cljs.core.PersistentArrayMap(null, ",cljs.core.count.call(null,keys),", [",cljs.compiler.comma_sep.call(null,cljs.core.interleave.call(null,keys,vals)),"], null)");
} else {
cljs.compiler.emits.call(null,"cljs.core.PersistentArrayMap.fromArray([",cljs.compiler.comma_sep.call(null,cljs.core.interleave.call(null,keys,vals)),"], true, false)");
}
} else {
cljs.compiler.emits.call(null,"cljs.core.PersistentHashMap.fromArrays([",cljs.compiler.comma_sep.call(null,keys),"],[",cljs.compiler.comma_sep.call(null,vals),"])");

}
}

if(cljs.core._EQ_.call(null,new cljs.core.Keyword(null,"expr","expr",745722291),new cljs.core.Keyword(null,"context","context",-830191113).cljs$core$IFn$_invoke$arity$1(env__25235__auto__))){
return null;
} else {
return cljs.compiler.emitln.call(null,";");
}
}));
cljs.core._add_method.call(null,cljs.compiler.emit_STAR_,new cljs.core.Keyword(null,"list","list",765357683),(function (p__31161){
var map__31162 = p__31161;
var map__31162__$1 = ((((!((map__31162 == null)))?((((map__31162.cljs$lang$protocol_mask$partition0$ & (64))) || (map__31162.cljs$core$ISeq$))?true:false):false))?cljs.core.apply.call(null,cljs.core.hash_map,map__31162):map__31162);
var items = cljs.core.get.call(null,map__31162__$1,new cljs.core.Keyword(null,"items","items",1031954938));
var env = cljs.core.get.call(null,map__31162__$1,new cljs.core.Keyword(null,"env","env",-1815813235));
var env__25235__auto__ = env;
if(cljs.core._EQ_.call(null,new cljs.core.Keyword(null,"return","return",-1891502105),new cljs.core.Keyword(null,"context","context",-830191113).cljs$core$IFn$_invoke$arity$1(env__25235__auto__))){
cljs.compiler.emits.call(null,"return ");
} else {
}

if(cljs.core.empty_QMARK_.call(null,items)){
cljs.compiler.emits.call(null,"cljs.core.List.EMPTY");
} else {
cljs.compiler.emits.call(null,"cljs.core.list(",cljs.compiler.comma_sep.call(null,items),")");
}

if(cljs.core._EQ_.call(null,new cljs.core.Keyword(null,"expr","expr",745722291),new cljs.core.Keyword(null,"context","context",-830191113).cljs$core$IFn$_invoke$arity$1(env__25235__auto__))){
return null;
} else {
return cljs.compiler.emitln.call(null,";");
}
}));
cljs.core._add_method.call(null,cljs.compiler.emit_STAR_,new cljs.core.Keyword(null,"vector","vector",1902966158),(function (p__31164){
var map__31165 = p__31164;
var map__31165__$1 = ((((!((map__31165 == null)))?((((map__31165.cljs$lang$protocol_mask$partition0$ & (64))) || (map__31165.cljs$core$ISeq$))?true:false):false))?cljs.core.apply.call(null,cljs.core.hash_map,map__31165):map__31165);
var items = cljs.core.get.call(null,map__31165__$1,new cljs.core.Keyword(null,"items","items",1031954938));
var env = cljs.core.get.call(null,map__31165__$1,new cljs.core.Keyword(null,"env","env",-1815813235));
var env__25235__auto__ = env;
if(cljs.core._EQ_.call(null,new cljs.core.Keyword(null,"return","return",-1891502105),new cljs.core.Keyword(null,"context","context",-830191113).cljs$core$IFn$_invoke$arity$1(env__25235__auto__))){
cljs.compiler.emits.call(null,"return ");
} else {
}

if(cljs.core.empty_QMARK_.call(null,items)){
cljs.compiler.emits.call(null,"cljs.core.PersistentVector.EMPTY");
} else {
var cnt_31167 = cljs.core.count.call(null,items);
if((cnt_31167 < (32))){
cljs.compiler.emits.call(null,"new cljs.core.PersistentVector(null, ",cnt_31167,", 5, cljs.core.PersistentVector.EMPTY_NODE, [",cljs.compiler.comma_sep.call(null,items),"], null)");
} else {
cljs.compiler.emits.call(null,"cljs.core.PersistentVector.fromArray([",cljs.compiler.comma_sep.call(null,items),"], true)");
}
}

if(cljs.core._EQ_.call(null,new cljs.core.Keyword(null,"expr","expr",745722291),new cljs.core.Keyword(null,"context","context",-830191113).cljs$core$IFn$_invoke$arity$1(env__25235__auto__))){
return null;
} else {
return cljs.compiler.emitln.call(null,";");
}
}));
cljs.compiler.distinct_constants_QMARK_ = (function cljs$compiler$distinct_constants_QMARK_(items){
return (cljs.core.every_QMARK_.call(null,(function (p1__31168_SHARP_){
return cljs.core._EQ_.call(null,new cljs.core.Keyword(null,"op","op",-1882987955).cljs$core$IFn$_invoke$arity$1(p1__31168_SHARP_),new cljs.core.Keyword(null,"constant","constant",-379609303));
}),items)) && (cljs.core._EQ_.call(null,cljs.core.count.call(null,cljs.core.into.call(null,cljs.core.PersistentHashSet.EMPTY,items)),cljs.core.count.call(null,items)));
});
cljs.core._add_method.call(null,cljs.compiler.emit_STAR_,new cljs.core.Keyword(null,"set","set",304602554),(function (p__31169){
var map__31170 = p__31169;
var map__31170__$1 = ((((!((map__31170 == null)))?((((map__31170.cljs$lang$protocol_mask$partition0$ & (64))) || (map__31170.cljs$core$ISeq$))?true:false):false))?cljs.core.apply.call(null,cljs.core.hash_map,map__31170):map__31170);
var items = cljs.core.get.call(null,map__31170__$1,new cljs.core.Keyword(null,"items","items",1031954938));
var env = cljs.core.get.call(null,map__31170__$1,new cljs.core.Keyword(null,"env","env",-1815813235));
var env__25235__auto__ = env;
if(cljs.core._EQ_.call(null,new cljs.core.Keyword(null,"return","return",-1891502105),new cljs.core.Keyword(null,"context","context",-830191113).cljs$core$IFn$_invoke$arity$1(env__25235__auto__))){
cljs.compiler.emits.call(null,"return ");
} else {
}

if(cljs.core.empty_QMARK_.call(null,items)){
cljs.compiler.emits.call(null,"cljs.core.PersistentHashSet.EMPTY");
} else {
if(cljs.core.truth_(cljs.compiler.distinct_constants_QMARK_.call(null,items))){
cljs.compiler.emits.call(null,"new cljs.core.PersistentHashSet(null, new cljs.core.PersistentArrayMap(null, ",cljs.core.count.call(null,items),", [",cljs.compiler.comma_sep.call(null,cljs.core.interleave.call(null,items,cljs.core.repeat.call(null,"null"))),"], null), null)");
} else {
cljs.compiler.emits.call(null,"cljs.core.PersistentHashSet.fromArray([",cljs.compiler.comma_sep.call(null,items),"], true)");

}
}

if(cljs.core._EQ_.call(null,new cljs.core.Keyword(null,"expr","expr",745722291),new cljs.core.Keyword(null,"context","context",-830191113).cljs$core$IFn$_invoke$arity$1(env__25235__auto__))){
return null;
} else {
return cljs.compiler.emitln.call(null,";");
}
}));
cljs.core._add_method.call(null,cljs.compiler.emit_STAR_,new cljs.core.Keyword(null,"js-value","js-value",-758336661),(function (p__31172){
var map__31173 = p__31172;
var map__31173__$1 = ((((!((map__31173 == null)))?((((map__31173.cljs$lang$protocol_mask$partition0$ & (64))) || (map__31173.cljs$core$ISeq$))?true:false):false))?cljs.core.apply.call(null,cljs.core.hash_map,map__31173):map__31173);
var items = cljs.core.get.call(null,map__31173__$1,new cljs.core.Keyword(null,"items","items",1031954938));
var js_type = cljs.core.get.call(null,map__31173__$1,new cljs.core.Keyword(null,"js-type","js-type",539386702));
var env = cljs.core.get.call(null,map__31173__$1,new cljs.core.Keyword(null,"env","env",-1815813235));
var env__25235__auto__ = env;
if(cljs.core._EQ_.call(null,new cljs.core.Keyword(null,"return","return",-1891502105),new cljs.core.Keyword(null,"context","context",-830191113).cljs$core$IFn$_invoke$arity$1(env__25235__auto__))){
cljs.compiler.emits.call(null,"return ");
} else {
}

if(cljs.core._EQ_.call(null,js_type,new cljs.core.Keyword(null,"object","object",1474613949))){
cljs.compiler.emits.call(null,"{");

var temp__4657__auto___31183 = cljs.core.seq.call(null,items);
if(temp__4657__auto___31183){
var items_31184__$1 = temp__4657__auto___31183;
var vec__31175_31185 = items_31184__$1;
var vec__31176_31186 = cljs.core.nth.call(null,vec__31175_31185,(0),null);
var k_31187 = cljs.core.nth.call(null,vec__31176_31186,(0),null);
var v_31188 = cljs.core.nth.call(null,vec__31176_31186,(1),null);
var r_31189 = cljs.core.nthnext.call(null,vec__31175_31185,(1));
cljs.compiler.emits.call(null,"\"",cljs.core.name.call(null,k_31187),"\": ",v_31188);

var seq__31177_31190 = cljs.core.seq.call(null,r_31189);
var chunk__31178_31191 = null;
var count__31179_31192 = (0);
var i__31180_31193 = (0);
while(true){
if((i__31180_31193 < count__31179_31192)){
var vec__31181_31194 = cljs.core._nth.call(null,chunk__31178_31191,i__31180_31193);
var k_31195__$1 = cljs.core.nth.call(null,vec__31181_31194,(0),null);
var v_31196__$1 = cljs.core.nth.call(null,vec__31181_31194,(1),null);
cljs.compiler.emits.call(null,", \"",cljs.core.name.call(null,k_31195__$1),"\": ",v_31196__$1);

var G__31197 = seq__31177_31190;
var G__31198 = chunk__31178_31191;
var G__31199 = count__31179_31192;
var G__31200 = (i__31180_31193 + (1));
seq__31177_31190 = G__31197;
chunk__31178_31191 = G__31198;
count__31179_31192 = G__31199;
i__31180_31193 = G__31200;
continue;
} else {
var temp__4657__auto___31201__$1 = cljs.core.seq.call(null,seq__31177_31190);
if(temp__4657__auto___31201__$1){
var seq__31177_31202__$1 = temp__4657__auto___31201__$1;
if(cljs.core.chunked_seq_QMARK_.call(null,seq__31177_31202__$1)){
var c__23723__auto___31203 = cljs.core.chunk_first.call(null,seq__31177_31202__$1);
var G__31204 = cljs.core.chunk_rest.call(null,seq__31177_31202__$1);
var G__31205 = c__23723__auto___31203;
var G__31206 = cljs.core.count.call(null,c__23723__auto___31203);
var G__31207 = (0);
seq__31177_31190 = G__31204;
chunk__31178_31191 = G__31205;
count__31179_31192 = G__31206;
i__31180_31193 = G__31207;
continue;
} else {
var vec__31182_31208 = cljs.core.first.call(null,seq__31177_31202__$1);
var k_31209__$1 = cljs.core.nth.call(null,vec__31182_31208,(0),null);
var v_31210__$1 = cljs.core.nth.call(null,vec__31182_31208,(1),null);
cljs.compiler.emits.call(null,", \"",cljs.core.name.call(null,k_31209__$1),"\": ",v_31210__$1);

var G__31211 = cljs.core.next.call(null,seq__31177_31202__$1);
var G__31212 = null;
var G__31213 = (0);
var G__31214 = (0);
seq__31177_31190 = G__31211;
chunk__31178_31191 = G__31212;
count__31179_31192 = G__31213;
i__31180_31193 = G__31214;
continue;
}
} else {
}
}
break;
}
} else {
}

cljs.compiler.emits.call(null,"}");
} else {
cljs.compiler.emits.call(null,"[",cljs.compiler.comma_sep.call(null,items),"]");
}

if(cljs.core._EQ_.call(null,new cljs.core.Keyword(null,"expr","expr",745722291),new cljs.core.Keyword(null,"context","context",-830191113).cljs$core$IFn$_invoke$arity$1(env__25235__auto__))){
return null;
} else {
return cljs.compiler.emitln.call(null,";");
}
}));
cljs.core._add_method.call(null,cljs.compiler.emit_STAR_,new cljs.core.Keyword(null,"constant","constant",-379609303),(function (p__31215){
var map__31216 = p__31215;
var map__31216__$1 = ((((!((map__31216 == null)))?((((map__31216.cljs$lang$protocol_mask$partition0$ & (64))) || (map__31216.cljs$core$ISeq$))?true:false):false))?cljs.core.apply.call(null,cljs.core.hash_map,map__31216):map__31216);
var form = cljs.core.get.call(null,map__31216__$1,new cljs.core.Keyword(null,"form","form",-1624062471));
var env = cljs.core.get.call(null,map__31216__$1,new cljs.core.Keyword(null,"env","env",-1815813235));
if(cljs.core._EQ_.call(null,new cljs.core.Keyword(null,"statement","statement",-32780863),new cljs.core.Keyword(null,"context","context",-830191113).cljs$core$IFn$_invoke$arity$1(env))){
return null;
} else {
var env__25235__auto__ = env;
if(cljs.core._EQ_.call(null,new cljs.core.Keyword(null,"return","return",-1891502105),new cljs.core.Keyword(null,"context","context",-830191113).cljs$core$IFn$_invoke$arity$1(env__25235__auto__))){
cljs.compiler.emits.call(null,"return ");
} else {
}

cljs.compiler.emit_constant.call(null,form);

if(cljs.core._EQ_.call(null,new cljs.core.Keyword(null,"expr","expr",745722291),new cljs.core.Keyword(null,"context","context",-830191113).cljs$core$IFn$_invoke$arity$1(env__25235__auto__))){
return null;
} else {
return cljs.compiler.emitln.call(null,";");
}
}
}));
cljs.compiler.truthy_constant_QMARK_ = (function cljs$compiler$truthy_constant_QMARK_(p__31218){
var map__31221 = p__31218;
var map__31221__$1 = ((((!((map__31221 == null)))?((((map__31221.cljs$lang$protocol_mask$partition0$ & (64))) || (map__31221.cljs$core$ISeq$))?true:false):false))?cljs.core.apply.call(null,cljs.core.hash_map,map__31221):map__31221);
var op = cljs.core.get.call(null,map__31221__$1,new cljs.core.Keyword(null,"op","op",-1882987955));
var form = cljs.core.get.call(null,map__31221__$1,new cljs.core.Keyword(null,"form","form",-1624062471));
var and__22900__auto__ = cljs.core._EQ_.call(null,op,new cljs.core.Keyword(null,"constant","constant",-379609303));
if(and__22900__auto__){
var and__22900__auto____$1 = form;
if(cljs.core.truth_(and__22900__auto____$1)){
return !(((typeof form === 'string') && (cljs.core._EQ_.call(null,form,""))) || ((typeof form === 'number') && ((form === (0)))));
} else {
return and__22900__auto____$1;
}
} else {
return and__22900__auto__;
}
});
cljs.compiler.falsey_constant_QMARK_ = (function cljs$compiler$falsey_constant_QMARK_(p__31223){
var map__31226 = p__31223;
var map__31226__$1 = ((((!((map__31226 == null)))?((((map__31226.cljs$lang$protocol_mask$partition0$ & (64))) || (map__31226.cljs$core$ISeq$))?true:false):false))?cljs.core.apply.call(null,cljs.core.hash_map,map__31226):map__31226);
var op = cljs.core.get.call(null,map__31226__$1,new cljs.core.Keyword(null,"op","op",-1882987955));
var form = cljs.core.get.call(null,map__31226__$1,new cljs.core.Keyword(null,"form","form",-1624062471));
return (cljs.core._EQ_.call(null,op,new cljs.core.Keyword(null,"constant","constant",-379609303))) && ((form === false) || ((form == null)));
});
cljs.compiler.safe_test_QMARK_ = (function cljs$compiler$safe_test_QMARK_(env,e){
var tag = cljs.analyzer.infer_tag.call(null,env,e);
var or__22912__auto__ = new cljs.core.PersistentHashSet(null, new cljs.core.PersistentArrayMap(null, 2, [new cljs.core.Symbol(null,"seq","seq",-177272256,null),null,new cljs.core.Symbol(null,"boolean","boolean",-278886877,null),null], null), null).call(null,tag);
if(cljs.core.truth_(or__22912__auto__)){
return or__22912__auto__;
} else {
return cljs.compiler.truthy_constant_QMARK_.call(null,e);
}
});
cljs.core._add_method.call(null,cljs.compiler.emit_STAR_,new cljs.core.Keyword(null,"if","if",-458814265),(function (p__31228){
var map__31229 = p__31228;
var map__31229__$1 = ((((!((map__31229 == null)))?((((map__31229.cljs$lang$protocol_mask$partition0$ & (64))) || (map__31229.cljs$core$ISeq$))?true:false):false))?cljs.core.apply.call(null,cljs.core.hash_map,map__31229):map__31229);
var test = cljs.core.get.call(null,map__31229__$1,new cljs.core.Keyword(null,"test","test",577538877));
var then = cljs.core.get.call(null,map__31229__$1,new cljs.core.Keyword(null,"then","then",460598070));
var else$ = cljs.core.get.call(null,map__31229__$1,new cljs.core.Keyword(null,"else","else",-1508377146));
var env = cljs.core.get.call(null,map__31229__$1,new cljs.core.Keyword(null,"env","env",-1815813235));
var unchecked = cljs.core.get.call(null,map__31229__$1,new cljs.core.Keyword(null,"unchecked","unchecked",924418378));
var context = new cljs.core.Keyword(null,"context","context",-830191113).cljs$core$IFn$_invoke$arity$1(env);
var checked = cljs.core.not.call(null,(function (){var or__22912__auto__ = unchecked;
if(cljs.core.truth_(or__22912__auto__)){
return or__22912__auto__;
} else {
return cljs.compiler.safe_test_QMARK_.call(null,env,test);
}
})());
if(cljs.core.truth_(cljs.compiler.truthy_constant_QMARK_.call(null,test))){
return cljs.compiler.emitln.call(null,then);
} else {
if(cljs.core.truth_(cljs.compiler.falsey_constant_QMARK_.call(null,test))){
return cljs.compiler.emitln.call(null,else$);
} else {
if(cljs.core._EQ_.call(null,new cljs.core.Keyword(null,"expr","expr",745722291),context)){
return cljs.compiler.emits.call(null,"(",((checked)?"cljs.core.truth_":null),"(",test,")?",then,":",else$,")");
} else {
if(checked){
cljs.compiler.emitln.call(null,"if(cljs.core.truth_(",test,")){");
} else {
cljs.compiler.emitln.call(null,"if(",test,"){");
}

cljs.compiler.emitln.call(null,then,"} else {");

return cljs.compiler.emitln.call(null,else$,"}");
}

}
}
}));
cljs.core._add_method.call(null,cljs.compiler.emit_STAR_,new cljs.core.Keyword(null,"case*","case*",716180697),(function (p__31231){
var map__31232 = p__31231;
var map__31232__$1 = ((((!((map__31232 == null)))?((((map__31232.cljs$lang$protocol_mask$partition0$ & (64))) || (map__31232.cljs$core$ISeq$))?true:false):false))?cljs.core.apply.call(null,cljs.core.hash_map,map__31232):map__31232);
var v = cljs.core.get.call(null,map__31232__$1,new cljs.core.Keyword(null,"v","v",21465059));
var tests = cljs.core.get.call(null,map__31232__$1,new cljs.core.Keyword(null,"tests","tests",-1041085625));
var thens = cljs.core.get.call(null,map__31232__$1,new cljs.core.Keyword(null,"thens","thens",226631442));
var default$ = cljs.core.get.call(null,map__31232__$1,new cljs.core.Keyword(null,"default","default",-1987822328));
var env = cljs.core.get.call(null,map__31232__$1,new cljs.core.Keyword(null,"env","env",-1815813235));
if(cljs.core._EQ_.call(null,new cljs.core.Keyword(null,"context","context",-830191113).cljs$core$IFn$_invoke$arity$1(env),new cljs.core.Keyword(null,"expr","expr",745722291))){
cljs.compiler.emitln.call(null,"(function(){");
} else {
}

var gs = cljs.core.gensym.call(null,"caseval__");
if(cljs.core._EQ_.call(null,new cljs.core.Keyword(null,"expr","expr",745722291),new cljs.core.Keyword(null,"context","context",-830191113).cljs$core$IFn$_invoke$arity$1(env))){
cljs.compiler.emitln.call(null,"var ",gs,";");
} else {
}

cljs.compiler.emitln.call(null,"switch (",v,") {");

var seq__31234_31248 = cljs.core.seq.call(null,cljs.core.partition.call(null,(2),cljs.core.interleave.call(null,tests,thens)));
var chunk__31235_31249 = null;
var count__31236_31250 = (0);
var i__31237_31251 = (0);
while(true){
if((i__31237_31251 < count__31236_31250)){
var vec__31238_31252 = cljs.core._nth.call(null,chunk__31235_31249,i__31237_31251);
var ts_31253 = cljs.core.nth.call(null,vec__31238_31252,(0),null);
var then_31254 = cljs.core.nth.call(null,vec__31238_31252,(1),null);
var seq__31239_31255 = cljs.core.seq.call(null,ts_31253);
var chunk__31240_31256 = null;
var count__31241_31257 = (0);
var i__31242_31258 = (0);
while(true){
if((i__31242_31258 < count__31241_31257)){
var test_31259 = cljs.core._nth.call(null,chunk__31240_31256,i__31242_31258);
cljs.compiler.emitln.call(null,"case ",test_31259,":");

var G__31260 = seq__31239_31255;
var G__31261 = chunk__31240_31256;
var G__31262 = count__31241_31257;
var G__31263 = (i__31242_31258 + (1));
seq__31239_31255 = G__31260;
chunk__31240_31256 = G__31261;
count__31241_31257 = G__31262;
i__31242_31258 = G__31263;
continue;
} else {
var temp__4657__auto___31264 = cljs.core.seq.call(null,seq__31239_31255);
if(temp__4657__auto___31264){
var seq__31239_31265__$1 = temp__4657__auto___31264;
if(cljs.core.chunked_seq_QMARK_.call(null,seq__31239_31265__$1)){
var c__23723__auto___31266 = cljs.core.chunk_first.call(null,seq__31239_31265__$1);
var G__31267 = cljs.core.chunk_rest.call(null,seq__31239_31265__$1);
var G__31268 = c__23723__auto___31266;
var G__31269 = cljs.core.count.call(null,c__23723__auto___31266);
var G__31270 = (0);
seq__31239_31255 = G__31267;
chunk__31240_31256 = G__31268;
count__31241_31257 = G__31269;
i__31242_31258 = G__31270;
continue;
} else {
var test_31271 = cljs.core.first.call(null,seq__31239_31265__$1);
cljs.compiler.emitln.call(null,"case ",test_31271,":");

var G__31272 = cljs.core.next.call(null,seq__31239_31265__$1);
var G__31273 = null;
var G__31274 = (0);
var G__31275 = (0);
seq__31239_31255 = G__31272;
chunk__31240_31256 = G__31273;
count__31241_31257 = G__31274;
i__31242_31258 = G__31275;
continue;
}
} else {
}
}
break;
}

if(cljs.core._EQ_.call(null,new cljs.core.Keyword(null,"expr","expr",745722291),new cljs.core.Keyword(null,"context","context",-830191113).cljs$core$IFn$_invoke$arity$1(env))){
cljs.compiler.emitln.call(null,gs,"=",then_31254);
} else {
cljs.compiler.emitln.call(null,then_31254);
}

cljs.compiler.emitln.call(null,"break;");

var G__31276 = seq__31234_31248;
var G__31277 = chunk__31235_31249;
var G__31278 = count__31236_31250;
var G__31279 = (i__31237_31251 + (1));
seq__31234_31248 = G__31276;
chunk__31235_31249 = G__31277;
count__31236_31250 = G__31278;
i__31237_31251 = G__31279;
continue;
} else {
var temp__4657__auto___31280 = cljs.core.seq.call(null,seq__31234_31248);
if(temp__4657__auto___31280){
var seq__31234_31281__$1 = temp__4657__auto___31280;
if(cljs.core.chunked_seq_QMARK_.call(null,seq__31234_31281__$1)){
var c__23723__auto___31282 = cljs.core.chunk_first.call(null,seq__31234_31281__$1);
var G__31283 = cljs.core.chunk_rest.call(null,seq__31234_31281__$1);
var G__31284 = c__23723__auto___31282;
var G__31285 = cljs.core.count.call(null,c__23723__auto___31282);
var G__31286 = (0);
seq__31234_31248 = G__31283;
chunk__31235_31249 = G__31284;
count__31236_31250 = G__31285;
i__31237_31251 = G__31286;
continue;
} else {
var vec__31243_31287 = cljs.core.first.call(null,seq__31234_31281__$1);
var ts_31288 = cljs.core.nth.call(null,vec__31243_31287,(0),null);
var then_31289 = cljs.core.nth.call(null,vec__31243_31287,(1),null);
var seq__31244_31290 = cljs.core.seq.call(null,ts_31288);
var chunk__31245_31291 = null;
var count__31246_31292 = (0);
var i__31247_31293 = (0);
while(true){
if((i__31247_31293 < count__31246_31292)){
var test_31294 = cljs.core._nth.call(null,chunk__31245_31291,i__31247_31293);
cljs.compiler.emitln.call(null,"case ",test_31294,":");

var G__31295 = seq__31244_31290;
var G__31296 = chunk__31245_31291;
var G__31297 = count__31246_31292;
var G__31298 = (i__31247_31293 + (1));
seq__31244_31290 = G__31295;
chunk__31245_31291 = G__31296;
count__31246_31292 = G__31297;
i__31247_31293 = G__31298;
continue;
} else {
var temp__4657__auto___31299__$1 = cljs.core.seq.call(null,seq__31244_31290);
if(temp__4657__auto___31299__$1){
var seq__31244_31300__$1 = temp__4657__auto___31299__$1;
if(cljs.core.chunked_seq_QMARK_.call(null,seq__31244_31300__$1)){
var c__23723__auto___31301 = cljs.core.chunk_first.call(null,seq__31244_31300__$1);
var G__31302 = cljs.core.chunk_rest.call(null,seq__31244_31300__$1);
var G__31303 = c__23723__auto___31301;
var G__31304 = cljs.core.count.call(null,c__23723__auto___31301);
var G__31305 = (0);
seq__31244_31290 = G__31302;
chunk__31245_31291 = G__31303;
count__31246_31292 = G__31304;
i__31247_31293 = G__31305;
continue;
} else {
var test_31306 = cljs.core.first.call(null,seq__31244_31300__$1);
cljs.compiler.emitln.call(null,"case ",test_31306,":");

var G__31307 = cljs.core.next.call(null,seq__31244_31300__$1);
var G__31308 = null;
var G__31309 = (0);
var G__31310 = (0);
seq__31244_31290 = G__31307;
chunk__31245_31291 = G__31308;
count__31246_31292 = G__31309;
i__31247_31293 = G__31310;
continue;
}
} else {
}
}
break;
}

if(cljs.core._EQ_.call(null,new cljs.core.Keyword(null,"expr","expr",745722291),new cljs.core.Keyword(null,"context","context",-830191113).cljs$core$IFn$_invoke$arity$1(env))){
cljs.compiler.emitln.call(null,gs,"=",then_31289);
} else {
cljs.compiler.emitln.call(null,then_31289);
}

cljs.compiler.emitln.call(null,"break;");

var G__31311 = cljs.core.next.call(null,seq__31234_31281__$1);
var G__31312 = null;
var G__31313 = (0);
var G__31314 = (0);
seq__31234_31248 = G__31311;
chunk__31235_31249 = G__31312;
count__31236_31250 = G__31313;
i__31237_31251 = G__31314;
continue;
}
} else {
}
}
break;
}

if(cljs.core.truth_(default$)){
cljs.compiler.emitln.call(null,"default:");

if(cljs.core._EQ_.call(null,new cljs.core.Keyword(null,"expr","expr",745722291),new cljs.core.Keyword(null,"context","context",-830191113).cljs$core$IFn$_invoke$arity$1(env))){
cljs.compiler.emitln.call(null,gs,"=",default$);
} else {
cljs.compiler.emitln.call(null,default$);
}
} else {
}

cljs.compiler.emitln.call(null,"}");

if(cljs.core._EQ_.call(null,new cljs.core.Keyword(null,"expr","expr",745722291),new cljs.core.Keyword(null,"context","context",-830191113).cljs$core$IFn$_invoke$arity$1(env))){
return cljs.compiler.emitln.call(null,"return ",gs,";})()");
} else {
return null;
}
}));
cljs.core._add_method.call(null,cljs.compiler.emit_STAR_,new cljs.core.Keyword(null,"throw","throw",-1044625833),(function (p__31315){
var map__31316 = p__31315;
var map__31316__$1 = ((((!((map__31316 == null)))?((((map__31316.cljs$lang$protocol_mask$partition0$ & (64))) || (map__31316.cljs$core$ISeq$))?true:false):false))?cljs.core.apply.call(null,cljs.core.hash_map,map__31316):map__31316);
var throw$ = cljs.core.get.call(null,map__31316__$1,new cljs.core.Keyword(null,"throw","throw",-1044625833));
var env = cljs.core.get.call(null,map__31316__$1,new cljs.core.Keyword(null,"env","env",-1815813235));
if(cljs.core._EQ_.call(null,new cljs.core.Keyword(null,"expr","expr",745722291),new cljs.core.Keyword(null,"context","context",-830191113).cljs$core$IFn$_invoke$arity$1(env))){
return cljs.compiler.emits.call(null,"(function(){throw ",throw$,"})()");
} else {
return cljs.compiler.emitln.call(null,"throw ",throw$,";");
}
}));
cljs.compiler.base_types = new cljs.core.PersistentHashSet(null, new cljs.core.PersistentArrayMap(null, 15, ["boolean",null,"object",null,"*",null,"string",null,"Object",null,"Number",null,"null",null,"Date",null,"number",null,"String",null,"RegExp",null,"...*",null,"Array",null,"array",null,"Boolean",null], null), null);
cljs.compiler.mapped_types = new cljs.core.PersistentArrayMap(null, 1, ["nil","null"], null);
cljs.compiler.resolve_type = (function cljs$compiler$resolve_type(env,t){
if(cljs.core.truth_(cljs.core.get.call(null,cljs.compiler.base_types,t))){
return t;
} else {
if(cljs.core.truth_(cljs.core.get.call(null,cljs.compiler.mapped_types,t))){
return cljs.core.get.call(null,cljs.compiler.mapped_types,t);
} else {
if(cljs.core.truth_(goog.string.startsWith(t,"!"))){
return [cljs.core.str("!"),cljs.core.str(cljs$compiler$resolve_type.call(null,env,cljs.core.subs.call(null,t,(1))))].join('');
} else {
if(cljs.core.truth_(goog.string.startsWith(t,"{"))){
return t;
} else {
if(cljs.core.truth_(goog.string.startsWith(t,"function"))){
var idx = t.lastIndexOf(":");
var vec__31321 = ((!(((-1) === idx)))?new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.subs.call(null,t,(0),idx),cljs.core.subs.call(null,t,(idx + (1)),cljs.core.count.call(null,t))], null):new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [t,null], null));
var fstr = cljs.core.nth.call(null,vec__31321,(0),null);
var rstr = cljs.core.nth.call(null,vec__31321,(1),null);
var ret_t = (cljs.core.truth_(rstr)?cljs$compiler$resolve_type.call(null,env,rstr):null);
var axstr = cljs.core.subs.call(null,fstr,(9),(cljs.core.count.call(null,fstr) - (1)));
var args_ts = ((clojure.string.blank_QMARK_.call(null,axstr))?null:cljs.core.map.call(null,cljs.core.comp.call(null,((function (idx,vec__31321,fstr,rstr,ret_t,axstr){
return (function (p1__31318_SHARP_){
return cljs$compiler$resolve_type.call(null,env,p1__31318_SHARP_);
});})(idx,vec__31321,fstr,rstr,ret_t,axstr))
,clojure.string.trim),clojure.string.split.call(null,axstr,/,/)));
var G__31322 = [cljs.core.str("function("),cljs.core.str(clojure.string.join.call(null,",",args_ts)),cljs.core.str(")")].join('');
if(cljs.core.truth_(ret_t)){
return [cljs.core.str(G__31322),cljs.core.str(":"),cljs.core.str(ret_t)].join('');
} else {
return G__31322;
}
} else {
if(cljs.core.truth_(goog.string.endsWith(t,"="))){
return [cljs.core.str(cljs$compiler$resolve_type.call(null,env,cljs.core.subs.call(null,t,(0),(cljs.core.count.call(null,t) - (1))))),cljs.core.str("=")].join('');
} else {
return cljs.compiler.munge.call(null,[cljs.core.str(new cljs.core.Keyword(null,"name","name",1843675177).cljs$core$IFn$_invoke$arity$1(cljs.analyzer.resolve_var.call(null,env,cljs.core.symbol.call(null,t))))].join(''));

}
}
}
}
}
}
});
cljs.compiler.resolve_types = (function cljs$compiler$resolve_types(env,ts){
var ts__$1 = cljs.core.subs.call(null,clojure.string.trim.call(null,ts),(1),(cljs.core.count.call(null,ts) - (1)));
var xs = clojure.string.split.call(null,ts__$1,/\|/);
return [cljs.core.str("{"),cljs.core.str(clojure.string.join.call(null,"|",cljs.core.map.call(null,((function (ts__$1,xs){
return (function (p1__31323_SHARP_){
return cljs.compiler.resolve_type.call(null,env,p1__31323_SHARP_);
});})(ts__$1,xs))
,xs))),cljs.core.str("}")].join('');
});
cljs.compiler.munge_param_return = (function cljs$compiler$munge_param_return(env,line){
if(cljs.core.truth_(cljs.core.re_find.call(null,/@param/,line))){
var vec__31326 = cljs.core.map.call(null,clojure.string.trim,clojure.string.split.call(null,clojure.string.trim.call(null,line),/ /));
var p = cljs.core.nth.call(null,vec__31326,(0),null);
var ts = cljs.core.nth.call(null,vec__31326,(1),null);
var n = cljs.core.nth.call(null,vec__31326,(2),null);
var xs = cljs.core.nthnext.call(null,vec__31326,(3));
if(cljs.core.truth_((function (){var and__22900__auto__ = cljs.core._EQ_.call(null,"@param",p);
if(and__22900__auto__){
var and__22900__auto____$1 = ts;
if(cljs.core.truth_(and__22900__auto____$1)){
return goog.string.startsWith(ts,"{");
} else {
return and__22900__auto____$1;
}
} else {
return and__22900__auto__;
}
})())){
return clojure.string.join.call(null," ",cljs.core.concat.call(null,new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [p,cljs.compiler.resolve_types.call(null,env,ts),cljs.compiler.munge.call(null,n)], null),xs));
} else {
return line;
}
} else {
if(cljs.core.truth_(cljs.core.re_find.call(null,/@return/,line))){
var vec__31327 = cljs.core.map.call(null,clojure.string.trim,clojure.string.split.call(null,clojure.string.trim.call(null,line),/ /));
var p = cljs.core.nth.call(null,vec__31327,(0),null);
var ts = cljs.core.nth.call(null,vec__31327,(1),null);
var xs = cljs.core.nthnext.call(null,vec__31327,(2));
if(cljs.core.truth_((function (){var and__22900__auto__ = cljs.core._EQ_.call(null,"@return",p);
if(and__22900__auto__){
var and__22900__auto____$1 = ts;
if(cljs.core.truth_(and__22900__auto____$1)){
return goog.string.startsWith(ts,"{");
} else {
return and__22900__auto____$1;
}
} else {
return and__22900__auto__;
}
})())){
return clojure.string.join.call(null," ",cljs.core.concat.call(null,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [p,cljs.compiler.resolve_types.call(null,env,ts)], null),xs));
} else {
return line;
}
} else {
return line;

}
}
});
cljs.compiler.checking_types_QMARK_ = (function cljs$compiler$checking_types_QMARK_(){
return new cljs.core.PersistentHashSet(null, new cljs.core.PersistentArrayMap(null, 2, [new cljs.core.Keyword(null,"warn","warn",-436710552),null,new cljs.core.Keyword(null,"error","error",-978969032),null], null), null).call(null,cljs.core.get_in.call(null,cljs.core.deref.call(null,cljs.env._STAR_compiler_STAR_),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword(null,"options","options",99638489),new cljs.core.Keyword(null,"closure-warnings","closure-warnings",1362834211),new cljs.core.Keyword(null,"check-types","check-types",-833794607)], null)));
});
/**
 * Emit a nicely formatted comment string.
 */
cljs.compiler.emit_comment = (function cljs$compiler$emit_comment(var_args){
var args31329 = [];
var len__23982__auto___31356 = arguments.length;
var i__23983__auto___31357 = (0);
while(true){
if((i__23983__auto___31357 < len__23982__auto___31356)){
args31329.push((arguments[i__23983__auto___31357]));

var G__31358 = (i__23983__auto___31357 + (1));
i__23983__auto___31357 = G__31358;
continue;
} else {
}
break;
}

var G__31331 = args31329.length;
switch (G__31331) {
case 2:
return cljs.compiler.emit_comment.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.compiler.emit_comment.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error([cljs.core.str("Invalid arity: "),cljs.core.str(args31329.length)].join('')));

}
});

cljs.compiler.emit_comment.cljs$core$IFn$_invoke$arity$2 = (function (doc,jsdoc){
return cljs.compiler.emit_comment.call(null,null,doc,jsdoc);
});

cljs.compiler.emit_comment.cljs$core$IFn$_invoke$arity$3 = (function (env,doc,jsdoc){
var docs = (cljs.core.truth_(doc)?new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [doc], null):null);
var docs__$1 = (cljs.core.truth_(jsdoc)?cljs.core.concat.call(null,docs,jsdoc):docs);
var docs__$2 = cljs.core.remove.call(null,cljs.core.nil_QMARK_,docs__$1);
var print_comment_lines = ((function (docs,docs__$1,docs__$2){
return (function cljs$compiler$print_comment_lines(e){
var vec__31347 = cljs.core.map.call(null,((function (docs,docs__$1,docs__$2){
return (function (p1__31328_SHARP_){
if(cljs.core.truth_(cljs.compiler.checking_types_QMARK_.call(null))){
return cljs.compiler.munge_param_return.call(null,env,p1__31328_SHARP_);
} else {
return p1__31328_SHARP_;
}
});})(docs,docs__$1,docs__$2))
,clojure.string.split_lines.call(null,e));
var x = cljs.core.nth.call(null,vec__31347,(0),null);
var ys = cljs.core.nthnext.call(null,vec__31347,(1));
cljs.compiler.emitln.call(null," * ",clojure.string.replace.call(null,x,"*/","* /"));

var seq__31348 = cljs.core.seq.call(null,ys);
var chunk__31349 = null;
var count__31350 = (0);
var i__31351 = (0);
while(true){
if((i__31351 < count__31350)){
var next_line = cljs.core._nth.call(null,chunk__31349,i__31351);
cljs.compiler.emitln.call(null," * ",clojure.string.replace.call(null,clojure.string.replace.call(null,next_line,/^   /,""),"*/","* /"));

var G__31360 = seq__31348;
var G__31361 = chunk__31349;
var G__31362 = count__31350;
var G__31363 = (i__31351 + (1));
seq__31348 = G__31360;
chunk__31349 = G__31361;
count__31350 = G__31362;
i__31351 = G__31363;
continue;
} else {
var temp__4657__auto__ = cljs.core.seq.call(null,seq__31348);
if(temp__4657__auto__){
var seq__31348__$1 = temp__4657__auto__;
if(cljs.core.chunked_seq_QMARK_.call(null,seq__31348__$1)){
var c__23723__auto__ = cljs.core.chunk_first.call(null,seq__31348__$1);
var G__31364 = cljs.core.chunk_rest.call(null,seq__31348__$1);
var G__31365 = c__23723__auto__;
var G__31366 = cljs.core.count.call(null,c__23723__auto__);
var G__31367 = (0);
seq__31348 = G__31364;
chunk__31349 = G__31365;
count__31350 = G__31366;
i__31351 = G__31367;
continue;
} else {
var next_line = cljs.core.first.call(null,seq__31348__$1);
cljs.compiler.emitln.call(null," * ",clojure.string.replace.call(null,clojure.string.replace.call(null,next_line,/^   /,""),"*/","* /"));

var G__31368 = cljs.core.next.call(null,seq__31348__$1);
var G__31369 = null;
var G__31370 = (0);
var G__31371 = (0);
seq__31348 = G__31368;
chunk__31349 = G__31369;
count__31350 = G__31370;
i__31351 = G__31371;
continue;
}
} else {
return null;
}
}
break;
}
});})(docs,docs__$1,docs__$2))
;
if(cljs.core.seq.call(null,docs__$2)){
cljs.compiler.emitln.call(null,"/**");

var seq__31352_31372 = cljs.core.seq.call(null,docs__$2);
var chunk__31353_31373 = null;
var count__31354_31374 = (0);
var i__31355_31375 = (0);
while(true){
if((i__31355_31375 < count__31354_31374)){
var e_31376 = cljs.core._nth.call(null,chunk__31353_31373,i__31355_31375);
if(cljs.core.truth_(e_31376)){
print_comment_lines.call(null,e_31376);
} else {
}

var G__31377 = seq__31352_31372;
var G__31378 = chunk__31353_31373;
var G__31379 = count__31354_31374;
var G__31380 = (i__31355_31375 + (1));
seq__31352_31372 = G__31377;
chunk__31353_31373 = G__31378;
count__31354_31374 = G__31379;
i__31355_31375 = G__31380;
continue;
} else {
var temp__4657__auto___31381 = cljs.core.seq.call(null,seq__31352_31372);
if(temp__4657__auto___31381){
var seq__31352_31382__$1 = temp__4657__auto___31381;
if(cljs.core.chunked_seq_QMARK_.call(null,seq__31352_31382__$1)){
var c__23723__auto___31383 = cljs.core.chunk_first.call(null,seq__31352_31382__$1);
var G__31384 = cljs.core.chunk_rest.call(null,seq__31352_31382__$1);
var G__31385 = c__23723__auto___31383;
var G__31386 = cljs.core.count.call(null,c__23723__auto___31383);
var G__31387 = (0);
seq__31352_31372 = G__31384;
chunk__31353_31373 = G__31385;
count__31354_31374 = G__31386;
i__31355_31375 = G__31387;
continue;
} else {
var e_31388 = cljs.core.first.call(null,seq__31352_31382__$1);
if(cljs.core.truth_(e_31388)){
print_comment_lines.call(null,e_31388);
} else {
}

var G__31389 = cljs.core.next.call(null,seq__31352_31382__$1);
var G__31390 = null;
var G__31391 = (0);
var G__31392 = (0);
seq__31352_31372 = G__31389;
chunk__31353_31373 = G__31390;
count__31354_31374 = G__31391;
i__31355_31375 = G__31392;
continue;
}
} else {
}
}
break;
}

return cljs.compiler.emitln.call(null," */");
} else {
return null;
}
});

cljs.compiler.emit_comment.cljs$lang$maxFixedArity = 3;
cljs.compiler.valid_define_value_QMARK_ = (function cljs$compiler$valid_define_value_QMARK_(x){
return (typeof x === 'string') || (x === true) || (x === false) || (typeof x === 'number');
});
cljs.compiler.get_define = (function cljs$compiler$get_define(mname,jsdoc){
var opts = cljs.core.get.call(null,cljs.core.deref.call(null,cljs.env._STAR_compiler_STAR_),new cljs.core.Keyword(null,"options","options",99638489));
var and__22900__auto__ = cljs.core.some.call(null,((function (opts){
return (function (p1__31394_SHARP_){
return goog.string.startsWith(p1__31394_SHARP_,"@define");
});})(opts))
,jsdoc);
if(cljs.core.truth_(and__22900__auto__)){
var and__22900__auto____$1 = opts;
if(cljs.core.truth_(and__22900__auto____$1)){
var and__22900__auto____$2 = cljs.core._EQ_.call(null,new cljs.core.Keyword(null,"optimizations","optimizations",-2047476854).cljs$core$IFn$_invoke$arity$1(opts),new cljs.core.Keyword(null,"none","none",1333468478));
if(and__22900__auto____$2){
var define = cljs.core.get_in.call(null,opts,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword(null,"closure-defines","closure-defines",-1213856476),[cljs.core.str(mname)].join('')], null));
if(cljs.core.truth_(cljs.compiler.valid_define_value_QMARK_.call(null,define))){
return cljs.core.pr_str.call(null,define);
} else {
return null;
}
} else {
return and__22900__auto____$2;
}
} else {
return and__22900__auto____$1;
}
} else {
return and__22900__auto__;
}
});
cljs.core._add_method.call(null,cljs.compiler.emit_STAR_,new cljs.core.Keyword(null,"def","def",-1043430536),(function (p__31395){
var map__31396 = p__31395;
var map__31396__$1 = ((((!((map__31396 == null)))?((((map__31396.cljs$lang$protocol_mask$partition0$ & (64))) || (map__31396.cljs$core$ISeq$))?true:false):false))?cljs.core.apply.call(null,cljs.core.hash_map,map__31396):map__31396);
var name = cljs.core.get.call(null,map__31396__$1,new cljs.core.Keyword(null,"name","name",1843675177));
var var$ = cljs.core.get.call(null,map__31396__$1,new cljs.core.Keyword(null,"var","var",-769682797));
var init = cljs.core.get.call(null,map__31396__$1,new cljs.core.Keyword(null,"init","init",-1875481434));
var env = cljs.core.get.call(null,map__31396__$1,new cljs.core.Keyword(null,"env","env",-1815813235));
var doc = cljs.core.get.call(null,map__31396__$1,new cljs.core.Keyword(null,"doc","doc",1913296891));
var jsdoc = cljs.core.get.call(null,map__31396__$1,new cljs.core.Keyword(null,"jsdoc","jsdoc",1745183516));
var export$ = cljs.core.get.call(null,map__31396__$1,new cljs.core.Keyword(null,"export","export",214356590));
var test = cljs.core.get.call(null,map__31396__$1,new cljs.core.Keyword(null,"test","test",577538877));
var var_ast = cljs.core.get.call(null,map__31396__$1,new cljs.core.Keyword(null,"var-ast","var-ast",1200379319));
if(cljs.core.truth_((function (){var or__22912__auto__ = init;
if(cljs.core.truth_(or__22912__auto__)){
return or__22912__auto__;
} else {
return new cljs.core.Keyword(null,"def-emits-var","def-emits-var",-1551927320).cljs$core$IFn$_invoke$arity$1(env);
}
})())){
var mname = cljs.compiler.munge.call(null,name);
cljs.compiler.emit_comment.call(null,env,doc,cljs.core.concat.call(null,jsdoc,new cljs.core.Keyword(null,"jsdoc","jsdoc",1745183516).cljs$core$IFn$_invoke$arity$1(init)));

if(cljs.core.truth_(new cljs.core.Keyword(null,"def-emits-var","def-emits-var",-1551927320).cljs$core$IFn$_invoke$arity$1(env))){
if(cljs.core._EQ_.call(null,new cljs.core.Keyword(null,"return","return",-1891502105),new cljs.core.Keyword(null,"context","context",-830191113).cljs$core$IFn$_invoke$arity$1(env))){
cljs.compiler.emitln.call(null,"return (");
} else {
}

cljs.compiler.emitln.call(null,"(function (){");
} else {
}

cljs.compiler.emits.call(null,var$);

if(cljs.core.truth_(init)){
cljs.compiler.emits.call(null," = ",(function (){var temp__4655__auto__ = cljs.compiler.get_define.call(null,mname,jsdoc);
if(cljs.core.truth_(temp__4655__auto__)){
var define = temp__4655__auto__;
return define;
} else {
return init;
}
})());
} else {
}

if(cljs.core.truth_(new cljs.core.Keyword(null,"def-emits-var","def-emits-var",-1551927320).cljs$core$IFn$_invoke$arity$1(env))){
cljs.compiler.emitln.call(null,"; return (");

cljs.compiler.emits.call(null,cljs.core.merge.call(null,new cljs.core.PersistentArrayMap(null, 2, [new cljs.core.Keyword(null,"op","op",-1882987955),new cljs.core.Keyword(null,"var-special","var-special",1131576802),new cljs.core.Keyword(null,"env","env",-1815813235),cljs.core.assoc.call(null,env,new cljs.core.Keyword(null,"context","context",-830191113),new cljs.core.Keyword(null,"expr","expr",745722291))], null),var_ast));

cljs.compiler.emitln.call(null,");})()");

if(cljs.core._EQ_.call(null,new cljs.core.Keyword(null,"return","return",-1891502105),new cljs.core.Keyword(null,"context","context",-830191113).cljs$core$IFn$_invoke$arity$1(env))){
cljs.compiler.emitln.call(null,")");
} else {
}
} else {
}

if(cljs.core._EQ_.call(null,new cljs.core.Keyword(null,"expr","expr",745722291),new cljs.core.Keyword(null,"context","context",-830191113).cljs$core$IFn$_invoke$arity$1(env))){
} else {
cljs.compiler.emitln.call(null,";");
}

if(cljs.core.truth_(export$)){
cljs.compiler.emitln.call(null,"goog.exportSymbol('",cljs.compiler.munge.call(null,export$),"', ",mname,");");
} else {
}

if(cljs.core.truth_((function (){var and__22900__auto__ = cljs.analyzer._STAR_load_tests_STAR_;
if(cljs.core.truth_(and__22900__auto__)){
return test;
} else {
return and__22900__auto__;
}
})())){
if(cljs.core._EQ_.call(null,new cljs.core.Keyword(null,"expr","expr",745722291),new cljs.core.Keyword(null,"context","context",-830191113).cljs$core$IFn$_invoke$arity$1(env))){
cljs.compiler.emitln.call(null,";");
} else {
}

return cljs.compiler.emitln.call(null,var$,".cljs$lang$test = ",test,";");
} else {
return null;
}
} else {
return null;
}
}));
cljs.compiler.emit_apply_to = (function cljs$compiler$emit_apply_to(p__31398){
var map__31415 = p__31398;
var map__31415__$1 = ((((!((map__31415 == null)))?((((map__31415.cljs$lang$protocol_mask$partition0$ & (64))) || (map__31415.cljs$core$ISeq$))?true:false):false))?cljs.core.apply.call(null,cljs.core.hash_map,map__31415):map__31415);
var name = cljs.core.get.call(null,map__31415__$1,new cljs.core.Keyword(null,"name","name",1843675177));
var params = cljs.core.get.call(null,map__31415__$1,new cljs.core.Keyword(null,"params","params",710516235));
var env = cljs.core.get.call(null,map__31415__$1,new cljs.core.Keyword(null,"env","env",-1815813235));
var arglist = cljs.core.gensym.call(null,"arglist__");
var delegate_name = [cljs.core.str(cljs.compiler.munge.call(null,name)),cljs.core.str("__delegate")].join('');
cljs.compiler.emitln.call(null,"(function (",arglist,"){");

var seq__31417_31431 = cljs.core.seq.call(null,cljs.core.map_indexed.call(null,cljs.core.vector,cljs.core.drop_last.call(null,(2),params)));
var chunk__31418_31432 = null;
var count__31419_31433 = (0);
var i__31420_31434 = (0);
while(true){
if((i__31420_31434 < count__31419_31433)){
var vec__31421_31435 = cljs.core._nth.call(null,chunk__31418_31432,i__31420_31434);
var i_31436 = cljs.core.nth.call(null,vec__31421_31435,(0),null);
var param_31437 = cljs.core.nth.call(null,vec__31421_31435,(1),null);
cljs.compiler.emits.call(null,"var ");

cljs.compiler.emit.call(null,param_31437);

cljs.compiler.emits.call(null," = cljs.core.first(");

cljs.compiler.emitln.call(null,arglist,");");

cljs.compiler.emitln.call(null,arglist," = cljs.core.next(",arglist,");");

var G__31438 = seq__31417_31431;
var G__31439 = chunk__31418_31432;
var G__31440 = count__31419_31433;
var G__31441 = (i__31420_31434 + (1));
seq__31417_31431 = G__31438;
chunk__31418_31432 = G__31439;
count__31419_31433 = G__31440;
i__31420_31434 = G__31441;
continue;
} else {
var temp__4657__auto___31442 = cljs.core.seq.call(null,seq__31417_31431);
if(temp__4657__auto___31442){
var seq__31417_31443__$1 = temp__4657__auto___31442;
if(cljs.core.chunked_seq_QMARK_.call(null,seq__31417_31443__$1)){
var c__23723__auto___31444 = cljs.core.chunk_first.call(null,seq__31417_31443__$1);
var G__31445 = cljs.core.chunk_rest.call(null,seq__31417_31443__$1);
var G__31446 = c__23723__auto___31444;
var G__31447 = cljs.core.count.call(null,c__23723__auto___31444);
var G__31448 = (0);
seq__31417_31431 = G__31445;
chunk__31418_31432 = G__31446;
count__31419_31433 = G__31447;
i__31420_31434 = G__31448;
continue;
} else {
var vec__31422_31449 = cljs.core.first.call(null,seq__31417_31443__$1);
var i_31450 = cljs.core.nth.call(null,vec__31422_31449,(0),null);
var param_31451 = cljs.core.nth.call(null,vec__31422_31449,(1),null);
cljs.compiler.emits.call(null,"var ");

cljs.compiler.emit.call(null,param_31451);

cljs.compiler.emits.call(null," = cljs.core.first(");

cljs.compiler.emitln.call(null,arglist,");");

cljs.compiler.emitln.call(null,arglist," = cljs.core.next(",arglist,");");

var G__31452 = cljs.core.next.call(null,seq__31417_31443__$1);
var G__31453 = null;
var G__31454 = (0);
var G__31455 = (0);
seq__31417_31431 = G__31452;
chunk__31418_31432 = G__31453;
count__31419_31433 = G__31454;
i__31420_31434 = G__31455;
continue;
}
} else {
}
}
break;
}

if(((1) < cljs.core.count.call(null,params))){
cljs.compiler.emits.call(null,"var ");

cljs.compiler.emit.call(null,cljs.core.last.call(null,cljs.core.butlast.call(null,params)));

cljs.compiler.emitln.call(null," = cljs.core.first(",arglist,");");

cljs.compiler.emits.call(null,"var ");

cljs.compiler.emit.call(null,cljs.core.last.call(null,params));

cljs.compiler.emitln.call(null," = cljs.core.rest(",arglist,");");

cljs.compiler.emits.call(null,"return ",delegate_name,"(");

var seq__31423_31456 = cljs.core.seq.call(null,params);
var chunk__31424_31457 = null;
var count__31425_31458 = (0);
var i__31426_31459 = (0);
while(true){
if((i__31426_31459 < count__31425_31458)){
var param_31460 = cljs.core._nth.call(null,chunk__31424_31457,i__31426_31459);
cljs.compiler.emit.call(null,param_31460);

if(cljs.core._EQ_.call(null,param_31460,cljs.core.last.call(null,params))){
} else {
cljs.compiler.emits.call(null,",");
}

var G__31461 = seq__31423_31456;
var G__31462 = chunk__31424_31457;
var G__31463 = count__31425_31458;
var G__31464 = (i__31426_31459 + (1));
seq__31423_31456 = G__31461;
chunk__31424_31457 = G__31462;
count__31425_31458 = G__31463;
i__31426_31459 = G__31464;
continue;
} else {
var temp__4657__auto___31465 = cljs.core.seq.call(null,seq__31423_31456);
if(temp__4657__auto___31465){
var seq__31423_31466__$1 = temp__4657__auto___31465;
if(cljs.core.chunked_seq_QMARK_.call(null,seq__31423_31466__$1)){
var c__23723__auto___31467 = cljs.core.chunk_first.call(null,seq__31423_31466__$1);
var G__31468 = cljs.core.chunk_rest.call(null,seq__31423_31466__$1);
var G__31469 = c__23723__auto___31467;
var G__31470 = cljs.core.count.call(null,c__23723__auto___31467);
var G__31471 = (0);
seq__31423_31456 = G__31468;
chunk__31424_31457 = G__31469;
count__31425_31458 = G__31470;
i__31426_31459 = G__31471;
continue;
} else {
var param_31472 = cljs.core.first.call(null,seq__31423_31466__$1);
cljs.compiler.emit.call(null,param_31472);

if(cljs.core._EQ_.call(null,param_31472,cljs.core.last.call(null,params))){
} else {
cljs.compiler.emits.call(null,",");
}

var G__31473 = cljs.core.next.call(null,seq__31423_31466__$1);
var G__31474 = null;
var G__31475 = (0);
var G__31476 = (0);
seq__31423_31456 = G__31473;
chunk__31424_31457 = G__31474;
count__31425_31458 = G__31475;
i__31426_31459 = G__31476;
continue;
}
} else {
}
}
break;
}

cljs.compiler.emitln.call(null,");");
} else {
cljs.compiler.emits.call(null,"var ");

cljs.compiler.emit.call(null,cljs.core.last.call(null,params));

cljs.compiler.emitln.call(null," = cljs.core.seq(",arglist,");");

cljs.compiler.emits.call(null,"return ",delegate_name,"(");

var seq__31427_31477 = cljs.core.seq.call(null,params);
var chunk__31428_31478 = null;
var count__31429_31479 = (0);
var i__31430_31480 = (0);
while(true){
if((i__31430_31480 < count__31429_31479)){
var param_31481 = cljs.core._nth.call(null,chunk__31428_31478,i__31430_31480);
cljs.compiler.emit.call(null,param_31481);

if(cljs.core._EQ_.call(null,param_31481,cljs.core.last.call(null,params))){
} else {
cljs.compiler.emits.call(null,",");
}

var G__31482 = seq__31427_31477;
var G__31483 = chunk__31428_31478;
var G__31484 = count__31429_31479;
var G__31485 = (i__31430_31480 + (1));
seq__31427_31477 = G__31482;
chunk__31428_31478 = G__31483;
count__31429_31479 = G__31484;
i__31430_31480 = G__31485;
continue;
} else {
var temp__4657__auto___31486 = cljs.core.seq.call(null,seq__31427_31477);
if(temp__4657__auto___31486){
var seq__31427_31487__$1 = temp__4657__auto___31486;
if(cljs.core.chunked_seq_QMARK_.call(null,seq__31427_31487__$1)){
var c__23723__auto___31488 = cljs.core.chunk_first.call(null,seq__31427_31487__$1);
var G__31489 = cljs.core.chunk_rest.call(null,seq__31427_31487__$1);
var G__31490 = c__23723__auto___31488;
var G__31491 = cljs.core.count.call(null,c__23723__auto___31488);
var G__31492 = (0);
seq__31427_31477 = G__31489;
chunk__31428_31478 = G__31490;
count__31429_31479 = G__31491;
i__31430_31480 = G__31492;
continue;
} else {
var param_31493 = cljs.core.first.call(null,seq__31427_31487__$1);
cljs.compiler.emit.call(null,param_31493);

if(cljs.core._EQ_.call(null,param_31493,cljs.core.last.call(null,params))){
} else {
cljs.compiler.emits.call(null,",");
}

var G__31494 = cljs.core.next.call(null,seq__31427_31487__$1);
var G__31495 = null;
var G__31496 = (0);
var G__31497 = (0);
seq__31427_31477 = G__31494;
chunk__31428_31478 = G__31495;
count__31429_31479 = G__31496;
i__31430_31480 = G__31497;
continue;
}
} else {
}
}
break;
}

cljs.compiler.emitln.call(null,");");
}

return cljs.compiler.emits.call(null,"})");
});
cljs.compiler.emit_fn_params = (function cljs$compiler$emit_fn_params(params){
var seq__31502 = cljs.core.seq.call(null,params);
var chunk__31503 = null;
var count__31504 = (0);
var i__31505 = (0);
while(true){
if((i__31505 < count__31504)){
var param = cljs.core._nth.call(null,chunk__31503,i__31505);
cljs.compiler.emit.call(null,param);

if(cljs.core._EQ_.call(null,param,cljs.core.last.call(null,params))){
} else {
cljs.compiler.emits.call(null,",");
}

var G__31506 = seq__31502;
var G__31507 = chunk__31503;
var G__31508 = count__31504;
var G__31509 = (i__31505 + (1));
seq__31502 = G__31506;
chunk__31503 = G__31507;
count__31504 = G__31508;
i__31505 = G__31509;
continue;
} else {
var temp__4657__auto__ = cljs.core.seq.call(null,seq__31502);
if(temp__4657__auto__){
var seq__31502__$1 = temp__4657__auto__;
if(cljs.core.chunked_seq_QMARK_.call(null,seq__31502__$1)){
var c__23723__auto__ = cljs.core.chunk_first.call(null,seq__31502__$1);
var G__31510 = cljs.core.chunk_rest.call(null,seq__31502__$1);
var G__31511 = c__23723__auto__;
var G__31512 = cljs.core.count.call(null,c__23723__auto__);
var G__31513 = (0);
seq__31502 = G__31510;
chunk__31503 = G__31511;
count__31504 = G__31512;
i__31505 = G__31513;
continue;
} else {
var param = cljs.core.first.call(null,seq__31502__$1);
cljs.compiler.emit.call(null,param);

if(cljs.core._EQ_.call(null,param,cljs.core.last.call(null,params))){
} else {
cljs.compiler.emits.call(null,",");
}

var G__31514 = cljs.core.next.call(null,seq__31502__$1);
var G__31515 = null;
var G__31516 = (0);
var G__31517 = (0);
seq__31502 = G__31514;
chunk__31503 = G__31515;
count__31504 = G__31516;
i__31505 = G__31517;
continue;
}
} else {
return null;
}
}
break;
}
});
cljs.compiler.emit_fn_method = (function cljs$compiler$emit_fn_method(p__31518){
var map__31521 = p__31518;
var map__31521__$1 = ((((!((map__31521 == null)))?((((map__31521.cljs$lang$protocol_mask$partition0$ & (64))) || (map__31521.cljs$core$ISeq$))?true:false):false))?cljs.core.apply.call(null,cljs.core.hash_map,map__31521):map__31521);
var type = cljs.core.get.call(null,map__31521__$1,new cljs.core.Keyword(null,"type","type",1174270348));
var name = cljs.core.get.call(null,map__31521__$1,new cljs.core.Keyword(null,"name","name",1843675177));
var variadic = cljs.core.get.call(null,map__31521__$1,new cljs.core.Keyword(null,"variadic","variadic",882626057));
var params = cljs.core.get.call(null,map__31521__$1,new cljs.core.Keyword(null,"params","params",710516235));
var expr = cljs.core.get.call(null,map__31521__$1,new cljs.core.Keyword(null,"expr","expr",745722291));
var env = cljs.core.get.call(null,map__31521__$1,new cljs.core.Keyword(null,"env","env",-1815813235));
var recurs = cljs.core.get.call(null,map__31521__$1,new cljs.core.Keyword(null,"recurs","recurs",-1959309309));
var max_fixed_arity = cljs.core.get.call(null,map__31521__$1,new cljs.core.Keyword(null,"max-fixed-arity","max-fixed-arity",-690205543));
var env__25235__auto__ = env;
if(cljs.core._EQ_.call(null,new cljs.core.Keyword(null,"return","return",-1891502105),new cljs.core.Keyword(null,"context","context",-830191113).cljs$core$IFn$_invoke$arity$1(env__25235__auto__))){
cljs.compiler.emits.call(null,"return ");
} else {
}

cljs.compiler.emits.call(null,"(function ",cljs.compiler.munge.call(null,name),"(");

cljs.compiler.emit_fn_params.call(null,params);

cljs.compiler.emitln.call(null,"){");

if(cljs.core.truth_(type)){
cljs.compiler.emitln.call(null,"var self__ = this;");
} else {
}

if(cljs.core.truth_(recurs)){
cljs.compiler.emitln.call(null,"while(true){");
} else {
}

cljs.compiler.emits.call(null,expr);

if(cljs.core.truth_(recurs)){
cljs.compiler.emitln.call(null,"break;");

cljs.compiler.emitln.call(null,"}");
} else {
}

cljs.compiler.emits.call(null,"})");

if(cljs.core._EQ_.call(null,new cljs.core.Keyword(null,"expr","expr",745722291),new cljs.core.Keyword(null,"context","context",-830191113).cljs$core$IFn$_invoke$arity$1(env__25235__auto__))){
return null;
} else {
return cljs.compiler.emitln.call(null,";");
}
});
/**
 * Emit code that copies function arguments into an array starting at an index.
 *   Returns name of var holding the array.
 */
cljs.compiler.emit_arguments_to_array = (function cljs$compiler$emit_arguments_to_array(startslice){
if(((startslice >= (0))) && (cljs.core.integer_QMARK_.call(null,startslice))){
} else {
throw (new Error("Assert failed: (and (>= startslice 0) (integer? startslice))"));
}

var mname = cljs.compiler.munge.call(null,cljs.core.gensym.call(null));
var i = [cljs.core.str(mname),cljs.core.str("__i")].join('');
var a = [cljs.core.str(mname),cljs.core.str("__a")].join('');
cljs.compiler.emitln.call(null,"var ",i," = 0, ",a," = new Array(arguments.length -  ",startslice,");");

cljs.compiler.emitln.call(null,"while (",i," < ",a,".length) {",a,"[",i,"] = arguments[",i," + ",startslice,"]; ++",i,";}");

return a;
});
cljs.compiler.emit_variadic_fn_method = (function cljs$compiler$emit_variadic_fn_method(p__31523){
var map__31534 = p__31523;
var map__31534__$1 = ((((!((map__31534 == null)))?((((map__31534.cljs$lang$protocol_mask$partition0$ & (64))) || (map__31534.cljs$core$ISeq$))?true:false):false))?cljs.core.apply.call(null,cljs.core.hash_map,map__31534):map__31534);
var f = map__31534__$1;
var type = cljs.core.get.call(null,map__31534__$1,new cljs.core.Keyword(null,"type","type",1174270348));
var name = cljs.core.get.call(null,map__31534__$1,new cljs.core.Keyword(null,"name","name",1843675177));
var variadic = cljs.core.get.call(null,map__31534__$1,new cljs.core.Keyword(null,"variadic","variadic",882626057));
var params = cljs.core.get.call(null,map__31534__$1,new cljs.core.Keyword(null,"params","params",710516235));
var expr = cljs.core.get.call(null,map__31534__$1,new cljs.core.Keyword(null,"expr","expr",745722291));
var env = cljs.core.get.call(null,map__31534__$1,new cljs.core.Keyword(null,"env","env",-1815813235));
var recurs = cljs.core.get.call(null,map__31534__$1,new cljs.core.Keyword(null,"recurs","recurs",-1959309309));
var max_fixed_arity = cljs.core.get.call(null,map__31534__$1,new cljs.core.Keyword(null,"max-fixed-arity","max-fixed-arity",-690205543));
var env__25235__auto__ = env;
if(cljs.core._EQ_.call(null,new cljs.core.Keyword(null,"return","return",-1891502105),new cljs.core.Keyword(null,"context","context",-830191113).cljs$core$IFn$_invoke$arity$1(env__25235__auto__))){
cljs.compiler.emits.call(null,"return ");
} else {
}

var name_31544__$1 = (function (){var or__22912__auto__ = name;
if(cljs.core.truth_(or__22912__auto__)){
return or__22912__auto__;
} else {
return cljs.core.gensym.call(null);
}
})();
var mname_31545 = cljs.compiler.munge.call(null,name_31544__$1);
var delegate_name_31546 = [cljs.core.str(mname_31545),cljs.core.str("__delegate")].join('');
cljs.compiler.emitln.call(null,"(function() { ");

cljs.compiler.emits.call(null,"var ",delegate_name_31546," = function (");

var seq__31536_31547 = cljs.core.seq.call(null,params);
var chunk__31537_31548 = null;
var count__31538_31549 = (0);
var i__31539_31550 = (0);
while(true){
if((i__31539_31550 < count__31538_31549)){
var param_31551 = cljs.core._nth.call(null,chunk__31537_31548,i__31539_31550);
cljs.compiler.emit.call(null,param_31551);

if(cljs.core._EQ_.call(null,param_31551,cljs.core.last.call(null,params))){
} else {
cljs.compiler.emits.call(null,",");
}

var G__31552 = seq__31536_31547;
var G__31553 = chunk__31537_31548;
var G__31554 = count__31538_31549;
var G__31555 = (i__31539_31550 + (1));
seq__31536_31547 = G__31552;
chunk__31537_31548 = G__31553;
count__31538_31549 = G__31554;
i__31539_31550 = G__31555;
continue;
} else {
var temp__4657__auto___31556 = cljs.core.seq.call(null,seq__31536_31547);
if(temp__4657__auto___31556){
var seq__31536_31557__$1 = temp__4657__auto___31556;
if(cljs.core.chunked_seq_QMARK_.call(null,seq__31536_31557__$1)){
var c__23723__auto___31558 = cljs.core.chunk_first.call(null,seq__31536_31557__$1);
var G__31559 = cljs.core.chunk_rest.call(null,seq__31536_31557__$1);
var G__31560 = c__23723__auto___31558;
var G__31561 = cljs.core.count.call(null,c__23723__auto___31558);
var G__31562 = (0);
seq__31536_31547 = G__31559;
chunk__31537_31548 = G__31560;
count__31538_31549 = G__31561;
i__31539_31550 = G__31562;
continue;
} else {
var param_31563 = cljs.core.first.call(null,seq__31536_31557__$1);
cljs.compiler.emit.call(null,param_31563);

if(cljs.core._EQ_.call(null,param_31563,cljs.core.last.call(null,params))){
} else {
cljs.compiler.emits.call(null,",");
}

var G__31564 = cljs.core.next.call(null,seq__31536_31557__$1);
var G__31565 = null;
var G__31566 = (0);
var G__31567 = (0);
seq__31536_31547 = G__31564;
chunk__31537_31548 = G__31565;
count__31538_31549 = G__31566;
i__31539_31550 = G__31567;
continue;
}
} else {
}
}
break;
}

cljs.compiler.emitln.call(null,"){");

if(cljs.core.truth_(recurs)){
cljs.compiler.emitln.call(null,"while(true){");
} else {
}

cljs.compiler.emits.call(null,expr);

if(cljs.core.truth_(recurs)){
cljs.compiler.emitln.call(null,"break;");

cljs.compiler.emitln.call(null,"}");
} else {
}

cljs.compiler.emitln.call(null,"};");

cljs.compiler.emitln.call(null,"var ",mname_31545," = function (",cljs.compiler.comma_sep.call(null,(cljs.core.truth_(variadic)?cljs.core.concat.call(null,cljs.core.butlast.call(null,params),new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Symbol(null,"var_args","var_args",1214280389,null)], null)):params)),"){");

if(cljs.core.truth_(type)){
cljs.compiler.emitln.call(null,"var self__ = this;");
} else {
}

if(cljs.core.truth_(variadic)){
cljs.compiler.emits.call(null,"var ");

cljs.compiler.emit.call(null,cljs.core.last.call(null,params));

cljs.compiler.emitln.call(null," = null;");

cljs.compiler.emitln.call(null,"if (arguments.length > ",(cljs.core.count.call(null,params) - (1)),") {");

var a_31568 = cljs.compiler.emit_arguments_to_array.call(null,(cljs.core.count.call(null,params) - (1)));
cljs.compiler.emitln.call(null,"  ",cljs.core.last.call(null,params)," = new cljs.core.IndexedSeq(",a_31568,",0);");

cljs.compiler.emitln.call(null,"} ");
} else {
}

cljs.compiler.emits.call(null,"return ",delegate_name_31546,".call(this,");

var seq__31540_31569 = cljs.core.seq.call(null,params);
var chunk__31541_31570 = null;
var count__31542_31571 = (0);
var i__31543_31572 = (0);
while(true){
if((i__31543_31572 < count__31542_31571)){
var param_31573 = cljs.core._nth.call(null,chunk__31541_31570,i__31543_31572);
cljs.compiler.emit.call(null,param_31573);

if(cljs.core._EQ_.call(null,param_31573,cljs.core.last.call(null,params))){
} else {
cljs.compiler.emits.call(null,",");
}

var G__31574 = seq__31540_31569;
var G__31575 = chunk__31541_31570;
var G__31576 = count__31542_31571;
var G__31577 = (i__31543_31572 + (1));
seq__31540_31569 = G__31574;
chunk__31541_31570 = G__31575;
count__31542_31571 = G__31576;
i__31543_31572 = G__31577;
continue;
} else {
var temp__4657__auto___31578 = cljs.core.seq.call(null,seq__31540_31569);
if(temp__4657__auto___31578){
var seq__31540_31579__$1 = temp__4657__auto___31578;
if(cljs.core.chunked_seq_QMARK_.call(null,seq__31540_31579__$1)){
var c__23723__auto___31580 = cljs.core.chunk_first.call(null,seq__31540_31579__$1);
var G__31581 = cljs.core.chunk_rest.call(null,seq__31540_31579__$1);
var G__31582 = c__23723__auto___31580;
var G__31583 = cljs.core.count.call(null,c__23723__auto___31580);
var G__31584 = (0);
seq__31540_31569 = G__31581;
chunk__31541_31570 = G__31582;
count__31542_31571 = G__31583;
i__31543_31572 = G__31584;
continue;
} else {
var param_31585 = cljs.core.first.call(null,seq__31540_31579__$1);
cljs.compiler.emit.call(null,param_31585);

if(cljs.core._EQ_.call(null,param_31585,cljs.core.last.call(null,params))){
} else {
cljs.compiler.emits.call(null,",");
}

var G__31586 = cljs.core.next.call(null,seq__31540_31579__$1);
var G__31587 = null;
var G__31588 = (0);
var G__31589 = (0);
seq__31540_31569 = G__31586;
chunk__31541_31570 = G__31587;
count__31542_31571 = G__31588;
i__31543_31572 = G__31589;
continue;
}
} else {
}
}
break;
}

cljs.compiler.emits.call(null,");");

cljs.compiler.emitln.call(null,"};");

cljs.compiler.emitln.call(null,mname_31545,".cljs$lang$maxFixedArity = ",max_fixed_arity,";");

cljs.compiler.emits.call(null,mname_31545,".cljs$lang$applyTo = ");

cljs.compiler.emit_apply_to.call(null,cljs.core.assoc.call(null,f,new cljs.core.Keyword(null,"name","name",1843675177),name_31544__$1));

cljs.compiler.emitln.call(null,";");

cljs.compiler.emitln.call(null,mname_31545,".cljs$core$IFn$_invoke$arity$variadic = ",delegate_name_31546,";");

cljs.compiler.emitln.call(null,"return ",mname_31545,";");

cljs.compiler.emitln.call(null,"})()");

if(cljs.core._EQ_.call(null,new cljs.core.Keyword(null,"expr","expr",745722291),new cljs.core.Keyword(null,"context","context",-830191113).cljs$core$IFn$_invoke$arity$1(env__25235__auto__))){
return null;
} else {
return cljs.compiler.emitln.call(null,";");
}
});
cljs.core._add_method.call(null,cljs.compiler.emit_STAR_,new cljs.core.Keyword(null,"fn","fn",-1175266204),(function (p__31593){
var map__31594 = p__31593;
var map__31594__$1 = ((((!((map__31594 == null)))?((((map__31594.cljs$lang$protocol_mask$partition0$ & (64))) || (map__31594.cljs$core$ISeq$))?true:false):false))?cljs.core.apply.call(null,cljs.core.hash_map,map__31594):map__31594);
var name = cljs.core.get.call(null,map__31594__$1,new cljs.core.Keyword(null,"name","name",1843675177));
var env = cljs.core.get.call(null,map__31594__$1,new cljs.core.Keyword(null,"env","env",-1815813235));
var methods$ = cljs.core.get.call(null,map__31594__$1,new cljs.core.Keyword(null,"methods","methods",453930866));
var max_fixed_arity = cljs.core.get.call(null,map__31594__$1,new cljs.core.Keyword(null,"max-fixed-arity","max-fixed-arity",-690205543));
var variadic = cljs.core.get.call(null,map__31594__$1,new cljs.core.Keyword(null,"variadic","variadic",882626057));
var recur_frames = cljs.core.get.call(null,map__31594__$1,new cljs.core.Keyword(null,"recur-frames","recur-frames",-307205196));
var loop_lets = cljs.core.get.call(null,map__31594__$1,new cljs.core.Keyword(null,"loop-lets","loop-lets",2036794185));
if(cljs.core._EQ_.call(null,new cljs.core.Keyword(null,"statement","statement",-32780863),new cljs.core.Keyword(null,"context","context",-830191113).cljs$core$IFn$_invoke$arity$1(env))){
return null;
} else {
var loop_locals = cljs.core.seq.call(null,cljs.core.map.call(null,cljs.compiler.munge,cljs.core.concat.call(null,cljs.core.mapcat.call(null,new cljs.core.Keyword(null,"params","params",710516235),cljs.core.filter.call(null,((function (map__31594,map__31594__$1,name,env,methods$,max_fixed_arity,variadic,recur_frames,loop_lets){
return (function (p1__31590_SHARP_){
var and__22900__auto__ = p1__31590_SHARP_;
if(cljs.core.truth_(and__22900__auto__)){
return cljs.core.deref.call(null,new cljs.core.Keyword(null,"flag","flag",1088647881).cljs$core$IFn$_invoke$arity$1(p1__31590_SHARP_));
} else {
return and__22900__auto__;
}
});})(map__31594,map__31594__$1,name,env,methods$,max_fixed_arity,variadic,recur_frames,loop_lets))
,recur_frames)),cljs.core.mapcat.call(null,new cljs.core.Keyword(null,"params","params",710516235),loop_lets))));
if(loop_locals){
if(cljs.core._EQ_.call(null,new cljs.core.Keyword(null,"return","return",-1891502105),new cljs.core.Keyword(null,"context","context",-830191113).cljs$core$IFn$_invoke$arity$1(env))){
cljs.compiler.emits.call(null,"return ");
} else {
}

cljs.compiler.emitln.call(null,"((function (",cljs.compiler.comma_sep.call(null,cljs.core.map.call(null,cljs.compiler.munge,loop_locals)),"){");

if(cljs.core._EQ_.call(null,new cljs.core.Keyword(null,"return","return",-1891502105),new cljs.core.Keyword(null,"context","context",-830191113).cljs$core$IFn$_invoke$arity$1(env))){
} else {
cljs.compiler.emits.call(null,"return ");
}
} else {
}

if(cljs.core._EQ_.call(null,(1),cljs.core.count.call(null,methods$))){
if(cljs.core.truth_(variadic)){
cljs.compiler.emit_variadic_fn_method.call(null,cljs.core.assoc.call(null,cljs.core.first.call(null,methods$),new cljs.core.Keyword(null,"name","name",1843675177),name));
} else {
cljs.compiler.emit_fn_method.call(null,cljs.core.assoc.call(null,cljs.core.first.call(null,methods$),new cljs.core.Keyword(null,"name","name",1843675177),name));
}
} else {
var name_31615__$1 = (function (){var or__22912__auto__ = name;
if(cljs.core.truth_(or__22912__auto__)){
return or__22912__auto__;
} else {
return cljs.core.gensym.call(null);
}
})();
var mname_31616 = cljs.compiler.munge.call(null,name_31615__$1);
var maxparams_31617 = cljs.core.apply.call(null,cljs.core.max_key,cljs.core.count,cljs.core.map.call(null,new cljs.core.Keyword(null,"params","params",710516235),methods$));
var mmap_31618 = cljs.core.into.call(null,cljs.core.PersistentArrayMap.EMPTY,cljs.core.map.call(null,((function (name_31615__$1,mname_31616,maxparams_31617,loop_locals,map__31594,map__31594__$1,name,env,methods$,max_fixed_arity,variadic,recur_frames,loop_lets){
return (function (method){
return new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.compiler.munge.call(null,cljs.core.symbol.call(null,[cljs.core.str(mname_31616),cljs.core.str("__"),cljs.core.str(cljs.core.count.call(null,new cljs.core.Keyword(null,"params","params",710516235).cljs$core$IFn$_invoke$arity$1(method)))].join(''))),method], null);
});})(name_31615__$1,mname_31616,maxparams_31617,loop_locals,map__31594,map__31594__$1,name,env,methods$,max_fixed_arity,variadic,recur_frames,loop_lets))
,methods$));
var ms_31619 = cljs.core.sort_by.call(null,((function (name_31615__$1,mname_31616,maxparams_31617,mmap_31618,loop_locals,map__31594,map__31594__$1,name,env,methods$,max_fixed_arity,variadic,recur_frames,loop_lets){
return (function (p1__31591_SHARP_){
return cljs.core.count.call(null,new cljs.core.Keyword(null,"params","params",710516235).cljs$core$IFn$_invoke$arity$1(cljs.core.second.call(null,p1__31591_SHARP_)));
});})(name_31615__$1,mname_31616,maxparams_31617,mmap_31618,loop_locals,map__31594,map__31594__$1,name,env,methods$,max_fixed_arity,variadic,recur_frames,loop_lets))
,cljs.core.seq.call(null,mmap_31618));
if(cljs.core._EQ_.call(null,new cljs.core.Keyword(null,"return","return",-1891502105),new cljs.core.Keyword(null,"context","context",-830191113).cljs$core$IFn$_invoke$arity$1(env))){
cljs.compiler.emits.call(null,"return ");
} else {
}

cljs.compiler.emitln.call(null,"(function() {");

cljs.compiler.emitln.call(null,"var ",mname_31616," = null;");

var seq__31596_31620 = cljs.core.seq.call(null,ms_31619);
var chunk__31597_31621 = null;
var count__31598_31622 = (0);
var i__31599_31623 = (0);
while(true){
if((i__31599_31623 < count__31598_31622)){
var vec__31600_31624 = cljs.core._nth.call(null,chunk__31597_31621,i__31599_31623);
var n_31625 = cljs.core.nth.call(null,vec__31600_31624,(0),null);
var meth_31626 = cljs.core.nth.call(null,vec__31600_31624,(1),null);
cljs.compiler.emits.call(null,"var ",n_31625," = ");

if(cljs.core.truth_(new cljs.core.Keyword(null,"variadic","variadic",882626057).cljs$core$IFn$_invoke$arity$1(meth_31626))){
cljs.compiler.emit_variadic_fn_method.call(null,meth_31626);
} else {
cljs.compiler.emit_fn_method.call(null,meth_31626);
}

cljs.compiler.emitln.call(null,";");

var G__31627 = seq__31596_31620;
var G__31628 = chunk__31597_31621;
var G__31629 = count__31598_31622;
var G__31630 = (i__31599_31623 + (1));
seq__31596_31620 = G__31627;
chunk__31597_31621 = G__31628;
count__31598_31622 = G__31629;
i__31599_31623 = G__31630;
continue;
} else {
var temp__4657__auto___31631 = cljs.core.seq.call(null,seq__31596_31620);
if(temp__4657__auto___31631){
var seq__31596_31632__$1 = temp__4657__auto___31631;
if(cljs.core.chunked_seq_QMARK_.call(null,seq__31596_31632__$1)){
var c__23723__auto___31633 = cljs.core.chunk_first.call(null,seq__31596_31632__$1);
var G__31634 = cljs.core.chunk_rest.call(null,seq__31596_31632__$1);
var G__31635 = c__23723__auto___31633;
var G__31636 = cljs.core.count.call(null,c__23723__auto___31633);
var G__31637 = (0);
seq__31596_31620 = G__31634;
chunk__31597_31621 = G__31635;
count__31598_31622 = G__31636;
i__31599_31623 = G__31637;
continue;
} else {
var vec__31601_31638 = cljs.core.first.call(null,seq__31596_31632__$1);
var n_31639 = cljs.core.nth.call(null,vec__31601_31638,(0),null);
var meth_31640 = cljs.core.nth.call(null,vec__31601_31638,(1),null);
cljs.compiler.emits.call(null,"var ",n_31639," = ");

if(cljs.core.truth_(new cljs.core.Keyword(null,"variadic","variadic",882626057).cljs$core$IFn$_invoke$arity$1(meth_31640))){
cljs.compiler.emit_variadic_fn_method.call(null,meth_31640);
} else {
cljs.compiler.emit_fn_method.call(null,meth_31640);
}

cljs.compiler.emitln.call(null,";");

var G__31641 = cljs.core.next.call(null,seq__31596_31632__$1);
var G__31642 = null;
var G__31643 = (0);
var G__31644 = (0);
seq__31596_31620 = G__31641;
chunk__31597_31621 = G__31642;
count__31598_31622 = G__31643;
i__31599_31623 = G__31644;
continue;
}
} else {
}
}
break;
}

cljs.compiler.emitln.call(null,mname_31616," = function(",cljs.compiler.comma_sep.call(null,(cljs.core.truth_(variadic)?cljs.core.concat.call(null,cljs.core.butlast.call(null,maxparams_31617),new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Symbol(null,"var_args","var_args",1214280389,null)], null)):maxparams_31617)),"){");

if(cljs.core.truth_(variadic)){
cljs.compiler.emits.call(null,"var ");

cljs.compiler.emit.call(null,cljs.core.last.call(null,maxparams_31617));

cljs.compiler.emitln.call(null," = var_args;");
} else {
}

cljs.compiler.emitln.call(null,"switch(arguments.length){");

var seq__31602_31645 = cljs.core.seq.call(null,ms_31619);
var chunk__31603_31646 = null;
var count__31604_31647 = (0);
var i__31605_31648 = (0);
while(true){
if((i__31605_31648 < count__31604_31647)){
var vec__31606_31649 = cljs.core._nth.call(null,chunk__31603_31646,i__31605_31648);
var n_31650 = cljs.core.nth.call(null,vec__31606_31649,(0),null);
var meth_31651 = cljs.core.nth.call(null,vec__31606_31649,(1),null);
if(cljs.core.truth_(new cljs.core.Keyword(null,"variadic","variadic",882626057).cljs$core$IFn$_invoke$arity$1(meth_31651))){
cljs.compiler.emitln.call(null,"default:");

var restarg_31652 = cljs.compiler.munge.call(null,cljs.core.gensym.call(null));
cljs.compiler.emitln.call(null,"var ",restarg_31652," = null;");

cljs.compiler.emitln.call(null,"if (arguments.length > ",max_fixed_arity,") {");

var a_31653 = cljs.compiler.emit_arguments_to_array.call(null,max_fixed_arity);
cljs.compiler.emitln.call(null,restarg_31652," = new cljs.core.IndexedSeq(",a_31653,",0);");

cljs.compiler.emitln.call(null,"}");

cljs.compiler.emitln.call(null,"return ",n_31650,".cljs$core$IFn$_invoke$arity$variadic(",cljs.compiler.comma_sep.call(null,cljs.core.butlast.call(null,maxparams_31617)),(((cljs.core.count.call(null,maxparams_31617) > (1)))?", ":null),restarg_31652,");");
} else {
var pcnt_31654 = cljs.core.count.call(null,new cljs.core.Keyword(null,"params","params",710516235).cljs$core$IFn$_invoke$arity$1(meth_31651));
cljs.compiler.emitln.call(null,"case ",pcnt_31654,":");

cljs.compiler.emitln.call(null,"return ",n_31650,".call(this",(((pcnt_31654 === (0)))?null:cljs.core._conj.call(null,(function (){var x__23746__auto__ = cljs.compiler.comma_sep.call(null,cljs.core.take.call(null,pcnt_31654,maxparams_31617));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),",")),");");
}

var G__31655 = seq__31602_31645;
var G__31656 = chunk__31603_31646;
var G__31657 = count__31604_31647;
var G__31658 = (i__31605_31648 + (1));
seq__31602_31645 = G__31655;
chunk__31603_31646 = G__31656;
count__31604_31647 = G__31657;
i__31605_31648 = G__31658;
continue;
} else {
var temp__4657__auto___31659 = cljs.core.seq.call(null,seq__31602_31645);
if(temp__4657__auto___31659){
var seq__31602_31660__$1 = temp__4657__auto___31659;
if(cljs.core.chunked_seq_QMARK_.call(null,seq__31602_31660__$1)){
var c__23723__auto___31661 = cljs.core.chunk_first.call(null,seq__31602_31660__$1);
var G__31662 = cljs.core.chunk_rest.call(null,seq__31602_31660__$1);
var G__31663 = c__23723__auto___31661;
var G__31664 = cljs.core.count.call(null,c__23723__auto___31661);
var G__31665 = (0);
seq__31602_31645 = G__31662;
chunk__31603_31646 = G__31663;
count__31604_31647 = G__31664;
i__31605_31648 = G__31665;
continue;
} else {
var vec__31607_31666 = cljs.core.first.call(null,seq__31602_31660__$1);
var n_31667 = cljs.core.nth.call(null,vec__31607_31666,(0),null);
var meth_31668 = cljs.core.nth.call(null,vec__31607_31666,(1),null);
if(cljs.core.truth_(new cljs.core.Keyword(null,"variadic","variadic",882626057).cljs$core$IFn$_invoke$arity$1(meth_31668))){
cljs.compiler.emitln.call(null,"default:");

var restarg_31669 = cljs.compiler.munge.call(null,cljs.core.gensym.call(null));
cljs.compiler.emitln.call(null,"var ",restarg_31669," = null;");

cljs.compiler.emitln.call(null,"if (arguments.length > ",max_fixed_arity,") {");

var a_31670 = cljs.compiler.emit_arguments_to_array.call(null,max_fixed_arity);
cljs.compiler.emitln.call(null,restarg_31669," = new cljs.core.IndexedSeq(",a_31670,",0);");

cljs.compiler.emitln.call(null,"}");

cljs.compiler.emitln.call(null,"return ",n_31667,".cljs$core$IFn$_invoke$arity$variadic(",cljs.compiler.comma_sep.call(null,cljs.core.butlast.call(null,maxparams_31617)),(((cljs.core.count.call(null,maxparams_31617) > (1)))?", ":null),restarg_31669,");");
} else {
var pcnt_31671 = cljs.core.count.call(null,new cljs.core.Keyword(null,"params","params",710516235).cljs$core$IFn$_invoke$arity$1(meth_31668));
cljs.compiler.emitln.call(null,"case ",pcnt_31671,":");

cljs.compiler.emitln.call(null,"return ",n_31667,".call(this",(((pcnt_31671 === (0)))?null:cljs.core._conj.call(null,(function (){var x__23746__auto__ = cljs.compiler.comma_sep.call(null,cljs.core.take.call(null,pcnt_31671,maxparams_31617));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23746__auto__);
})(),",")),");");
}

var G__31672 = cljs.core.next.call(null,seq__31602_31660__$1);
var G__31673 = null;
var G__31674 = (0);
var G__31675 = (0);
seq__31602_31645 = G__31672;
chunk__31603_31646 = G__31673;
count__31604_31647 = G__31674;
i__31605_31648 = G__31675;
continue;
}
} else {
}
}
break;
}

cljs.compiler.emitln.call(null,"}");

cljs.compiler.emitln.call(null,"throw(new Error('Invalid arity: ' + arguments.length));");

cljs.compiler.emitln.call(null,"};");

if(cljs.core.truth_(variadic)){
cljs.compiler.emitln.call(null,mname_31616,".cljs$lang$maxFixedArity = ",max_fixed_arity,";");

cljs.compiler.emitln.call(null,mname_31616,".cljs$lang$applyTo = ",cljs.core.some.call(null,((function (name_31615__$1,mname_31616,maxparams_31617,mmap_31618,ms_31619,loop_locals,map__31594,map__31594__$1,name,env,methods$,max_fixed_arity,variadic,recur_frames,loop_lets){
return (function (p1__31592_SHARP_){
var vec__31608 = p1__31592_SHARP_;
var n = cljs.core.nth.call(null,vec__31608,(0),null);
var m = cljs.core.nth.call(null,vec__31608,(1),null);
if(cljs.core.truth_(new cljs.core.Keyword(null,"variadic","variadic",882626057).cljs$core$IFn$_invoke$arity$1(m))){
return n;
} else {
return null;
}
});})(name_31615__$1,mname_31616,maxparams_31617,mmap_31618,ms_31619,loop_locals,map__31594,map__31594__$1,name,env,methods$,max_fixed_arity,variadic,recur_frames,loop_lets))
,ms_31619),".cljs$lang$applyTo;");
} else {
}

var seq__31609_31676 = cljs.core.seq.call(null,ms_31619);
var chunk__31610_31677 = null;
var count__31611_31678 = (0);
var i__31612_31679 = (0);
while(true){
if((i__31612_31679 < count__31611_31678)){
var vec__31613_31680 = cljs.core._nth.call(null,chunk__31610_31677,i__31612_31679);
var n_31681 = cljs.core.nth.call(null,vec__31613_31680,(0),null);
var meth_31682 = cljs.core.nth.call(null,vec__31613_31680,(1),null);
var c_31683 = cljs.core.count.call(null,new cljs.core.Keyword(null,"params","params",710516235).cljs$core$IFn$_invoke$arity$1(meth_31682));
if(cljs.core.truth_(new cljs.core.Keyword(null,"variadic","variadic",882626057).cljs$core$IFn$_invoke$arity$1(meth_31682))){
cljs.compiler.emitln.call(null,mname_31616,".cljs$core$IFn$_invoke$arity$variadic = ",n_31681,".cljs$core$IFn$_invoke$arity$variadic;");
} else {
cljs.compiler.emitln.call(null,mname_31616,".cljs$core$IFn$_invoke$arity$",c_31683," = ",n_31681,";");
}

var G__31684 = seq__31609_31676;
var G__31685 = chunk__31610_31677;
var G__31686 = count__31611_31678;
var G__31687 = (i__31612_31679 + (1));
seq__31609_31676 = G__31684;
chunk__31610_31677 = G__31685;
count__31611_31678 = G__31686;
i__31612_31679 = G__31687;
continue;
} else {
var temp__4657__auto___31688 = cljs.core.seq.call(null,seq__31609_31676);
if(temp__4657__auto___31688){
var seq__31609_31689__$1 = temp__4657__auto___31688;
if(cljs.core.chunked_seq_QMARK_.call(null,seq__31609_31689__$1)){
var c__23723__auto___31690 = cljs.core.chunk_first.call(null,seq__31609_31689__$1);
var G__31691 = cljs.core.chunk_rest.call(null,seq__31609_31689__$1);
var G__31692 = c__23723__auto___31690;
var G__31693 = cljs.core.count.call(null,c__23723__auto___31690);
var G__31694 = (0);
seq__31609_31676 = G__31691;
chunk__31610_31677 = G__31692;
count__31611_31678 = G__31693;
i__31612_31679 = G__31694;
continue;
} else {
var vec__31614_31695 = cljs.core.first.call(null,seq__31609_31689__$1);
var n_31696 = cljs.core.nth.call(null,vec__31614_31695,(0),null);
var meth_31697 = cljs.core.nth.call(null,vec__31614_31695,(1),null);
var c_31698 = cljs.core.count.call(null,new cljs.core.Keyword(null,"params","params",710516235).cljs$core$IFn$_invoke$arity$1(meth_31697));
if(cljs.core.truth_(new cljs.core.Keyword(null,"variadic","variadic",882626057).cljs$core$IFn$_invoke$arity$1(meth_31697))){
cljs.compiler.emitln.call(null,mname_31616,".cljs$core$IFn$_invoke$arity$variadic = ",n_31696,".cljs$core$IFn$_invoke$arity$variadic;");
} else {
cljs.compiler.emitln.call(null,mname_31616,".cljs$core$IFn$_invoke$arity$",c_31698," = ",n_31696,";");
}

var G__31699 = cljs.core.next.call(null,seq__31609_31689__$1);
var G__31700 = null;
var G__31701 = (0);
var G__31702 = (0);
seq__31609_31676 = G__31699;
chunk__31610_31677 = G__31700;
count__31611_31678 = G__31701;
i__31612_31679 = G__31702;
continue;
}
} else {
}
}
break;
}

cljs.compiler.emitln.call(null,"return ",mname_31616,";");

cljs.compiler.emitln.call(null,"})()");
}

if(loop_locals){
return cljs.compiler.emitln.call(null,";})(",cljs.compiler.comma_sep.call(null,loop_locals),"))");
} else {
return null;
}
}
}));
cljs.core._add_method.call(null,cljs.compiler.emit_STAR_,new cljs.core.Keyword(null,"do","do",46310725),(function (p__31703){
var map__31704 = p__31703;
var map__31704__$1 = ((((!((map__31704 == null)))?((((map__31704.cljs$lang$protocol_mask$partition0$ & (64))) || (map__31704.cljs$core$ISeq$))?true:false):false))?cljs.core.apply.call(null,cljs.core.hash_map,map__31704):map__31704);
var statements = cljs.core.get.call(null,map__31704__$1,new cljs.core.Keyword(null,"statements","statements",600349855));
var ret = cljs.core.get.call(null,map__31704__$1,new cljs.core.Keyword(null,"ret","ret",-468222814));
var env = cljs.core.get.call(null,map__31704__$1,new cljs.core.Keyword(null,"env","env",-1815813235));
var context = new cljs.core.Keyword(null,"context","context",-830191113).cljs$core$IFn$_invoke$arity$1(env);
if(cljs.core.truth_((function (){var and__22900__auto__ = statements;
if(cljs.core.truth_(and__22900__auto__)){
return cljs.core._EQ_.call(null,new cljs.core.Keyword(null,"expr","expr",745722291),context);
} else {
return and__22900__auto__;
}
})())){
cljs.compiler.emitln.call(null,"(function (){");
} else {
}

var seq__31706_31710 = cljs.core.seq.call(null,statements);
var chunk__31707_31711 = null;
var count__31708_31712 = (0);
var i__31709_31713 = (0);
while(true){
if((i__31709_31713 < count__31708_31712)){
var s_31714 = cljs.core._nth.call(null,chunk__31707_31711,i__31709_31713);
cljs.compiler.emitln.call(null,s_31714);

var G__31715 = seq__31706_31710;
var G__31716 = chunk__31707_31711;
var G__31717 = count__31708_31712;
var G__31718 = (i__31709_31713 + (1));
seq__31706_31710 = G__31715;
chunk__31707_31711 = G__31716;
count__31708_31712 = G__31717;
i__31709_31713 = G__31718;
continue;
} else {
var temp__4657__auto___31719 = cljs.core.seq.call(null,seq__31706_31710);
if(temp__4657__auto___31719){
var seq__31706_31720__$1 = temp__4657__auto___31719;
if(cljs.core.chunked_seq_QMARK_.call(null,seq__31706_31720__$1)){
var c__23723__auto___31721 = cljs.core.chunk_first.call(null,seq__31706_31720__$1);
var G__31722 = cljs.core.chunk_rest.call(null,seq__31706_31720__$1);
var G__31723 = c__23723__auto___31721;
var G__31724 = cljs.core.count.call(null,c__23723__auto___31721);
var G__31725 = (0);
seq__31706_31710 = G__31722;
chunk__31707_31711 = G__31723;
count__31708_31712 = G__31724;
i__31709_31713 = G__31725;
continue;
} else {
var s_31726 = cljs.core.first.call(null,seq__31706_31720__$1);
cljs.compiler.emitln.call(null,s_31726);

var G__31727 = cljs.core.next.call(null,seq__31706_31720__$1);
var G__31728 = null;
var G__31729 = (0);
var G__31730 = (0);
seq__31706_31710 = G__31727;
chunk__31707_31711 = G__31728;
count__31708_31712 = G__31729;
i__31709_31713 = G__31730;
continue;
}
} else {
}
}
break;
}

cljs.compiler.emit.call(null,ret);

if(cljs.core.truth_((function (){var and__22900__auto__ = statements;
if(cljs.core.truth_(and__22900__auto__)){
return cljs.core._EQ_.call(null,new cljs.core.Keyword(null,"expr","expr",745722291),context);
} else {
return and__22900__auto__;
}
})())){
return cljs.compiler.emitln.call(null,"})()");
} else {
return null;
}
}));
cljs.core._add_method.call(null,cljs.compiler.emit_STAR_,new cljs.core.Keyword(null,"try","try",1380742522),(function (p__31731){
var map__31732 = p__31731;
var map__31732__$1 = ((((!((map__31732 == null)))?((((map__31732.cljs$lang$protocol_mask$partition0$ & (64))) || (map__31732.cljs$core$ISeq$))?true:false):false))?cljs.core.apply.call(null,cljs.core.hash_map,map__31732):map__31732);
var env = cljs.core.get.call(null,map__31732__$1,new cljs.core.Keyword(null,"env","env",-1815813235));
var try$ = cljs.core.get.call(null,map__31732__$1,new cljs.core.Keyword(null,"try","try",1380742522));
var catch$ = cljs.core.get.call(null,map__31732__$1,new cljs.core.Keyword(null,"catch","catch",1038065524));
var name = cljs.core.get.call(null,map__31732__$1,new cljs.core.Keyword(null,"name","name",1843675177));
var finally$ = cljs.core.get.call(null,map__31732__$1,new cljs.core.Keyword(null,"finally","finally",1589088705));
var context = new cljs.core.Keyword(null,"context","context",-830191113).cljs$core$IFn$_invoke$arity$1(env);
if(cljs.core.truth_((function (){var or__22912__auto__ = name;
if(cljs.core.truth_(or__22912__auto__)){
return or__22912__auto__;
} else {
return finally$;
}
})())){
if(cljs.core._EQ_.call(null,new cljs.core.Keyword(null,"expr","expr",745722291),context)){
cljs.compiler.emits.call(null,"(function (){");
} else {
}

cljs.compiler.emits.call(null,"try{",try$,"}");

if(cljs.core.truth_(name)){
cljs.compiler.emits.call(null,"catch (",cljs.compiler.munge.call(null,name),"){",catch$,"}");
} else {
}

if(cljs.core.truth_(finally$)){
if(cljs.core.not_EQ_.call(null,new cljs.core.Keyword(null,"constant","constant",-379609303),new cljs.core.Keyword(null,"op","op",-1882987955).cljs$core$IFn$_invoke$arity$1(finally$))){
} else {
throw (new Error([cljs.core.str("Assert failed: "),cljs.core.str("finally block cannot contain constant"),cljs.core.str("\n"),cljs.core.str("(not= :constant (:op finally))")].join('')));
}

cljs.compiler.emits.call(null,"finally {",finally$,"}");
} else {
}

if(cljs.core._EQ_.call(null,new cljs.core.Keyword(null,"expr","expr",745722291),context)){
return cljs.compiler.emits.call(null,"})()");
} else {
return null;
}
} else {
return cljs.compiler.emits.call(null,try$);
}
}));
cljs.compiler.emit_let = (function cljs$compiler$emit_let(p__31734,is_loop){
var map__31746 = p__31734;
var map__31746__$1 = ((((!((map__31746 == null)))?((((map__31746.cljs$lang$protocol_mask$partition0$ & (64))) || (map__31746.cljs$core$ISeq$))?true:false):false))?cljs.core.apply.call(null,cljs.core.hash_map,map__31746):map__31746);
var bindings = cljs.core.get.call(null,map__31746__$1,new cljs.core.Keyword(null,"bindings","bindings",1271397192));
var expr = cljs.core.get.call(null,map__31746__$1,new cljs.core.Keyword(null,"expr","expr",745722291));
var env = cljs.core.get.call(null,map__31746__$1,new cljs.core.Keyword(null,"env","env",-1815813235));
var context = new cljs.core.Keyword(null,"context","context",-830191113).cljs$core$IFn$_invoke$arity$1(env);
if(cljs.core._EQ_.call(null,new cljs.core.Keyword(null,"expr","expr",745722291),context)){
cljs.compiler.emits.call(null,"(function (){");
} else {
}

var _STAR_lexical_renames_STAR_31748_31757 = cljs.compiler._STAR_lexical_renames_STAR_;
cljs.compiler._STAR_lexical_renames_STAR_ = cljs.core.into.call(null,cljs.compiler._STAR_lexical_renames_STAR_,((cljs.core._EQ_.call(null,new cljs.core.Keyword(null,"statement","statement",-32780863),context))?cljs.core.map.call(null,((function (_STAR_lexical_renames_STAR_31748_31757,context,map__31746,map__31746__$1,bindings,expr,env){
return (function (binding){
var name = new cljs.core.Keyword(null,"name","name",1843675177).cljs$core$IFn$_invoke$arity$1(binding);
return (new cljs.core.PersistentVector(null,2,(5),cljs.core.PersistentVector.EMPTY_NODE,[cljs.compiler.hash_scope.call(null,binding),cljs.core.gensym.call(null,[cljs.core.str(name),cljs.core.str("-")].join(''))],null));
});})(_STAR_lexical_renames_STAR_31748_31757,context,map__31746,map__31746__$1,bindings,expr,env))
,bindings):null));

try{var seq__31749_31758 = cljs.core.seq.call(null,bindings);
var chunk__31750_31759 = null;
var count__31751_31760 = (0);
var i__31752_31761 = (0);
while(true){
if((i__31752_31761 < count__31751_31760)){
var map__31753_31762 = cljs.core._nth.call(null,chunk__31750_31759,i__31752_31761);
var map__31753_31763__$1 = ((((!((map__31753_31762 == null)))?((((map__31753_31762.cljs$lang$protocol_mask$partition0$ & (64))) || (map__31753_31762.cljs$core$ISeq$))?true:false):false))?cljs.core.apply.call(null,cljs.core.hash_map,map__31753_31762):map__31753_31762);
var binding_31764 = map__31753_31763__$1;
var init_31765 = cljs.core.get.call(null,map__31753_31763__$1,new cljs.core.Keyword(null,"init","init",-1875481434));
cljs.compiler.emits.call(null,"var ");

cljs.compiler.emit.call(null,binding_31764);

cljs.compiler.emitln.call(null," = ",init_31765,";");

var G__31766 = seq__31749_31758;
var G__31767 = chunk__31750_31759;
var G__31768 = count__31751_31760;
var G__31769 = (i__31752_31761 + (1));
seq__31749_31758 = G__31766;
chunk__31750_31759 = G__31767;
count__31751_31760 = G__31768;
i__31752_31761 = G__31769;
continue;
} else {
var temp__4657__auto___31770 = cljs.core.seq.call(null,seq__31749_31758);
if(temp__4657__auto___31770){
var seq__31749_31771__$1 = temp__4657__auto___31770;
if(cljs.core.chunked_seq_QMARK_.call(null,seq__31749_31771__$1)){
var c__23723__auto___31772 = cljs.core.chunk_first.call(null,seq__31749_31771__$1);
var G__31773 = cljs.core.chunk_rest.call(null,seq__31749_31771__$1);
var G__31774 = c__23723__auto___31772;
var G__31775 = cljs.core.count.call(null,c__23723__auto___31772);
var G__31776 = (0);
seq__31749_31758 = G__31773;
chunk__31750_31759 = G__31774;
count__31751_31760 = G__31775;
i__31752_31761 = G__31776;
continue;
} else {
var map__31755_31777 = cljs.core.first.call(null,seq__31749_31771__$1);
var map__31755_31778__$1 = ((((!((map__31755_31777 == null)))?((((map__31755_31777.cljs$lang$protocol_mask$partition0$ & (64))) || (map__31755_31777.cljs$core$ISeq$))?true:false):false))?cljs.core.apply.call(null,cljs.core.hash_map,map__31755_31777):map__31755_31777);
var binding_31779 = map__31755_31778__$1;
var init_31780 = cljs.core.get.call(null,map__31755_31778__$1,new cljs.core.Keyword(null,"init","init",-1875481434));
cljs.compiler.emits.call(null,"var ");

cljs.compiler.emit.call(null,binding_31779);

cljs.compiler.emitln.call(null," = ",init_31780,";");

var G__31781 = cljs.core.next.call(null,seq__31749_31771__$1);
var G__31782 = null;
var G__31783 = (0);
var G__31784 = (0);
seq__31749_31758 = G__31781;
chunk__31750_31759 = G__31782;
count__31751_31760 = G__31783;
i__31752_31761 = G__31784;
continue;
}
} else {
}
}
break;
}

if(cljs.core.truth_(is_loop)){
cljs.compiler.emitln.call(null,"while(true){");
} else {
}

cljs.compiler.emits.call(null,expr);

if(cljs.core.truth_(is_loop)){
cljs.compiler.emitln.call(null,"break;");

cljs.compiler.emitln.call(null,"}");
} else {
}
}finally {cljs.compiler._STAR_lexical_renames_STAR_ = _STAR_lexical_renames_STAR_31748_31757;
}
if(cljs.core._EQ_.call(null,new cljs.core.Keyword(null,"expr","expr",745722291),context)){
return cljs.compiler.emits.call(null,"})()");
} else {
return null;
}
});
cljs.core._add_method.call(null,cljs.compiler.emit_STAR_,new cljs.core.Keyword(null,"let","let",-1282412701),(function (ast){
return cljs.compiler.emit_let.call(null,ast,false);
}));
cljs.core._add_method.call(null,cljs.compiler.emit_STAR_,new cljs.core.Keyword(null,"loop","loop",-395552849),(function (ast){
return cljs.compiler.emit_let.call(null,ast,true);
}));
cljs.core._add_method.call(null,cljs.compiler.emit_STAR_,new cljs.core.Keyword(null,"recur","recur",-437573268),(function (p__31785){
var map__31786 = p__31785;
var map__31786__$1 = ((((!((map__31786 == null)))?((((map__31786.cljs$lang$protocol_mask$partition0$ & (64))) || (map__31786.cljs$core$ISeq$))?true:false):false))?cljs.core.apply.call(null,cljs.core.hash_map,map__31786):map__31786);
var frame = cljs.core.get.call(null,map__31786__$1,new cljs.core.Keyword(null,"frame","frame",-1711082588));
var exprs = cljs.core.get.call(null,map__31786__$1,new cljs.core.Keyword(null,"exprs","exprs",1795829094));
var env = cljs.core.get.call(null,map__31786__$1,new cljs.core.Keyword(null,"env","env",-1815813235));
var temps = cljs.core.vec.call(null,cljs.core.take.call(null,cljs.core.count.call(null,exprs),cljs.core.repeatedly.call(null,cljs.core.gensym)));
var params = new cljs.core.Keyword(null,"params","params",710516235).cljs$core$IFn$_invoke$arity$1(frame);
var n__23827__auto___31788 = cljs.core.count.call(null,exprs);
var i_31789 = (0);
while(true){
if((i_31789 < n__23827__auto___31788)){
cljs.compiler.emitln.call(null,"var ",temps.call(null,i_31789)," = ",exprs.call(null,i_31789),";");

var G__31790 = (i_31789 + (1));
i_31789 = G__31790;
continue;
} else {
}
break;
}

var n__23827__auto___31791 = cljs.core.count.call(null,exprs);
var i_31792 = (0);
while(true){
if((i_31792 < n__23827__auto___31791)){
cljs.compiler.emitln.call(null,cljs.compiler.munge.call(null,params.call(null,i_31792))," = ",temps.call(null,i_31792),";");

var G__31793 = (i_31792 + (1));
i_31792 = G__31793;
continue;
} else {
}
break;
}

return cljs.compiler.emitln.call(null,"continue;");
}));
cljs.core._add_method.call(null,cljs.compiler.emit_STAR_,new cljs.core.Keyword(null,"letfn","letfn",-2121022354),(function (p__31794){
var map__31795 = p__31794;
var map__31795__$1 = ((((!((map__31795 == null)))?((((map__31795.cljs$lang$protocol_mask$partition0$ & (64))) || (map__31795.cljs$core$ISeq$))?true:false):false))?cljs.core.apply.call(null,cljs.core.hash_map,map__31795):map__31795);
var bindings = cljs.core.get.call(null,map__31795__$1,new cljs.core.Keyword(null,"bindings","bindings",1271397192));
var expr = cljs.core.get.call(null,map__31795__$1,new cljs.core.Keyword(null,"expr","expr",745722291));
var env = cljs.core.get.call(null,map__31795__$1,new cljs.core.Keyword(null,"env","env",-1815813235));
var context = new cljs.core.Keyword(null,"context","context",-830191113).cljs$core$IFn$_invoke$arity$1(env);
if(cljs.core._EQ_.call(null,new cljs.core.Keyword(null,"expr","expr",745722291),context)){
cljs.compiler.emits.call(null,"(function (){");
} else {
}

var seq__31797_31805 = cljs.core.seq.call(null,bindings);
var chunk__31798_31806 = null;
var count__31799_31807 = (0);
var i__31800_31808 = (0);
while(true){
if((i__31800_31808 < count__31799_31807)){
var map__31801_31809 = cljs.core._nth.call(null,chunk__31798_31806,i__31800_31808);
var map__31801_31810__$1 = ((((!((map__31801_31809 == null)))?((((map__31801_31809.cljs$lang$protocol_mask$partition0$ & (64))) || (map__31801_31809.cljs$core$ISeq$))?true:false):false))?cljs.core.apply.call(null,cljs.core.hash_map,map__31801_31809):map__31801_31809);
var binding_31811 = map__31801_31810__$1;
var init_31812 = cljs.core.get.call(null,map__31801_31810__$1,new cljs.core.Keyword(null,"init","init",-1875481434));
cljs.compiler.emitln.call(null,"var ",cljs.compiler.munge.call(null,binding_31811)," = ",init_31812,";");

var G__31813 = seq__31797_31805;
var G__31814 = chunk__31798_31806;
var G__31815 = count__31799_31807;
var G__31816 = (i__31800_31808 + (1));
seq__31797_31805 = G__31813;
chunk__31798_31806 = G__31814;
count__31799_31807 = G__31815;
i__31800_31808 = G__31816;
continue;
} else {
var temp__4657__auto___31817 = cljs.core.seq.call(null,seq__31797_31805);
if(temp__4657__auto___31817){
var seq__31797_31818__$1 = temp__4657__auto___31817;
if(cljs.core.chunked_seq_QMARK_.call(null,seq__31797_31818__$1)){
var c__23723__auto___31819 = cljs.core.chunk_first.call(null,seq__31797_31818__$1);
var G__31820 = cljs.core.chunk_rest.call(null,seq__31797_31818__$1);
var G__31821 = c__23723__auto___31819;
var G__31822 = cljs.core.count.call(null,c__23723__auto___31819);
var G__31823 = (0);
seq__31797_31805 = G__31820;
chunk__31798_31806 = G__31821;
count__31799_31807 = G__31822;
i__31800_31808 = G__31823;
continue;
} else {
var map__31803_31824 = cljs.core.first.call(null,seq__31797_31818__$1);
var map__31803_31825__$1 = ((((!((map__31803_31824 == null)))?((((map__31803_31824.cljs$lang$protocol_mask$partition0$ & (64))) || (map__31803_31824.cljs$core$ISeq$))?true:false):false))?cljs.core.apply.call(null,cljs.core.hash_map,map__31803_31824):map__31803_31824);
var binding_31826 = map__31803_31825__$1;
var init_31827 = cljs.core.get.call(null,map__31803_31825__$1,new cljs.core.Keyword(null,"init","init",-1875481434));
cljs.compiler.emitln.call(null,"var ",cljs.compiler.munge.call(null,binding_31826)," = ",init_31827,";");

var G__31828 = cljs.core.next.call(null,seq__31797_31818__$1);
var G__31829 = null;
var G__31830 = (0);
var G__31831 = (0);
seq__31797_31805 = G__31828;
chunk__31798_31806 = G__31829;
count__31799_31807 = G__31830;
i__31800_31808 = G__31831;
continue;
}
} else {
}
}
break;
}

cljs.compiler.emits.call(null,expr);

if(cljs.core._EQ_.call(null,new cljs.core.Keyword(null,"expr","expr",745722291),context)){
return cljs.compiler.emits.call(null,"})()");
} else {
return null;
}
}));
cljs.compiler.protocol_prefix = (function cljs$compiler$protocol_prefix(psym){
return cljs.core.symbol.call(null,[cljs.core.str([cljs.core.str(psym)].join('').replace((new RegExp("\\.","g")),"$").replace("/","$")),cljs.core.str("$")].join(''));
});
cljs.core._add_method.call(null,cljs.compiler.emit_STAR_,new cljs.core.Keyword(null,"invoke","invoke",1145927159),(function (p__31834){
var map__31835 = p__31834;
var map__31835__$1 = ((((!((map__31835 == null)))?((((map__31835.cljs$lang$protocol_mask$partition0$ & (64))) || (map__31835.cljs$core$ISeq$))?true:false):false))?cljs.core.apply.call(null,cljs.core.hash_map,map__31835):map__31835);
var expr = map__31835__$1;
var f = cljs.core.get.call(null,map__31835__$1,new cljs.core.Keyword(null,"f","f",-1597136552));
var args = cljs.core.get.call(null,map__31835__$1,new cljs.core.Keyword(null,"args","args",1315556576));
var env = cljs.core.get.call(null,map__31835__$1,new cljs.core.Keyword(null,"env","env",-1815813235));
var info = new cljs.core.Keyword(null,"info","info",-317069002).cljs$core$IFn$_invoke$arity$1(f);
var fn_QMARK_ = (function (){var and__22900__auto__ = cljs.analyzer._STAR_cljs_static_fns_STAR_;
if(cljs.core.truth_(and__22900__auto__)){
var and__22900__auto____$1 = cljs.core.not.call(null,new cljs.core.Keyword(null,"dynamic","dynamic",704819571).cljs$core$IFn$_invoke$arity$1(info));
if(and__22900__auto____$1){
return new cljs.core.Keyword(null,"fn-var","fn-var",1086204730).cljs$core$IFn$_invoke$arity$1(info);
} else {
return and__22900__auto____$1;
}
} else {
return and__22900__auto__;
}
})();
var protocol = new cljs.core.Keyword(null,"protocol","protocol",652470118).cljs$core$IFn$_invoke$arity$1(info);
var tag = cljs.analyzer.infer_tag.call(null,env,cljs.core.first.call(null,new cljs.core.Keyword(null,"args","args",1315556576).cljs$core$IFn$_invoke$arity$1(expr)));
var proto_QMARK_ = (function (){var and__22900__auto__ = protocol;
if(cljs.core.truth_(and__22900__auto__)){
var and__22900__auto____$1 = tag;
if(cljs.core.truth_(and__22900__auto____$1)){
var or__22912__auto__ = (function (){var and__22900__auto____$2 = cljs.analyzer._STAR_cljs_static_fns_STAR_;
if(cljs.core.truth_(and__22900__auto____$2)){
var and__22900__auto____$3 = protocol;
if(cljs.core.truth_(and__22900__auto____$3)){
return cljs.core._EQ_.call(null,tag,new cljs.core.Symbol(null,"not-native","not-native",-236392494,null));
} else {
return and__22900__auto____$3;
}
} else {
return and__22900__auto____$2;
}
})();
if(cljs.core.truth_(or__22912__auto__)){
return or__22912__auto__;
} else {
var and__22900__auto____$2 = (function (){var or__22912__auto____$1 = cljs.analyzer._STAR_cljs_static_fns_STAR_;
if(cljs.core.truth_(or__22912__auto____$1)){
return or__22912__auto____$1;
} else {
return new cljs.core.Keyword(null,"protocol-inline","protocol-inline",1550487556).cljs$core$IFn$_invoke$arity$1(env);
}
})();
if(cljs.core.truth_(and__22900__auto____$2)){
var or__22912__auto____$1 = cljs.core._EQ_.call(null,protocol,tag);
if(or__22912__auto____$1){
return or__22912__auto____$1;
} else {
var and__22900__auto____$3 = !(cljs.core.set_QMARK_.call(null,tag));
if(and__22900__auto____$3){
var and__22900__auto____$4 = cljs.core.not.call(null,new cljs.core.PersistentHashSet(null, new cljs.core.PersistentArrayMap(null, 10, [new cljs.core.Symbol(null,"clj","clj",980036099,null),null,new cljs.core.Symbol(null,"boolean","boolean",-278886877,null),null,new cljs.core.Symbol(null,"object","object",-1179821820,null),null,new cljs.core.Symbol(null,"any","any",-948528346,null),null,new cljs.core.Symbol(null,"number","number",-1084057331,null),null,new cljs.core.Symbol(null,"clj-or-nil","clj-or-nil",-2008798668,null),null,new cljs.core.Symbol(null,"array","array",-440182315,null),null,new cljs.core.Symbol(null,"string","string",-349010059,null),null,new cljs.core.Symbol(null,"function","function",-486723946,null),null,new cljs.core.Symbol(null,"clj-nil","clj-nil",1321798654,null),null], null), null).call(null,tag));
if(and__22900__auto____$4){
var temp__4657__auto__ = new cljs.core.Keyword(null,"protocols","protocols",-5615896).cljs$core$IFn$_invoke$arity$1(cljs.analyzer.resolve_existing_var.call(null,cljs.core.dissoc.call(null,env,new cljs.core.Keyword(null,"locals","locals",535295783)),tag));
if(cljs.core.truth_(temp__4657__auto__)){
var ps = temp__4657__auto__;
return ps.call(null,protocol);
} else {
return null;
}
} else {
return and__22900__auto____$4;
}
} else {
return and__22900__auto____$3;
}
}
} else {
return and__22900__auto____$2;
}
}
} else {
return and__22900__auto____$1;
}
} else {
return and__22900__auto__;
}
})();
var opt_not_QMARK_ = (cljs.core._EQ_.call(null,new cljs.core.Keyword(null,"name","name",1843675177).cljs$core$IFn$_invoke$arity$1(info),new cljs.core.Symbol("cljs.core","not","cljs.core/not",100665144,null))) && (cljs.core._EQ_.call(null,cljs.analyzer.infer_tag.call(null,env,cljs.core.first.call(null,new cljs.core.Keyword(null,"args","args",1315556576).cljs$core$IFn$_invoke$arity$1(expr))),new cljs.core.Symbol(null,"boolean","boolean",-278886877,null)));
var ns = new cljs.core.Keyword(null,"ns","ns",441598760).cljs$core$IFn$_invoke$arity$1(info);
var js_QMARK_ = (cljs.core._EQ_.call(null,ns,new cljs.core.Symbol(null,"js","js",-886355190,null))) || (cljs.core._EQ_.call(null,ns,new cljs.core.Symbol(null,"Math","Math",2033287572,null)));
var goog_QMARK_ = (cljs.core.truth_(ns)?(function (){var or__22912__auto__ = cljs.core._EQ_.call(null,ns,new cljs.core.Symbol(null,"goog","goog",-70603925,null));
if(or__22912__auto__){
return or__22912__auto__;
} else {
var temp__4657__auto__ = [cljs.core.str(ns)].join('');
if(cljs.core.truth_(temp__4657__auto__)){
var ns_str = temp__4657__auto__;
return cljs.core._EQ_.call(null,cljs.core.get.call(null,clojure.string.split.call(null,ns_str,/\./),(0),null),"goog");
} else {
return null;
}
}
})():null);
var keyword_QMARK_ = (cljs.core._EQ_.call(null,new cljs.core.Keyword(null,"op","op",-1882987955).cljs$core$IFn$_invoke$arity$1(f),new cljs.core.Keyword(null,"constant","constant",-379609303))) && ((new cljs.core.Keyword(null,"form","form",-1624062471).cljs$core$IFn$_invoke$arity$1(f) instanceof cljs.core.Keyword));
var vec__31837 = (cljs.core.truth_(fn_QMARK_)?(function (){var arity = cljs.core.count.call(null,args);
var variadic_QMARK_ = new cljs.core.Keyword(null,"variadic","variadic",882626057).cljs$core$IFn$_invoke$arity$1(info);
var mps = new cljs.core.Keyword(null,"method-params","method-params",-980792179).cljs$core$IFn$_invoke$arity$1(info);
var mfa = new cljs.core.Keyword(null,"max-fixed-arity","max-fixed-arity",-690205543).cljs$core$IFn$_invoke$arity$1(info);
if((cljs.core.not.call(null,variadic_QMARK_)) && (cljs.core._EQ_.call(null,cljs.core.count.call(null,mps),(1)))){
return new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [f,null], null);
} else {
if(cljs.core.truth_((function (){var and__22900__auto__ = variadic_QMARK_;
if(cljs.core.truth_(and__22900__auto__)){
return (arity > mfa);
} else {
return and__22900__auto__;
}
})())){
return new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.update_in.call(null,f,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword(null,"info","info",-317069002)], null),((function (arity,variadic_QMARK_,mps,mfa,info,fn_QMARK_,protocol,tag,proto_QMARK_,opt_not_QMARK_,ns,js_QMARK_,goog_QMARK_,keyword_QMARK_,map__31835,map__31835__$1,expr,f,args,env){
return (function (info__$1){
return cljs.core.update_in.call(null,cljs.core.assoc.call(null,info__$1,new cljs.core.Keyword(null,"name","name",1843675177),cljs.core.symbol.call(null,[cljs.core.str(cljs.compiler.munge.call(null,info__$1)),cljs.core.str(".cljs$core$IFn$_invoke$arity$variadic")].join(''))),new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword(null,"info","info",-317069002)], null),((function (arity,variadic_QMARK_,mps,mfa,info,fn_QMARK_,protocol,tag,proto_QMARK_,opt_not_QMARK_,ns,js_QMARK_,goog_QMARK_,keyword_QMARK_,map__31835,map__31835__$1,expr,f,args,env){
return (function (p1__31832_SHARP_){
return cljs.core.dissoc.call(null,cljs.core.dissoc.call(null,p1__31832_SHARP_,new cljs.core.Keyword(null,"shadow","shadow",873231803)),new cljs.core.Keyword(null,"fn-self-name","fn-self-name",1461143531));
});})(arity,variadic_QMARK_,mps,mfa,info,fn_QMARK_,protocol,tag,proto_QMARK_,opt_not_QMARK_,ns,js_QMARK_,goog_QMARK_,keyword_QMARK_,map__31835,map__31835__$1,expr,f,args,env))
);
});})(arity,variadic_QMARK_,mps,mfa,info,fn_QMARK_,protocol,tag,proto_QMARK_,opt_not_QMARK_,ns,js_QMARK_,goog_QMARK_,keyword_QMARK_,map__31835,map__31835__$1,expr,f,args,env))
),new cljs.core.PersistentArrayMap(null, 1, [new cljs.core.Keyword(null,"max-fixed-arity","max-fixed-arity",-690205543),mfa], null)], null);
} else {
var arities = cljs.core.map.call(null,cljs.core.count,mps);
if(cljs.core.truth_(cljs.core.some.call(null,cljs.core.PersistentHashSet.fromArray([arity], true),arities))){
return new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.update_in.call(null,f,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword(null,"info","info",-317069002)], null),((function (arities,arity,variadic_QMARK_,mps,mfa,info,fn_QMARK_,protocol,tag,proto_QMARK_,opt_not_QMARK_,ns,js_QMARK_,goog_QMARK_,keyword_QMARK_,map__31835,map__31835__$1,expr,f,args,env){
return (function (info__$1){
return cljs.core.update_in.call(null,cljs.core.assoc.call(null,info__$1,new cljs.core.Keyword(null,"name","name",1843675177),cljs.core.symbol.call(null,[cljs.core.str(cljs.compiler.munge.call(null,info__$1)),cljs.core.str(".cljs$core$IFn$_invoke$arity$"),cljs.core.str(arity)].join(''))),new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword(null,"info","info",-317069002)], null),((function (arities,arity,variadic_QMARK_,mps,mfa,info,fn_QMARK_,protocol,tag,proto_QMARK_,opt_not_QMARK_,ns,js_QMARK_,goog_QMARK_,keyword_QMARK_,map__31835,map__31835__$1,expr,f,args,env){
return (function (p1__31833_SHARP_){
return cljs.core.dissoc.call(null,cljs.core.dissoc.call(null,p1__31833_SHARP_,new cljs.core.Keyword(null,"shadow","shadow",873231803)),new cljs.core.Keyword(null,"fn-self-name","fn-self-name",1461143531));
});})(arities,arity,variadic_QMARK_,mps,mfa,info,fn_QMARK_,protocol,tag,proto_QMARK_,opt_not_QMARK_,ns,js_QMARK_,goog_QMARK_,keyword_QMARK_,map__31835,map__31835__$1,expr,f,args,env))
);
});})(arities,arity,variadic_QMARK_,mps,mfa,info,fn_QMARK_,protocol,tag,proto_QMARK_,opt_not_QMARK_,ns,js_QMARK_,goog_QMARK_,keyword_QMARK_,map__31835,map__31835__$1,expr,f,args,env))
),null], null);
} else {
return new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [f,null], null);
}

}
}
})():new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [f,null], null));
var f__$1 = cljs.core.nth.call(null,vec__31837,(0),null);
var variadic_invoke = cljs.core.nth.call(null,vec__31837,(1),null);
var env__25235__auto__ = env;
if(cljs.core._EQ_.call(null,new cljs.core.Keyword(null,"return","return",-1891502105),new cljs.core.Keyword(null,"context","context",-830191113).cljs$core$IFn$_invoke$arity$1(env__25235__auto__))){
cljs.compiler.emits.call(null,"return ");
} else {
}

if(opt_not_QMARK_){
cljs.compiler.emits.call(null,"!(",cljs.core.first.call(null,args),")");
} else {
if(cljs.core.truth_(proto_QMARK_)){
var pimpl_31838 = [cljs.core.str(cljs.compiler.munge.call(null,cljs.compiler.protocol_prefix.call(null,protocol))),cljs.core.str(cljs.compiler.munge.call(null,cljs.core.name.call(null,new cljs.core.Keyword(null,"name","name",1843675177).cljs$core$IFn$_invoke$arity$1(info)))),cljs.core.str("$arity$"),cljs.core.str(cljs.core.count.call(null,args))].join('');
cljs.compiler.emits.call(null,cljs.core.first.call(null,args),".",pimpl_31838,"(",cljs.compiler.comma_sep.call(null,cljs.core.cons.call(null,"null",cljs.core.rest.call(null,args))),")");
} else {
if(keyword_QMARK_){
cljs.compiler.emits.call(null,f__$1,".cljs$core$IFn$_invoke$arity$",cljs.core.count.call(null,args),"(",cljs.compiler.comma_sep.call(null,args),")");
} else {
if(cljs.core.truth_(variadic_invoke)){
var mfa_31839 = new cljs.core.Keyword(null,"max-fixed-arity","max-fixed-arity",-690205543).cljs$core$IFn$_invoke$arity$1(variadic_invoke);
cljs.compiler.emits.call(null,f__$1,"(",cljs.compiler.comma_sep.call(null,cljs.core.take.call(null,mfa_31839,args)),(((mfa_31839 === (0)))?null:","),"cljs.core.array_seq([",cljs.compiler.comma_sep.call(null,cljs.core.drop.call(null,mfa_31839,args)),"], 0))");
} else {
if(cljs.core.truth_((function (){var or__22912__auto__ = fn_QMARK_;
if(cljs.core.truth_(or__22912__auto__)){
return or__22912__auto__;
} else {
var or__22912__auto____$1 = js_QMARK_;
if(or__22912__auto____$1){
return or__22912__auto____$1;
} else {
return goog_QMARK_;
}
}
})())){
cljs.compiler.emits.call(null,f__$1,"(",cljs.compiler.comma_sep.call(null,args),")");
} else {
if(cljs.core.truth_((function (){var and__22900__auto__ = cljs.analyzer._STAR_cljs_static_fns_STAR_;
if(cljs.core.truth_(and__22900__auto__)){
return cljs.core._EQ_.call(null,new cljs.core.Keyword(null,"op","op",-1882987955).cljs$core$IFn$_invoke$arity$1(f__$1),new cljs.core.Keyword(null,"var","var",-769682797));
} else {
return and__22900__auto__;
}
})())){
var fprop_31840 = [cljs.core.str(".cljs$core$IFn$_invoke$arity$"),cljs.core.str(cljs.core.count.call(null,args))].join('');
cljs.compiler.emits.call(null,"(",f__$1,fprop_31840," ? ",f__$1,fprop_31840,"(",cljs.compiler.comma_sep.call(null,args),") : ",f__$1,".call(",cljs.compiler.comma_sep.call(null,cljs.core.cons.call(null,"null",args)),"))");
} else {
cljs.compiler.emits.call(null,f__$1,".call(",cljs.compiler.comma_sep.call(null,cljs.core.cons.call(null,"null",args)),")");
}

}
}
}
}
}

if(cljs.core._EQ_.call(null,new cljs.core.Keyword(null,"expr","expr",745722291),new cljs.core.Keyword(null,"context","context",-830191113).cljs$core$IFn$_invoke$arity$1(env__25235__auto__))){
return null;
} else {
return cljs.compiler.emitln.call(null,";");
}
}));
cljs.core._add_method.call(null,cljs.compiler.emit_STAR_,new cljs.core.Keyword(null,"new","new",-2085437848),(function (p__31841){
var map__31842 = p__31841;
var map__31842__$1 = ((((!((map__31842 == null)))?((((map__31842.cljs$lang$protocol_mask$partition0$ & (64))) || (map__31842.cljs$core$ISeq$))?true:false):false))?cljs.core.apply.call(null,cljs.core.hash_map,map__31842):map__31842);
var ctor = cljs.core.get.call(null,map__31842__$1,new cljs.core.Keyword(null,"ctor","ctor",1750864802));
var args = cljs.core.get.call(null,map__31842__$1,new cljs.core.Keyword(null,"args","args",1315556576));
var env = cljs.core.get.call(null,map__31842__$1,new cljs.core.Keyword(null,"env","env",-1815813235));
var env__25235__auto__ = env;
if(cljs.core._EQ_.call(null,new cljs.core.Keyword(null,"return","return",-1891502105),new cljs.core.Keyword(null,"context","context",-830191113).cljs$core$IFn$_invoke$arity$1(env__25235__auto__))){
cljs.compiler.emits.call(null,"return ");
} else {
}

cljs.compiler.emits.call(null,"(new ",ctor,"(",cljs.compiler.comma_sep.call(null,args),"))");

if(cljs.core._EQ_.call(null,new cljs.core.Keyword(null,"expr","expr",745722291),new cljs.core.Keyword(null,"context","context",-830191113).cljs$core$IFn$_invoke$arity$1(env__25235__auto__))){
return null;
} else {
return cljs.compiler.emitln.call(null,";");
}
}));
cljs.core._add_method.call(null,cljs.compiler.emit_STAR_,new cljs.core.Keyword(null,"set!","set!",-1389817006),(function (p__31844){
var map__31845 = p__31844;
var map__31845__$1 = ((((!((map__31845 == null)))?((((map__31845.cljs$lang$protocol_mask$partition0$ & (64))) || (map__31845.cljs$core$ISeq$))?true:false):false))?cljs.core.apply.call(null,cljs.core.hash_map,map__31845):map__31845);
var target = cljs.core.get.call(null,map__31845__$1,new cljs.core.Keyword(null,"target","target",253001721));
var val = cljs.core.get.call(null,map__31845__$1,new cljs.core.Keyword(null,"val","val",128701612));
var env = cljs.core.get.call(null,map__31845__$1,new cljs.core.Keyword(null,"env","env",-1815813235));
var env__25235__auto__ = env;
if(cljs.core._EQ_.call(null,new cljs.core.Keyword(null,"return","return",-1891502105),new cljs.core.Keyword(null,"context","context",-830191113).cljs$core$IFn$_invoke$arity$1(env__25235__auto__))){
cljs.compiler.emits.call(null,"return ");
} else {
}

cljs.compiler.emits.call(null,target," = ",val);

if(cljs.core._EQ_.call(null,new cljs.core.Keyword(null,"expr","expr",745722291),new cljs.core.Keyword(null,"context","context",-830191113).cljs$core$IFn$_invoke$arity$1(env__25235__auto__))){
return null;
} else {
return cljs.compiler.emitln.call(null,";");
}
}));
cljs.compiler.load_libs = (function cljs$compiler$load_libs(libs,seen,reloads){
var loaded_libs = cljs.compiler.munge.call(null,new cljs.core.Symbol(null,"cljs.core.*loaded-libs*","cljs.core.*loaded-libs*",-1847086525,null));
var loaded_libs_temp = cljs.compiler.munge.call(null,cljs.core.gensym.call(null,new cljs.core.Symbol(null,"cljs.core.*loaded-libs*","cljs.core.*loaded-libs*",-1847086525,null)));
if(cljs.core.truth_(new cljs.core.Keyword(null,"reload-all","reload-all",761570200).cljs$core$IFn$_invoke$arity$1(cljs.core.meta.call(null,libs)))){
cljs.compiler.emitln.call(null,"if(!COMPILED) ",loaded_libs_temp," = ",loaded_libs," || cljs.core.set();");

cljs.compiler.emitln.call(null,"if(!COMPILED) ",loaded_libs," = cljs.core.set();");
} else {
}

var seq__31851_31855 = cljs.core.seq.call(null,cljs.core.remove.call(null,cljs.core.set.call(null,cljs.core.vals.call(null,seen)),cljs.core.distinct.call(null,cljs.core.vals.call(null,libs))));
var chunk__31852_31856 = null;
var count__31853_31857 = (0);
var i__31854_31858 = (0);
while(true){
if((i__31854_31858 < count__31853_31857)){
var lib_31859 = cljs.core._nth.call(null,chunk__31852_31856,i__31854_31858);
if(cljs.core.truth_((function (){var or__22912__auto__ = new cljs.core.Keyword(null,"reload","reload",863702807).cljs$core$IFn$_invoke$arity$1(cljs.core.meta.call(null,libs));
if(cljs.core.truth_(or__22912__auto__)){
return or__22912__auto__;
} else {
return cljs.core._EQ_.call(null,cljs.core.get.call(null,reloads,lib_31859),new cljs.core.Keyword(null,"reload","reload",863702807));
}
})())){
cljs.compiler.emitln.call(null,"goog.require('",cljs.compiler.munge.call(null,lib_31859),"', 'reload');");
} else {
if(cljs.core.truth_((function (){var or__22912__auto__ = new cljs.core.Keyword(null,"reload-all","reload-all",761570200).cljs$core$IFn$_invoke$arity$1(cljs.core.meta.call(null,libs));
if(cljs.core.truth_(or__22912__auto__)){
return or__22912__auto__;
} else {
return cljs.core._EQ_.call(null,cljs.core.get.call(null,reloads,lib_31859),new cljs.core.Keyword(null,"reload-all","reload-all",761570200));
}
})())){
cljs.compiler.emitln.call(null,"goog.require('",cljs.compiler.munge.call(null,lib_31859),"', 'reload-all');");
} else {
cljs.compiler.emitln.call(null,"goog.require('",cljs.compiler.munge.call(null,lib_31859),"');");

}
}

var G__31860 = seq__31851_31855;
var G__31861 = chunk__31852_31856;
var G__31862 = count__31853_31857;
var G__31863 = (i__31854_31858 + (1));
seq__31851_31855 = G__31860;
chunk__31852_31856 = G__31861;
count__31853_31857 = G__31862;
i__31854_31858 = G__31863;
continue;
} else {
var temp__4657__auto___31864 = cljs.core.seq.call(null,seq__31851_31855);
if(temp__4657__auto___31864){
var seq__31851_31865__$1 = temp__4657__auto___31864;
if(cljs.core.chunked_seq_QMARK_.call(null,seq__31851_31865__$1)){
var c__23723__auto___31866 = cljs.core.chunk_first.call(null,seq__31851_31865__$1);
var G__31867 = cljs.core.chunk_rest.call(null,seq__31851_31865__$1);
var G__31868 = c__23723__auto___31866;
var G__31869 = cljs.core.count.call(null,c__23723__auto___31866);
var G__31870 = (0);
seq__31851_31855 = G__31867;
chunk__31852_31856 = G__31868;
count__31853_31857 = G__31869;
i__31854_31858 = G__31870;
continue;
} else {
var lib_31871 = cljs.core.first.call(null,seq__31851_31865__$1);
if(cljs.core.truth_((function (){var or__22912__auto__ = new cljs.core.Keyword(null,"reload","reload",863702807).cljs$core$IFn$_invoke$arity$1(cljs.core.meta.call(null,libs));
if(cljs.core.truth_(or__22912__auto__)){
return or__22912__auto__;
} else {
return cljs.core._EQ_.call(null,cljs.core.get.call(null,reloads,lib_31871),new cljs.core.Keyword(null,"reload","reload",863702807));
}
})())){
cljs.compiler.emitln.call(null,"goog.require('",cljs.compiler.munge.call(null,lib_31871),"', 'reload');");
} else {
if(cljs.core.truth_((function (){var or__22912__auto__ = new cljs.core.Keyword(null,"reload-all","reload-all",761570200).cljs$core$IFn$_invoke$arity$1(cljs.core.meta.call(null,libs));
if(cljs.core.truth_(or__22912__auto__)){
return or__22912__auto__;
} else {
return cljs.core._EQ_.call(null,cljs.core.get.call(null,reloads,lib_31871),new cljs.core.Keyword(null,"reload-all","reload-all",761570200));
}
})())){
cljs.compiler.emitln.call(null,"goog.require('",cljs.compiler.munge.call(null,lib_31871),"', 'reload-all');");
} else {
cljs.compiler.emitln.call(null,"goog.require('",cljs.compiler.munge.call(null,lib_31871),"');");

}
}

var G__31872 = cljs.core.next.call(null,seq__31851_31865__$1);
var G__31873 = null;
var G__31874 = (0);
var G__31875 = (0);
seq__31851_31855 = G__31872;
chunk__31852_31856 = G__31873;
count__31853_31857 = G__31874;
i__31854_31858 = G__31875;
continue;
}
} else {
}
}
break;
}

if(cljs.core.truth_(new cljs.core.Keyword(null,"reload-all","reload-all",761570200).cljs$core$IFn$_invoke$arity$1(cljs.core.meta.call(null,libs)))){
return cljs.compiler.emitln.call(null,"if(!COMPILED) ",loaded_libs," = cljs.core.into(",loaded_libs_temp,", ",loaded_libs,");");
} else {
return null;
}
});
cljs.core._add_method.call(null,cljs.compiler.emit_STAR_,new cljs.core.Keyword(null,"ns","ns",441598760),(function (p__31876){
var map__31877 = p__31876;
var map__31877__$1 = ((((!((map__31877 == null)))?((((map__31877.cljs$lang$protocol_mask$partition0$ & (64))) || (map__31877.cljs$core$ISeq$))?true:false):false))?cljs.core.apply.call(null,cljs.core.hash_map,map__31877):map__31877);
var name = cljs.core.get.call(null,map__31877__$1,new cljs.core.Keyword(null,"name","name",1843675177));
var requires = cljs.core.get.call(null,map__31877__$1,new cljs.core.Keyword(null,"requires","requires",-1201390927));
var uses = cljs.core.get.call(null,map__31877__$1,new cljs.core.Keyword(null,"uses","uses",232664692));
var require_macros = cljs.core.get.call(null,map__31877__$1,new cljs.core.Keyword(null,"require-macros","require-macros",707947416));
var reloads = cljs.core.get.call(null,map__31877__$1,new cljs.core.Keyword(null,"reloads","reloads",610698522));
var env = cljs.core.get.call(null,map__31877__$1,new cljs.core.Keyword(null,"env","env",-1815813235));
cljs.compiler.emitln.call(null,"goog.provide('",cljs.compiler.munge.call(null,name),"');");

if(cljs.core._EQ_.call(null,name,new cljs.core.Symbol(null,"cljs.core","cljs.core",770546058,null))){
} else {
cljs.compiler.emitln.call(null,"goog.require('cljs.core');");
}

cljs.compiler.load_libs.call(null,requires,null,new cljs.core.Keyword(null,"require","require",-468001333).cljs$core$IFn$_invoke$arity$1(reloads));

return cljs.compiler.load_libs.call(null,uses,requires,new cljs.core.Keyword(null,"use","use",-1846382424).cljs$core$IFn$_invoke$arity$1(reloads));
}));
cljs.core._add_method.call(null,cljs.compiler.emit_STAR_,new cljs.core.Keyword(null,"deftype*","deftype*",-677871637),(function (p__31879){
var map__31880 = p__31879;
var map__31880__$1 = ((((!((map__31880 == null)))?((((map__31880.cljs$lang$protocol_mask$partition0$ & (64))) || (map__31880.cljs$core$ISeq$))?true:false):false))?cljs.core.apply.call(null,cljs.core.hash_map,map__31880):map__31880);
var t = cljs.core.get.call(null,map__31880__$1,new cljs.core.Keyword(null,"t","t",-1397832519));
var fields = cljs.core.get.call(null,map__31880__$1,new cljs.core.Keyword(null,"fields","fields",-1932066230));
var pmasks = cljs.core.get.call(null,map__31880__$1,new cljs.core.Keyword(null,"pmasks","pmasks",-871416698));
var body = cljs.core.get.call(null,map__31880__$1,new cljs.core.Keyword(null,"body","body",-2049205669));
var protocols = cljs.core.get.call(null,map__31880__$1,new cljs.core.Keyword(null,"protocols","protocols",-5615896));
var fields__$1 = cljs.core.map.call(null,cljs.compiler.munge,fields);
cljs.compiler.emitln.call(null,"");

cljs.compiler.emitln.call(null,"/**");

cljs.compiler.emitln.call(null,"* @constructor");

var seq__31882_31896 = cljs.core.seq.call(null,protocols);
var chunk__31883_31897 = null;
var count__31884_31898 = (0);
var i__31885_31899 = (0);
while(true){
if((i__31885_31899 < count__31884_31898)){
var protocol_31900 = cljs.core._nth.call(null,chunk__31883_31897,i__31885_31899);
cljs.compiler.emitln.call(null," * @implements {",cljs.compiler.munge.call(null,[cljs.core.str(protocol_31900)].join('')),"}");

var G__31901 = seq__31882_31896;
var G__31902 = chunk__31883_31897;
var G__31903 = count__31884_31898;
var G__31904 = (i__31885_31899 + (1));
seq__31882_31896 = G__31901;
chunk__31883_31897 = G__31902;
count__31884_31898 = G__31903;
i__31885_31899 = G__31904;
continue;
} else {
var temp__4657__auto___31905 = cljs.core.seq.call(null,seq__31882_31896);
if(temp__4657__auto___31905){
var seq__31882_31906__$1 = temp__4657__auto___31905;
if(cljs.core.chunked_seq_QMARK_.call(null,seq__31882_31906__$1)){
var c__23723__auto___31907 = cljs.core.chunk_first.call(null,seq__31882_31906__$1);
var G__31908 = cljs.core.chunk_rest.call(null,seq__31882_31906__$1);
var G__31909 = c__23723__auto___31907;
var G__31910 = cljs.core.count.call(null,c__23723__auto___31907);
var G__31911 = (0);
seq__31882_31896 = G__31908;
chunk__31883_31897 = G__31909;
count__31884_31898 = G__31910;
i__31885_31899 = G__31911;
continue;
} else {
var protocol_31912 = cljs.core.first.call(null,seq__31882_31906__$1);
cljs.compiler.emitln.call(null," * @implements {",cljs.compiler.munge.call(null,[cljs.core.str(protocol_31912)].join('')),"}");

var G__31913 = cljs.core.next.call(null,seq__31882_31906__$1);
var G__31914 = null;
var G__31915 = (0);
var G__31916 = (0);
seq__31882_31896 = G__31913;
chunk__31883_31897 = G__31914;
count__31884_31898 = G__31915;
i__31885_31899 = G__31916;
continue;
}
} else {
}
}
break;
}

cljs.compiler.emitln.call(null,"*/");

cljs.compiler.emitln.call(null,cljs.compiler.munge.call(null,t)," = (function (",cljs.compiler.comma_sep.call(null,fields__$1),"){");

var seq__31886_31917 = cljs.core.seq.call(null,fields__$1);
var chunk__31887_31918 = null;
var count__31888_31919 = (0);
var i__31889_31920 = (0);
while(true){
if((i__31889_31920 < count__31888_31919)){
var fld_31921 = cljs.core._nth.call(null,chunk__31887_31918,i__31889_31920);
cljs.compiler.emitln.call(null,"this.",fld_31921," = ",fld_31921,";");

var G__31922 = seq__31886_31917;
var G__31923 = chunk__31887_31918;
var G__31924 = count__31888_31919;
var G__31925 = (i__31889_31920 + (1));
seq__31886_31917 = G__31922;
chunk__31887_31918 = G__31923;
count__31888_31919 = G__31924;
i__31889_31920 = G__31925;
continue;
} else {
var temp__4657__auto___31926 = cljs.core.seq.call(null,seq__31886_31917);
if(temp__4657__auto___31926){
var seq__31886_31927__$1 = temp__4657__auto___31926;
if(cljs.core.chunked_seq_QMARK_.call(null,seq__31886_31927__$1)){
var c__23723__auto___31928 = cljs.core.chunk_first.call(null,seq__31886_31927__$1);
var G__31929 = cljs.core.chunk_rest.call(null,seq__31886_31927__$1);
var G__31930 = c__23723__auto___31928;
var G__31931 = cljs.core.count.call(null,c__23723__auto___31928);
var G__31932 = (0);
seq__31886_31917 = G__31929;
chunk__31887_31918 = G__31930;
count__31888_31919 = G__31931;
i__31889_31920 = G__31932;
continue;
} else {
var fld_31933 = cljs.core.first.call(null,seq__31886_31927__$1);
cljs.compiler.emitln.call(null,"this.",fld_31933," = ",fld_31933,";");

var G__31934 = cljs.core.next.call(null,seq__31886_31927__$1);
var G__31935 = null;
var G__31936 = (0);
var G__31937 = (0);
seq__31886_31917 = G__31934;
chunk__31887_31918 = G__31935;
count__31888_31919 = G__31936;
i__31889_31920 = G__31937;
continue;
}
} else {
}
}
break;
}

var seq__31890_31938 = cljs.core.seq.call(null,pmasks);
var chunk__31891_31939 = null;
var count__31892_31940 = (0);
var i__31893_31941 = (0);
while(true){
if((i__31893_31941 < count__31892_31940)){
var vec__31894_31942 = cljs.core._nth.call(null,chunk__31891_31939,i__31893_31941);
var pno_31943 = cljs.core.nth.call(null,vec__31894_31942,(0),null);
var pmask_31944 = cljs.core.nth.call(null,vec__31894_31942,(1),null);
cljs.compiler.emitln.call(null,"this.cljs$lang$protocol_mask$partition",pno_31943,"$ = ",pmask_31944,";");

var G__31945 = seq__31890_31938;
var G__31946 = chunk__31891_31939;
var G__31947 = count__31892_31940;
var G__31948 = (i__31893_31941 + (1));
seq__31890_31938 = G__31945;
chunk__31891_31939 = G__31946;
count__31892_31940 = G__31947;
i__31893_31941 = G__31948;
continue;
} else {
var temp__4657__auto___31949 = cljs.core.seq.call(null,seq__31890_31938);
if(temp__4657__auto___31949){
var seq__31890_31950__$1 = temp__4657__auto___31949;
if(cljs.core.chunked_seq_QMARK_.call(null,seq__31890_31950__$1)){
var c__23723__auto___31951 = cljs.core.chunk_first.call(null,seq__31890_31950__$1);
var G__31952 = cljs.core.chunk_rest.call(null,seq__31890_31950__$1);
var G__31953 = c__23723__auto___31951;
var G__31954 = cljs.core.count.call(null,c__23723__auto___31951);
var G__31955 = (0);
seq__31890_31938 = G__31952;
chunk__31891_31939 = G__31953;
count__31892_31940 = G__31954;
i__31893_31941 = G__31955;
continue;
} else {
var vec__31895_31956 = cljs.core.first.call(null,seq__31890_31950__$1);
var pno_31957 = cljs.core.nth.call(null,vec__31895_31956,(0),null);
var pmask_31958 = cljs.core.nth.call(null,vec__31895_31956,(1),null);
cljs.compiler.emitln.call(null,"this.cljs$lang$protocol_mask$partition",pno_31957,"$ = ",pmask_31958,";");

var G__31959 = cljs.core.next.call(null,seq__31890_31950__$1);
var G__31960 = null;
var G__31961 = (0);
var G__31962 = (0);
seq__31890_31938 = G__31959;
chunk__31891_31939 = G__31960;
count__31892_31940 = G__31961;
i__31893_31941 = G__31962;
continue;
}
} else {
}
}
break;
}

cljs.compiler.emitln.call(null,"})");

return cljs.compiler.emit.call(null,body);
}));
cljs.core._add_method.call(null,cljs.compiler.emit_STAR_,new cljs.core.Keyword(null,"defrecord*","defrecord*",718069562),(function (p__31963){
var map__31964 = p__31963;
var map__31964__$1 = ((((!((map__31964 == null)))?((((map__31964.cljs$lang$protocol_mask$partition0$ & (64))) || (map__31964.cljs$core$ISeq$))?true:false):false))?cljs.core.apply.call(null,cljs.core.hash_map,map__31964):map__31964);
var t = cljs.core.get.call(null,map__31964__$1,new cljs.core.Keyword(null,"t","t",-1397832519));
var fields = cljs.core.get.call(null,map__31964__$1,new cljs.core.Keyword(null,"fields","fields",-1932066230));
var pmasks = cljs.core.get.call(null,map__31964__$1,new cljs.core.Keyword(null,"pmasks","pmasks",-871416698));
var body = cljs.core.get.call(null,map__31964__$1,new cljs.core.Keyword(null,"body","body",-2049205669));
var protocols = cljs.core.get.call(null,map__31964__$1,new cljs.core.Keyword(null,"protocols","protocols",-5615896));
var fields__$1 = cljs.core.concat.call(null,cljs.core.map.call(null,cljs.compiler.munge,fields),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Symbol(null,"__meta","__meta",-946752628,null),new cljs.core.Symbol(null,"__extmap","__extmap",-1435580931,null),new cljs.core.Symbol(null,"__hash","__hash",-1328796629,null)], null));
cljs.compiler.emitln.call(null,"");

cljs.compiler.emitln.call(null,"/**");

cljs.compiler.emitln.call(null,"* @constructor");

var seq__31966_31980 = cljs.core.seq.call(null,protocols);
var chunk__31967_31981 = null;
var count__31968_31982 = (0);
var i__31969_31983 = (0);
while(true){
if((i__31969_31983 < count__31968_31982)){
var protocol_31984 = cljs.core._nth.call(null,chunk__31967_31981,i__31969_31983);
cljs.compiler.emitln.call(null," * @implements {",cljs.compiler.munge.call(null,[cljs.core.str(protocol_31984)].join('')),"}");

var G__31985 = seq__31966_31980;
var G__31986 = chunk__31967_31981;
var G__31987 = count__31968_31982;
var G__31988 = (i__31969_31983 + (1));
seq__31966_31980 = G__31985;
chunk__31967_31981 = G__31986;
count__31968_31982 = G__31987;
i__31969_31983 = G__31988;
continue;
} else {
var temp__4657__auto___31989 = cljs.core.seq.call(null,seq__31966_31980);
if(temp__4657__auto___31989){
var seq__31966_31990__$1 = temp__4657__auto___31989;
if(cljs.core.chunked_seq_QMARK_.call(null,seq__31966_31990__$1)){
var c__23723__auto___31991 = cljs.core.chunk_first.call(null,seq__31966_31990__$1);
var G__31992 = cljs.core.chunk_rest.call(null,seq__31966_31990__$1);
var G__31993 = c__23723__auto___31991;
var G__31994 = cljs.core.count.call(null,c__23723__auto___31991);
var G__31995 = (0);
seq__31966_31980 = G__31992;
chunk__31967_31981 = G__31993;
count__31968_31982 = G__31994;
i__31969_31983 = G__31995;
continue;
} else {
var protocol_31996 = cljs.core.first.call(null,seq__31966_31990__$1);
cljs.compiler.emitln.call(null," * @implements {",cljs.compiler.munge.call(null,[cljs.core.str(protocol_31996)].join('')),"}");

var G__31997 = cljs.core.next.call(null,seq__31966_31990__$1);
var G__31998 = null;
var G__31999 = (0);
var G__32000 = (0);
seq__31966_31980 = G__31997;
chunk__31967_31981 = G__31998;
count__31968_31982 = G__31999;
i__31969_31983 = G__32000;
continue;
}
} else {
}
}
break;
}

cljs.compiler.emitln.call(null,"*/");

cljs.compiler.emitln.call(null,cljs.compiler.munge.call(null,t)," = (function (",cljs.compiler.comma_sep.call(null,fields__$1),"){");

var seq__31970_32001 = cljs.core.seq.call(null,fields__$1);
var chunk__31971_32002 = null;
var count__31972_32003 = (0);
var i__31973_32004 = (0);
while(true){
if((i__31973_32004 < count__31972_32003)){
var fld_32005 = cljs.core._nth.call(null,chunk__31971_32002,i__31973_32004);
cljs.compiler.emitln.call(null,"this.",fld_32005," = ",fld_32005,";");

var G__32006 = seq__31970_32001;
var G__32007 = chunk__31971_32002;
var G__32008 = count__31972_32003;
var G__32009 = (i__31973_32004 + (1));
seq__31970_32001 = G__32006;
chunk__31971_32002 = G__32007;
count__31972_32003 = G__32008;
i__31973_32004 = G__32009;
continue;
} else {
var temp__4657__auto___32010 = cljs.core.seq.call(null,seq__31970_32001);
if(temp__4657__auto___32010){
var seq__31970_32011__$1 = temp__4657__auto___32010;
if(cljs.core.chunked_seq_QMARK_.call(null,seq__31970_32011__$1)){
var c__23723__auto___32012 = cljs.core.chunk_first.call(null,seq__31970_32011__$1);
var G__32013 = cljs.core.chunk_rest.call(null,seq__31970_32011__$1);
var G__32014 = c__23723__auto___32012;
var G__32015 = cljs.core.count.call(null,c__23723__auto___32012);
var G__32016 = (0);
seq__31970_32001 = G__32013;
chunk__31971_32002 = G__32014;
count__31972_32003 = G__32015;
i__31973_32004 = G__32016;
continue;
} else {
var fld_32017 = cljs.core.first.call(null,seq__31970_32011__$1);
cljs.compiler.emitln.call(null,"this.",fld_32017," = ",fld_32017,";");

var G__32018 = cljs.core.next.call(null,seq__31970_32011__$1);
var G__32019 = null;
var G__32020 = (0);
var G__32021 = (0);
seq__31970_32001 = G__32018;
chunk__31971_32002 = G__32019;
count__31972_32003 = G__32020;
i__31973_32004 = G__32021;
continue;
}
} else {
}
}
break;
}

var seq__31974_32022 = cljs.core.seq.call(null,pmasks);
var chunk__31975_32023 = null;
var count__31976_32024 = (0);
var i__31977_32025 = (0);
while(true){
if((i__31977_32025 < count__31976_32024)){
var vec__31978_32026 = cljs.core._nth.call(null,chunk__31975_32023,i__31977_32025);
var pno_32027 = cljs.core.nth.call(null,vec__31978_32026,(0),null);
var pmask_32028 = cljs.core.nth.call(null,vec__31978_32026,(1),null);
cljs.compiler.emitln.call(null,"this.cljs$lang$protocol_mask$partition",pno_32027,"$ = ",pmask_32028,";");

var G__32029 = seq__31974_32022;
var G__32030 = chunk__31975_32023;
var G__32031 = count__31976_32024;
var G__32032 = (i__31977_32025 + (1));
seq__31974_32022 = G__32029;
chunk__31975_32023 = G__32030;
count__31976_32024 = G__32031;
i__31977_32025 = G__32032;
continue;
} else {
var temp__4657__auto___32033 = cljs.core.seq.call(null,seq__31974_32022);
if(temp__4657__auto___32033){
var seq__31974_32034__$1 = temp__4657__auto___32033;
if(cljs.core.chunked_seq_QMARK_.call(null,seq__31974_32034__$1)){
var c__23723__auto___32035 = cljs.core.chunk_first.call(null,seq__31974_32034__$1);
var G__32036 = cljs.core.chunk_rest.call(null,seq__31974_32034__$1);
var G__32037 = c__23723__auto___32035;
var G__32038 = cljs.core.count.call(null,c__23723__auto___32035);
var G__32039 = (0);
seq__31974_32022 = G__32036;
chunk__31975_32023 = G__32037;
count__31976_32024 = G__32038;
i__31977_32025 = G__32039;
continue;
} else {
var vec__31979_32040 = cljs.core.first.call(null,seq__31974_32034__$1);
var pno_32041 = cljs.core.nth.call(null,vec__31979_32040,(0),null);
var pmask_32042 = cljs.core.nth.call(null,vec__31979_32040,(1),null);
cljs.compiler.emitln.call(null,"this.cljs$lang$protocol_mask$partition",pno_32041,"$ = ",pmask_32042,";");

var G__32043 = cljs.core.next.call(null,seq__31974_32034__$1);
var G__32044 = null;
var G__32045 = (0);
var G__32046 = (0);
seq__31974_32022 = G__32043;
chunk__31975_32023 = G__32044;
count__31976_32024 = G__32045;
i__31977_32025 = G__32046;
continue;
}
} else {
}
}
break;
}

cljs.compiler.emitln.call(null,"})");

return cljs.compiler.emit.call(null,body);
}));
cljs.core._add_method.call(null,cljs.compiler.emit_STAR_,new cljs.core.Keyword(null,"dot","dot",1442709401),(function (p__32047){
var map__32048 = p__32047;
var map__32048__$1 = ((((!((map__32048 == null)))?((((map__32048.cljs$lang$protocol_mask$partition0$ & (64))) || (map__32048.cljs$core$ISeq$))?true:false):false))?cljs.core.apply.call(null,cljs.core.hash_map,map__32048):map__32048);
var target = cljs.core.get.call(null,map__32048__$1,new cljs.core.Keyword(null,"target","target",253001721));
var field = cljs.core.get.call(null,map__32048__$1,new cljs.core.Keyword(null,"field","field",-1302436500));
var method = cljs.core.get.call(null,map__32048__$1,new cljs.core.Keyword(null,"method","method",55703592));
var args = cljs.core.get.call(null,map__32048__$1,new cljs.core.Keyword(null,"args","args",1315556576));
var env = cljs.core.get.call(null,map__32048__$1,new cljs.core.Keyword(null,"env","env",-1815813235));
var env__25235__auto__ = env;
if(cljs.core._EQ_.call(null,new cljs.core.Keyword(null,"return","return",-1891502105),new cljs.core.Keyword(null,"context","context",-830191113).cljs$core$IFn$_invoke$arity$1(env__25235__auto__))){
cljs.compiler.emits.call(null,"return ");
} else {
}

if(cljs.core.truth_(field)){
cljs.compiler.emits.call(null,target,".",cljs.compiler.munge.call(null,field,cljs.core.PersistentHashSet.EMPTY));
} else {
cljs.compiler.emits.call(null,target,".",cljs.compiler.munge.call(null,method,cljs.core.PersistentHashSet.EMPTY),"(",cljs.compiler.comma_sep.call(null,args),")");
}

if(cljs.core._EQ_.call(null,new cljs.core.Keyword(null,"expr","expr",745722291),new cljs.core.Keyword(null,"context","context",-830191113).cljs$core$IFn$_invoke$arity$1(env__25235__auto__))){
return null;
} else {
return cljs.compiler.emitln.call(null,";");
}
}));
cljs.core._add_method.call(null,cljs.compiler.emit_STAR_,new cljs.core.Keyword(null,"js","js",1768080579),(function (p__32050){
var map__32051 = p__32050;
var map__32051__$1 = ((((!((map__32051 == null)))?((((map__32051.cljs$lang$protocol_mask$partition0$ & (64))) || (map__32051.cljs$core$ISeq$))?true:false):false))?cljs.core.apply.call(null,cljs.core.hash_map,map__32051):map__32051);
var op = cljs.core.get.call(null,map__32051__$1,new cljs.core.Keyword(null,"op","op",-1882987955));
var env = cljs.core.get.call(null,map__32051__$1,new cljs.core.Keyword(null,"env","env",-1815813235));
var code = cljs.core.get.call(null,map__32051__$1,new cljs.core.Keyword(null,"code","code",1586293142));
var segs = cljs.core.get.call(null,map__32051__$1,new cljs.core.Keyword(null,"segs","segs",-1940299576));
var args = cljs.core.get.call(null,map__32051__$1,new cljs.core.Keyword(null,"args","args",1315556576));
if(cljs.core.truth_((function (){var and__22900__auto__ = code;
if(cljs.core.truth_(and__22900__auto__)){
return goog.string.startsWith(clojure.string.trim.call(null,code),"/*");
} else {
return and__22900__auto__;
}
})())){
return cljs.compiler.emits.call(null,code);
} else {
var env__25235__auto__ = env;
if(cljs.core._EQ_.call(null,new cljs.core.Keyword(null,"return","return",-1891502105),new cljs.core.Keyword(null,"context","context",-830191113).cljs$core$IFn$_invoke$arity$1(env__25235__auto__))){
cljs.compiler.emits.call(null,"return ");
} else {
}

if(cljs.core.truth_(code)){
cljs.compiler.emits.call(null,code);
} else {
cljs.compiler.emits.call(null,cljs.core.interleave.call(null,cljs.core.concat.call(null,segs,cljs.core.repeat.call(null,null)),cljs.core.concat.call(null,args,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [null], null))));
}

if(cljs.core._EQ_.call(null,new cljs.core.Keyword(null,"expr","expr",745722291),new cljs.core.Keyword(null,"context","context",-830191113).cljs$core$IFn$_invoke$arity$1(env__25235__auto__))){
return null;
} else {
return cljs.compiler.emitln.call(null,";");
}
}
}));
cljs.compiler.build_affecting_options = (function cljs$compiler$build_affecting_options(opts){
return cljs.core.select_keys.call(null,opts,new cljs.core.PersistentVector(null, 4, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword(null,"static-fns","static-fns",-501950748),new cljs.core.Keyword(null,"optimize-constants","optimize-constants",232704518),new cljs.core.Keyword(null,"elide-asserts","elide-asserts",537063272),new cljs.core.Keyword(null,"target","target",253001721)], null));
});
cljs.compiler.emit_constants_table = (function cljs$compiler$emit_constants_table(table){
var seq__32061 = cljs.core.seq.call(null,table);
var chunk__32062 = null;
var count__32063 = (0);
var i__32064 = (0);
while(true){
if((i__32064 < count__32063)){
var vec__32065 = cljs.core._nth.call(null,chunk__32062,i__32064);
var sym = cljs.core.nth.call(null,vec__32065,(0),null);
var value = cljs.core.nth.call(null,vec__32065,(1),null);
var ns_32067 = cljs.core.namespace.call(null,sym);
var name_32068 = cljs.core.name.call(null,sym);
cljs.compiler.emits.call(null,"cljs.core.",value," = ");

if((sym instanceof cljs.core.Keyword)){
cljs.compiler.emits_keyword.call(null,sym);
} else {
if((sym instanceof cljs.core.Symbol)){
cljs.compiler.emits_symbol.call(null,sym);
} else {
throw cljs.core.ex_info.call(null,[cljs.core.str("Cannot emit constant for type "),cljs.core.str(cljs.core.type.call(null,sym))].join(''),new cljs.core.PersistentArrayMap(null, 1, [new cljs.core.Keyword(null,"error","error",-978969032),new cljs.core.Keyword(null,"invalid-constant-type","invalid-constant-type",1294847471)], null));

}
}

cljs.compiler.emits.call(null,";\n");

var G__32069 = seq__32061;
var G__32070 = chunk__32062;
var G__32071 = count__32063;
var G__32072 = (i__32064 + (1));
seq__32061 = G__32069;
chunk__32062 = G__32070;
count__32063 = G__32071;
i__32064 = G__32072;
continue;
} else {
var temp__4657__auto__ = cljs.core.seq.call(null,seq__32061);
if(temp__4657__auto__){
var seq__32061__$1 = temp__4657__auto__;
if(cljs.core.chunked_seq_QMARK_.call(null,seq__32061__$1)){
var c__23723__auto__ = cljs.core.chunk_first.call(null,seq__32061__$1);
var G__32073 = cljs.core.chunk_rest.call(null,seq__32061__$1);
var G__32074 = c__23723__auto__;
var G__32075 = cljs.core.count.call(null,c__23723__auto__);
var G__32076 = (0);
seq__32061 = G__32073;
chunk__32062 = G__32074;
count__32063 = G__32075;
i__32064 = G__32076;
continue;
} else {
var vec__32066 = cljs.core.first.call(null,seq__32061__$1);
var sym = cljs.core.nth.call(null,vec__32066,(0),null);
var value = cljs.core.nth.call(null,vec__32066,(1),null);
var ns_32077 = cljs.core.namespace.call(null,sym);
var name_32078 = cljs.core.name.call(null,sym);
cljs.compiler.emits.call(null,"cljs.core.",value," = ");

if((sym instanceof cljs.core.Keyword)){
cljs.compiler.emits_keyword.call(null,sym);
} else {
if((sym instanceof cljs.core.Symbol)){
cljs.compiler.emits_symbol.call(null,sym);
} else {
throw cljs.core.ex_info.call(null,[cljs.core.str("Cannot emit constant for type "),cljs.core.str(cljs.core.type.call(null,sym))].join(''),new cljs.core.PersistentArrayMap(null, 1, [new cljs.core.Keyword(null,"error","error",-978969032),new cljs.core.Keyword(null,"invalid-constant-type","invalid-constant-type",1294847471)], null));

}
}

cljs.compiler.emits.call(null,";\n");

var G__32079 = cljs.core.next.call(null,seq__32061__$1);
var G__32080 = null;
var G__32081 = (0);
var G__32082 = (0);
seq__32061 = G__32079;
chunk__32062 = G__32080;
count__32063 = G__32081;
i__32064 = G__32082;
continue;
}
} else {
return null;
}
}
break;
}
});

//# sourceMappingURL=compiler.js.map