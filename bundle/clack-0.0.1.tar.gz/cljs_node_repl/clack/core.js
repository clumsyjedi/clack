// Compiled by ClojureScript 1.8.51 {:target :nodejs}
goog.provide('clack.core');
goog.require('cljs.core');
goog.require('cljs.nodejs');
goog.require('cljs.pprint');
goog.require('clack.util');
cljs.nodejs.enable_util_print_BANG_.call(null);
clack.core.allowed_opts = new cljs.core.PersistentArrayMap(null, 6, [new cljs.core.Keyword(null,"input-format","input-format",-422703481),new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, ["-i","--input-format"], null),new cljs.core.Keyword(null,"output-format","output-format",-1826382676),new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, ["-i","--output-format"], null),new cljs.core.Keyword(null,"filter","filter",-948537934),new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, ["-f","--filter"], null),new cljs.core.Keyword(null,"remove","remove",-131428414),new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, ["-r","--remove"], null),new cljs.core.Keyword(null,"get","get",1683182755),new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, ["-g","--get-in"], null),new cljs.core.Keyword(null,"eval","eval",-1103567905),new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, ["-e","--eval"], null)], null);
clack.core.meta_opt_keys = new cljs.core.PersistentHashSet(null, new cljs.core.PersistentArrayMap(null, 2, [new cljs.core.Keyword(null,"input-format","input-format",-422703481),null,new cljs.core.Keyword(null,"output-format","output-format",-1826382676),null], null), null);
clack.core.search_opts = cljs.core.reduce.call(null,(function (coll,p__33188){
var vec__33189 = p__33188;
var k = cljs.core.nth.call(null,vec__33189,(0),null);
var vec__33190 = cljs.core.nth.call(null,vec__33189,(1),null);
var short_opt = cljs.core.nth.call(null,vec__33190,(0),null);
var long_opt = cljs.core.nth.call(null,vec__33190,(1),null);
return cljs.core.assoc.call(null,coll,short_opt,k,long_opt,k);
}),cljs.core.PersistentArrayMap.EMPTY,cljs.core.remove.call(null,(function (p1__33187_SHARP_){
return clack.core.meta_opt_keys.call(null,cljs.core.key.call(null,p1__33187_SHARP_));
}),clack.core.allowed_opts));
clack.core.meta_opts = cljs.core.reduce.call(null,(function (coll,p__33192){
var vec__33193 = p__33192;
var k = cljs.core.nth.call(null,vec__33193,(0),null);
var vec__33194 = cljs.core.nth.call(null,vec__33193,(1),null);
var short_opt = cljs.core.nth.call(null,vec__33194,(0),null);
var long_opt = cljs.core.nth.call(null,vec__33194,(1),null);
return cljs.core.assoc.call(null,coll,short_opt,k,long_opt,k);
}),cljs.core.PersistentArrayMap.EMPTY,cljs.core.filter.call(null,(function (p1__33191_SHARP_){
return clack.core.meta_opt_keys.call(null,cljs.core.key.call(null,p1__33191_SHARP_));
}),clack.core.allowed_opts));
clack.core.looks_like_keyword_QMARK_ = (function clack$core$looks_like_keyword_QMARK_(s){
return cljs.core.re_find.call(null,/^:[\w\-\.\/]+$/,s);
});
clack.core.looks_like_string_QMARK_ = (function clack$core$looks_like_string_QMARK_(s){
return cljs.core.re_find.call(null,/^[\w\.][\w\-\.]*$/,s);
});
clack.core.looks_like_number_QMARK_ = (function clack$core$looks_like_number_QMARK_(s){
return cljs.core.every_QMARK_.call(null,new cljs.core.PersistentHashSet(null, new cljs.core.PersistentArrayMap(null, 10, ["0",null,"1",null,"2",null,"3",null,"4",null,"5",null,"6",null,"7",null,"8",null,"9",null], null), null),s);
});
clack.core.get_query = (function clack$core$get_query(var_args){
var args33195 = [];
var len__23955__auto___33200 = arguments.length;
var i__23956__auto___33201 = (0);
while(true){
if((i__23956__auto___33201 < len__23955__auto___33200)){
args33195.push((arguments[i__23956__auto___33201]));

var G__33202 = (i__23956__auto___33201 + (1));
i__23956__auto___33201 = G__33202;
continue;
} else {
}
break;
}

var G__33197 = args33195.length;
switch (G__33197) {
case 1:
return clack.core.get_query.cljs$core$IFn$_invoke$arity$1((arguments[(0)]));

break;
case 2:
return clack.core.get_query.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
default:
throw (new Error([cljs.core.str("Invalid arity: "),cljs.core.str(args33195.length)].join('')));

}
});

clack.core.get_query.cljs$core$IFn$_invoke$arity$1 = (function (args){
return clack.core.get_query.call(null,args,new cljs.core.PersistentArrayMap(null, 2, [new cljs.core.Keyword(null,"meta","meta",1499536964),cljs.core.PersistentArrayMap.EMPTY,new cljs.core.Keyword(null,"search","search",1564939822),cljs.core.PersistentVector.EMPTY], null));
});

clack.core.get_query.cljs$core$IFn$_invoke$arity$2 = (function (p__33198,query){
while(true){
var vec__33199 = p__33198;
var arg = cljs.core.nth.call(null,vec__33199,(0),null);
var args = cljs.core.nthnext.call(null,vec__33199,(1));
if(cljs.core.not.call(null,arg)){
return query;
} else {
if(cljs.core.truth_(clack.core.looks_like_keyword_QMARK_.call(null,arg))){
var G__33204 = args;
var G__33205 = cljs.core.update_in.call(null,query,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword(null,"search","search",1564939822)], null),cljs.core.conj,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword(null,"get","get",1683182755),cljs.core.keyword.call(null,arg.substr((1)))], null));
p__33198 = G__33204;
query = G__33205;
continue;
} else {
if(cljs.core.truth_(clack.core.looks_like_number_QMARK_.call(null,arg))){
var G__33206 = args;
var G__33207 = cljs.core.update_in.call(null,query,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword(null,"search","search",1564939822)], null),cljs.core.conj,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword(null,"get","get",1683182755),parseInt(arg)], null));
p__33198 = G__33206;
query = G__33207;
continue;
} else {
if(cljs.core.truth_(clack.core.looks_like_string_QMARK_.call(null,arg))){
var G__33208 = args;
var G__33209 = cljs.core.update_in.call(null,query,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword(null,"search","search",1564939822)], null),cljs.core.conj,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword(null,"get","get",1683182755),arg], null));
p__33198 = G__33208;
query = G__33209;
continue;
} else {
if(cljs.core.truth_(clack.core.meta_opts.call(null,arg))){
var G__33210 = cljs.core.rest.call(null,args);
var G__33211 = cljs.core.update_in.call(null,query,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword(null,"meta","meta",1499536964)], null),cljs.core.assoc,clack.core.meta_opts.call(null,arg),clack.util.read_input.call(null,new cljs.core.Keyword(null,"edn","edn",1317840885),cljs.core.keyword.call(null,cljs.core.first.call(null,args))));
p__33198 = G__33210;
query = G__33211;
continue;
} else {
if(cljs.core.truth_(clack.core.search_opts.call(null,arg))){
var G__33212 = cljs.core.rest.call(null,args);
var G__33213 = cljs.core.update_in.call(null,query,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword(null,"search","search",1564939822)], null),cljs.core.conj,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [clack.core.search_opts.call(null,arg),new cljs.core.Keyword(null,"value","value",305978217).cljs$core$IFn$_invoke$arity$1(clack.util.eval_STAR_.call(null,cljs.core.first.call(null,args)))], null));
p__33198 = G__33212;
query = G__33213;
continue;
} else {
return clack.util.error.call(null,[cljs.core.str("Unknown argument: "),cljs.core.str(arg)].join(''));

}
}
}
}
}
}
break;
}
});

clack.core.get_query.cljs$lang$maxFixedArity = 2;
clack.core.search = (function clack$core$search(data,p__33214){
while(true){
var vec__33220 = p__33214;
var vec__33221 = cljs.core.nth.call(null,vec__33220,(0),null);
var qtype = cljs.core.nth.call(null,vec__33221,(0),null);
var qval = cljs.core.nth.call(null,vec__33221,(1),null);
var query = vec__33221;
var queries = cljs.core.nthnext.call(null,vec__33220,(1));
if(cljs.core.not.call(null,query)){
return data;
} else {
var G__33225 = (function (){var pred__33222 = cljs.core._EQ_;
var expr__33223 = qtype;
if(cljs.core.truth_(pred__33222.call(null,new cljs.core.Keyword(null,"get","get",1683182755),expr__33223))){
return cljs.core.get.call(null,data,qval);
} else {
if(cljs.core.truth_(pred__33222.call(null,new cljs.core.Keyword(null,"filter","filter",-948537934),expr__33223))){
return cljs.core.filter.call(null,qval,data);
} else {
if(cljs.core.truth_(pred__33222.call(null,new cljs.core.Keyword(null,"remove","remove",-131428414),expr__33223))){
return cljs.core.remove.call(null,qval,data);
} else {
if(cljs.core.truth_(pred__33222.call(null,new cljs.core.Keyword(null,"eval","eval",-1103567905),expr__33223))){
return qval.call(null,data);
} else {
return [cljs.core.str("Unknown query type: "),cljs.core.str(qtype)].join('');
}
}
}
}
})();
var G__33226 = queries;
data = G__33225;
p__33214 = G__33226;
continue;
}
break;
}
});
clack.core.handle_input = (function clack$core$handle_input(input,query,meta){

var data = clack.util.read_input.call(null,new cljs.core.Keyword(null,"input-format","input-format",-422703481).cljs$core$IFn$_invoke$arity$1(meta),input);
if(cljs.core.truth_(cljs.core.not_empty.call(null,query))){
return clack.core.search.call(null,data,query);
} else {
return data;
}
});
clack.core.slurp_stdin = (function clack$core$slurp_stdin(){
var input = cljs.core.atom.call(null,"");
var map__33230 = (function (){var temp__4657__auto__ = cljs.core.not_empty.call(null,cljs.core.drop.call(null,(2),cljs.core.js__GT_clj.call(null,process.argv)));
if(cljs.core.truth_(temp__4657__auto__)){
var args = temp__4657__auto__;
return clack.core.get_query.call(null,args);
} else {
return null;
}
})();
var map__33230__$1 = ((((!((map__33230 == null)))?((((map__33230.cljs$lang$protocol_mask$partition0$ & (64))) || (map__33230.cljs$core$ISeq$))?true:false):false))?cljs.core.apply.call(null,cljs.core.hash_map,map__33230):map__33230);
var meta = cljs.core.get.call(null,map__33230__$1,new cljs.core.Keyword(null,"meta","meta",1499536964));
var search = cljs.core.get.call(null,map__33230__$1,new cljs.core.Keyword(null,"search","search",1564939822));
process.stdin.on("readable",((function (input,map__33230,map__33230__$1,meta,search){
return (function (){
var temp__4657__auto__ = process.stdin.read();
if(cljs.core.truth_(temp__4657__auto__)){
var chunk = temp__4657__auto__;
return cljs.core.swap_BANG_.call(null,input,((function (chunk,temp__4657__auto__,input,map__33230,map__33230__$1,meta,search){
return (function (p1__33227_SHARP_){
return [cljs.core.str(p1__33227_SHARP_),cljs.core.str(chunk)].join('');
});})(chunk,temp__4657__auto__,input,map__33230,map__33230__$1,meta,search))
);
} else {
return null;
}
});})(input,map__33230,map__33230__$1,meta,search))
);

return process.stdin.on("end",((function (input,map__33230,map__33230__$1,meta,search){
return (function (){
return cljs.pprint.pprint.call(null,clack.core.handle_input.call(null,cljs.core.deref.call(null,input),search,meta));
});})(input,map__33230,map__33230__$1,meta,search))
);
});
clack.core._main = (function clack$core$_main(var_args){
var args__23962__auto__ = [];
var len__23955__auto___33233 = arguments.length;
var i__23956__auto___33234 = (0);
while(true){
if((i__23956__auto___33234 < len__23955__auto___33233)){
args__23962__auto__.push((arguments[i__23956__auto___33234]));

var G__33235 = (i__23956__auto___33234 + (1));
i__23956__auto___33234 = G__33235;
continue;
} else {
}
break;
}

var argseq__23963__auto__ = ((((0) < args__23962__auto__.length))?(new cljs.core.IndexedSeq(args__23962__auto__.slice((0)),(0),null)):null);
return clack.core._main.cljs$core$IFn$_invoke$arity$variadic(argseq__23963__auto__);
});

clack.core._main.cljs$core$IFn$_invoke$arity$variadic = (function (args){
return clack.core.slurp_stdin.call(null);
});

clack.core._main.cljs$lang$maxFixedArity = (0);

clack.core._main.cljs$lang$applyTo = (function (seq33232){
return clack.core._main.cljs$core$IFn$_invoke$arity$variadic(cljs.core.seq.call(null,seq33232));
});
cljs.core._STAR_main_cli_fn_STAR_ = clack.core._main;

//# sourceMappingURL=core.js.map