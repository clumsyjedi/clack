(ns clack.util
  (:require [cljs.tools.reader :refer [read-string]]
            [cljs.js :refer [eval js-eval empty-state]]
            [cognitect.transit :as transit]))

(defn error 
  "log error and exit with error code"
  [msg]
  (js/console.error msg)
  (js/process.exit 1))

(defn slurp [filename]
  (js/require "fs")
  (js/fs.readFileSync filename))

(defn eval* 
  "evaluate string"
  [s]
  (eval (empty-state)
        (read-string s)
        {:eval       js-eval
         :source-map true
         :context    :expr}
        (fn [result] result)))



(defmulti read-input (fn [encoding input] encoding))

(defmethod read-input :json [_ input]
  (let [r (transit/reader :json)]
    (transit/read r input)))

(defmethod read-input :tjs [_ input]
  (let [r (transit/reader :json)]
    (transit/read r input)))

(defmethod read-input :edn [_ input]
  (read-string input))

(defmethod read-input :default [_ input]
  (read-input :edn input))

