// Compiled by ClojureScript 1.8.51 {}
goog.provide('clack.util');
goog.require('cljs.core');
goog.require('cljs.tools.reader');
goog.require('cljs.js');
goog.require('cognitect.transit');
/**
 * log error and exit with error code
 */
clack.util.error = (function clack$util$error(msg){
console.error(msg);

return process.exit((1));
});
clack.util.slurp = (function clack$util$slurp(filename){
require("fs");

return fs.readFileSync(filename);
});
/**
 * evaluate string
 */
clack.util.eval_STAR_ = (function clack$util$eval_STAR_(s){
return cljs.js.eval.call(null,cljs.js.empty_state.call(null),cljs.tools.reader.read_string.call(null,s),new cljs.core.PersistentArrayMap(null, 3, [new cljs.core.Keyword(null,"eval","eval",-1103567905),cljs.js.js_eval,new cljs.core.Keyword(null,"source-map","source-map",1706252311),true,new cljs.core.Keyword(null,"context","context",-830191113),new cljs.core.Keyword(null,"expr","expr",745722291)], null),(function (result){
return result;
}));
});
if(typeof clack.util.read_input !== 'undefined'){
} else {
clack.util.read_input = (function (){var method_table__23810__auto__ = cljs.core.atom.call(null,cljs.core.PersistentArrayMap.EMPTY);
var prefer_table__23811__auto__ = cljs.core.atom.call(null,cljs.core.PersistentArrayMap.EMPTY);
var method_cache__23812__auto__ = cljs.core.atom.call(null,cljs.core.PersistentArrayMap.EMPTY);
var cached_hierarchy__23813__auto__ = cljs.core.atom.call(null,cljs.core.PersistentArrayMap.EMPTY);
var hierarchy__23814__auto__ = cljs.core.get.call(null,cljs.core.PersistentArrayMap.EMPTY,new cljs.core.Keyword(null,"hierarchy","hierarchy",-1053470341),cljs.core.get_global_hierarchy.call(null));
return (new cljs.core.MultiFn(cljs.core.symbol.call(null,"clack.util","read-input"),((function (method_table__23810__auto__,prefer_table__23811__auto__,method_cache__23812__auto__,cached_hierarchy__23813__auto__,hierarchy__23814__auto__){
return (function (encoding,input){
return encoding;
});})(method_table__23810__auto__,prefer_table__23811__auto__,method_cache__23812__auto__,cached_hierarchy__23813__auto__,hierarchy__23814__auto__))
,new cljs.core.Keyword(null,"default","default",-1987822328),hierarchy__23814__auto__,method_table__23810__auto__,prefer_table__23811__auto__,method_cache__23812__auto__,cached_hierarchy__23813__auto__));
})();
}
cljs.core._add_method.call(null,clack.util.read_input,new cljs.core.Keyword(null,"json","json",1279968570),(function (_,input){
var r = cognitect.transit.reader.call(null,new cljs.core.Keyword(null,"json","json",1279968570));
return cognitect.transit.read.call(null,r,input);
}));
cljs.core._add_method.call(null,clack.util.read_input,new cljs.core.Keyword(null,"tjs","tjs",720509395),(function (_,input){
var r = cognitect.transit.reader.call(null,new cljs.core.Keyword(null,"json","json",1279968570));
return cognitect.transit.read.call(null,r,input);
}));
cljs.core._add_method.call(null,clack.util.read_input,new cljs.core.Keyword(null,"edn","edn",1317840885),(function (_,input){
return cljs.tools.reader.read_string.call(null,input);
}));
cljs.core._add_method.call(null,clack.util.read_input,new cljs.core.Keyword(null,"default","default",-1987822328),(function (_,input){
return clack.util.read_input.call(null,new cljs.core.Keyword(null,"edn","edn",1317840885),input);
}));

//# sourceMappingURL=util.js.map