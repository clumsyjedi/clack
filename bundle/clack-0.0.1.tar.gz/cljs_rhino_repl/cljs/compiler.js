// Compiled by ClojureScript 1.8.51 {}
goog.provide('cljs.compiler');
goog.require('cljs.core');
goog.require('goog.string');
goog.require('cljs.tools.reader');
goog.require('cljs.env');
goog.require('cljs.analyzer');
goog.require('cljs.source_map');
goog.require('goog.string.StringBuffer');
goog.require('clojure.string');
cljs.compiler.js_reserved = cljs.analyzer.js_reserved;
cljs.compiler._STAR_recompiled_STAR_ = null;
cljs.compiler._STAR_inputs_STAR_ = null;
cljs.compiler._STAR_source_map_data_STAR_ = null;
cljs.compiler._STAR_lexical_renames_STAR_ = cljs.core.PersistentArrayMap.EMPTY;
cljs.compiler.cljs_reserved_file_names = new cljs.core.PersistentHashSet(null, new cljs.core.PersistentArrayMap(null, 1, ["deps.cljs",null], null), null);
cljs.compiler.ns_first_segments = (function cljs$compiler$ns_first_segments(){
var get_first_ns_segment = (function cljs$compiler$ns_first_segments_$_get_first_ns_segment(ns){
return cljs.core.first.call(null,clojure.string.split.call(null,[cljs.core.str(ns)].join(''),/\./));
});
return cljs.core.map.call(null,get_first_ns_segment,cljs.core.keys.call(null,new cljs.core.Keyword("cljs.analyzer","namespaces","cljs.analyzer/namespaces",-260788927).cljs$core$IFn$_invoke$arity$1(cljs.core.deref.call(null,cljs.env._STAR_compiler_STAR_))));
});
cljs.compiler.shadow_depth = (function cljs$compiler$shadow_depth(s){
var map__30742 = s;
var map__30742__$1 = ((((!((map__30742 == null)))?((((map__30742.cljs$lang$protocol_mask$partition0$ & (64))) || (map__30742.cljs$core$ISeq$))?true:false):false))?cljs.core.apply.call(null,cljs.core.hash_map,map__30742):map__30742);
var name = cljs.core.get.call(null,map__30742__$1,new cljs.core.Keyword(null,"name","name",1843675177));
var info = cljs.core.get.call(null,map__30742__$1,new cljs.core.Keyword(null,"info","info",-317069002));
var d = (0);
var G__30745 = info;
var map__30746 = G__30745;
var map__30746__$1 = ((((!((map__30746 == null)))?((((map__30746.cljs$lang$protocol_mask$partition0$ & (64))) || (map__30746.cljs$core$ISeq$))?true:false):false))?cljs.core.apply.call(null,cljs.core.hash_map,map__30746):map__30746);
var shadow = cljs.core.get.call(null,map__30746__$1,new cljs.core.Keyword(null,"shadow","shadow",873231803));
var d__$1 = d;
var G__30745__$1 = G__30745;
while(true){
var d__$2 = d__$1;
var map__30748 = G__30745__$1;
var map__30748__$1 = ((((!((map__30748 == null)))?((((map__30748.cljs$lang$protocol_mask$partition0$ & (64))) || (map__30748.cljs$core$ISeq$))?true:false):false))?cljs.core.apply.call(null,cljs.core.hash_map,map__30748):map__30748);
var shadow__$1 = cljs.core.get.call(null,map__30748__$1,new cljs.core.Keyword(null,"shadow","shadow",873231803));
if(cljs.core.truth_(shadow__$1)){
var G__30750 = (d__$2 + (1));
var G__30751 = shadow__$1;
d__$1 = G__30750;
G__30745__$1 = G__30751;
continue;
} else {
if(cljs.core.truth_(cljs.core.some.call(null,cljs.core.PersistentHashSet.fromArray([[cljs.core.str(name)].join('')], true),cljs.compiler.ns_first_segments.call(null)))){
return (d__$2 + (1));
} else {
return d__$2;

}
}
break;
}
});
cljs.compiler.hash_scope = (function cljs$compiler$hash_scope(s){
return cljs.core.hash_combine.call(null,cljs.core._hash.call(null,new cljs.core.Keyword(null,"name","name",1843675177).cljs$core$IFn$_invoke$arity$1(s)),cljs.compiler.shadow_depth.call(null,s));
});
cljs.compiler.fn_self_name = (function cljs$compiler$fn_self_name(p__30752){
var map__30757 = p__30752;
var map__30757__$1 = ((((!((map__30757 == null)))?((((map__30757.cljs$lang$protocol_mask$partition0$ & (64))) || (map__30757.cljs$core$ISeq$))?true:false):false))?cljs.core.apply.call(null,cljs.core.hash_map,map__30757):map__30757);
var name_var = map__30757__$1;
var name = cljs.core.get.call(null,map__30757__$1,new cljs.core.Keyword(null,"name","name",1843675177));
var info = cljs.core.get.call(null,map__30757__$1,new cljs.core.Keyword(null,"info","info",-317069002));
var name__$1 = clojure.string.replace.call(null,[cljs.core.str(name)].join(''),"..","_DOT__DOT_");
var map__30759 = info;
var map__30759__$1 = ((((!((map__30759 == null)))?((((map__30759.cljs$lang$protocol_mask$partition0$ & (64))) || (map__30759.cljs$core$ISeq$))?true:false):false))?cljs.core.apply.call(null,cljs.core.hash_map,map__30759):map__30759);
var ns = cljs.core.get.call(null,map__30759__$1,new cljs.core.Keyword(null,"ns","ns",441598760));
var fn_scope = cljs.core.get.call(null,map__30759__$1,new cljs.core.Keyword(null,"fn-scope","fn-scope",-865664859));
var scoped_name = cljs.core.apply.call(null,cljs.core.str,cljs.core.interpose.call(null,"_$_",cljs.core.concat.call(null,cljs.core.map.call(null,cljs.core.comp.call(null,cljs.core.str,new cljs.core.Keyword(null,"name","name",1843675177)),fn_scope),new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [name__$1], null))));
return cljs.core.symbol.call(null,cljs.compiler.munge.call(null,[cljs.core.str(clojure.string.replace.call(null,[cljs.core.str(ns)].join(''),".","$")),cljs.core.str("$"),cljs.core.str(scoped_name)].join('')));
});
cljs.compiler.munge_reserved = (function cljs$compiler$munge_reserved(reserved){
return (function (s){
if(!((cljs.core.get.call(null,reserved,s) == null))){
return [cljs.core.str(s),cljs.core.str("$")].join('');
} else {
return s;
}
});
});
cljs.compiler.munge = (function cljs$compiler$munge(var_args){
var args30761 = [];
var len__23955__auto___30764 = arguments.length;
var i__23956__auto___30765 = (0);
while(true){
if((i__23956__auto___30765 < len__23955__auto___30764)){
args30761.push((arguments[i__23956__auto___30765]));

var G__30766 = (i__23956__auto___30765 + (1));
i__23956__auto___30765 = G__30766;
continue;
} else {
}
break;
}

var G__30763 = args30761.length;
switch (G__30763) {
case 1:
return cljs.compiler.munge.cljs$core$IFn$_invoke$arity$1((arguments[(0)]));

break;
case 2:
return cljs.compiler.munge.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
default:
throw (new Error([cljs.core.str("Invalid arity: "),cljs.core.str(args30761.length)].join('')));

}
});

cljs.compiler.munge.cljs$core$IFn$_invoke$arity$1 = (function (s){
return cljs.compiler.munge.call(null,s,cljs.compiler.js_reserved);
});

cljs.compiler.munge.cljs$core$IFn$_invoke$arity$2 = (function (s,reserved){
if(cljs.analyzer.cljs_map_QMARK_.call(null,s)){
var name_var = s;
var name = new cljs.core.Keyword(null,"name","name",1843675177).cljs$core$IFn$_invoke$arity$1(name_var);
var field = new cljs.core.Keyword(null,"field","field",-1302436500).cljs$core$IFn$_invoke$arity$1(name_var);
var info = new cljs.core.Keyword(null,"info","info",-317069002).cljs$core$IFn$_invoke$arity$1(name_var);
if(!((new cljs.core.Keyword(null,"fn-self-name","fn-self-name",1461143531).cljs$core$IFn$_invoke$arity$1(info) == null))){
return cljs.compiler.fn_self_name.call(null,s);
} else {
var depth = cljs.compiler.shadow_depth.call(null,s);
var code = cljs.compiler.hash_scope.call(null,s);
var renamed = cljs.core.get.call(null,cljs.compiler._STAR_lexical_renames_STAR_,code);
var name__$1 = ((field === true)?[cljs.core.str("self__."),cljs.core.str(name)].join(''):((!((renamed == null)))?renamed:name
));
var munged_name = cljs.compiler.munge.call(null,name__$1,reserved);
if((field === true) || ((depth === (0)))){
return munged_name;
} else {
return cljs.core.symbol.call(null,[cljs.core.str(munged_name),cljs.core.str("__$"),cljs.core.str(depth)].join(''));
}
}
} else {
var ss = clojure.string.replace.call(null,[cljs.core.str(s)].join(''),"..","_DOT__DOT_");
var ss__$1 = clojure.string.replace.call(null,ss,(new RegExp("\\/(.)")),".$1");
var rf = cljs.compiler.munge_reserved.call(null,reserved);
var ss__$2 = cljs.core.map.call(null,rf,clojure.string.split.call(null,ss__$1,/\./));
var ss__$3 = clojure.string.join.call(null,".",ss__$2);
var ms = cljs.core.munge.call(null,ss__$3);
if((s instanceof cljs.core.Symbol)){
return cljs.core.symbol.call(null,ms);
} else {
return ms;
}
}
});

cljs.compiler.munge.cljs$lang$maxFixedArity = 2;
cljs.compiler.comma_sep = (function cljs$compiler$comma_sep(xs){
return cljs.core.interpose.call(null,",",xs);
});
cljs.compiler.escape_char = (function cljs$compiler$escape_char(c){
var cp = goog.string.hashCode(c);
var G__30769 = cp;
switch (G__30769) {
case (34):
return "\\\"";

break;
case (92):
return "\\\\";

break;
case (8):
return "\\b";

break;
case (12):
return "\\f";

break;
case (10):
return "\\n";

break;
case (13):
return "\\r";

break;
case (9):
return "\\t";

break;
default:
if((((31) < cp)) && ((cp < (127)))){
return c;
} else {
var unpadded = cp.toString((16));
var pad = cljs.core.subs.call(null,"0000",unpadded.length);
return [cljs.core.str("\\u"),cljs.core.str(pad),cljs.core.str(unpadded)].join('');
}

}
});
cljs.compiler.escape_string = (function cljs$compiler$escape_string(s){
var sb = (new goog.string.StringBuffer());
var seq__30775_30779 = cljs.core.seq.call(null,s);
var chunk__30776_30780 = null;
var count__30777_30781 = (0);
var i__30778_30782 = (0);
while(true){
if((i__30778_30782 < count__30777_30781)){
var c_30783 = cljs.core._nth.call(null,chunk__30776_30780,i__30778_30782);
sb.append(cljs.compiler.escape_char.call(null,c_30783));

var G__30784 = seq__30775_30779;
var G__30785 = chunk__30776_30780;
var G__30786 = count__30777_30781;
var G__30787 = (i__30778_30782 + (1));
seq__30775_30779 = G__30784;
chunk__30776_30780 = G__30785;
count__30777_30781 = G__30786;
i__30778_30782 = G__30787;
continue;
} else {
var temp__4657__auto___30788 = cljs.core.seq.call(null,seq__30775_30779);
if(temp__4657__auto___30788){
var seq__30775_30789__$1 = temp__4657__auto___30788;
if(cljs.core.chunked_seq_QMARK_.call(null,seq__30775_30789__$1)){
var c__23696__auto___30790 = cljs.core.chunk_first.call(null,seq__30775_30789__$1);
var G__30791 = cljs.core.chunk_rest.call(null,seq__30775_30789__$1);
var G__30792 = c__23696__auto___30790;
var G__30793 = cljs.core.count.call(null,c__23696__auto___30790);
var G__30794 = (0);
seq__30775_30779 = G__30791;
chunk__30776_30780 = G__30792;
count__30777_30781 = G__30793;
i__30778_30782 = G__30794;
continue;
} else {
var c_30795 = cljs.core.first.call(null,seq__30775_30789__$1);
sb.append(cljs.compiler.escape_char.call(null,c_30795));

var G__30796 = cljs.core.next.call(null,seq__30775_30789__$1);
var G__30797 = null;
var G__30798 = (0);
var G__30799 = (0);
seq__30775_30779 = G__30796;
chunk__30776_30780 = G__30797;
count__30777_30781 = G__30798;
i__30778_30782 = G__30799;
continue;
}
} else {
}
}
break;
}

return sb.toString();
});
cljs.compiler.wrap_in_double_quotes = (function cljs$compiler$wrap_in_double_quotes(x){
return [cljs.core.str("\""),cljs.core.str(x),cljs.core.str("\"")].join('');
});
if(typeof cljs.compiler.emit_STAR_ !== 'undefined'){
} else {
cljs.compiler.emit_STAR_ = (function (){var method_table__23810__auto__ = cljs.core.atom.call(null,cljs.core.PersistentArrayMap.EMPTY);
var prefer_table__23811__auto__ = cljs.core.atom.call(null,cljs.core.PersistentArrayMap.EMPTY);
var method_cache__23812__auto__ = cljs.core.atom.call(null,cljs.core.PersistentArrayMap.EMPTY);
var cached_hierarchy__23813__auto__ = cljs.core.atom.call(null,cljs.core.PersistentArrayMap.EMPTY);
var hierarchy__23814__auto__ = cljs.core.get.call(null,cljs.core.PersistentArrayMap.EMPTY,new cljs.core.Keyword(null,"hierarchy","hierarchy",-1053470341),cljs.core.get_global_hierarchy.call(null));
return (new cljs.core.MultiFn(cljs.core.symbol.call(null,"cljs.compiler","emit*"),new cljs.core.Keyword(null,"op","op",-1882987955),new cljs.core.Keyword(null,"default","default",-1987822328),hierarchy__23814__auto__,method_table__23810__auto__,prefer_table__23811__auto__,method_cache__23812__auto__,cached_hierarchy__23813__auto__));
})();
}
cljs.compiler.emit = (function cljs$compiler$emit(ast){
var val__24270__auto__ = cljs.env._STAR_compiler_STAR_;
if((val__24270__auto__ == null)){
cljs.env._STAR_compiler_STAR_ = cljs.env.default_compiler_env.call(null);
} else {
}

try{if(cljs.core.truth_(cljs.compiler._STAR_source_map_data_STAR_)){
var map__30805_30810 = ast;
var map__30805_30811__$1 = ((((!((map__30805_30810 == null)))?((((map__30805_30810.cljs$lang$protocol_mask$partition0$ & (64))) || (map__30805_30810.cljs$core$ISeq$))?true:false):false))?cljs.core.apply.call(null,cljs.core.hash_map,map__30805_30810):map__30805_30810);
var env_30812 = cljs.core.get.call(null,map__30805_30811__$1,new cljs.core.Keyword(null,"env","env",-1815813235));
if(cljs.core.truth_(new cljs.core.Keyword(null,"line","line",212345235).cljs$core$IFn$_invoke$arity$1(env_30812))){
var map__30807_30813 = env_30812;
var map__30807_30814__$1 = ((((!((map__30807_30813 == null)))?((((map__30807_30813.cljs$lang$protocol_mask$partition0$ & (64))) || (map__30807_30813.cljs$core$ISeq$))?true:false):false))?cljs.core.apply.call(null,cljs.core.hash_map,map__30807_30813):map__30807_30813);
var line_30815 = cljs.core.get.call(null,map__30807_30814__$1,new cljs.core.Keyword(null,"line","line",212345235));
var column_30816 = cljs.core.get.call(null,map__30807_30814__$1,new cljs.core.Keyword(null,"column","column",2078222095));
cljs.core.swap_BANG_.call(null,cljs.compiler._STAR_source_map_data_STAR_,((function (map__30807_30813,map__30807_30814__$1,line_30815,column_30816,map__30805_30810,map__30805_30811__$1,env_30812,val__24270__auto__){
return (function (m){
var minfo = (function (){var G__30809 = new cljs.core.PersistentArrayMap(null, 2, [new cljs.core.Keyword(null,"gcol","gcol",309250807),new cljs.core.Keyword(null,"gen-col","gen-col",1901918303).cljs$core$IFn$_invoke$arity$1(m),new cljs.core.Keyword(null,"gline","gline",-1086242431),new cljs.core.Keyword(null,"gen-line","gen-line",589592125).cljs$core$IFn$_invoke$arity$1(m)], null);
if(cljs.core._EQ_.call(null,new cljs.core.Keyword(null,"op","op",-1882987955).cljs$core$IFn$_invoke$arity$1(ast),new cljs.core.Keyword(null,"var","var",-769682797))){
return cljs.core.assoc.call(null,G__30809,new cljs.core.Keyword(null,"name","name",1843675177),[cljs.core.str(new cljs.core.Keyword(null,"name","name",1843675177).cljs$core$IFn$_invoke$arity$1(new cljs.core.Keyword(null,"info","info",-317069002).cljs$core$IFn$_invoke$arity$1(ast)))].join(''));
} else {
return G__30809;
}
})();
return cljs.core.update_in.call(null,m,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword(null,"source-map","source-map",1706252311),(line_30815 - (1))], null),cljs.core.fnil.call(null,((function (minfo,map__30807_30813,map__30807_30814__$1,line_30815,column_30816,map__30805_30810,map__30805_30811__$1,env_30812,val__24270__auto__){
return (function (line__$1){
return cljs.core.update_in.call(null,line__$1,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [(cljs.core.truth_(column_30816)?(column_30816 - (1)):(0))], null),cljs.core.fnil.call(null,((function (minfo,map__30807_30813,map__30807_30814__$1,line_30815,column_30816,map__30805_30810,map__30805_30811__$1,env_30812,val__24270__auto__){
return (function (column__$1){
return cljs.core.conj.call(null,column__$1,minfo);
});})(minfo,map__30807_30813,map__30807_30814__$1,line_30815,column_30816,map__30805_30810,map__30805_30811__$1,env_30812,val__24270__auto__))
,cljs.core.PersistentVector.EMPTY));
});})(minfo,map__30807_30813,map__30807_30814__$1,line_30815,column_30816,map__30805_30810,map__30805_30811__$1,env_30812,val__24270__auto__))
,cljs.core.sorted_map.call(null)));
});})(map__30807_30813,map__30807_30814__$1,line_30815,column_30816,map__30805_30810,map__30805_30811__$1,env_30812,val__24270__auto__))
);
} else {
}
} else {
}

return cljs.compiler.emit_STAR_.call(null,ast);
}finally {if((val__24270__auto__ == null)){
cljs.env._STAR_compiler_STAR_ = null;
} else {
}
}});
cljs.compiler.emits = (function cljs$compiler$emits(var_args){
var args__23962__auto__ = [];
var len__23955__auto___30823 = arguments.length;
var i__23956__auto___30824 = (0);
while(true){
if((i__23956__auto___30824 < len__23955__auto___30823)){
args__23962__auto__.push((arguments[i__23956__auto___30824]));

var G__30825 = (i__23956__auto___30824 + (1));
i__23956__auto___30824 = G__30825;
continue;
} else {
}
break;
}

var argseq__23963__auto__ = ((((0) < args__23962__auto__.length))?(new cljs.core.IndexedSeq(args__23962__auto__.slice((0)),(0),null)):null);
return cljs.compiler.emits.cljs$core$IFn$_invoke$arity$variadic(argseq__23963__auto__);
});

cljs.compiler.emits.cljs$core$IFn$_invoke$arity$variadic = (function (xs){
var seq__30819_30826 = cljs.core.seq.call(null,xs);
var chunk__30820_30827 = null;
var count__30821_30828 = (0);
var i__30822_30829 = (0);
while(true){
if((i__30822_30829 < count__30821_30828)){
var x_30830 = cljs.core._nth.call(null,chunk__30820_30827,i__30822_30829);
if((x_30830 == null)){
} else {
if(cljs.analyzer.cljs_map_QMARK_.call(null,x_30830)){
cljs.compiler.emit.call(null,x_30830);
} else {
if(cljs.analyzer.cljs_seq_QMARK_.call(null,x_30830)){
cljs.core.apply.call(null,cljs.compiler.emits,x_30830);
} else {
if(goog.isFunction(x_30830)){
x_30830.call(null);
} else {
var s_30831 = cljs.core.print_str.call(null,x_30830);
if((cljs.compiler._STAR_source_map_data_STAR_ == null)){
} else {
cljs.core.swap_BANG_.call(null,cljs.compiler._STAR_source_map_data_STAR_,cljs.core.update_in,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword(null,"gen-col","gen-col",1901918303)], null),((function (seq__30819_30826,chunk__30820_30827,count__30821_30828,i__30822_30829,s_30831,x_30830){
return (function (p1__30817_SHARP_){
return (p1__30817_SHARP_ + cljs.core.count.call(null,s_30831));
});})(seq__30819_30826,chunk__30820_30827,count__30821_30828,i__30822_30829,s_30831,x_30830))
);
}

cljs.core.print.call(null,s_30831);

}
}
}
}

var G__30832 = seq__30819_30826;
var G__30833 = chunk__30820_30827;
var G__30834 = count__30821_30828;
var G__30835 = (i__30822_30829 + (1));
seq__30819_30826 = G__30832;
chunk__30820_30827 = G__30833;
count__30821_30828 = G__30834;
i__30822_30829 = G__30835;
continue;
} else {
var temp__4657__auto___30836 = cljs.core.seq.call(null,seq__30819_30826);
if(temp__4657__auto___30836){
var seq__30819_30837__$1 = temp__4657__auto___30836;
if(cljs.core.chunked_seq_QMARK_.call(null,seq__30819_30837__$1)){
var c__23696__auto___30838 = cljs.core.chunk_first.call(null,seq__30819_30837__$1);
var G__30839 = cljs.core.chunk_rest.call(null,seq__30819_30837__$1);
var G__30840 = c__23696__auto___30838;
var G__30841 = cljs.core.count.call(null,c__23696__auto___30838);
var G__30842 = (0);
seq__30819_30826 = G__30839;
chunk__30820_30827 = G__30840;
count__30821_30828 = G__30841;
i__30822_30829 = G__30842;
continue;
} else {
var x_30843 = cljs.core.first.call(null,seq__30819_30837__$1);
if((x_30843 == null)){
} else {
if(cljs.analyzer.cljs_map_QMARK_.call(null,x_30843)){
cljs.compiler.emit.call(null,x_30843);
} else {
if(cljs.analyzer.cljs_seq_QMARK_.call(null,x_30843)){
cljs.core.apply.call(null,cljs.compiler.emits,x_30843);
} else {
if(goog.isFunction(x_30843)){
x_30843.call(null);
} else {
var s_30844 = cljs.core.print_str.call(null,x_30843);
if((cljs.compiler._STAR_source_map_data_STAR_ == null)){
} else {
cljs.core.swap_BANG_.call(null,cljs.compiler._STAR_source_map_data_STAR_,cljs.core.update_in,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword(null,"gen-col","gen-col",1901918303)], null),((function (seq__30819_30826,chunk__30820_30827,count__30821_30828,i__30822_30829,s_30844,x_30843,seq__30819_30837__$1,temp__4657__auto___30836){
return (function (p1__30817_SHARP_){
return (p1__30817_SHARP_ + cljs.core.count.call(null,s_30844));
});})(seq__30819_30826,chunk__30820_30827,count__30821_30828,i__30822_30829,s_30844,x_30843,seq__30819_30837__$1,temp__4657__auto___30836))
);
}

cljs.core.print.call(null,s_30844);

}
}
}
}

var G__30845 = cljs.core.next.call(null,seq__30819_30837__$1);
var G__30846 = null;
var G__30847 = (0);
var G__30848 = (0);
seq__30819_30826 = G__30845;
chunk__30820_30827 = G__30846;
count__30821_30828 = G__30847;
i__30822_30829 = G__30848;
continue;
}
} else {
}
}
break;
}

return null;
});

cljs.compiler.emits.cljs$lang$maxFixedArity = (0);

cljs.compiler.emits.cljs$lang$applyTo = (function (seq30818){
return cljs.compiler.emits.cljs$core$IFn$_invoke$arity$variadic(cljs.core.seq.call(null,seq30818));
});
cljs.compiler.emitln = (function cljs$compiler$emitln(var_args){
var args__23962__auto__ = [];
var len__23955__auto___30853 = arguments.length;
var i__23956__auto___30854 = (0);
while(true){
if((i__23956__auto___30854 < len__23955__auto___30853)){
args__23962__auto__.push((arguments[i__23956__auto___30854]));

var G__30855 = (i__23956__auto___30854 + (1));
i__23956__auto___30854 = G__30855;
continue;
} else {
}
break;
}

var argseq__23963__auto__ = ((((0) < args__23962__auto__.length))?(new cljs.core.IndexedSeq(args__23962__auto__.slice((0)),(0),null)):null);
return cljs.compiler.emitln.cljs$core$IFn$_invoke$arity$variadic(argseq__23963__auto__);
});

cljs.compiler.emitln.cljs$core$IFn$_invoke$arity$variadic = (function (xs){
cljs.core.apply.call(null,cljs.compiler.emits,xs);

cljs.core.println.call(null);

if(cljs.core.truth_(cljs.compiler._STAR_source_map_data_STAR_)){
cljs.core.swap_BANG_.call(null,cljs.compiler._STAR_source_map_data_STAR_,(function (p__30850){
var map__30851 = p__30850;
var map__30851__$1 = ((((!((map__30851 == null)))?((((map__30851.cljs$lang$protocol_mask$partition0$ & (64))) || (map__30851.cljs$core$ISeq$))?true:false):false))?cljs.core.apply.call(null,cljs.core.hash_map,map__30851):map__30851);
var m = map__30851__$1;
var gen_line = cljs.core.get.call(null,map__30851__$1,new cljs.core.Keyword(null,"gen-line","gen-line",589592125));
return cljs.core.assoc.call(null,m,new cljs.core.Keyword(null,"gen-line","gen-line",589592125),(gen_line + (1)),new cljs.core.Keyword(null,"gen-col","gen-col",1901918303),(0));
}));
} else {
}

return null;
});

cljs.compiler.emitln.cljs$lang$maxFixedArity = (0);

cljs.compiler.emitln.cljs$lang$applyTo = (function (seq30849){
return cljs.compiler.emitln.cljs$core$IFn$_invoke$arity$variadic(cljs.core.seq.call(null,seq30849));
});
cljs.compiler.emit_str = (function cljs$compiler$emit_str(expr){
var sb__23871__auto__ = (new goog.string.StringBuffer());
var _STAR_print_newline_STAR_30858_30860 = cljs.core._STAR_print_newline_STAR_;
var _STAR_print_fn_STAR_30859_30861 = cljs.core._STAR_print_fn_STAR_;
cljs.core._STAR_print_newline_STAR_ = true;

cljs.core._STAR_print_fn_STAR_ = ((function (_STAR_print_newline_STAR_30858_30860,_STAR_print_fn_STAR_30859_30861,sb__23871__auto__){
return (function (x__23872__auto__){
return sb__23871__auto__.append(x__23872__auto__);
});})(_STAR_print_newline_STAR_30858_30860,_STAR_print_fn_STAR_30859_30861,sb__23871__auto__))
;

try{cljs.compiler.emit.call(null,expr);
}finally {cljs.core._STAR_print_fn_STAR_ = _STAR_print_fn_STAR_30859_30861;

cljs.core._STAR_print_newline_STAR_ = _STAR_print_newline_STAR_30858_30860;
}
return [cljs.core.str(sb__23871__auto__)].join('');
});
if(typeof cljs.compiler.emit_constant !== 'undefined'){
} else {
cljs.compiler.emit_constant = (function (){var method_table__23810__auto__ = cljs.core.atom.call(null,cljs.core.PersistentArrayMap.EMPTY);
var prefer_table__23811__auto__ = cljs.core.atom.call(null,cljs.core.PersistentArrayMap.EMPTY);
var method_cache__23812__auto__ = cljs.core.atom.call(null,cljs.core.PersistentArrayMap.EMPTY);
var cached_hierarchy__23813__auto__ = cljs.core.atom.call(null,cljs.core.PersistentArrayMap.EMPTY);
var hierarchy__23814__auto__ = cljs.core.get.call(null,cljs.core.PersistentArrayMap.EMPTY,new cljs.core.Keyword(null,"hierarchy","hierarchy",-1053470341),cljs.core.get_global_hierarchy.call(null));
return (new cljs.core.MultiFn(cljs.core.symbol.call(null,"cljs.compiler","emit-constant"),cljs.core.type,new cljs.core.Keyword(null,"default","default",-1987822328),hierarchy__23814__auto__,method_table__23810__auto__,prefer_table__23811__auto__,method_cache__23812__auto__,cached_hierarchy__23813__auto__));
})();
}
cljs.core._add_method.call(null,cljs.compiler.emit_constant,null,(function (x){
return cljs.compiler.emits.call(null,"null");
}));
cljs.core._add_method.call(null,cljs.compiler.emit_constant,Number,(function (x){
return cljs.compiler.emits.call(null,"(",x,")");
}));
cljs.core._add_method.call(null,cljs.compiler.emit_constant,String,(function (x){
return cljs.compiler.emits.call(null,cljs.compiler.wrap_in_double_quotes.call(null,cljs.compiler.escape_string.call(null,x)));
}));
cljs.core._add_method.call(null,cljs.compiler.emit_constant,Boolean,(function (x){
return cljs.compiler.emits.call(null,(cljs.core.truth_(x)?"true":"false"));
}));
cljs.core._add_method.call(null,cljs.compiler.emit_constant,RegExp,(function (x){
if(cljs.core._EQ_.call(null,"",[cljs.core.str(x)].join(''))){
return cljs.compiler.emits.call(null,"(new RegExp(\"\"))");
} else {
var vec__30862 = cljs.core.re_find.call(null,/^(?:\(\?([idmsux]*)\))?(.*)/,[cljs.core.str(x)].join(''));
var _ = cljs.core.nth.call(null,vec__30862,(0),null);
var flags = cljs.core.nth.call(null,vec__30862,(1),null);
var pattern = cljs.core.nth.call(null,vec__30862,(2),null);
return cljs.compiler.emits.call(null,pattern);
}
}));
cljs.compiler.emits_keyword = (function cljs$compiler$emits_keyword(kw){
var ns = cljs.core.namespace.call(null,kw);
var name = cljs.core.name.call(null,kw);
cljs.compiler.emits.call(null,"new cljs.core.Keyword(");

cljs.compiler.emit_constant.call(null,ns);

cljs.compiler.emits.call(null,",");

cljs.compiler.emit_constant.call(null,name);

cljs.compiler.emits.call(null,",");

cljs.compiler.emit_constant.call(null,(cljs.core.truth_(ns)?[cljs.core.str(ns),cljs.core.str("/"),cljs.core.str(name)].join(''):name));

cljs.compiler.emits.call(null,",");

cljs.compiler.emit_constant.call(null,cljs.core.hash.call(null,kw));

return cljs.compiler.emits.call(null,")");
});
cljs.compiler.emits_symbol = (function cljs$compiler$emits_symbol(sym){
var ns = cljs.core.namespace.call(null,sym);
var name = cljs.core.name.call(null,sym);
var symstr = ((!((ns == null)))?[cljs.core.str(ns),cljs.core.str("/"),cljs.core.str(name)].join(''):name);
cljs.compiler.emits.call(null,"new cljs.core.Symbol(");

cljs.compiler.emit_constant.call(null,ns);

cljs.compiler.emits.call(null,",");

cljs.compiler.emit_constant.call(null,name);

cljs.compiler.emits.call(null,",");

cljs.compiler.emit_constant.call(null,symstr);

cljs.compiler.emits.call(null,",");

cljs.compiler.emit_constant.call(null,cljs.core.hash.call(null,sym));

cljs.compiler.emits.call(null,",");

cljs.compiler.emit_constant.call(null,null);

return cljs.compiler.emits.call(null,")");
});
cljs.core._add_method.call(null,cljs.compiler.emit_constant,cljs.core.Keyword,(function (x){
if(cljs.core.truth_(new cljs.core.Keyword(null,"emit-constants","emit-constants",-476585410).cljs$core$IFn$_invoke$arity$1(new cljs.core.Keyword(null,"options","options",99638489).cljs$core$IFn$_invoke$arity$1(cljs.core.deref.call(null,cljs.env._STAR_compiler_STAR_))))){
var value = x.call(null,new cljs.core.Keyword("cljs.analyzer","constant-table","cljs.analyzer/constant-table",-114131889).cljs$core$IFn$_invoke$arity$1(cljs.core.deref.call(null,cljs.env._STAR_compiler_STAR_)));
return cljs.compiler.emits.call(null,"cljs.core.",value);
} else {
return cljs.compiler.emits_keyword.call(null,x);
}
}));
cljs.core._add_method.call(null,cljs.compiler.emit_constant,cljs.core.Symbol,(function (x){
if(cljs.core.truth_(new cljs.core.Keyword(null,"emit-constants","emit-constants",-476585410).cljs$core$IFn$_invoke$arity$1(new cljs.core.Keyword(null,"options","options",99638489).cljs$core$IFn$_invoke$arity$1(cljs.core.deref.call(null,cljs.env._STAR_compiler_STAR_))))){
var value = x.call(null,new cljs.core.Keyword("cljs.analyzer","constant-table","cljs.analyzer/constant-table",-114131889).cljs$core$IFn$_invoke$arity$1(cljs.core.deref.call(null,cljs.env._STAR_compiler_STAR_)));
return cljs.compiler.emits.call(null,"cljs.core.",value);
} else {
return cljs.compiler.emits_symbol.call(null,x);
}
}));
cljs.core._add_method.call(null,cljs.compiler.emit_constant,Date,(function (date){
return cljs.compiler.emits.call(null,"new Date(",date.getTime(),")");
}));
cljs.core._add_method.call(null,cljs.compiler.emit_constant,cljs.core.UUID,(function (uuid){
var uuid_str = uuid.toString();
return cljs.compiler.emits.call(null,"new cljs.core.UUID(\"",uuid_str,"\", ",cljs.core.hash.call(null,uuid_str),")");
}));
cljs.core._add_method.call(null,cljs.compiler.emit_STAR_,new cljs.core.Keyword(null,"no-op","no-op",-93046065),(function (m){
return null;
}));
cljs.core._add_method.call(null,cljs.compiler.emit_STAR_,new cljs.core.Keyword(null,"var","var",-769682797),(function (p__30864){
var map__30865 = p__30864;
var map__30865__$1 = ((((!((map__30865 == null)))?((((map__30865.cljs$lang$protocol_mask$partition0$ & (64))) || (map__30865.cljs$core$ISeq$))?true:false):false))?cljs.core.apply.call(null,cljs.core.hash_map,map__30865):map__30865);
var arg = map__30865__$1;
var info = cljs.core.get.call(null,map__30865__$1,new cljs.core.Keyword(null,"info","info",-317069002));
var env = cljs.core.get.call(null,map__30865__$1,new cljs.core.Keyword(null,"env","env",-1815813235));
var form = cljs.core.get.call(null,map__30865__$1,new cljs.core.Keyword(null,"form","form",-1624062471));
var var_name = new cljs.core.Keyword(null,"name","name",1843675177).cljs$core$IFn$_invoke$arity$1(info);
var info__$1 = ((cljs.core._EQ_.call(null,cljs.core.namespace.call(null,var_name),"js"))?(function (){var js_module_name = cljs.core.get_in.call(null,cljs.core.deref.call(null,cljs.env._STAR_compiler_STAR_),new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword(null,"js-module-index","js-module-index",2072061931),cljs.core.name.call(null,var_name)], null));
var or__22885__auto__ = js_module_name;
if(cljs.core.truth_(or__22885__auto__)){
return or__22885__auto__;
} else {
return cljs.core.name.call(null,var_name);
}
})():info);
if(cljs.core.truth_(new cljs.core.Keyword(null,"binding-form?","binding-form?",1728940169).cljs$core$IFn$_invoke$arity$1(arg))){
return cljs.compiler.emits.call(null,cljs.compiler.munge.call(null,arg));
} else {
if(cljs.core._EQ_.call(null,new cljs.core.Keyword(null,"statement","statement",-32780863),new cljs.core.Keyword(null,"context","context",-830191113).cljs$core$IFn$_invoke$arity$1(env))){
return null;
} else {
var env__24998__auto__ = env;
if(cljs.core._EQ_.call(null,new cljs.core.Keyword(null,"return","return",-1891502105),new cljs.core.Keyword(null,"context","context",-830191113).cljs$core$IFn$_invoke$arity$1(env__24998__auto__))){
cljs.compiler.emits.call(null,"return ");
} else {
}

cljs.compiler.emits.call(null,(function (){var G__30867 = info__$1;
if(cljs.core.not_EQ_.call(null,form,new cljs.core.Symbol("js","-Infinity","js/-Infinity",958706333,null))){
return cljs.compiler.munge.call(null,G__30867);
} else {
return G__30867;
}
})());

if(cljs.core._EQ_.call(null,new cljs.core.Keyword(null,"expr","expr",745722291),new cljs.core.Keyword(null,"context","context",-830191113).cljs$core$IFn$_invoke$arity$1(env__24998__auto__))){
return null;
} else {
return cljs.compiler.emitln.call(null,";");
}
}
}
}));
cljs.core._add_method.call(null,cljs.compiler.emit_STAR_,new cljs.core.Keyword(null,"var-special","var-special",1131576802),(function (p__30868){
var map__30869 = p__30868;
var map__30869__$1 = ((((!((map__30869 == null)))?((((map__30869.cljs$lang$protocol_mask$partition0$ & (64))) || (map__30869.cljs$core$ISeq$))?true:false):false))?cljs.core.apply.call(null,cljs.core.hash_map,map__30869):map__30869);
var arg = map__30869__$1;
var env = cljs.core.get.call(null,map__30869__$1,new cljs.core.Keyword(null,"env","env",-1815813235));
var var$ = cljs.core.get.call(null,map__30869__$1,new cljs.core.Keyword(null,"var","var",-769682797));
var sym = cljs.core.get.call(null,map__30869__$1,new cljs.core.Keyword(null,"sym","sym",-1444860305));
var meta = cljs.core.get.call(null,map__30869__$1,new cljs.core.Keyword(null,"meta","meta",1499536964));
if(cljs.analyzer.ast_QMARK_.call(null,sym)){
} else {
throw (new Error("Assert failed: (ana/ast? sym)"));
}

if(cljs.analyzer.ast_QMARK_.call(null,meta)){
} else {
throw (new Error("Assert failed: (ana/ast? meta)"));
}

var map__30871 = new cljs.core.Keyword(null,"info","info",-317069002).cljs$core$IFn$_invoke$arity$1(var$);
var map__30871__$1 = ((((!((map__30871 == null)))?((((map__30871.cljs$lang$protocol_mask$partition0$ & (64))) || (map__30871.cljs$core$ISeq$))?true:false):false))?cljs.core.apply.call(null,cljs.core.hash_map,map__30871):map__30871);
var name = cljs.core.get.call(null,map__30871__$1,new cljs.core.Keyword(null,"name","name",1843675177));
var env__24998__auto__ = env;
if(cljs.core._EQ_.call(null,new cljs.core.Keyword(null,"return","return",-1891502105),new cljs.core.Keyword(null,"context","context",-830191113).cljs$core$IFn$_invoke$arity$1(env__24998__auto__))){
cljs.compiler.emits.call(null,"return ");
} else {
}

cljs.compiler.emits.call(null,"new cljs.core.Var(function(){return ",cljs.compiler.munge.call(null,name),";},",sym,",",meta,")");

if(cljs.core._EQ_.call(null,new cljs.core.Keyword(null,"expr","expr",745722291),new cljs.core.Keyword(null,"context","context",-830191113).cljs$core$IFn$_invoke$arity$1(env__24998__auto__))){
return null;
} else {
return cljs.compiler.emitln.call(null,";");
}
}));
cljs.core._add_method.call(null,cljs.compiler.emit_STAR_,new cljs.core.Keyword(null,"meta","meta",1499536964),(function (p__30873){
var map__30874 = p__30873;
var map__30874__$1 = ((((!((map__30874 == null)))?((((map__30874.cljs$lang$protocol_mask$partition0$ & (64))) || (map__30874.cljs$core$ISeq$))?true:false):false))?cljs.core.apply.call(null,cljs.core.hash_map,map__30874):map__30874);
var expr = cljs.core.get.call(null,map__30874__$1,new cljs.core.Keyword(null,"expr","expr",745722291));
var meta = cljs.core.get.call(null,map__30874__$1,new cljs.core.Keyword(null,"meta","meta",1499536964));
var env = cljs.core.get.call(null,map__30874__$1,new cljs.core.Keyword(null,"env","env",-1815813235));
var env__24998__auto__ = env;
if(cljs.core._EQ_.call(null,new cljs.core.Keyword(null,"return","return",-1891502105),new cljs.core.Keyword(null,"context","context",-830191113).cljs$core$IFn$_invoke$arity$1(env__24998__auto__))){
cljs.compiler.emits.call(null,"return ");
} else {
}

cljs.compiler.emits.call(null,"cljs.core.with_meta(",expr,",",meta,")");

if(cljs.core._EQ_.call(null,new cljs.core.Keyword(null,"expr","expr",745722291),new cljs.core.Keyword(null,"context","context",-830191113).cljs$core$IFn$_invoke$arity$1(env__24998__auto__))){
return null;
} else {
return cljs.compiler.emitln.call(null,";");
}
}));
cljs.compiler.array_map_threshold = (8);
cljs.compiler.distinct_keys_QMARK_ = (function cljs$compiler$distinct_keys_QMARK_(keys){
return (cljs.core.every_QMARK_.call(null,(function (p1__30876_SHARP_){
return cljs.core._EQ_.call(null,new cljs.core.Keyword(null,"op","op",-1882987955).cljs$core$IFn$_invoke$arity$1(p1__30876_SHARP_),new cljs.core.Keyword(null,"constant","constant",-379609303));
}),keys)) && (cljs.core._EQ_.call(null,cljs.core.count.call(null,cljs.core.into.call(null,cljs.core.PersistentHashSet.EMPTY,keys)),cljs.core.count.call(null,keys)));
});
cljs.core._add_method.call(null,cljs.compiler.emit_STAR_,new cljs.core.Keyword(null,"map","map",1371690461),(function (p__30877){
var map__30878 = p__30877;
var map__30878__$1 = ((((!((map__30878 == null)))?((((map__30878.cljs$lang$protocol_mask$partition0$ & (64))) || (map__30878.cljs$core$ISeq$))?true:false):false))?cljs.core.apply.call(null,cljs.core.hash_map,map__30878):map__30878);
var env = cljs.core.get.call(null,map__30878__$1,new cljs.core.Keyword(null,"env","env",-1815813235));
var keys = cljs.core.get.call(null,map__30878__$1,new cljs.core.Keyword(null,"keys","keys",1068423698));
var vals = cljs.core.get.call(null,map__30878__$1,new cljs.core.Keyword(null,"vals","vals",768058733));
var env__24998__auto__ = env;
if(cljs.core._EQ_.call(null,new cljs.core.Keyword(null,"return","return",-1891502105),new cljs.core.Keyword(null,"context","context",-830191113).cljs$core$IFn$_invoke$arity$1(env__24998__auto__))){
cljs.compiler.emits.call(null,"return ");
} else {
}

if((cljs.core.count.call(null,keys) === (0))){
cljs.compiler.emits.call(null,"cljs.core.PersistentArrayMap.EMPTY");
} else {
if((cljs.core.count.call(null,keys) <= cljs.compiler.array_map_threshold)){
if(cljs.core.truth_(cljs.compiler.distinct_keys_QMARK_.call(null,keys))){
cljs.compiler.emits.call(null,"new cljs.core.PersistentArrayMap(null, ",cljs.core.count.call(null,keys),", [",cljs.compiler.comma_sep.call(null,cljs.core.interleave.call(null,keys,vals)),"], null)");
} else {
cljs.compiler.emits.call(null,"cljs.core.PersistentArrayMap.fromArray([",cljs.compiler.comma_sep.call(null,cljs.core.interleave.call(null,keys,vals)),"], true, false)");
}
} else {
cljs.compiler.emits.call(null,"cljs.core.PersistentHashMap.fromArrays([",cljs.compiler.comma_sep.call(null,keys),"],[",cljs.compiler.comma_sep.call(null,vals),"])");

}
}

if(cljs.core._EQ_.call(null,new cljs.core.Keyword(null,"expr","expr",745722291),new cljs.core.Keyword(null,"context","context",-830191113).cljs$core$IFn$_invoke$arity$1(env__24998__auto__))){
return null;
} else {
return cljs.compiler.emitln.call(null,";");
}
}));
cljs.core._add_method.call(null,cljs.compiler.emit_STAR_,new cljs.core.Keyword(null,"list","list",765357683),(function (p__30880){
var map__30881 = p__30880;
var map__30881__$1 = ((((!((map__30881 == null)))?((((map__30881.cljs$lang$protocol_mask$partition0$ & (64))) || (map__30881.cljs$core$ISeq$))?true:false):false))?cljs.core.apply.call(null,cljs.core.hash_map,map__30881):map__30881);
var items = cljs.core.get.call(null,map__30881__$1,new cljs.core.Keyword(null,"items","items",1031954938));
var env = cljs.core.get.call(null,map__30881__$1,new cljs.core.Keyword(null,"env","env",-1815813235));
var env__24998__auto__ = env;
if(cljs.core._EQ_.call(null,new cljs.core.Keyword(null,"return","return",-1891502105),new cljs.core.Keyword(null,"context","context",-830191113).cljs$core$IFn$_invoke$arity$1(env__24998__auto__))){
cljs.compiler.emits.call(null,"return ");
} else {
}

if(cljs.core.empty_QMARK_.call(null,items)){
cljs.compiler.emits.call(null,"cljs.core.List.EMPTY");
} else {
cljs.compiler.emits.call(null,"cljs.core.list(",cljs.compiler.comma_sep.call(null,items),")");
}

if(cljs.core._EQ_.call(null,new cljs.core.Keyword(null,"expr","expr",745722291),new cljs.core.Keyword(null,"context","context",-830191113).cljs$core$IFn$_invoke$arity$1(env__24998__auto__))){
return null;
} else {
return cljs.compiler.emitln.call(null,";");
}
}));
cljs.core._add_method.call(null,cljs.compiler.emit_STAR_,new cljs.core.Keyword(null,"vector","vector",1902966158),(function (p__30883){
var map__30884 = p__30883;
var map__30884__$1 = ((((!((map__30884 == null)))?((((map__30884.cljs$lang$protocol_mask$partition0$ & (64))) || (map__30884.cljs$core$ISeq$))?true:false):false))?cljs.core.apply.call(null,cljs.core.hash_map,map__30884):map__30884);
var items = cljs.core.get.call(null,map__30884__$1,new cljs.core.Keyword(null,"items","items",1031954938));
var env = cljs.core.get.call(null,map__30884__$1,new cljs.core.Keyword(null,"env","env",-1815813235));
var env__24998__auto__ = env;
if(cljs.core._EQ_.call(null,new cljs.core.Keyword(null,"return","return",-1891502105),new cljs.core.Keyword(null,"context","context",-830191113).cljs$core$IFn$_invoke$arity$1(env__24998__auto__))){
cljs.compiler.emits.call(null,"return ");
} else {
}

if(cljs.core.empty_QMARK_.call(null,items)){
cljs.compiler.emits.call(null,"cljs.core.PersistentVector.EMPTY");
} else {
var cnt_30886 = cljs.core.count.call(null,items);
if((cnt_30886 < (32))){
cljs.compiler.emits.call(null,"new cljs.core.PersistentVector(null, ",cnt_30886,", 5, cljs.core.PersistentVector.EMPTY_NODE, [",cljs.compiler.comma_sep.call(null,items),"], null)");
} else {
cljs.compiler.emits.call(null,"cljs.core.PersistentVector.fromArray([",cljs.compiler.comma_sep.call(null,items),"], true)");
}
}

if(cljs.core._EQ_.call(null,new cljs.core.Keyword(null,"expr","expr",745722291),new cljs.core.Keyword(null,"context","context",-830191113).cljs$core$IFn$_invoke$arity$1(env__24998__auto__))){
return null;
} else {
return cljs.compiler.emitln.call(null,";");
}
}));
cljs.compiler.distinct_constants_QMARK_ = (function cljs$compiler$distinct_constants_QMARK_(items){
return (cljs.core.every_QMARK_.call(null,(function (p1__30887_SHARP_){
return cljs.core._EQ_.call(null,new cljs.core.Keyword(null,"op","op",-1882987955).cljs$core$IFn$_invoke$arity$1(p1__30887_SHARP_),new cljs.core.Keyword(null,"constant","constant",-379609303));
}),items)) && (cljs.core._EQ_.call(null,cljs.core.count.call(null,cljs.core.into.call(null,cljs.core.PersistentHashSet.EMPTY,items)),cljs.core.count.call(null,items)));
});
cljs.core._add_method.call(null,cljs.compiler.emit_STAR_,new cljs.core.Keyword(null,"set","set",304602554),(function (p__30888){
var map__30889 = p__30888;
var map__30889__$1 = ((((!((map__30889 == null)))?((((map__30889.cljs$lang$protocol_mask$partition0$ & (64))) || (map__30889.cljs$core$ISeq$))?true:false):false))?cljs.core.apply.call(null,cljs.core.hash_map,map__30889):map__30889);
var items = cljs.core.get.call(null,map__30889__$1,new cljs.core.Keyword(null,"items","items",1031954938));
var env = cljs.core.get.call(null,map__30889__$1,new cljs.core.Keyword(null,"env","env",-1815813235));
var env__24998__auto__ = env;
if(cljs.core._EQ_.call(null,new cljs.core.Keyword(null,"return","return",-1891502105),new cljs.core.Keyword(null,"context","context",-830191113).cljs$core$IFn$_invoke$arity$1(env__24998__auto__))){
cljs.compiler.emits.call(null,"return ");
} else {
}

if(cljs.core.empty_QMARK_.call(null,items)){
cljs.compiler.emits.call(null,"cljs.core.PersistentHashSet.EMPTY");
} else {
if(cljs.core.truth_(cljs.compiler.distinct_constants_QMARK_.call(null,items))){
cljs.compiler.emits.call(null,"new cljs.core.PersistentHashSet(null, new cljs.core.PersistentArrayMap(null, ",cljs.core.count.call(null,items),", [",cljs.compiler.comma_sep.call(null,cljs.core.interleave.call(null,items,cljs.core.repeat.call(null,"null"))),"], null), null)");
} else {
cljs.compiler.emits.call(null,"cljs.core.PersistentHashSet.fromArray([",cljs.compiler.comma_sep.call(null,items),"], true)");

}
}

if(cljs.core._EQ_.call(null,new cljs.core.Keyword(null,"expr","expr",745722291),new cljs.core.Keyword(null,"context","context",-830191113).cljs$core$IFn$_invoke$arity$1(env__24998__auto__))){
return null;
} else {
return cljs.compiler.emitln.call(null,";");
}
}));
cljs.core._add_method.call(null,cljs.compiler.emit_STAR_,new cljs.core.Keyword(null,"js-value","js-value",-758336661),(function (p__30891){
var map__30892 = p__30891;
var map__30892__$1 = ((((!((map__30892 == null)))?((((map__30892.cljs$lang$protocol_mask$partition0$ & (64))) || (map__30892.cljs$core$ISeq$))?true:false):false))?cljs.core.apply.call(null,cljs.core.hash_map,map__30892):map__30892);
var items = cljs.core.get.call(null,map__30892__$1,new cljs.core.Keyword(null,"items","items",1031954938));
var js_type = cljs.core.get.call(null,map__30892__$1,new cljs.core.Keyword(null,"js-type","js-type",539386702));
var env = cljs.core.get.call(null,map__30892__$1,new cljs.core.Keyword(null,"env","env",-1815813235));
var env__24998__auto__ = env;
if(cljs.core._EQ_.call(null,new cljs.core.Keyword(null,"return","return",-1891502105),new cljs.core.Keyword(null,"context","context",-830191113).cljs$core$IFn$_invoke$arity$1(env__24998__auto__))){
cljs.compiler.emits.call(null,"return ");
} else {
}

if(cljs.core._EQ_.call(null,js_type,new cljs.core.Keyword(null,"object","object",1474613949))){
cljs.compiler.emits.call(null,"{");

var temp__4657__auto___30902 = cljs.core.seq.call(null,items);
if(temp__4657__auto___30902){
var items_30903__$1 = temp__4657__auto___30902;
var vec__30894_30904 = items_30903__$1;
var vec__30895_30905 = cljs.core.nth.call(null,vec__30894_30904,(0),null);
var k_30906 = cljs.core.nth.call(null,vec__30895_30905,(0),null);
var v_30907 = cljs.core.nth.call(null,vec__30895_30905,(1),null);
var r_30908 = cljs.core.nthnext.call(null,vec__30894_30904,(1));
cljs.compiler.emits.call(null,"\"",cljs.core.name.call(null,k_30906),"\": ",v_30907);

var seq__30896_30909 = cljs.core.seq.call(null,r_30908);
var chunk__30897_30910 = null;
var count__30898_30911 = (0);
var i__30899_30912 = (0);
while(true){
if((i__30899_30912 < count__30898_30911)){
var vec__30900_30913 = cljs.core._nth.call(null,chunk__30897_30910,i__30899_30912);
var k_30914__$1 = cljs.core.nth.call(null,vec__30900_30913,(0),null);
var v_30915__$1 = cljs.core.nth.call(null,vec__30900_30913,(1),null);
cljs.compiler.emits.call(null,", \"",cljs.core.name.call(null,k_30914__$1),"\": ",v_30915__$1);

var G__30916 = seq__30896_30909;
var G__30917 = chunk__30897_30910;
var G__30918 = count__30898_30911;
var G__30919 = (i__30899_30912 + (1));
seq__30896_30909 = G__30916;
chunk__30897_30910 = G__30917;
count__30898_30911 = G__30918;
i__30899_30912 = G__30919;
continue;
} else {
var temp__4657__auto___30920__$1 = cljs.core.seq.call(null,seq__30896_30909);
if(temp__4657__auto___30920__$1){
var seq__30896_30921__$1 = temp__4657__auto___30920__$1;
if(cljs.core.chunked_seq_QMARK_.call(null,seq__30896_30921__$1)){
var c__23696__auto___30922 = cljs.core.chunk_first.call(null,seq__30896_30921__$1);
var G__30923 = cljs.core.chunk_rest.call(null,seq__30896_30921__$1);
var G__30924 = c__23696__auto___30922;
var G__30925 = cljs.core.count.call(null,c__23696__auto___30922);
var G__30926 = (0);
seq__30896_30909 = G__30923;
chunk__30897_30910 = G__30924;
count__30898_30911 = G__30925;
i__30899_30912 = G__30926;
continue;
} else {
var vec__30901_30927 = cljs.core.first.call(null,seq__30896_30921__$1);
var k_30928__$1 = cljs.core.nth.call(null,vec__30901_30927,(0),null);
var v_30929__$1 = cljs.core.nth.call(null,vec__30901_30927,(1),null);
cljs.compiler.emits.call(null,", \"",cljs.core.name.call(null,k_30928__$1),"\": ",v_30929__$1);

var G__30930 = cljs.core.next.call(null,seq__30896_30921__$1);
var G__30931 = null;
var G__30932 = (0);
var G__30933 = (0);
seq__30896_30909 = G__30930;
chunk__30897_30910 = G__30931;
count__30898_30911 = G__30932;
i__30899_30912 = G__30933;
continue;
}
} else {
}
}
break;
}
} else {
}

cljs.compiler.emits.call(null,"}");
} else {
cljs.compiler.emits.call(null,"[",cljs.compiler.comma_sep.call(null,items),"]");
}

if(cljs.core._EQ_.call(null,new cljs.core.Keyword(null,"expr","expr",745722291),new cljs.core.Keyword(null,"context","context",-830191113).cljs$core$IFn$_invoke$arity$1(env__24998__auto__))){
return null;
} else {
return cljs.compiler.emitln.call(null,";");
}
}));
cljs.core._add_method.call(null,cljs.compiler.emit_STAR_,new cljs.core.Keyword(null,"constant","constant",-379609303),(function (p__30934){
var map__30935 = p__30934;
var map__30935__$1 = ((((!((map__30935 == null)))?((((map__30935.cljs$lang$protocol_mask$partition0$ & (64))) || (map__30935.cljs$core$ISeq$))?true:false):false))?cljs.core.apply.call(null,cljs.core.hash_map,map__30935):map__30935);
var form = cljs.core.get.call(null,map__30935__$1,new cljs.core.Keyword(null,"form","form",-1624062471));
var env = cljs.core.get.call(null,map__30935__$1,new cljs.core.Keyword(null,"env","env",-1815813235));
if(cljs.core._EQ_.call(null,new cljs.core.Keyword(null,"statement","statement",-32780863),new cljs.core.Keyword(null,"context","context",-830191113).cljs$core$IFn$_invoke$arity$1(env))){
return null;
} else {
var env__24998__auto__ = env;
if(cljs.core._EQ_.call(null,new cljs.core.Keyword(null,"return","return",-1891502105),new cljs.core.Keyword(null,"context","context",-830191113).cljs$core$IFn$_invoke$arity$1(env__24998__auto__))){
cljs.compiler.emits.call(null,"return ");
} else {
}

cljs.compiler.emit_constant.call(null,form);

if(cljs.core._EQ_.call(null,new cljs.core.Keyword(null,"expr","expr",745722291),new cljs.core.Keyword(null,"context","context",-830191113).cljs$core$IFn$_invoke$arity$1(env__24998__auto__))){
return null;
} else {
return cljs.compiler.emitln.call(null,";");
}
}
}));
cljs.compiler.truthy_constant_QMARK_ = (function cljs$compiler$truthy_constant_QMARK_(p__30937){
var map__30940 = p__30937;
var map__30940__$1 = ((((!((map__30940 == null)))?((((map__30940.cljs$lang$protocol_mask$partition0$ & (64))) || (map__30940.cljs$core$ISeq$))?true:false):false))?cljs.core.apply.call(null,cljs.core.hash_map,map__30940):map__30940);
var op = cljs.core.get.call(null,map__30940__$1,new cljs.core.Keyword(null,"op","op",-1882987955));
var form = cljs.core.get.call(null,map__30940__$1,new cljs.core.Keyword(null,"form","form",-1624062471));
var and__22873__auto__ = cljs.core._EQ_.call(null,op,new cljs.core.Keyword(null,"constant","constant",-379609303));
if(and__22873__auto__){
var and__22873__auto____$1 = form;
if(cljs.core.truth_(and__22873__auto____$1)){
return !(((typeof form === 'string') && (cljs.core._EQ_.call(null,form,""))) || ((typeof form === 'number') && ((form === (0)))));
} else {
return and__22873__auto____$1;
}
} else {
return and__22873__auto__;
}
});
cljs.compiler.falsey_constant_QMARK_ = (function cljs$compiler$falsey_constant_QMARK_(p__30942){
var map__30945 = p__30942;
var map__30945__$1 = ((((!((map__30945 == null)))?((((map__30945.cljs$lang$protocol_mask$partition0$ & (64))) || (map__30945.cljs$core$ISeq$))?true:false):false))?cljs.core.apply.call(null,cljs.core.hash_map,map__30945):map__30945);
var op = cljs.core.get.call(null,map__30945__$1,new cljs.core.Keyword(null,"op","op",-1882987955));
var form = cljs.core.get.call(null,map__30945__$1,new cljs.core.Keyword(null,"form","form",-1624062471));
return (cljs.core._EQ_.call(null,op,new cljs.core.Keyword(null,"constant","constant",-379609303))) && ((form === false) || ((form == null)));
});
cljs.compiler.safe_test_QMARK_ = (function cljs$compiler$safe_test_QMARK_(env,e){
var tag = cljs.analyzer.infer_tag.call(null,env,e);
var or__22885__auto__ = new cljs.core.PersistentHashSet(null, new cljs.core.PersistentArrayMap(null, 2, [new cljs.core.Symbol(null,"seq","seq",-177272256,null),null,new cljs.core.Symbol(null,"boolean","boolean",-278886877,null),null], null), null).call(null,tag);
if(cljs.core.truth_(or__22885__auto__)){
return or__22885__auto__;
} else {
return cljs.compiler.truthy_constant_QMARK_.call(null,e);
}
});
cljs.core._add_method.call(null,cljs.compiler.emit_STAR_,new cljs.core.Keyword(null,"if","if",-458814265),(function (p__30947){
var map__30948 = p__30947;
var map__30948__$1 = ((((!((map__30948 == null)))?((((map__30948.cljs$lang$protocol_mask$partition0$ & (64))) || (map__30948.cljs$core$ISeq$))?true:false):false))?cljs.core.apply.call(null,cljs.core.hash_map,map__30948):map__30948);
var test = cljs.core.get.call(null,map__30948__$1,new cljs.core.Keyword(null,"test","test",577538877));
var then = cljs.core.get.call(null,map__30948__$1,new cljs.core.Keyword(null,"then","then",460598070));
var else$ = cljs.core.get.call(null,map__30948__$1,new cljs.core.Keyword(null,"else","else",-1508377146));
var env = cljs.core.get.call(null,map__30948__$1,new cljs.core.Keyword(null,"env","env",-1815813235));
var unchecked = cljs.core.get.call(null,map__30948__$1,new cljs.core.Keyword(null,"unchecked","unchecked",924418378));
var context = new cljs.core.Keyword(null,"context","context",-830191113).cljs$core$IFn$_invoke$arity$1(env);
var checked = cljs.core.not.call(null,(function (){var or__22885__auto__ = unchecked;
if(cljs.core.truth_(or__22885__auto__)){
return or__22885__auto__;
} else {
return cljs.compiler.safe_test_QMARK_.call(null,env,test);
}
})());
if(cljs.core.truth_(cljs.compiler.truthy_constant_QMARK_.call(null,test))){
return cljs.compiler.emitln.call(null,then);
} else {
if(cljs.core.truth_(cljs.compiler.falsey_constant_QMARK_.call(null,test))){
return cljs.compiler.emitln.call(null,else$);
} else {
if(cljs.core._EQ_.call(null,new cljs.core.Keyword(null,"expr","expr",745722291),context)){
return cljs.compiler.emits.call(null,"(",((checked)?"cljs.core.truth_":null),"(",test,")?",then,":",else$,")");
} else {
if(checked){
cljs.compiler.emitln.call(null,"if(cljs.core.truth_(",test,")){");
} else {
cljs.compiler.emitln.call(null,"if(",test,"){");
}

cljs.compiler.emitln.call(null,then,"} else {");

return cljs.compiler.emitln.call(null,else$,"}");
}

}
}
}));
cljs.core._add_method.call(null,cljs.compiler.emit_STAR_,new cljs.core.Keyword(null,"case*","case*",716180697),(function (p__30950){
var map__30951 = p__30950;
var map__30951__$1 = ((((!((map__30951 == null)))?((((map__30951.cljs$lang$protocol_mask$partition0$ & (64))) || (map__30951.cljs$core$ISeq$))?true:false):false))?cljs.core.apply.call(null,cljs.core.hash_map,map__30951):map__30951);
var v = cljs.core.get.call(null,map__30951__$1,new cljs.core.Keyword(null,"v","v",21465059));
var tests = cljs.core.get.call(null,map__30951__$1,new cljs.core.Keyword(null,"tests","tests",-1041085625));
var thens = cljs.core.get.call(null,map__30951__$1,new cljs.core.Keyword(null,"thens","thens",226631442));
var default$ = cljs.core.get.call(null,map__30951__$1,new cljs.core.Keyword(null,"default","default",-1987822328));
var env = cljs.core.get.call(null,map__30951__$1,new cljs.core.Keyword(null,"env","env",-1815813235));
if(cljs.core._EQ_.call(null,new cljs.core.Keyword(null,"context","context",-830191113).cljs$core$IFn$_invoke$arity$1(env),new cljs.core.Keyword(null,"expr","expr",745722291))){
cljs.compiler.emitln.call(null,"(function(){");
} else {
}

var gs = cljs.core.gensym.call(null,"caseval__");
if(cljs.core._EQ_.call(null,new cljs.core.Keyword(null,"expr","expr",745722291),new cljs.core.Keyword(null,"context","context",-830191113).cljs$core$IFn$_invoke$arity$1(env))){
cljs.compiler.emitln.call(null,"var ",gs,";");
} else {
}

cljs.compiler.emitln.call(null,"switch (",v,") {");

var seq__30953_30967 = cljs.core.seq.call(null,cljs.core.partition.call(null,(2),cljs.core.interleave.call(null,tests,thens)));
var chunk__30954_30968 = null;
var count__30955_30969 = (0);
var i__30956_30970 = (0);
while(true){
if((i__30956_30970 < count__30955_30969)){
var vec__30957_30971 = cljs.core._nth.call(null,chunk__30954_30968,i__30956_30970);
var ts_30972 = cljs.core.nth.call(null,vec__30957_30971,(0),null);
var then_30973 = cljs.core.nth.call(null,vec__30957_30971,(1),null);
var seq__30958_30974 = cljs.core.seq.call(null,ts_30972);
var chunk__30959_30975 = null;
var count__30960_30976 = (0);
var i__30961_30977 = (0);
while(true){
if((i__30961_30977 < count__30960_30976)){
var test_30978 = cljs.core._nth.call(null,chunk__30959_30975,i__30961_30977);
cljs.compiler.emitln.call(null,"case ",test_30978,":");

var G__30979 = seq__30958_30974;
var G__30980 = chunk__30959_30975;
var G__30981 = count__30960_30976;
var G__30982 = (i__30961_30977 + (1));
seq__30958_30974 = G__30979;
chunk__30959_30975 = G__30980;
count__30960_30976 = G__30981;
i__30961_30977 = G__30982;
continue;
} else {
var temp__4657__auto___30983 = cljs.core.seq.call(null,seq__30958_30974);
if(temp__4657__auto___30983){
var seq__30958_30984__$1 = temp__4657__auto___30983;
if(cljs.core.chunked_seq_QMARK_.call(null,seq__30958_30984__$1)){
var c__23696__auto___30985 = cljs.core.chunk_first.call(null,seq__30958_30984__$1);
var G__30986 = cljs.core.chunk_rest.call(null,seq__30958_30984__$1);
var G__30987 = c__23696__auto___30985;
var G__30988 = cljs.core.count.call(null,c__23696__auto___30985);
var G__30989 = (0);
seq__30958_30974 = G__30986;
chunk__30959_30975 = G__30987;
count__30960_30976 = G__30988;
i__30961_30977 = G__30989;
continue;
} else {
var test_30990 = cljs.core.first.call(null,seq__30958_30984__$1);
cljs.compiler.emitln.call(null,"case ",test_30990,":");

var G__30991 = cljs.core.next.call(null,seq__30958_30984__$1);
var G__30992 = null;
var G__30993 = (0);
var G__30994 = (0);
seq__30958_30974 = G__30991;
chunk__30959_30975 = G__30992;
count__30960_30976 = G__30993;
i__30961_30977 = G__30994;
continue;
}
} else {
}
}
break;
}

if(cljs.core._EQ_.call(null,new cljs.core.Keyword(null,"expr","expr",745722291),new cljs.core.Keyword(null,"context","context",-830191113).cljs$core$IFn$_invoke$arity$1(env))){
cljs.compiler.emitln.call(null,gs,"=",then_30973);
} else {
cljs.compiler.emitln.call(null,then_30973);
}

cljs.compiler.emitln.call(null,"break;");

var G__30995 = seq__30953_30967;
var G__30996 = chunk__30954_30968;
var G__30997 = count__30955_30969;
var G__30998 = (i__30956_30970 + (1));
seq__30953_30967 = G__30995;
chunk__30954_30968 = G__30996;
count__30955_30969 = G__30997;
i__30956_30970 = G__30998;
continue;
} else {
var temp__4657__auto___30999 = cljs.core.seq.call(null,seq__30953_30967);
if(temp__4657__auto___30999){
var seq__30953_31000__$1 = temp__4657__auto___30999;
if(cljs.core.chunked_seq_QMARK_.call(null,seq__30953_31000__$1)){
var c__23696__auto___31001 = cljs.core.chunk_first.call(null,seq__30953_31000__$1);
var G__31002 = cljs.core.chunk_rest.call(null,seq__30953_31000__$1);
var G__31003 = c__23696__auto___31001;
var G__31004 = cljs.core.count.call(null,c__23696__auto___31001);
var G__31005 = (0);
seq__30953_30967 = G__31002;
chunk__30954_30968 = G__31003;
count__30955_30969 = G__31004;
i__30956_30970 = G__31005;
continue;
} else {
var vec__30962_31006 = cljs.core.first.call(null,seq__30953_31000__$1);
var ts_31007 = cljs.core.nth.call(null,vec__30962_31006,(0),null);
var then_31008 = cljs.core.nth.call(null,vec__30962_31006,(1),null);
var seq__30963_31009 = cljs.core.seq.call(null,ts_31007);
var chunk__30964_31010 = null;
var count__30965_31011 = (0);
var i__30966_31012 = (0);
while(true){
if((i__30966_31012 < count__30965_31011)){
var test_31013 = cljs.core._nth.call(null,chunk__30964_31010,i__30966_31012);
cljs.compiler.emitln.call(null,"case ",test_31013,":");

var G__31014 = seq__30963_31009;
var G__31015 = chunk__30964_31010;
var G__31016 = count__30965_31011;
var G__31017 = (i__30966_31012 + (1));
seq__30963_31009 = G__31014;
chunk__30964_31010 = G__31015;
count__30965_31011 = G__31016;
i__30966_31012 = G__31017;
continue;
} else {
var temp__4657__auto___31018__$1 = cljs.core.seq.call(null,seq__30963_31009);
if(temp__4657__auto___31018__$1){
var seq__30963_31019__$1 = temp__4657__auto___31018__$1;
if(cljs.core.chunked_seq_QMARK_.call(null,seq__30963_31019__$1)){
var c__23696__auto___31020 = cljs.core.chunk_first.call(null,seq__30963_31019__$1);
var G__31021 = cljs.core.chunk_rest.call(null,seq__30963_31019__$1);
var G__31022 = c__23696__auto___31020;
var G__31023 = cljs.core.count.call(null,c__23696__auto___31020);
var G__31024 = (0);
seq__30963_31009 = G__31021;
chunk__30964_31010 = G__31022;
count__30965_31011 = G__31023;
i__30966_31012 = G__31024;
continue;
} else {
var test_31025 = cljs.core.first.call(null,seq__30963_31019__$1);
cljs.compiler.emitln.call(null,"case ",test_31025,":");

var G__31026 = cljs.core.next.call(null,seq__30963_31019__$1);
var G__31027 = null;
var G__31028 = (0);
var G__31029 = (0);
seq__30963_31009 = G__31026;
chunk__30964_31010 = G__31027;
count__30965_31011 = G__31028;
i__30966_31012 = G__31029;
continue;
}
} else {
}
}
break;
}

if(cljs.core._EQ_.call(null,new cljs.core.Keyword(null,"expr","expr",745722291),new cljs.core.Keyword(null,"context","context",-830191113).cljs$core$IFn$_invoke$arity$1(env))){
cljs.compiler.emitln.call(null,gs,"=",then_31008);
} else {
cljs.compiler.emitln.call(null,then_31008);
}

cljs.compiler.emitln.call(null,"break;");

var G__31030 = cljs.core.next.call(null,seq__30953_31000__$1);
var G__31031 = null;
var G__31032 = (0);
var G__31033 = (0);
seq__30953_30967 = G__31030;
chunk__30954_30968 = G__31031;
count__30955_30969 = G__31032;
i__30956_30970 = G__31033;
continue;
}
} else {
}
}
break;
}

if(cljs.core.truth_(default$)){
cljs.compiler.emitln.call(null,"default:");

if(cljs.core._EQ_.call(null,new cljs.core.Keyword(null,"expr","expr",745722291),new cljs.core.Keyword(null,"context","context",-830191113).cljs$core$IFn$_invoke$arity$1(env))){
cljs.compiler.emitln.call(null,gs,"=",default$);
} else {
cljs.compiler.emitln.call(null,default$);
}
} else {
}

cljs.compiler.emitln.call(null,"}");

if(cljs.core._EQ_.call(null,new cljs.core.Keyword(null,"expr","expr",745722291),new cljs.core.Keyword(null,"context","context",-830191113).cljs$core$IFn$_invoke$arity$1(env))){
return cljs.compiler.emitln.call(null,"return ",gs,";})()");
} else {
return null;
}
}));
cljs.core._add_method.call(null,cljs.compiler.emit_STAR_,new cljs.core.Keyword(null,"throw","throw",-1044625833),(function (p__31034){
var map__31035 = p__31034;
var map__31035__$1 = ((((!((map__31035 == null)))?((((map__31035.cljs$lang$protocol_mask$partition0$ & (64))) || (map__31035.cljs$core$ISeq$))?true:false):false))?cljs.core.apply.call(null,cljs.core.hash_map,map__31035):map__31035);
var throw$ = cljs.core.get.call(null,map__31035__$1,new cljs.core.Keyword(null,"throw","throw",-1044625833));
var env = cljs.core.get.call(null,map__31035__$1,new cljs.core.Keyword(null,"env","env",-1815813235));
if(cljs.core._EQ_.call(null,new cljs.core.Keyword(null,"expr","expr",745722291),new cljs.core.Keyword(null,"context","context",-830191113).cljs$core$IFn$_invoke$arity$1(env))){
return cljs.compiler.emits.call(null,"(function(){throw ",throw$,"})()");
} else {
return cljs.compiler.emitln.call(null,"throw ",throw$,";");
}
}));
cljs.compiler.base_types = new cljs.core.PersistentHashSet(null, new cljs.core.PersistentArrayMap(null, 15, ["boolean",null,"object",null,"*",null,"string",null,"Object",null,"Number",null,"null",null,"Date",null,"number",null,"String",null,"RegExp",null,"...*",null,"Array",null,"array",null,"Boolean",null], null), null);
cljs.compiler.mapped_types = new cljs.core.PersistentArrayMap(null, 1, ["nil","null"], null);
cljs.compiler.resolve_type = (function cljs$compiler$resolve_type(env,t){
if(cljs.core.truth_(cljs.core.get.call(null,cljs.compiler.base_types,t))){
return t;
} else {
if(cljs.core.truth_(cljs.core.get.call(null,cljs.compiler.mapped_types,t))){
return cljs.core.get.call(null,cljs.compiler.mapped_types,t);
} else {
if(cljs.core.truth_(goog.string.startsWith(t,"!"))){
return [cljs.core.str("!"),cljs.core.str(cljs$compiler$resolve_type.call(null,env,cljs.core.subs.call(null,t,(1))))].join('');
} else {
if(cljs.core.truth_(goog.string.startsWith(t,"{"))){
return t;
} else {
if(cljs.core.truth_(goog.string.startsWith(t,"function"))){
var idx = t.lastIndexOf(":");
var vec__31040 = ((!(((-1) === idx)))?new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.subs.call(null,t,(0),idx),cljs.core.subs.call(null,t,(idx + (1)),cljs.core.count.call(null,t))], null):new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [t,null], null));
var fstr = cljs.core.nth.call(null,vec__31040,(0),null);
var rstr = cljs.core.nth.call(null,vec__31040,(1),null);
var ret_t = (cljs.core.truth_(rstr)?cljs$compiler$resolve_type.call(null,env,rstr):null);
var axstr = cljs.core.subs.call(null,fstr,(9),(cljs.core.count.call(null,fstr) - (1)));
var args_ts = ((clojure.string.blank_QMARK_.call(null,axstr))?null:cljs.core.map.call(null,cljs.core.comp.call(null,((function (idx,vec__31040,fstr,rstr,ret_t,axstr){
return (function (p1__31037_SHARP_){
return cljs$compiler$resolve_type.call(null,env,p1__31037_SHARP_);
});})(idx,vec__31040,fstr,rstr,ret_t,axstr))
,clojure.string.trim),clojure.string.split.call(null,axstr,/,/)));
var G__31041 = [cljs.core.str("function("),cljs.core.str(clojure.string.join.call(null,",",args_ts)),cljs.core.str(")")].join('');
if(cljs.core.truth_(ret_t)){
return [cljs.core.str(G__31041),cljs.core.str(":"),cljs.core.str(ret_t)].join('');
} else {
return G__31041;
}
} else {
if(cljs.core.truth_(goog.string.endsWith(t,"="))){
return [cljs.core.str(cljs$compiler$resolve_type.call(null,env,cljs.core.subs.call(null,t,(0),(cljs.core.count.call(null,t) - (1))))),cljs.core.str("=")].join('');
} else {
return cljs.compiler.munge.call(null,[cljs.core.str(new cljs.core.Keyword(null,"name","name",1843675177).cljs$core$IFn$_invoke$arity$1(cljs.analyzer.resolve_var.call(null,env,cljs.core.symbol.call(null,t))))].join(''));

}
}
}
}
}
}
});
cljs.compiler.resolve_types = (function cljs$compiler$resolve_types(env,ts){
var ts__$1 = cljs.core.subs.call(null,clojure.string.trim.call(null,ts),(1),(cljs.core.count.call(null,ts) - (1)));
var xs = clojure.string.split.call(null,ts__$1,/\|/);
return [cljs.core.str("{"),cljs.core.str(clojure.string.join.call(null,"|",cljs.core.map.call(null,((function (ts__$1,xs){
return (function (p1__31042_SHARP_){
return cljs.compiler.resolve_type.call(null,env,p1__31042_SHARP_);
});})(ts__$1,xs))
,xs))),cljs.core.str("}")].join('');
});
cljs.compiler.munge_param_return = (function cljs$compiler$munge_param_return(env,line){
if(cljs.core.truth_(cljs.core.re_find.call(null,/@param/,line))){
var vec__31045 = cljs.core.map.call(null,clojure.string.trim,clojure.string.split.call(null,clojure.string.trim.call(null,line),/ /));
var p = cljs.core.nth.call(null,vec__31045,(0),null);
var ts = cljs.core.nth.call(null,vec__31045,(1),null);
var n = cljs.core.nth.call(null,vec__31045,(2),null);
var xs = cljs.core.nthnext.call(null,vec__31045,(3));
if(cljs.core.truth_((function (){var and__22873__auto__ = cljs.core._EQ_.call(null,"@param",p);
if(and__22873__auto__){
var and__22873__auto____$1 = ts;
if(cljs.core.truth_(and__22873__auto____$1)){
return goog.string.startsWith(ts,"{");
} else {
return and__22873__auto____$1;
}
} else {
return and__22873__auto__;
}
})())){
return clojure.string.join.call(null," ",cljs.core.concat.call(null,new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [p,cljs.compiler.resolve_types.call(null,env,ts),cljs.compiler.munge.call(null,n)], null),xs));
} else {
return line;
}
} else {
if(cljs.core.truth_(cljs.core.re_find.call(null,/@return/,line))){
var vec__31046 = cljs.core.map.call(null,clojure.string.trim,clojure.string.split.call(null,clojure.string.trim.call(null,line),/ /));
var p = cljs.core.nth.call(null,vec__31046,(0),null);
var ts = cljs.core.nth.call(null,vec__31046,(1),null);
var xs = cljs.core.nthnext.call(null,vec__31046,(2));
if(cljs.core.truth_((function (){var and__22873__auto__ = cljs.core._EQ_.call(null,"@return",p);
if(and__22873__auto__){
var and__22873__auto____$1 = ts;
if(cljs.core.truth_(and__22873__auto____$1)){
return goog.string.startsWith(ts,"{");
} else {
return and__22873__auto____$1;
}
} else {
return and__22873__auto__;
}
})())){
return clojure.string.join.call(null," ",cljs.core.concat.call(null,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [p,cljs.compiler.resolve_types.call(null,env,ts)], null),xs));
} else {
return line;
}
} else {
return line;

}
}
});
cljs.compiler.checking_types_QMARK_ = (function cljs$compiler$checking_types_QMARK_(){
return new cljs.core.PersistentHashSet(null, new cljs.core.PersistentArrayMap(null, 2, [new cljs.core.Keyword(null,"warn","warn",-436710552),null,new cljs.core.Keyword(null,"error","error",-978969032),null], null), null).call(null,cljs.core.get_in.call(null,cljs.core.deref.call(null,cljs.env._STAR_compiler_STAR_),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword(null,"options","options",99638489),new cljs.core.Keyword(null,"closure-warnings","closure-warnings",1362834211),new cljs.core.Keyword(null,"check-types","check-types",-833794607)], null)));
});
/**
 * Emit a nicely formatted comment string.
 */
cljs.compiler.emit_comment = (function cljs$compiler$emit_comment(var_args){
var args31048 = [];
var len__23955__auto___31075 = arguments.length;
var i__23956__auto___31076 = (0);
while(true){
if((i__23956__auto___31076 < len__23955__auto___31075)){
args31048.push((arguments[i__23956__auto___31076]));

var G__31077 = (i__23956__auto___31076 + (1));
i__23956__auto___31076 = G__31077;
continue;
} else {
}
break;
}

var G__31050 = args31048.length;
switch (G__31050) {
case 2:
return cljs.compiler.emit_comment.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.compiler.emit_comment.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error([cljs.core.str("Invalid arity: "),cljs.core.str(args31048.length)].join('')));

}
});

cljs.compiler.emit_comment.cljs$core$IFn$_invoke$arity$2 = (function (doc,jsdoc){
return cljs.compiler.emit_comment.call(null,null,doc,jsdoc);
});

cljs.compiler.emit_comment.cljs$core$IFn$_invoke$arity$3 = (function (env,doc,jsdoc){
var docs = (cljs.core.truth_(doc)?new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [doc], null):null);
var docs__$1 = (cljs.core.truth_(jsdoc)?cljs.core.concat.call(null,docs,jsdoc):docs);
var docs__$2 = cljs.core.remove.call(null,cljs.core.nil_QMARK_,docs__$1);
var print_comment_lines = ((function (docs,docs__$1,docs__$2){
return (function cljs$compiler$print_comment_lines(e){
var vec__31066 = cljs.core.map.call(null,((function (docs,docs__$1,docs__$2){
return (function (p1__31047_SHARP_){
if(cljs.core.truth_(cljs.compiler.checking_types_QMARK_.call(null))){
return cljs.compiler.munge_param_return.call(null,env,p1__31047_SHARP_);
} else {
return p1__31047_SHARP_;
}
});})(docs,docs__$1,docs__$2))
,clojure.string.split_lines.call(null,e));
var x = cljs.core.nth.call(null,vec__31066,(0),null);
var ys = cljs.core.nthnext.call(null,vec__31066,(1));
cljs.compiler.emitln.call(null," * ",clojure.string.replace.call(null,x,"*/","* /"));

var seq__31067 = cljs.core.seq.call(null,ys);
var chunk__31068 = null;
var count__31069 = (0);
var i__31070 = (0);
while(true){
if((i__31070 < count__31069)){
var next_line = cljs.core._nth.call(null,chunk__31068,i__31070);
cljs.compiler.emitln.call(null," * ",clojure.string.replace.call(null,clojure.string.replace.call(null,next_line,/^   /,""),"*/","* /"));

var G__31079 = seq__31067;
var G__31080 = chunk__31068;
var G__31081 = count__31069;
var G__31082 = (i__31070 + (1));
seq__31067 = G__31079;
chunk__31068 = G__31080;
count__31069 = G__31081;
i__31070 = G__31082;
continue;
} else {
var temp__4657__auto__ = cljs.core.seq.call(null,seq__31067);
if(temp__4657__auto__){
var seq__31067__$1 = temp__4657__auto__;
if(cljs.core.chunked_seq_QMARK_.call(null,seq__31067__$1)){
var c__23696__auto__ = cljs.core.chunk_first.call(null,seq__31067__$1);
var G__31083 = cljs.core.chunk_rest.call(null,seq__31067__$1);
var G__31084 = c__23696__auto__;
var G__31085 = cljs.core.count.call(null,c__23696__auto__);
var G__31086 = (0);
seq__31067 = G__31083;
chunk__31068 = G__31084;
count__31069 = G__31085;
i__31070 = G__31086;
continue;
} else {
var next_line = cljs.core.first.call(null,seq__31067__$1);
cljs.compiler.emitln.call(null," * ",clojure.string.replace.call(null,clojure.string.replace.call(null,next_line,/^   /,""),"*/","* /"));

var G__31087 = cljs.core.next.call(null,seq__31067__$1);
var G__31088 = null;
var G__31089 = (0);
var G__31090 = (0);
seq__31067 = G__31087;
chunk__31068 = G__31088;
count__31069 = G__31089;
i__31070 = G__31090;
continue;
}
} else {
return null;
}
}
break;
}
});})(docs,docs__$1,docs__$2))
;
if(cljs.core.seq.call(null,docs__$2)){
cljs.compiler.emitln.call(null,"/**");

var seq__31071_31091 = cljs.core.seq.call(null,docs__$2);
var chunk__31072_31092 = null;
var count__31073_31093 = (0);
var i__31074_31094 = (0);
while(true){
if((i__31074_31094 < count__31073_31093)){
var e_31095 = cljs.core._nth.call(null,chunk__31072_31092,i__31074_31094);
if(cljs.core.truth_(e_31095)){
print_comment_lines.call(null,e_31095);
} else {
}

var G__31096 = seq__31071_31091;
var G__31097 = chunk__31072_31092;
var G__31098 = count__31073_31093;
var G__31099 = (i__31074_31094 + (1));
seq__31071_31091 = G__31096;
chunk__31072_31092 = G__31097;
count__31073_31093 = G__31098;
i__31074_31094 = G__31099;
continue;
} else {
var temp__4657__auto___31100 = cljs.core.seq.call(null,seq__31071_31091);
if(temp__4657__auto___31100){
var seq__31071_31101__$1 = temp__4657__auto___31100;
if(cljs.core.chunked_seq_QMARK_.call(null,seq__31071_31101__$1)){
var c__23696__auto___31102 = cljs.core.chunk_first.call(null,seq__31071_31101__$1);
var G__31103 = cljs.core.chunk_rest.call(null,seq__31071_31101__$1);
var G__31104 = c__23696__auto___31102;
var G__31105 = cljs.core.count.call(null,c__23696__auto___31102);
var G__31106 = (0);
seq__31071_31091 = G__31103;
chunk__31072_31092 = G__31104;
count__31073_31093 = G__31105;
i__31074_31094 = G__31106;
continue;
} else {
var e_31107 = cljs.core.first.call(null,seq__31071_31101__$1);
if(cljs.core.truth_(e_31107)){
print_comment_lines.call(null,e_31107);
} else {
}

var G__31108 = cljs.core.next.call(null,seq__31071_31101__$1);
var G__31109 = null;
var G__31110 = (0);
var G__31111 = (0);
seq__31071_31091 = G__31108;
chunk__31072_31092 = G__31109;
count__31073_31093 = G__31110;
i__31074_31094 = G__31111;
continue;
}
} else {
}
}
break;
}

return cljs.compiler.emitln.call(null," */");
} else {
return null;
}
});

cljs.compiler.emit_comment.cljs$lang$maxFixedArity = 3;
cljs.compiler.valid_define_value_QMARK_ = (function cljs$compiler$valid_define_value_QMARK_(x){
return (typeof x === 'string') || (x === true) || (x === false) || (typeof x === 'number');
});
cljs.compiler.get_define = (function cljs$compiler$get_define(mname,jsdoc){
var opts = cljs.core.get.call(null,cljs.core.deref.call(null,cljs.env._STAR_compiler_STAR_),new cljs.core.Keyword(null,"options","options",99638489));
var and__22873__auto__ = cljs.core.some.call(null,((function (opts){
return (function (p1__31113_SHARP_){
return goog.string.startsWith(p1__31113_SHARP_,"@define");
});})(opts))
,jsdoc);
if(cljs.core.truth_(and__22873__auto__)){
var and__22873__auto____$1 = opts;
if(cljs.core.truth_(and__22873__auto____$1)){
var and__22873__auto____$2 = cljs.core._EQ_.call(null,new cljs.core.Keyword(null,"optimizations","optimizations",-2047476854).cljs$core$IFn$_invoke$arity$1(opts),new cljs.core.Keyword(null,"none","none",1333468478));
if(and__22873__auto____$2){
var define = cljs.core.get_in.call(null,opts,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword(null,"closure-defines","closure-defines",-1213856476),[cljs.core.str(mname)].join('')], null));
if(cljs.core.truth_(cljs.compiler.valid_define_value_QMARK_.call(null,define))){
return cljs.core.pr_str.call(null,define);
} else {
return null;
}
} else {
return and__22873__auto____$2;
}
} else {
return and__22873__auto____$1;
}
} else {
return and__22873__auto__;
}
});
cljs.core._add_method.call(null,cljs.compiler.emit_STAR_,new cljs.core.Keyword(null,"def","def",-1043430536),(function (p__31114){
var map__31115 = p__31114;
var map__31115__$1 = ((((!((map__31115 == null)))?((((map__31115.cljs$lang$protocol_mask$partition0$ & (64))) || (map__31115.cljs$core$ISeq$))?true:false):false))?cljs.core.apply.call(null,cljs.core.hash_map,map__31115):map__31115);
var name = cljs.core.get.call(null,map__31115__$1,new cljs.core.Keyword(null,"name","name",1843675177));
var var$ = cljs.core.get.call(null,map__31115__$1,new cljs.core.Keyword(null,"var","var",-769682797));
var init = cljs.core.get.call(null,map__31115__$1,new cljs.core.Keyword(null,"init","init",-1875481434));
var env = cljs.core.get.call(null,map__31115__$1,new cljs.core.Keyword(null,"env","env",-1815813235));
var doc = cljs.core.get.call(null,map__31115__$1,new cljs.core.Keyword(null,"doc","doc",1913296891));
var jsdoc = cljs.core.get.call(null,map__31115__$1,new cljs.core.Keyword(null,"jsdoc","jsdoc",1745183516));
var export$ = cljs.core.get.call(null,map__31115__$1,new cljs.core.Keyword(null,"export","export",214356590));
var test = cljs.core.get.call(null,map__31115__$1,new cljs.core.Keyword(null,"test","test",577538877));
var var_ast = cljs.core.get.call(null,map__31115__$1,new cljs.core.Keyword(null,"var-ast","var-ast",1200379319));
if(cljs.core.truth_((function (){var or__22885__auto__ = init;
if(cljs.core.truth_(or__22885__auto__)){
return or__22885__auto__;
} else {
return new cljs.core.Keyword(null,"def-emits-var","def-emits-var",-1551927320).cljs$core$IFn$_invoke$arity$1(env);
}
})())){
var mname = cljs.compiler.munge.call(null,name);
cljs.compiler.emit_comment.call(null,env,doc,cljs.core.concat.call(null,jsdoc,new cljs.core.Keyword(null,"jsdoc","jsdoc",1745183516).cljs$core$IFn$_invoke$arity$1(init)));

if(cljs.core.truth_(new cljs.core.Keyword(null,"def-emits-var","def-emits-var",-1551927320).cljs$core$IFn$_invoke$arity$1(env))){
if(cljs.core._EQ_.call(null,new cljs.core.Keyword(null,"return","return",-1891502105),new cljs.core.Keyword(null,"context","context",-830191113).cljs$core$IFn$_invoke$arity$1(env))){
cljs.compiler.emitln.call(null,"return (");
} else {
}

cljs.compiler.emitln.call(null,"(function (){");
} else {
}

cljs.compiler.emits.call(null,var$);

if(cljs.core.truth_(init)){
cljs.compiler.emits.call(null," = ",(function (){var temp__4655__auto__ = cljs.compiler.get_define.call(null,mname,jsdoc);
if(cljs.core.truth_(temp__4655__auto__)){
var define = temp__4655__auto__;
return define;
} else {
return init;
}
})());
} else {
}

if(cljs.core.truth_(new cljs.core.Keyword(null,"def-emits-var","def-emits-var",-1551927320).cljs$core$IFn$_invoke$arity$1(env))){
cljs.compiler.emitln.call(null,"; return (");

cljs.compiler.emits.call(null,cljs.core.merge.call(null,new cljs.core.PersistentArrayMap(null, 2, [new cljs.core.Keyword(null,"op","op",-1882987955),new cljs.core.Keyword(null,"var-special","var-special",1131576802),new cljs.core.Keyword(null,"env","env",-1815813235),cljs.core.assoc.call(null,env,new cljs.core.Keyword(null,"context","context",-830191113),new cljs.core.Keyword(null,"expr","expr",745722291))], null),var_ast));

cljs.compiler.emitln.call(null,");})()");

if(cljs.core._EQ_.call(null,new cljs.core.Keyword(null,"return","return",-1891502105),new cljs.core.Keyword(null,"context","context",-830191113).cljs$core$IFn$_invoke$arity$1(env))){
cljs.compiler.emitln.call(null,")");
} else {
}
} else {
}

if(cljs.core._EQ_.call(null,new cljs.core.Keyword(null,"expr","expr",745722291),new cljs.core.Keyword(null,"context","context",-830191113).cljs$core$IFn$_invoke$arity$1(env))){
} else {
cljs.compiler.emitln.call(null,";");
}

if(cljs.core.truth_(export$)){
cljs.compiler.emitln.call(null,"goog.exportSymbol('",cljs.compiler.munge.call(null,export$),"', ",mname,");");
} else {
}

if(cljs.core.truth_((function (){var and__22873__auto__ = cljs.analyzer._STAR_load_tests_STAR_;
if(cljs.core.truth_(and__22873__auto__)){
return test;
} else {
return and__22873__auto__;
}
})())){
if(cljs.core._EQ_.call(null,new cljs.core.Keyword(null,"expr","expr",745722291),new cljs.core.Keyword(null,"context","context",-830191113).cljs$core$IFn$_invoke$arity$1(env))){
cljs.compiler.emitln.call(null,";");
} else {
}

return cljs.compiler.emitln.call(null,var$,".cljs$lang$test = ",test,";");
} else {
return null;
}
} else {
return null;
}
}));
cljs.compiler.emit_apply_to = (function cljs$compiler$emit_apply_to(p__31117){
var map__31134 = p__31117;
var map__31134__$1 = ((((!((map__31134 == null)))?((((map__31134.cljs$lang$protocol_mask$partition0$ & (64))) || (map__31134.cljs$core$ISeq$))?true:false):false))?cljs.core.apply.call(null,cljs.core.hash_map,map__31134):map__31134);
var name = cljs.core.get.call(null,map__31134__$1,new cljs.core.Keyword(null,"name","name",1843675177));
var params = cljs.core.get.call(null,map__31134__$1,new cljs.core.Keyword(null,"params","params",710516235));
var env = cljs.core.get.call(null,map__31134__$1,new cljs.core.Keyword(null,"env","env",-1815813235));
var arglist = cljs.core.gensym.call(null,"arglist__");
var delegate_name = [cljs.core.str(cljs.compiler.munge.call(null,name)),cljs.core.str("__delegate")].join('');
cljs.compiler.emitln.call(null,"(function (",arglist,"){");

var seq__31136_31150 = cljs.core.seq.call(null,cljs.core.map_indexed.call(null,cljs.core.vector,cljs.core.drop_last.call(null,(2),params)));
var chunk__31137_31151 = null;
var count__31138_31152 = (0);
var i__31139_31153 = (0);
while(true){
if((i__31139_31153 < count__31138_31152)){
var vec__31140_31154 = cljs.core._nth.call(null,chunk__31137_31151,i__31139_31153);
var i_31155 = cljs.core.nth.call(null,vec__31140_31154,(0),null);
var param_31156 = cljs.core.nth.call(null,vec__31140_31154,(1),null);
cljs.compiler.emits.call(null,"var ");

cljs.compiler.emit.call(null,param_31156);

cljs.compiler.emits.call(null," = cljs.core.first(");

cljs.compiler.emitln.call(null,arglist,");");

cljs.compiler.emitln.call(null,arglist," = cljs.core.next(",arglist,");");

var G__31157 = seq__31136_31150;
var G__31158 = chunk__31137_31151;
var G__31159 = count__31138_31152;
var G__31160 = (i__31139_31153 + (1));
seq__31136_31150 = G__31157;
chunk__31137_31151 = G__31158;
count__31138_31152 = G__31159;
i__31139_31153 = G__31160;
continue;
} else {
var temp__4657__auto___31161 = cljs.core.seq.call(null,seq__31136_31150);
if(temp__4657__auto___31161){
var seq__31136_31162__$1 = temp__4657__auto___31161;
if(cljs.core.chunked_seq_QMARK_.call(null,seq__31136_31162__$1)){
var c__23696__auto___31163 = cljs.core.chunk_first.call(null,seq__31136_31162__$1);
var G__31164 = cljs.core.chunk_rest.call(null,seq__31136_31162__$1);
var G__31165 = c__23696__auto___31163;
var G__31166 = cljs.core.count.call(null,c__23696__auto___31163);
var G__31167 = (0);
seq__31136_31150 = G__31164;
chunk__31137_31151 = G__31165;
count__31138_31152 = G__31166;
i__31139_31153 = G__31167;
continue;
} else {
var vec__31141_31168 = cljs.core.first.call(null,seq__31136_31162__$1);
var i_31169 = cljs.core.nth.call(null,vec__31141_31168,(0),null);
var param_31170 = cljs.core.nth.call(null,vec__31141_31168,(1),null);
cljs.compiler.emits.call(null,"var ");

cljs.compiler.emit.call(null,param_31170);

cljs.compiler.emits.call(null," = cljs.core.first(");

cljs.compiler.emitln.call(null,arglist,");");

cljs.compiler.emitln.call(null,arglist," = cljs.core.next(",arglist,");");

var G__31171 = cljs.core.next.call(null,seq__31136_31162__$1);
var G__31172 = null;
var G__31173 = (0);
var G__31174 = (0);
seq__31136_31150 = G__31171;
chunk__31137_31151 = G__31172;
count__31138_31152 = G__31173;
i__31139_31153 = G__31174;
continue;
}
} else {
}
}
break;
}

if(((1) < cljs.core.count.call(null,params))){
cljs.compiler.emits.call(null,"var ");

cljs.compiler.emit.call(null,cljs.core.last.call(null,cljs.core.butlast.call(null,params)));

cljs.compiler.emitln.call(null," = cljs.core.first(",arglist,");");

cljs.compiler.emits.call(null,"var ");

cljs.compiler.emit.call(null,cljs.core.last.call(null,params));

cljs.compiler.emitln.call(null," = cljs.core.rest(",arglist,");");

cljs.compiler.emits.call(null,"return ",delegate_name,"(");

var seq__31142_31175 = cljs.core.seq.call(null,params);
var chunk__31143_31176 = null;
var count__31144_31177 = (0);
var i__31145_31178 = (0);
while(true){
if((i__31145_31178 < count__31144_31177)){
var param_31179 = cljs.core._nth.call(null,chunk__31143_31176,i__31145_31178);
cljs.compiler.emit.call(null,param_31179);

if(cljs.core._EQ_.call(null,param_31179,cljs.core.last.call(null,params))){
} else {
cljs.compiler.emits.call(null,",");
}

var G__31180 = seq__31142_31175;
var G__31181 = chunk__31143_31176;
var G__31182 = count__31144_31177;
var G__31183 = (i__31145_31178 + (1));
seq__31142_31175 = G__31180;
chunk__31143_31176 = G__31181;
count__31144_31177 = G__31182;
i__31145_31178 = G__31183;
continue;
} else {
var temp__4657__auto___31184 = cljs.core.seq.call(null,seq__31142_31175);
if(temp__4657__auto___31184){
var seq__31142_31185__$1 = temp__4657__auto___31184;
if(cljs.core.chunked_seq_QMARK_.call(null,seq__31142_31185__$1)){
var c__23696__auto___31186 = cljs.core.chunk_first.call(null,seq__31142_31185__$1);
var G__31187 = cljs.core.chunk_rest.call(null,seq__31142_31185__$1);
var G__31188 = c__23696__auto___31186;
var G__31189 = cljs.core.count.call(null,c__23696__auto___31186);
var G__31190 = (0);
seq__31142_31175 = G__31187;
chunk__31143_31176 = G__31188;
count__31144_31177 = G__31189;
i__31145_31178 = G__31190;
continue;
} else {
var param_31191 = cljs.core.first.call(null,seq__31142_31185__$1);
cljs.compiler.emit.call(null,param_31191);

if(cljs.core._EQ_.call(null,param_31191,cljs.core.last.call(null,params))){
} else {
cljs.compiler.emits.call(null,",");
}

var G__31192 = cljs.core.next.call(null,seq__31142_31185__$1);
var G__31193 = null;
var G__31194 = (0);
var G__31195 = (0);
seq__31142_31175 = G__31192;
chunk__31143_31176 = G__31193;
count__31144_31177 = G__31194;
i__31145_31178 = G__31195;
continue;
}
} else {
}
}
break;
}

cljs.compiler.emitln.call(null,");");
} else {
cljs.compiler.emits.call(null,"var ");

cljs.compiler.emit.call(null,cljs.core.last.call(null,params));

cljs.compiler.emitln.call(null," = cljs.core.seq(",arglist,");");

cljs.compiler.emits.call(null,"return ",delegate_name,"(");

var seq__31146_31196 = cljs.core.seq.call(null,params);
var chunk__31147_31197 = null;
var count__31148_31198 = (0);
var i__31149_31199 = (0);
while(true){
if((i__31149_31199 < count__31148_31198)){
var param_31200 = cljs.core._nth.call(null,chunk__31147_31197,i__31149_31199);
cljs.compiler.emit.call(null,param_31200);

if(cljs.core._EQ_.call(null,param_31200,cljs.core.last.call(null,params))){
} else {
cljs.compiler.emits.call(null,",");
}

var G__31201 = seq__31146_31196;
var G__31202 = chunk__31147_31197;
var G__31203 = count__31148_31198;
var G__31204 = (i__31149_31199 + (1));
seq__31146_31196 = G__31201;
chunk__31147_31197 = G__31202;
count__31148_31198 = G__31203;
i__31149_31199 = G__31204;
continue;
} else {
var temp__4657__auto___31205 = cljs.core.seq.call(null,seq__31146_31196);
if(temp__4657__auto___31205){
var seq__31146_31206__$1 = temp__4657__auto___31205;
if(cljs.core.chunked_seq_QMARK_.call(null,seq__31146_31206__$1)){
var c__23696__auto___31207 = cljs.core.chunk_first.call(null,seq__31146_31206__$1);
var G__31208 = cljs.core.chunk_rest.call(null,seq__31146_31206__$1);
var G__31209 = c__23696__auto___31207;
var G__31210 = cljs.core.count.call(null,c__23696__auto___31207);
var G__31211 = (0);
seq__31146_31196 = G__31208;
chunk__31147_31197 = G__31209;
count__31148_31198 = G__31210;
i__31149_31199 = G__31211;
continue;
} else {
var param_31212 = cljs.core.first.call(null,seq__31146_31206__$1);
cljs.compiler.emit.call(null,param_31212);

if(cljs.core._EQ_.call(null,param_31212,cljs.core.last.call(null,params))){
} else {
cljs.compiler.emits.call(null,",");
}

var G__31213 = cljs.core.next.call(null,seq__31146_31206__$1);
var G__31214 = null;
var G__31215 = (0);
var G__31216 = (0);
seq__31146_31196 = G__31213;
chunk__31147_31197 = G__31214;
count__31148_31198 = G__31215;
i__31149_31199 = G__31216;
continue;
}
} else {
}
}
break;
}

cljs.compiler.emitln.call(null,");");
}

return cljs.compiler.emits.call(null,"})");
});
cljs.compiler.emit_fn_params = (function cljs$compiler$emit_fn_params(params){
var seq__31221 = cljs.core.seq.call(null,params);
var chunk__31222 = null;
var count__31223 = (0);
var i__31224 = (0);
while(true){
if((i__31224 < count__31223)){
var param = cljs.core._nth.call(null,chunk__31222,i__31224);
cljs.compiler.emit.call(null,param);

if(cljs.core._EQ_.call(null,param,cljs.core.last.call(null,params))){
} else {
cljs.compiler.emits.call(null,",");
}

var G__31225 = seq__31221;
var G__31226 = chunk__31222;
var G__31227 = count__31223;
var G__31228 = (i__31224 + (1));
seq__31221 = G__31225;
chunk__31222 = G__31226;
count__31223 = G__31227;
i__31224 = G__31228;
continue;
} else {
var temp__4657__auto__ = cljs.core.seq.call(null,seq__31221);
if(temp__4657__auto__){
var seq__31221__$1 = temp__4657__auto__;
if(cljs.core.chunked_seq_QMARK_.call(null,seq__31221__$1)){
var c__23696__auto__ = cljs.core.chunk_first.call(null,seq__31221__$1);
var G__31229 = cljs.core.chunk_rest.call(null,seq__31221__$1);
var G__31230 = c__23696__auto__;
var G__31231 = cljs.core.count.call(null,c__23696__auto__);
var G__31232 = (0);
seq__31221 = G__31229;
chunk__31222 = G__31230;
count__31223 = G__31231;
i__31224 = G__31232;
continue;
} else {
var param = cljs.core.first.call(null,seq__31221__$1);
cljs.compiler.emit.call(null,param);

if(cljs.core._EQ_.call(null,param,cljs.core.last.call(null,params))){
} else {
cljs.compiler.emits.call(null,",");
}

var G__31233 = cljs.core.next.call(null,seq__31221__$1);
var G__31234 = null;
var G__31235 = (0);
var G__31236 = (0);
seq__31221 = G__31233;
chunk__31222 = G__31234;
count__31223 = G__31235;
i__31224 = G__31236;
continue;
}
} else {
return null;
}
}
break;
}
});
cljs.compiler.emit_fn_method = (function cljs$compiler$emit_fn_method(p__31237){
var map__31240 = p__31237;
var map__31240__$1 = ((((!((map__31240 == null)))?((((map__31240.cljs$lang$protocol_mask$partition0$ & (64))) || (map__31240.cljs$core$ISeq$))?true:false):false))?cljs.core.apply.call(null,cljs.core.hash_map,map__31240):map__31240);
var type = cljs.core.get.call(null,map__31240__$1,new cljs.core.Keyword(null,"type","type",1174270348));
var name = cljs.core.get.call(null,map__31240__$1,new cljs.core.Keyword(null,"name","name",1843675177));
var variadic = cljs.core.get.call(null,map__31240__$1,new cljs.core.Keyword(null,"variadic","variadic",882626057));
var params = cljs.core.get.call(null,map__31240__$1,new cljs.core.Keyword(null,"params","params",710516235));
var expr = cljs.core.get.call(null,map__31240__$1,new cljs.core.Keyword(null,"expr","expr",745722291));
var env = cljs.core.get.call(null,map__31240__$1,new cljs.core.Keyword(null,"env","env",-1815813235));
var recurs = cljs.core.get.call(null,map__31240__$1,new cljs.core.Keyword(null,"recurs","recurs",-1959309309));
var max_fixed_arity = cljs.core.get.call(null,map__31240__$1,new cljs.core.Keyword(null,"max-fixed-arity","max-fixed-arity",-690205543));
var env__24998__auto__ = env;
if(cljs.core._EQ_.call(null,new cljs.core.Keyword(null,"return","return",-1891502105),new cljs.core.Keyword(null,"context","context",-830191113).cljs$core$IFn$_invoke$arity$1(env__24998__auto__))){
cljs.compiler.emits.call(null,"return ");
} else {
}

cljs.compiler.emits.call(null,"(function ",cljs.compiler.munge.call(null,name),"(");

cljs.compiler.emit_fn_params.call(null,params);

cljs.compiler.emitln.call(null,"){");

if(cljs.core.truth_(type)){
cljs.compiler.emitln.call(null,"var self__ = this;");
} else {
}

if(cljs.core.truth_(recurs)){
cljs.compiler.emitln.call(null,"while(true){");
} else {
}

cljs.compiler.emits.call(null,expr);

if(cljs.core.truth_(recurs)){
cljs.compiler.emitln.call(null,"break;");

cljs.compiler.emitln.call(null,"}");
} else {
}

cljs.compiler.emits.call(null,"})");

if(cljs.core._EQ_.call(null,new cljs.core.Keyword(null,"expr","expr",745722291),new cljs.core.Keyword(null,"context","context",-830191113).cljs$core$IFn$_invoke$arity$1(env__24998__auto__))){
return null;
} else {
return cljs.compiler.emitln.call(null,";");
}
});
/**
 * Emit code that copies function arguments into an array starting at an index.
 *   Returns name of var holding the array.
 */
cljs.compiler.emit_arguments_to_array = (function cljs$compiler$emit_arguments_to_array(startslice){
if(((startslice >= (0))) && (cljs.core.integer_QMARK_.call(null,startslice))){
} else {
throw (new Error("Assert failed: (and (>= startslice 0) (integer? startslice))"));
}

var mname = cljs.compiler.munge.call(null,cljs.core.gensym.call(null));
var i = [cljs.core.str(mname),cljs.core.str("__i")].join('');
var a = [cljs.core.str(mname),cljs.core.str("__a")].join('');
cljs.compiler.emitln.call(null,"var ",i," = 0, ",a," = new Array(arguments.length -  ",startslice,");");

cljs.compiler.emitln.call(null,"while (",i," < ",a,".length) {",a,"[",i,"] = arguments[",i," + ",startslice,"]; ++",i,";}");

return a;
});
cljs.compiler.emit_variadic_fn_method = (function cljs$compiler$emit_variadic_fn_method(p__31242){
var map__31253 = p__31242;
var map__31253__$1 = ((((!((map__31253 == null)))?((((map__31253.cljs$lang$protocol_mask$partition0$ & (64))) || (map__31253.cljs$core$ISeq$))?true:false):false))?cljs.core.apply.call(null,cljs.core.hash_map,map__31253):map__31253);
var f = map__31253__$1;
var type = cljs.core.get.call(null,map__31253__$1,new cljs.core.Keyword(null,"type","type",1174270348));
var name = cljs.core.get.call(null,map__31253__$1,new cljs.core.Keyword(null,"name","name",1843675177));
var variadic = cljs.core.get.call(null,map__31253__$1,new cljs.core.Keyword(null,"variadic","variadic",882626057));
var params = cljs.core.get.call(null,map__31253__$1,new cljs.core.Keyword(null,"params","params",710516235));
var expr = cljs.core.get.call(null,map__31253__$1,new cljs.core.Keyword(null,"expr","expr",745722291));
var env = cljs.core.get.call(null,map__31253__$1,new cljs.core.Keyword(null,"env","env",-1815813235));
var recurs = cljs.core.get.call(null,map__31253__$1,new cljs.core.Keyword(null,"recurs","recurs",-1959309309));
var max_fixed_arity = cljs.core.get.call(null,map__31253__$1,new cljs.core.Keyword(null,"max-fixed-arity","max-fixed-arity",-690205543));
var env__24998__auto__ = env;
if(cljs.core._EQ_.call(null,new cljs.core.Keyword(null,"return","return",-1891502105),new cljs.core.Keyword(null,"context","context",-830191113).cljs$core$IFn$_invoke$arity$1(env__24998__auto__))){
cljs.compiler.emits.call(null,"return ");
} else {
}

var name_31263__$1 = (function (){var or__22885__auto__ = name;
if(cljs.core.truth_(or__22885__auto__)){
return or__22885__auto__;
} else {
return cljs.core.gensym.call(null);
}
})();
var mname_31264 = cljs.compiler.munge.call(null,name_31263__$1);
var delegate_name_31265 = [cljs.core.str(mname_31264),cljs.core.str("__delegate")].join('');
cljs.compiler.emitln.call(null,"(function() { ");

cljs.compiler.emits.call(null,"var ",delegate_name_31265," = function (");

var seq__31255_31266 = cljs.core.seq.call(null,params);
var chunk__31256_31267 = null;
var count__31257_31268 = (0);
var i__31258_31269 = (0);
while(true){
if((i__31258_31269 < count__31257_31268)){
var param_31270 = cljs.core._nth.call(null,chunk__31256_31267,i__31258_31269);
cljs.compiler.emit.call(null,param_31270);

if(cljs.core._EQ_.call(null,param_31270,cljs.core.last.call(null,params))){
} else {
cljs.compiler.emits.call(null,",");
}

var G__31271 = seq__31255_31266;
var G__31272 = chunk__31256_31267;
var G__31273 = count__31257_31268;
var G__31274 = (i__31258_31269 + (1));
seq__31255_31266 = G__31271;
chunk__31256_31267 = G__31272;
count__31257_31268 = G__31273;
i__31258_31269 = G__31274;
continue;
} else {
var temp__4657__auto___31275 = cljs.core.seq.call(null,seq__31255_31266);
if(temp__4657__auto___31275){
var seq__31255_31276__$1 = temp__4657__auto___31275;
if(cljs.core.chunked_seq_QMARK_.call(null,seq__31255_31276__$1)){
var c__23696__auto___31277 = cljs.core.chunk_first.call(null,seq__31255_31276__$1);
var G__31278 = cljs.core.chunk_rest.call(null,seq__31255_31276__$1);
var G__31279 = c__23696__auto___31277;
var G__31280 = cljs.core.count.call(null,c__23696__auto___31277);
var G__31281 = (0);
seq__31255_31266 = G__31278;
chunk__31256_31267 = G__31279;
count__31257_31268 = G__31280;
i__31258_31269 = G__31281;
continue;
} else {
var param_31282 = cljs.core.first.call(null,seq__31255_31276__$1);
cljs.compiler.emit.call(null,param_31282);

if(cljs.core._EQ_.call(null,param_31282,cljs.core.last.call(null,params))){
} else {
cljs.compiler.emits.call(null,",");
}

var G__31283 = cljs.core.next.call(null,seq__31255_31276__$1);
var G__31284 = null;
var G__31285 = (0);
var G__31286 = (0);
seq__31255_31266 = G__31283;
chunk__31256_31267 = G__31284;
count__31257_31268 = G__31285;
i__31258_31269 = G__31286;
continue;
}
} else {
}
}
break;
}

cljs.compiler.emitln.call(null,"){");

if(cljs.core.truth_(recurs)){
cljs.compiler.emitln.call(null,"while(true){");
} else {
}

cljs.compiler.emits.call(null,expr);

if(cljs.core.truth_(recurs)){
cljs.compiler.emitln.call(null,"break;");

cljs.compiler.emitln.call(null,"}");
} else {
}

cljs.compiler.emitln.call(null,"};");

cljs.compiler.emitln.call(null,"var ",mname_31264," = function (",cljs.compiler.comma_sep.call(null,(cljs.core.truth_(variadic)?cljs.core.concat.call(null,cljs.core.butlast.call(null,params),new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Symbol(null,"var_args","var_args",1214280389,null)], null)):params)),"){");

if(cljs.core.truth_(type)){
cljs.compiler.emitln.call(null,"var self__ = this;");
} else {
}

if(cljs.core.truth_(variadic)){
cljs.compiler.emits.call(null,"var ");

cljs.compiler.emit.call(null,cljs.core.last.call(null,params));

cljs.compiler.emitln.call(null," = null;");

cljs.compiler.emitln.call(null,"if (arguments.length > ",(cljs.core.count.call(null,params) - (1)),") {");

var a_31287 = cljs.compiler.emit_arguments_to_array.call(null,(cljs.core.count.call(null,params) - (1)));
cljs.compiler.emitln.call(null,"  ",cljs.core.last.call(null,params)," = new cljs.core.IndexedSeq(",a_31287,",0);");

cljs.compiler.emitln.call(null,"} ");
} else {
}

cljs.compiler.emits.call(null,"return ",delegate_name_31265,".call(this,");

var seq__31259_31288 = cljs.core.seq.call(null,params);
var chunk__31260_31289 = null;
var count__31261_31290 = (0);
var i__31262_31291 = (0);
while(true){
if((i__31262_31291 < count__31261_31290)){
var param_31292 = cljs.core._nth.call(null,chunk__31260_31289,i__31262_31291);
cljs.compiler.emit.call(null,param_31292);

if(cljs.core._EQ_.call(null,param_31292,cljs.core.last.call(null,params))){
} else {
cljs.compiler.emits.call(null,",");
}

var G__31293 = seq__31259_31288;
var G__31294 = chunk__31260_31289;
var G__31295 = count__31261_31290;
var G__31296 = (i__31262_31291 + (1));
seq__31259_31288 = G__31293;
chunk__31260_31289 = G__31294;
count__31261_31290 = G__31295;
i__31262_31291 = G__31296;
continue;
} else {
var temp__4657__auto___31297 = cljs.core.seq.call(null,seq__31259_31288);
if(temp__4657__auto___31297){
var seq__31259_31298__$1 = temp__4657__auto___31297;
if(cljs.core.chunked_seq_QMARK_.call(null,seq__31259_31298__$1)){
var c__23696__auto___31299 = cljs.core.chunk_first.call(null,seq__31259_31298__$1);
var G__31300 = cljs.core.chunk_rest.call(null,seq__31259_31298__$1);
var G__31301 = c__23696__auto___31299;
var G__31302 = cljs.core.count.call(null,c__23696__auto___31299);
var G__31303 = (0);
seq__31259_31288 = G__31300;
chunk__31260_31289 = G__31301;
count__31261_31290 = G__31302;
i__31262_31291 = G__31303;
continue;
} else {
var param_31304 = cljs.core.first.call(null,seq__31259_31298__$1);
cljs.compiler.emit.call(null,param_31304);

if(cljs.core._EQ_.call(null,param_31304,cljs.core.last.call(null,params))){
} else {
cljs.compiler.emits.call(null,",");
}

var G__31305 = cljs.core.next.call(null,seq__31259_31298__$1);
var G__31306 = null;
var G__31307 = (0);
var G__31308 = (0);
seq__31259_31288 = G__31305;
chunk__31260_31289 = G__31306;
count__31261_31290 = G__31307;
i__31262_31291 = G__31308;
continue;
}
} else {
}
}
break;
}

cljs.compiler.emits.call(null,");");

cljs.compiler.emitln.call(null,"};");

cljs.compiler.emitln.call(null,mname_31264,".cljs$lang$maxFixedArity = ",max_fixed_arity,";");

cljs.compiler.emits.call(null,mname_31264,".cljs$lang$applyTo = ");

cljs.compiler.emit_apply_to.call(null,cljs.core.assoc.call(null,f,new cljs.core.Keyword(null,"name","name",1843675177),name_31263__$1));

cljs.compiler.emitln.call(null,";");

cljs.compiler.emitln.call(null,mname_31264,".cljs$core$IFn$_invoke$arity$variadic = ",delegate_name_31265,";");

cljs.compiler.emitln.call(null,"return ",mname_31264,";");

cljs.compiler.emitln.call(null,"})()");

if(cljs.core._EQ_.call(null,new cljs.core.Keyword(null,"expr","expr",745722291),new cljs.core.Keyword(null,"context","context",-830191113).cljs$core$IFn$_invoke$arity$1(env__24998__auto__))){
return null;
} else {
return cljs.compiler.emitln.call(null,";");
}
});
cljs.core._add_method.call(null,cljs.compiler.emit_STAR_,new cljs.core.Keyword(null,"fn","fn",-1175266204),(function (p__31312){
var map__31313 = p__31312;
var map__31313__$1 = ((((!((map__31313 == null)))?((((map__31313.cljs$lang$protocol_mask$partition0$ & (64))) || (map__31313.cljs$core$ISeq$))?true:false):false))?cljs.core.apply.call(null,cljs.core.hash_map,map__31313):map__31313);
var name = cljs.core.get.call(null,map__31313__$1,new cljs.core.Keyword(null,"name","name",1843675177));
var env = cljs.core.get.call(null,map__31313__$1,new cljs.core.Keyword(null,"env","env",-1815813235));
var methods$ = cljs.core.get.call(null,map__31313__$1,new cljs.core.Keyword(null,"methods","methods",453930866));
var max_fixed_arity = cljs.core.get.call(null,map__31313__$1,new cljs.core.Keyword(null,"max-fixed-arity","max-fixed-arity",-690205543));
var variadic = cljs.core.get.call(null,map__31313__$1,new cljs.core.Keyword(null,"variadic","variadic",882626057));
var recur_frames = cljs.core.get.call(null,map__31313__$1,new cljs.core.Keyword(null,"recur-frames","recur-frames",-307205196));
var loop_lets = cljs.core.get.call(null,map__31313__$1,new cljs.core.Keyword(null,"loop-lets","loop-lets",2036794185));
if(cljs.core._EQ_.call(null,new cljs.core.Keyword(null,"statement","statement",-32780863),new cljs.core.Keyword(null,"context","context",-830191113).cljs$core$IFn$_invoke$arity$1(env))){
return null;
} else {
var loop_locals = cljs.core.seq.call(null,cljs.core.map.call(null,cljs.compiler.munge,cljs.core.concat.call(null,cljs.core.mapcat.call(null,new cljs.core.Keyword(null,"params","params",710516235),cljs.core.filter.call(null,((function (map__31313,map__31313__$1,name,env,methods$,max_fixed_arity,variadic,recur_frames,loop_lets){
return (function (p1__31309_SHARP_){
var and__22873__auto__ = p1__31309_SHARP_;
if(cljs.core.truth_(and__22873__auto__)){
return cljs.core.deref.call(null,new cljs.core.Keyword(null,"flag","flag",1088647881).cljs$core$IFn$_invoke$arity$1(p1__31309_SHARP_));
} else {
return and__22873__auto__;
}
});})(map__31313,map__31313__$1,name,env,methods$,max_fixed_arity,variadic,recur_frames,loop_lets))
,recur_frames)),cljs.core.mapcat.call(null,new cljs.core.Keyword(null,"params","params",710516235),loop_lets))));
if(loop_locals){
if(cljs.core._EQ_.call(null,new cljs.core.Keyword(null,"return","return",-1891502105),new cljs.core.Keyword(null,"context","context",-830191113).cljs$core$IFn$_invoke$arity$1(env))){
cljs.compiler.emits.call(null,"return ");
} else {
}

cljs.compiler.emitln.call(null,"((function (",cljs.compiler.comma_sep.call(null,cljs.core.map.call(null,cljs.compiler.munge,loop_locals)),"){");

if(cljs.core._EQ_.call(null,new cljs.core.Keyword(null,"return","return",-1891502105),new cljs.core.Keyword(null,"context","context",-830191113).cljs$core$IFn$_invoke$arity$1(env))){
} else {
cljs.compiler.emits.call(null,"return ");
}
} else {
}

if(cljs.core._EQ_.call(null,(1),cljs.core.count.call(null,methods$))){
if(cljs.core.truth_(variadic)){
cljs.compiler.emit_variadic_fn_method.call(null,cljs.core.assoc.call(null,cljs.core.first.call(null,methods$),new cljs.core.Keyword(null,"name","name",1843675177),name));
} else {
cljs.compiler.emit_fn_method.call(null,cljs.core.assoc.call(null,cljs.core.first.call(null,methods$),new cljs.core.Keyword(null,"name","name",1843675177),name));
}
} else {
var name_31334__$1 = (function (){var or__22885__auto__ = name;
if(cljs.core.truth_(or__22885__auto__)){
return or__22885__auto__;
} else {
return cljs.core.gensym.call(null);
}
})();
var mname_31335 = cljs.compiler.munge.call(null,name_31334__$1);
var maxparams_31336 = cljs.core.apply.call(null,cljs.core.max_key,cljs.core.count,cljs.core.map.call(null,new cljs.core.Keyword(null,"params","params",710516235),methods$));
var mmap_31337 = cljs.core.into.call(null,cljs.core.PersistentArrayMap.EMPTY,cljs.core.map.call(null,((function (name_31334__$1,mname_31335,maxparams_31336,loop_locals,map__31313,map__31313__$1,name,env,methods$,max_fixed_arity,variadic,recur_frames,loop_lets){
return (function (method){
return new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.compiler.munge.call(null,cljs.core.symbol.call(null,[cljs.core.str(mname_31335),cljs.core.str("__"),cljs.core.str(cljs.core.count.call(null,new cljs.core.Keyword(null,"params","params",710516235).cljs$core$IFn$_invoke$arity$1(method)))].join(''))),method], null);
});})(name_31334__$1,mname_31335,maxparams_31336,loop_locals,map__31313,map__31313__$1,name,env,methods$,max_fixed_arity,variadic,recur_frames,loop_lets))
,methods$));
var ms_31338 = cljs.core.sort_by.call(null,((function (name_31334__$1,mname_31335,maxparams_31336,mmap_31337,loop_locals,map__31313,map__31313__$1,name,env,methods$,max_fixed_arity,variadic,recur_frames,loop_lets){
return (function (p1__31310_SHARP_){
return cljs.core.count.call(null,new cljs.core.Keyword(null,"params","params",710516235).cljs$core$IFn$_invoke$arity$1(cljs.core.second.call(null,p1__31310_SHARP_)));
});})(name_31334__$1,mname_31335,maxparams_31336,mmap_31337,loop_locals,map__31313,map__31313__$1,name,env,methods$,max_fixed_arity,variadic,recur_frames,loop_lets))
,cljs.core.seq.call(null,mmap_31337));
if(cljs.core._EQ_.call(null,new cljs.core.Keyword(null,"return","return",-1891502105),new cljs.core.Keyword(null,"context","context",-830191113).cljs$core$IFn$_invoke$arity$1(env))){
cljs.compiler.emits.call(null,"return ");
} else {
}

cljs.compiler.emitln.call(null,"(function() {");

cljs.compiler.emitln.call(null,"var ",mname_31335," = null;");

var seq__31315_31339 = cljs.core.seq.call(null,ms_31338);
var chunk__31316_31340 = null;
var count__31317_31341 = (0);
var i__31318_31342 = (0);
while(true){
if((i__31318_31342 < count__31317_31341)){
var vec__31319_31343 = cljs.core._nth.call(null,chunk__31316_31340,i__31318_31342);
var n_31344 = cljs.core.nth.call(null,vec__31319_31343,(0),null);
var meth_31345 = cljs.core.nth.call(null,vec__31319_31343,(1),null);
cljs.compiler.emits.call(null,"var ",n_31344," = ");

if(cljs.core.truth_(new cljs.core.Keyword(null,"variadic","variadic",882626057).cljs$core$IFn$_invoke$arity$1(meth_31345))){
cljs.compiler.emit_variadic_fn_method.call(null,meth_31345);
} else {
cljs.compiler.emit_fn_method.call(null,meth_31345);
}

cljs.compiler.emitln.call(null,";");

var G__31346 = seq__31315_31339;
var G__31347 = chunk__31316_31340;
var G__31348 = count__31317_31341;
var G__31349 = (i__31318_31342 + (1));
seq__31315_31339 = G__31346;
chunk__31316_31340 = G__31347;
count__31317_31341 = G__31348;
i__31318_31342 = G__31349;
continue;
} else {
var temp__4657__auto___31350 = cljs.core.seq.call(null,seq__31315_31339);
if(temp__4657__auto___31350){
var seq__31315_31351__$1 = temp__4657__auto___31350;
if(cljs.core.chunked_seq_QMARK_.call(null,seq__31315_31351__$1)){
var c__23696__auto___31352 = cljs.core.chunk_first.call(null,seq__31315_31351__$1);
var G__31353 = cljs.core.chunk_rest.call(null,seq__31315_31351__$1);
var G__31354 = c__23696__auto___31352;
var G__31355 = cljs.core.count.call(null,c__23696__auto___31352);
var G__31356 = (0);
seq__31315_31339 = G__31353;
chunk__31316_31340 = G__31354;
count__31317_31341 = G__31355;
i__31318_31342 = G__31356;
continue;
} else {
var vec__31320_31357 = cljs.core.first.call(null,seq__31315_31351__$1);
var n_31358 = cljs.core.nth.call(null,vec__31320_31357,(0),null);
var meth_31359 = cljs.core.nth.call(null,vec__31320_31357,(1),null);
cljs.compiler.emits.call(null,"var ",n_31358," = ");

if(cljs.core.truth_(new cljs.core.Keyword(null,"variadic","variadic",882626057).cljs$core$IFn$_invoke$arity$1(meth_31359))){
cljs.compiler.emit_variadic_fn_method.call(null,meth_31359);
} else {
cljs.compiler.emit_fn_method.call(null,meth_31359);
}

cljs.compiler.emitln.call(null,";");

var G__31360 = cljs.core.next.call(null,seq__31315_31351__$1);
var G__31361 = null;
var G__31362 = (0);
var G__31363 = (0);
seq__31315_31339 = G__31360;
chunk__31316_31340 = G__31361;
count__31317_31341 = G__31362;
i__31318_31342 = G__31363;
continue;
}
} else {
}
}
break;
}

cljs.compiler.emitln.call(null,mname_31335," = function(",cljs.compiler.comma_sep.call(null,(cljs.core.truth_(variadic)?cljs.core.concat.call(null,cljs.core.butlast.call(null,maxparams_31336),new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Symbol(null,"var_args","var_args",1214280389,null)], null)):maxparams_31336)),"){");

if(cljs.core.truth_(variadic)){
cljs.compiler.emits.call(null,"var ");

cljs.compiler.emit.call(null,cljs.core.last.call(null,maxparams_31336));

cljs.compiler.emitln.call(null," = var_args;");
} else {
}

cljs.compiler.emitln.call(null,"switch(arguments.length){");

var seq__31321_31364 = cljs.core.seq.call(null,ms_31338);
var chunk__31322_31365 = null;
var count__31323_31366 = (0);
var i__31324_31367 = (0);
while(true){
if((i__31324_31367 < count__31323_31366)){
var vec__31325_31368 = cljs.core._nth.call(null,chunk__31322_31365,i__31324_31367);
var n_31369 = cljs.core.nth.call(null,vec__31325_31368,(0),null);
var meth_31370 = cljs.core.nth.call(null,vec__31325_31368,(1),null);
if(cljs.core.truth_(new cljs.core.Keyword(null,"variadic","variadic",882626057).cljs$core$IFn$_invoke$arity$1(meth_31370))){
cljs.compiler.emitln.call(null,"default:");

var restarg_31371 = cljs.compiler.munge.call(null,cljs.core.gensym.call(null));
cljs.compiler.emitln.call(null,"var ",restarg_31371," = null;");

cljs.compiler.emitln.call(null,"if (arguments.length > ",max_fixed_arity,") {");

var a_31372 = cljs.compiler.emit_arguments_to_array.call(null,max_fixed_arity);
cljs.compiler.emitln.call(null,restarg_31371," = new cljs.core.IndexedSeq(",a_31372,",0);");

cljs.compiler.emitln.call(null,"}");

cljs.compiler.emitln.call(null,"return ",n_31369,".cljs$core$IFn$_invoke$arity$variadic(",cljs.compiler.comma_sep.call(null,cljs.core.butlast.call(null,maxparams_31336)),(((cljs.core.count.call(null,maxparams_31336) > (1)))?", ":null),restarg_31371,");");
} else {
var pcnt_31373 = cljs.core.count.call(null,new cljs.core.Keyword(null,"params","params",710516235).cljs$core$IFn$_invoke$arity$1(meth_31370));
cljs.compiler.emitln.call(null,"case ",pcnt_31373,":");

cljs.compiler.emitln.call(null,"return ",n_31369,".call(this",(((pcnt_31373 === (0)))?null:cljs.core._conj.call(null,(function (){var x__23719__auto__ = cljs.compiler.comma_sep.call(null,cljs.core.take.call(null,pcnt_31373,maxparams_31336));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),",")),");");
}

var G__31374 = seq__31321_31364;
var G__31375 = chunk__31322_31365;
var G__31376 = count__31323_31366;
var G__31377 = (i__31324_31367 + (1));
seq__31321_31364 = G__31374;
chunk__31322_31365 = G__31375;
count__31323_31366 = G__31376;
i__31324_31367 = G__31377;
continue;
} else {
var temp__4657__auto___31378 = cljs.core.seq.call(null,seq__31321_31364);
if(temp__4657__auto___31378){
var seq__31321_31379__$1 = temp__4657__auto___31378;
if(cljs.core.chunked_seq_QMARK_.call(null,seq__31321_31379__$1)){
var c__23696__auto___31380 = cljs.core.chunk_first.call(null,seq__31321_31379__$1);
var G__31381 = cljs.core.chunk_rest.call(null,seq__31321_31379__$1);
var G__31382 = c__23696__auto___31380;
var G__31383 = cljs.core.count.call(null,c__23696__auto___31380);
var G__31384 = (0);
seq__31321_31364 = G__31381;
chunk__31322_31365 = G__31382;
count__31323_31366 = G__31383;
i__31324_31367 = G__31384;
continue;
} else {
var vec__31326_31385 = cljs.core.first.call(null,seq__31321_31379__$1);
var n_31386 = cljs.core.nth.call(null,vec__31326_31385,(0),null);
var meth_31387 = cljs.core.nth.call(null,vec__31326_31385,(1),null);
if(cljs.core.truth_(new cljs.core.Keyword(null,"variadic","variadic",882626057).cljs$core$IFn$_invoke$arity$1(meth_31387))){
cljs.compiler.emitln.call(null,"default:");

var restarg_31388 = cljs.compiler.munge.call(null,cljs.core.gensym.call(null));
cljs.compiler.emitln.call(null,"var ",restarg_31388," = null;");

cljs.compiler.emitln.call(null,"if (arguments.length > ",max_fixed_arity,") {");

var a_31389 = cljs.compiler.emit_arguments_to_array.call(null,max_fixed_arity);
cljs.compiler.emitln.call(null,restarg_31388," = new cljs.core.IndexedSeq(",a_31389,",0);");

cljs.compiler.emitln.call(null,"}");

cljs.compiler.emitln.call(null,"return ",n_31386,".cljs$core$IFn$_invoke$arity$variadic(",cljs.compiler.comma_sep.call(null,cljs.core.butlast.call(null,maxparams_31336)),(((cljs.core.count.call(null,maxparams_31336) > (1)))?", ":null),restarg_31388,");");
} else {
var pcnt_31390 = cljs.core.count.call(null,new cljs.core.Keyword(null,"params","params",710516235).cljs$core$IFn$_invoke$arity$1(meth_31387));
cljs.compiler.emitln.call(null,"case ",pcnt_31390,":");

cljs.compiler.emitln.call(null,"return ",n_31386,".call(this",(((pcnt_31390 === (0)))?null:cljs.core._conj.call(null,(function (){var x__23719__auto__ = cljs.compiler.comma_sep.call(null,cljs.core.take.call(null,pcnt_31390,maxparams_31336));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),",")),");");
}

var G__31391 = cljs.core.next.call(null,seq__31321_31379__$1);
var G__31392 = null;
var G__31393 = (0);
var G__31394 = (0);
seq__31321_31364 = G__31391;
chunk__31322_31365 = G__31392;
count__31323_31366 = G__31393;
i__31324_31367 = G__31394;
continue;
}
} else {
}
}
break;
}

cljs.compiler.emitln.call(null,"}");

cljs.compiler.emitln.call(null,"throw(new Error('Invalid arity: ' + arguments.length));");

cljs.compiler.emitln.call(null,"};");

if(cljs.core.truth_(variadic)){
cljs.compiler.emitln.call(null,mname_31335,".cljs$lang$maxFixedArity = ",max_fixed_arity,";");

cljs.compiler.emitln.call(null,mname_31335,".cljs$lang$applyTo = ",cljs.core.some.call(null,((function (name_31334__$1,mname_31335,maxparams_31336,mmap_31337,ms_31338,loop_locals,map__31313,map__31313__$1,name,env,methods$,max_fixed_arity,variadic,recur_frames,loop_lets){
return (function (p1__31311_SHARP_){
var vec__31327 = p1__31311_SHARP_;
var n = cljs.core.nth.call(null,vec__31327,(0),null);
var m = cljs.core.nth.call(null,vec__31327,(1),null);
if(cljs.core.truth_(new cljs.core.Keyword(null,"variadic","variadic",882626057).cljs$core$IFn$_invoke$arity$1(m))){
return n;
} else {
return null;
}
});})(name_31334__$1,mname_31335,maxparams_31336,mmap_31337,ms_31338,loop_locals,map__31313,map__31313__$1,name,env,methods$,max_fixed_arity,variadic,recur_frames,loop_lets))
,ms_31338),".cljs$lang$applyTo;");
} else {
}

var seq__31328_31395 = cljs.core.seq.call(null,ms_31338);
var chunk__31329_31396 = null;
var count__31330_31397 = (0);
var i__31331_31398 = (0);
while(true){
if((i__31331_31398 < count__31330_31397)){
var vec__31332_31399 = cljs.core._nth.call(null,chunk__31329_31396,i__31331_31398);
var n_31400 = cljs.core.nth.call(null,vec__31332_31399,(0),null);
var meth_31401 = cljs.core.nth.call(null,vec__31332_31399,(1),null);
var c_31402 = cljs.core.count.call(null,new cljs.core.Keyword(null,"params","params",710516235).cljs$core$IFn$_invoke$arity$1(meth_31401));
if(cljs.core.truth_(new cljs.core.Keyword(null,"variadic","variadic",882626057).cljs$core$IFn$_invoke$arity$1(meth_31401))){
cljs.compiler.emitln.call(null,mname_31335,".cljs$core$IFn$_invoke$arity$variadic = ",n_31400,".cljs$core$IFn$_invoke$arity$variadic;");
} else {
cljs.compiler.emitln.call(null,mname_31335,".cljs$core$IFn$_invoke$arity$",c_31402," = ",n_31400,";");
}

var G__31403 = seq__31328_31395;
var G__31404 = chunk__31329_31396;
var G__31405 = count__31330_31397;
var G__31406 = (i__31331_31398 + (1));
seq__31328_31395 = G__31403;
chunk__31329_31396 = G__31404;
count__31330_31397 = G__31405;
i__31331_31398 = G__31406;
continue;
} else {
var temp__4657__auto___31407 = cljs.core.seq.call(null,seq__31328_31395);
if(temp__4657__auto___31407){
var seq__31328_31408__$1 = temp__4657__auto___31407;
if(cljs.core.chunked_seq_QMARK_.call(null,seq__31328_31408__$1)){
var c__23696__auto___31409 = cljs.core.chunk_first.call(null,seq__31328_31408__$1);
var G__31410 = cljs.core.chunk_rest.call(null,seq__31328_31408__$1);
var G__31411 = c__23696__auto___31409;
var G__31412 = cljs.core.count.call(null,c__23696__auto___31409);
var G__31413 = (0);
seq__31328_31395 = G__31410;
chunk__31329_31396 = G__31411;
count__31330_31397 = G__31412;
i__31331_31398 = G__31413;
continue;
} else {
var vec__31333_31414 = cljs.core.first.call(null,seq__31328_31408__$1);
var n_31415 = cljs.core.nth.call(null,vec__31333_31414,(0),null);
var meth_31416 = cljs.core.nth.call(null,vec__31333_31414,(1),null);
var c_31417 = cljs.core.count.call(null,new cljs.core.Keyword(null,"params","params",710516235).cljs$core$IFn$_invoke$arity$1(meth_31416));
if(cljs.core.truth_(new cljs.core.Keyword(null,"variadic","variadic",882626057).cljs$core$IFn$_invoke$arity$1(meth_31416))){
cljs.compiler.emitln.call(null,mname_31335,".cljs$core$IFn$_invoke$arity$variadic = ",n_31415,".cljs$core$IFn$_invoke$arity$variadic;");
} else {
cljs.compiler.emitln.call(null,mname_31335,".cljs$core$IFn$_invoke$arity$",c_31417," = ",n_31415,";");
}

var G__31418 = cljs.core.next.call(null,seq__31328_31408__$1);
var G__31419 = null;
var G__31420 = (0);
var G__31421 = (0);
seq__31328_31395 = G__31418;
chunk__31329_31396 = G__31419;
count__31330_31397 = G__31420;
i__31331_31398 = G__31421;
continue;
}
} else {
}
}
break;
}

cljs.compiler.emitln.call(null,"return ",mname_31335,";");

cljs.compiler.emitln.call(null,"})()");
}

if(loop_locals){
return cljs.compiler.emitln.call(null,";})(",cljs.compiler.comma_sep.call(null,loop_locals),"))");
} else {
return null;
}
}
}));
cljs.core._add_method.call(null,cljs.compiler.emit_STAR_,new cljs.core.Keyword(null,"do","do",46310725),(function (p__31422){
var map__31423 = p__31422;
var map__31423__$1 = ((((!((map__31423 == null)))?((((map__31423.cljs$lang$protocol_mask$partition0$ & (64))) || (map__31423.cljs$core$ISeq$))?true:false):false))?cljs.core.apply.call(null,cljs.core.hash_map,map__31423):map__31423);
var statements = cljs.core.get.call(null,map__31423__$1,new cljs.core.Keyword(null,"statements","statements",600349855));
var ret = cljs.core.get.call(null,map__31423__$1,new cljs.core.Keyword(null,"ret","ret",-468222814));
var env = cljs.core.get.call(null,map__31423__$1,new cljs.core.Keyword(null,"env","env",-1815813235));
var context = new cljs.core.Keyword(null,"context","context",-830191113).cljs$core$IFn$_invoke$arity$1(env);
if(cljs.core.truth_((function (){var and__22873__auto__ = statements;
if(cljs.core.truth_(and__22873__auto__)){
return cljs.core._EQ_.call(null,new cljs.core.Keyword(null,"expr","expr",745722291),context);
} else {
return and__22873__auto__;
}
})())){
cljs.compiler.emitln.call(null,"(function (){");
} else {
}

var seq__31425_31429 = cljs.core.seq.call(null,statements);
var chunk__31426_31430 = null;
var count__31427_31431 = (0);
var i__31428_31432 = (0);
while(true){
if((i__31428_31432 < count__31427_31431)){
var s_31433 = cljs.core._nth.call(null,chunk__31426_31430,i__31428_31432);
cljs.compiler.emitln.call(null,s_31433);

var G__31434 = seq__31425_31429;
var G__31435 = chunk__31426_31430;
var G__31436 = count__31427_31431;
var G__31437 = (i__31428_31432 + (1));
seq__31425_31429 = G__31434;
chunk__31426_31430 = G__31435;
count__31427_31431 = G__31436;
i__31428_31432 = G__31437;
continue;
} else {
var temp__4657__auto___31438 = cljs.core.seq.call(null,seq__31425_31429);
if(temp__4657__auto___31438){
var seq__31425_31439__$1 = temp__4657__auto___31438;
if(cljs.core.chunked_seq_QMARK_.call(null,seq__31425_31439__$1)){
var c__23696__auto___31440 = cljs.core.chunk_first.call(null,seq__31425_31439__$1);
var G__31441 = cljs.core.chunk_rest.call(null,seq__31425_31439__$1);
var G__31442 = c__23696__auto___31440;
var G__31443 = cljs.core.count.call(null,c__23696__auto___31440);
var G__31444 = (0);
seq__31425_31429 = G__31441;
chunk__31426_31430 = G__31442;
count__31427_31431 = G__31443;
i__31428_31432 = G__31444;
continue;
} else {
var s_31445 = cljs.core.first.call(null,seq__31425_31439__$1);
cljs.compiler.emitln.call(null,s_31445);

var G__31446 = cljs.core.next.call(null,seq__31425_31439__$1);
var G__31447 = null;
var G__31448 = (0);
var G__31449 = (0);
seq__31425_31429 = G__31446;
chunk__31426_31430 = G__31447;
count__31427_31431 = G__31448;
i__31428_31432 = G__31449;
continue;
}
} else {
}
}
break;
}

cljs.compiler.emit.call(null,ret);

if(cljs.core.truth_((function (){var and__22873__auto__ = statements;
if(cljs.core.truth_(and__22873__auto__)){
return cljs.core._EQ_.call(null,new cljs.core.Keyword(null,"expr","expr",745722291),context);
} else {
return and__22873__auto__;
}
})())){
return cljs.compiler.emitln.call(null,"})()");
} else {
return null;
}
}));
cljs.core._add_method.call(null,cljs.compiler.emit_STAR_,new cljs.core.Keyword(null,"try","try",1380742522),(function (p__31450){
var map__31451 = p__31450;
var map__31451__$1 = ((((!((map__31451 == null)))?((((map__31451.cljs$lang$protocol_mask$partition0$ & (64))) || (map__31451.cljs$core$ISeq$))?true:false):false))?cljs.core.apply.call(null,cljs.core.hash_map,map__31451):map__31451);
var env = cljs.core.get.call(null,map__31451__$1,new cljs.core.Keyword(null,"env","env",-1815813235));
var try$ = cljs.core.get.call(null,map__31451__$1,new cljs.core.Keyword(null,"try","try",1380742522));
var catch$ = cljs.core.get.call(null,map__31451__$1,new cljs.core.Keyword(null,"catch","catch",1038065524));
var name = cljs.core.get.call(null,map__31451__$1,new cljs.core.Keyword(null,"name","name",1843675177));
var finally$ = cljs.core.get.call(null,map__31451__$1,new cljs.core.Keyword(null,"finally","finally",1589088705));
var context = new cljs.core.Keyword(null,"context","context",-830191113).cljs$core$IFn$_invoke$arity$1(env);
if(cljs.core.truth_((function (){var or__22885__auto__ = name;
if(cljs.core.truth_(or__22885__auto__)){
return or__22885__auto__;
} else {
return finally$;
}
})())){
if(cljs.core._EQ_.call(null,new cljs.core.Keyword(null,"expr","expr",745722291),context)){
cljs.compiler.emits.call(null,"(function (){");
} else {
}

cljs.compiler.emits.call(null,"try{",try$,"}");

if(cljs.core.truth_(name)){
cljs.compiler.emits.call(null,"catch (",cljs.compiler.munge.call(null,name),"){",catch$,"}");
} else {
}

if(cljs.core.truth_(finally$)){
if(cljs.core.not_EQ_.call(null,new cljs.core.Keyword(null,"constant","constant",-379609303),new cljs.core.Keyword(null,"op","op",-1882987955).cljs$core$IFn$_invoke$arity$1(finally$))){
} else {
throw (new Error([cljs.core.str("Assert failed: "),cljs.core.str("finally block cannot contain constant"),cljs.core.str("\n"),cljs.core.str("(not= :constant (:op finally))")].join('')));
}

cljs.compiler.emits.call(null,"finally {",finally$,"}");
} else {
}

if(cljs.core._EQ_.call(null,new cljs.core.Keyword(null,"expr","expr",745722291),context)){
return cljs.compiler.emits.call(null,"})()");
} else {
return null;
}
} else {
return cljs.compiler.emits.call(null,try$);
}
}));
cljs.compiler.emit_let = (function cljs$compiler$emit_let(p__31453,is_loop){
var map__31465 = p__31453;
var map__31465__$1 = ((((!((map__31465 == null)))?((((map__31465.cljs$lang$protocol_mask$partition0$ & (64))) || (map__31465.cljs$core$ISeq$))?true:false):false))?cljs.core.apply.call(null,cljs.core.hash_map,map__31465):map__31465);
var bindings = cljs.core.get.call(null,map__31465__$1,new cljs.core.Keyword(null,"bindings","bindings",1271397192));
var expr = cljs.core.get.call(null,map__31465__$1,new cljs.core.Keyword(null,"expr","expr",745722291));
var env = cljs.core.get.call(null,map__31465__$1,new cljs.core.Keyword(null,"env","env",-1815813235));
var context = new cljs.core.Keyword(null,"context","context",-830191113).cljs$core$IFn$_invoke$arity$1(env);
if(cljs.core._EQ_.call(null,new cljs.core.Keyword(null,"expr","expr",745722291),context)){
cljs.compiler.emits.call(null,"(function (){");
} else {
}

var _STAR_lexical_renames_STAR_31467_31476 = cljs.compiler._STAR_lexical_renames_STAR_;
cljs.compiler._STAR_lexical_renames_STAR_ = cljs.core.into.call(null,cljs.compiler._STAR_lexical_renames_STAR_,((cljs.core._EQ_.call(null,new cljs.core.Keyword(null,"statement","statement",-32780863),context))?cljs.core.map.call(null,((function (_STAR_lexical_renames_STAR_31467_31476,context,map__31465,map__31465__$1,bindings,expr,env){
return (function (binding){
var name = new cljs.core.Keyword(null,"name","name",1843675177).cljs$core$IFn$_invoke$arity$1(binding);
return (new cljs.core.PersistentVector(null,2,(5),cljs.core.PersistentVector.EMPTY_NODE,[cljs.compiler.hash_scope.call(null,binding),cljs.core.gensym.call(null,[cljs.core.str(name),cljs.core.str("-")].join(''))],null));
});})(_STAR_lexical_renames_STAR_31467_31476,context,map__31465,map__31465__$1,bindings,expr,env))
,bindings):null));

try{var seq__31468_31477 = cljs.core.seq.call(null,bindings);
var chunk__31469_31478 = null;
var count__31470_31479 = (0);
var i__31471_31480 = (0);
while(true){
if((i__31471_31480 < count__31470_31479)){
var map__31472_31481 = cljs.core._nth.call(null,chunk__31469_31478,i__31471_31480);
var map__31472_31482__$1 = ((((!((map__31472_31481 == null)))?((((map__31472_31481.cljs$lang$protocol_mask$partition0$ & (64))) || (map__31472_31481.cljs$core$ISeq$))?true:false):false))?cljs.core.apply.call(null,cljs.core.hash_map,map__31472_31481):map__31472_31481);
var binding_31483 = map__31472_31482__$1;
var init_31484 = cljs.core.get.call(null,map__31472_31482__$1,new cljs.core.Keyword(null,"init","init",-1875481434));
cljs.compiler.emits.call(null,"var ");

cljs.compiler.emit.call(null,binding_31483);

cljs.compiler.emitln.call(null," = ",init_31484,";");

var G__31485 = seq__31468_31477;
var G__31486 = chunk__31469_31478;
var G__31487 = count__31470_31479;
var G__31488 = (i__31471_31480 + (1));
seq__31468_31477 = G__31485;
chunk__31469_31478 = G__31486;
count__31470_31479 = G__31487;
i__31471_31480 = G__31488;
continue;
} else {
var temp__4657__auto___31489 = cljs.core.seq.call(null,seq__31468_31477);
if(temp__4657__auto___31489){
var seq__31468_31490__$1 = temp__4657__auto___31489;
if(cljs.core.chunked_seq_QMARK_.call(null,seq__31468_31490__$1)){
var c__23696__auto___31491 = cljs.core.chunk_first.call(null,seq__31468_31490__$1);
var G__31492 = cljs.core.chunk_rest.call(null,seq__31468_31490__$1);
var G__31493 = c__23696__auto___31491;
var G__31494 = cljs.core.count.call(null,c__23696__auto___31491);
var G__31495 = (0);
seq__31468_31477 = G__31492;
chunk__31469_31478 = G__31493;
count__31470_31479 = G__31494;
i__31471_31480 = G__31495;
continue;
} else {
var map__31474_31496 = cljs.core.first.call(null,seq__31468_31490__$1);
var map__31474_31497__$1 = ((((!((map__31474_31496 == null)))?((((map__31474_31496.cljs$lang$protocol_mask$partition0$ & (64))) || (map__31474_31496.cljs$core$ISeq$))?true:false):false))?cljs.core.apply.call(null,cljs.core.hash_map,map__31474_31496):map__31474_31496);
var binding_31498 = map__31474_31497__$1;
var init_31499 = cljs.core.get.call(null,map__31474_31497__$1,new cljs.core.Keyword(null,"init","init",-1875481434));
cljs.compiler.emits.call(null,"var ");

cljs.compiler.emit.call(null,binding_31498);

cljs.compiler.emitln.call(null," = ",init_31499,";");

var G__31500 = cljs.core.next.call(null,seq__31468_31490__$1);
var G__31501 = null;
var G__31502 = (0);
var G__31503 = (0);
seq__31468_31477 = G__31500;
chunk__31469_31478 = G__31501;
count__31470_31479 = G__31502;
i__31471_31480 = G__31503;
continue;
}
} else {
}
}
break;
}

if(cljs.core.truth_(is_loop)){
cljs.compiler.emitln.call(null,"while(true){");
} else {
}

cljs.compiler.emits.call(null,expr);

if(cljs.core.truth_(is_loop)){
cljs.compiler.emitln.call(null,"break;");

cljs.compiler.emitln.call(null,"}");
} else {
}
}finally {cljs.compiler._STAR_lexical_renames_STAR_ = _STAR_lexical_renames_STAR_31467_31476;
}
if(cljs.core._EQ_.call(null,new cljs.core.Keyword(null,"expr","expr",745722291),context)){
return cljs.compiler.emits.call(null,"})()");
} else {
return null;
}
});
cljs.core._add_method.call(null,cljs.compiler.emit_STAR_,new cljs.core.Keyword(null,"let","let",-1282412701),(function (ast){
return cljs.compiler.emit_let.call(null,ast,false);
}));
cljs.core._add_method.call(null,cljs.compiler.emit_STAR_,new cljs.core.Keyword(null,"loop","loop",-395552849),(function (ast){
return cljs.compiler.emit_let.call(null,ast,true);
}));
cljs.core._add_method.call(null,cljs.compiler.emit_STAR_,new cljs.core.Keyword(null,"recur","recur",-437573268),(function (p__31504){
var map__31505 = p__31504;
var map__31505__$1 = ((((!((map__31505 == null)))?((((map__31505.cljs$lang$protocol_mask$partition0$ & (64))) || (map__31505.cljs$core$ISeq$))?true:false):false))?cljs.core.apply.call(null,cljs.core.hash_map,map__31505):map__31505);
var frame = cljs.core.get.call(null,map__31505__$1,new cljs.core.Keyword(null,"frame","frame",-1711082588));
var exprs = cljs.core.get.call(null,map__31505__$1,new cljs.core.Keyword(null,"exprs","exprs",1795829094));
var env = cljs.core.get.call(null,map__31505__$1,new cljs.core.Keyword(null,"env","env",-1815813235));
var temps = cljs.core.vec.call(null,cljs.core.take.call(null,cljs.core.count.call(null,exprs),cljs.core.repeatedly.call(null,cljs.core.gensym)));
var params = new cljs.core.Keyword(null,"params","params",710516235).cljs$core$IFn$_invoke$arity$1(frame);
var n__23800__auto___31507 = cljs.core.count.call(null,exprs);
var i_31508 = (0);
while(true){
if((i_31508 < n__23800__auto___31507)){
cljs.compiler.emitln.call(null,"var ",temps.call(null,i_31508)," = ",exprs.call(null,i_31508),";");

var G__31509 = (i_31508 + (1));
i_31508 = G__31509;
continue;
} else {
}
break;
}

var n__23800__auto___31510 = cljs.core.count.call(null,exprs);
var i_31511 = (0);
while(true){
if((i_31511 < n__23800__auto___31510)){
cljs.compiler.emitln.call(null,cljs.compiler.munge.call(null,params.call(null,i_31511))," = ",temps.call(null,i_31511),";");

var G__31512 = (i_31511 + (1));
i_31511 = G__31512;
continue;
} else {
}
break;
}

return cljs.compiler.emitln.call(null,"continue;");
}));
cljs.core._add_method.call(null,cljs.compiler.emit_STAR_,new cljs.core.Keyword(null,"letfn","letfn",-2121022354),(function (p__31513){
var map__31514 = p__31513;
var map__31514__$1 = ((((!((map__31514 == null)))?((((map__31514.cljs$lang$protocol_mask$partition0$ & (64))) || (map__31514.cljs$core$ISeq$))?true:false):false))?cljs.core.apply.call(null,cljs.core.hash_map,map__31514):map__31514);
var bindings = cljs.core.get.call(null,map__31514__$1,new cljs.core.Keyword(null,"bindings","bindings",1271397192));
var expr = cljs.core.get.call(null,map__31514__$1,new cljs.core.Keyword(null,"expr","expr",745722291));
var env = cljs.core.get.call(null,map__31514__$1,new cljs.core.Keyword(null,"env","env",-1815813235));
var context = new cljs.core.Keyword(null,"context","context",-830191113).cljs$core$IFn$_invoke$arity$1(env);
if(cljs.core._EQ_.call(null,new cljs.core.Keyword(null,"expr","expr",745722291),context)){
cljs.compiler.emits.call(null,"(function (){");
} else {
}

var seq__31516_31524 = cljs.core.seq.call(null,bindings);
var chunk__31517_31525 = null;
var count__31518_31526 = (0);
var i__31519_31527 = (0);
while(true){
if((i__31519_31527 < count__31518_31526)){
var map__31520_31528 = cljs.core._nth.call(null,chunk__31517_31525,i__31519_31527);
var map__31520_31529__$1 = ((((!((map__31520_31528 == null)))?((((map__31520_31528.cljs$lang$protocol_mask$partition0$ & (64))) || (map__31520_31528.cljs$core$ISeq$))?true:false):false))?cljs.core.apply.call(null,cljs.core.hash_map,map__31520_31528):map__31520_31528);
var binding_31530 = map__31520_31529__$1;
var init_31531 = cljs.core.get.call(null,map__31520_31529__$1,new cljs.core.Keyword(null,"init","init",-1875481434));
cljs.compiler.emitln.call(null,"var ",cljs.compiler.munge.call(null,binding_31530)," = ",init_31531,";");

var G__31532 = seq__31516_31524;
var G__31533 = chunk__31517_31525;
var G__31534 = count__31518_31526;
var G__31535 = (i__31519_31527 + (1));
seq__31516_31524 = G__31532;
chunk__31517_31525 = G__31533;
count__31518_31526 = G__31534;
i__31519_31527 = G__31535;
continue;
} else {
var temp__4657__auto___31536 = cljs.core.seq.call(null,seq__31516_31524);
if(temp__4657__auto___31536){
var seq__31516_31537__$1 = temp__4657__auto___31536;
if(cljs.core.chunked_seq_QMARK_.call(null,seq__31516_31537__$1)){
var c__23696__auto___31538 = cljs.core.chunk_first.call(null,seq__31516_31537__$1);
var G__31539 = cljs.core.chunk_rest.call(null,seq__31516_31537__$1);
var G__31540 = c__23696__auto___31538;
var G__31541 = cljs.core.count.call(null,c__23696__auto___31538);
var G__31542 = (0);
seq__31516_31524 = G__31539;
chunk__31517_31525 = G__31540;
count__31518_31526 = G__31541;
i__31519_31527 = G__31542;
continue;
} else {
var map__31522_31543 = cljs.core.first.call(null,seq__31516_31537__$1);
var map__31522_31544__$1 = ((((!((map__31522_31543 == null)))?((((map__31522_31543.cljs$lang$protocol_mask$partition0$ & (64))) || (map__31522_31543.cljs$core$ISeq$))?true:false):false))?cljs.core.apply.call(null,cljs.core.hash_map,map__31522_31543):map__31522_31543);
var binding_31545 = map__31522_31544__$1;
var init_31546 = cljs.core.get.call(null,map__31522_31544__$1,new cljs.core.Keyword(null,"init","init",-1875481434));
cljs.compiler.emitln.call(null,"var ",cljs.compiler.munge.call(null,binding_31545)," = ",init_31546,";");

var G__31547 = cljs.core.next.call(null,seq__31516_31537__$1);
var G__31548 = null;
var G__31549 = (0);
var G__31550 = (0);
seq__31516_31524 = G__31547;
chunk__31517_31525 = G__31548;
count__31518_31526 = G__31549;
i__31519_31527 = G__31550;
continue;
}
} else {
}
}
break;
}

cljs.compiler.emits.call(null,expr);

if(cljs.core._EQ_.call(null,new cljs.core.Keyword(null,"expr","expr",745722291),context)){
return cljs.compiler.emits.call(null,"})()");
} else {
return null;
}
}));
cljs.compiler.protocol_prefix = (function cljs$compiler$protocol_prefix(psym){
return cljs.core.symbol.call(null,[cljs.core.str([cljs.core.str(psym)].join('').replace((new RegExp("\\.","g")),"$").replace("/","$")),cljs.core.str("$")].join(''));
});
cljs.core._add_method.call(null,cljs.compiler.emit_STAR_,new cljs.core.Keyword(null,"invoke","invoke",1145927159),(function (p__31553){
var map__31554 = p__31553;
var map__31554__$1 = ((((!((map__31554 == null)))?((((map__31554.cljs$lang$protocol_mask$partition0$ & (64))) || (map__31554.cljs$core$ISeq$))?true:false):false))?cljs.core.apply.call(null,cljs.core.hash_map,map__31554):map__31554);
var expr = map__31554__$1;
var f = cljs.core.get.call(null,map__31554__$1,new cljs.core.Keyword(null,"f","f",-1597136552));
var args = cljs.core.get.call(null,map__31554__$1,new cljs.core.Keyword(null,"args","args",1315556576));
var env = cljs.core.get.call(null,map__31554__$1,new cljs.core.Keyword(null,"env","env",-1815813235));
var info = new cljs.core.Keyword(null,"info","info",-317069002).cljs$core$IFn$_invoke$arity$1(f);
var fn_QMARK_ = (function (){var and__22873__auto__ = cljs.analyzer._STAR_cljs_static_fns_STAR_;
if(cljs.core.truth_(and__22873__auto__)){
var and__22873__auto____$1 = cljs.core.not.call(null,new cljs.core.Keyword(null,"dynamic","dynamic",704819571).cljs$core$IFn$_invoke$arity$1(info));
if(and__22873__auto____$1){
return new cljs.core.Keyword(null,"fn-var","fn-var",1086204730).cljs$core$IFn$_invoke$arity$1(info);
} else {
return and__22873__auto____$1;
}
} else {
return and__22873__auto__;
}
})();
var protocol = new cljs.core.Keyword(null,"protocol","protocol",652470118).cljs$core$IFn$_invoke$arity$1(info);
var tag = cljs.analyzer.infer_tag.call(null,env,cljs.core.first.call(null,new cljs.core.Keyword(null,"args","args",1315556576).cljs$core$IFn$_invoke$arity$1(expr)));
var proto_QMARK_ = (function (){var and__22873__auto__ = protocol;
if(cljs.core.truth_(and__22873__auto__)){
var and__22873__auto____$1 = tag;
if(cljs.core.truth_(and__22873__auto____$1)){
var or__22885__auto__ = (function (){var and__22873__auto____$2 = cljs.analyzer._STAR_cljs_static_fns_STAR_;
if(cljs.core.truth_(and__22873__auto____$2)){
var and__22873__auto____$3 = protocol;
if(cljs.core.truth_(and__22873__auto____$3)){
return cljs.core._EQ_.call(null,tag,new cljs.core.Symbol(null,"not-native","not-native",-236392494,null));
} else {
return and__22873__auto____$3;
}
} else {
return and__22873__auto____$2;
}
})();
if(cljs.core.truth_(or__22885__auto__)){
return or__22885__auto__;
} else {
var and__22873__auto____$2 = (function (){var or__22885__auto____$1 = cljs.analyzer._STAR_cljs_static_fns_STAR_;
if(cljs.core.truth_(or__22885__auto____$1)){
return or__22885__auto____$1;
} else {
return new cljs.core.Keyword(null,"protocol-inline","protocol-inline",1550487556).cljs$core$IFn$_invoke$arity$1(env);
}
})();
if(cljs.core.truth_(and__22873__auto____$2)){
var or__22885__auto____$1 = cljs.core._EQ_.call(null,protocol,tag);
if(or__22885__auto____$1){
return or__22885__auto____$1;
} else {
var and__22873__auto____$3 = !(cljs.core.set_QMARK_.call(null,tag));
if(and__22873__auto____$3){
var and__22873__auto____$4 = cljs.core.not.call(null,new cljs.core.PersistentHashSet(null, new cljs.core.PersistentArrayMap(null, 10, [new cljs.core.Symbol(null,"clj","clj",980036099,null),null,new cljs.core.Symbol(null,"boolean","boolean",-278886877,null),null,new cljs.core.Symbol(null,"object","object",-1179821820,null),null,new cljs.core.Symbol(null,"any","any",-948528346,null),null,new cljs.core.Symbol(null,"number","number",-1084057331,null),null,new cljs.core.Symbol(null,"clj-or-nil","clj-or-nil",-2008798668,null),null,new cljs.core.Symbol(null,"array","array",-440182315,null),null,new cljs.core.Symbol(null,"string","string",-349010059,null),null,new cljs.core.Symbol(null,"function","function",-486723946,null),null,new cljs.core.Symbol(null,"clj-nil","clj-nil",1321798654,null),null], null), null).call(null,tag));
if(and__22873__auto____$4){
var temp__4657__auto__ = new cljs.core.Keyword(null,"protocols","protocols",-5615896).cljs$core$IFn$_invoke$arity$1(cljs.analyzer.resolve_existing_var.call(null,cljs.core.dissoc.call(null,env,new cljs.core.Keyword(null,"locals","locals",535295783)),tag));
if(cljs.core.truth_(temp__4657__auto__)){
var ps = temp__4657__auto__;
return ps.call(null,protocol);
} else {
return null;
}
} else {
return and__22873__auto____$4;
}
} else {
return and__22873__auto____$3;
}
}
} else {
return and__22873__auto____$2;
}
}
} else {
return and__22873__auto____$1;
}
} else {
return and__22873__auto__;
}
})();
var opt_not_QMARK_ = (cljs.core._EQ_.call(null,new cljs.core.Keyword(null,"name","name",1843675177).cljs$core$IFn$_invoke$arity$1(info),new cljs.core.Symbol("cljs.core","not","cljs.core/not",100665144,null))) && (cljs.core._EQ_.call(null,cljs.analyzer.infer_tag.call(null,env,cljs.core.first.call(null,new cljs.core.Keyword(null,"args","args",1315556576).cljs$core$IFn$_invoke$arity$1(expr))),new cljs.core.Symbol(null,"boolean","boolean",-278886877,null)));
var ns = new cljs.core.Keyword(null,"ns","ns",441598760).cljs$core$IFn$_invoke$arity$1(info);
var js_QMARK_ = (cljs.core._EQ_.call(null,ns,new cljs.core.Symbol(null,"js","js",-886355190,null))) || (cljs.core._EQ_.call(null,ns,new cljs.core.Symbol(null,"Math","Math",2033287572,null)));
var goog_QMARK_ = (cljs.core.truth_(ns)?(function (){var or__22885__auto__ = cljs.core._EQ_.call(null,ns,new cljs.core.Symbol(null,"goog","goog",-70603925,null));
if(or__22885__auto__){
return or__22885__auto__;
} else {
var temp__4657__auto__ = [cljs.core.str(ns)].join('');
if(cljs.core.truth_(temp__4657__auto__)){
var ns_str = temp__4657__auto__;
return cljs.core._EQ_.call(null,cljs.core.get.call(null,clojure.string.split.call(null,ns_str,/\./),(0),null),"goog");
} else {
return null;
}
}
})():null);
var keyword_QMARK_ = (cljs.core._EQ_.call(null,new cljs.core.Keyword(null,"op","op",-1882987955).cljs$core$IFn$_invoke$arity$1(f),new cljs.core.Keyword(null,"constant","constant",-379609303))) && ((new cljs.core.Keyword(null,"form","form",-1624062471).cljs$core$IFn$_invoke$arity$1(f) instanceof cljs.core.Keyword));
var vec__31556 = (cljs.core.truth_(fn_QMARK_)?(function (){var arity = cljs.core.count.call(null,args);
var variadic_QMARK_ = new cljs.core.Keyword(null,"variadic","variadic",882626057).cljs$core$IFn$_invoke$arity$1(info);
var mps = new cljs.core.Keyword(null,"method-params","method-params",-980792179).cljs$core$IFn$_invoke$arity$1(info);
var mfa = new cljs.core.Keyword(null,"max-fixed-arity","max-fixed-arity",-690205543).cljs$core$IFn$_invoke$arity$1(info);
if((cljs.core.not.call(null,variadic_QMARK_)) && (cljs.core._EQ_.call(null,cljs.core.count.call(null,mps),(1)))){
return new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [f,null], null);
} else {
if(cljs.core.truth_((function (){var and__22873__auto__ = variadic_QMARK_;
if(cljs.core.truth_(and__22873__auto__)){
return (arity > mfa);
} else {
return and__22873__auto__;
}
})())){
return new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.update_in.call(null,f,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword(null,"info","info",-317069002)], null),((function (arity,variadic_QMARK_,mps,mfa,info,fn_QMARK_,protocol,tag,proto_QMARK_,opt_not_QMARK_,ns,js_QMARK_,goog_QMARK_,keyword_QMARK_,map__31554,map__31554__$1,expr,f,args,env){
return (function (info__$1){
return cljs.core.update_in.call(null,cljs.core.assoc.call(null,info__$1,new cljs.core.Keyword(null,"name","name",1843675177),cljs.core.symbol.call(null,[cljs.core.str(cljs.compiler.munge.call(null,info__$1)),cljs.core.str(".cljs$core$IFn$_invoke$arity$variadic")].join(''))),new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword(null,"info","info",-317069002)], null),((function (arity,variadic_QMARK_,mps,mfa,info,fn_QMARK_,protocol,tag,proto_QMARK_,opt_not_QMARK_,ns,js_QMARK_,goog_QMARK_,keyword_QMARK_,map__31554,map__31554__$1,expr,f,args,env){
return (function (p1__31551_SHARP_){
return cljs.core.dissoc.call(null,cljs.core.dissoc.call(null,p1__31551_SHARP_,new cljs.core.Keyword(null,"shadow","shadow",873231803)),new cljs.core.Keyword(null,"fn-self-name","fn-self-name",1461143531));
});})(arity,variadic_QMARK_,mps,mfa,info,fn_QMARK_,protocol,tag,proto_QMARK_,opt_not_QMARK_,ns,js_QMARK_,goog_QMARK_,keyword_QMARK_,map__31554,map__31554__$1,expr,f,args,env))
);
});})(arity,variadic_QMARK_,mps,mfa,info,fn_QMARK_,protocol,tag,proto_QMARK_,opt_not_QMARK_,ns,js_QMARK_,goog_QMARK_,keyword_QMARK_,map__31554,map__31554__$1,expr,f,args,env))
),new cljs.core.PersistentArrayMap(null, 1, [new cljs.core.Keyword(null,"max-fixed-arity","max-fixed-arity",-690205543),mfa], null)], null);
} else {
var arities = cljs.core.map.call(null,cljs.core.count,mps);
if(cljs.core.truth_(cljs.core.some.call(null,cljs.core.PersistentHashSet.fromArray([arity], true),arities))){
return new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.update_in.call(null,f,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword(null,"info","info",-317069002)], null),((function (arities,arity,variadic_QMARK_,mps,mfa,info,fn_QMARK_,protocol,tag,proto_QMARK_,opt_not_QMARK_,ns,js_QMARK_,goog_QMARK_,keyword_QMARK_,map__31554,map__31554__$1,expr,f,args,env){
return (function (info__$1){
return cljs.core.update_in.call(null,cljs.core.assoc.call(null,info__$1,new cljs.core.Keyword(null,"name","name",1843675177),cljs.core.symbol.call(null,[cljs.core.str(cljs.compiler.munge.call(null,info__$1)),cljs.core.str(".cljs$core$IFn$_invoke$arity$"),cljs.core.str(arity)].join(''))),new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword(null,"info","info",-317069002)], null),((function (arities,arity,variadic_QMARK_,mps,mfa,info,fn_QMARK_,protocol,tag,proto_QMARK_,opt_not_QMARK_,ns,js_QMARK_,goog_QMARK_,keyword_QMARK_,map__31554,map__31554__$1,expr,f,args,env){
return (function (p1__31552_SHARP_){
return cljs.core.dissoc.call(null,cljs.core.dissoc.call(null,p1__31552_SHARP_,new cljs.core.Keyword(null,"shadow","shadow",873231803)),new cljs.core.Keyword(null,"fn-self-name","fn-self-name",1461143531));
});})(arities,arity,variadic_QMARK_,mps,mfa,info,fn_QMARK_,protocol,tag,proto_QMARK_,opt_not_QMARK_,ns,js_QMARK_,goog_QMARK_,keyword_QMARK_,map__31554,map__31554__$1,expr,f,args,env))
);
});})(arities,arity,variadic_QMARK_,mps,mfa,info,fn_QMARK_,protocol,tag,proto_QMARK_,opt_not_QMARK_,ns,js_QMARK_,goog_QMARK_,keyword_QMARK_,map__31554,map__31554__$1,expr,f,args,env))
),null], null);
} else {
return new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [f,null], null);
}

}
}
})():new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [f,null], null));
var f__$1 = cljs.core.nth.call(null,vec__31556,(0),null);
var variadic_invoke = cljs.core.nth.call(null,vec__31556,(1),null);
var env__24998__auto__ = env;
if(cljs.core._EQ_.call(null,new cljs.core.Keyword(null,"return","return",-1891502105),new cljs.core.Keyword(null,"context","context",-830191113).cljs$core$IFn$_invoke$arity$1(env__24998__auto__))){
cljs.compiler.emits.call(null,"return ");
} else {
}

if(opt_not_QMARK_){
cljs.compiler.emits.call(null,"!(",cljs.core.first.call(null,args),")");
} else {
if(cljs.core.truth_(proto_QMARK_)){
var pimpl_31557 = [cljs.core.str(cljs.compiler.munge.call(null,cljs.compiler.protocol_prefix.call(null,protocol))),cljs.core.str(cljs.compiler.munge.call(null,cljs.core.name.call(null,new cljs.core.Keyword(null,"name","name",1843675177).cljs$core$IFn$_invoke$arity$1(info)))),cljs.core.str("$arity$"),cljs.core.str(cljs.core.count.call(null,args))].join('');
cljs.compiler.emits.call(null,cljs.core.first.call(null,args),".",pimpl_31557,"(",cljs.compiler.comma_sep.call(null,cljs.core.cons.call(null,"null",cljs.core.rest.call(null,args))),")");
} else {
if(keyword_QMARK_){
cljs.compiler.emits.call(null,f__$1,".cljs$core$IFn$_invoke$arity$",cljs.core.count.call(null,args),"(",cljs.compiler.comma_sep.call(null,args),")");
} else {
if(cljs.core.truth_(variadic_invoke)){
var mfa_31558 = new cljs.core.Keyword(null,"max-fixed-arity","max-fixed-arity",-690205543).cljs$core$IFn$_invoke$arity$1(variadic_invoke);
cljs.compiler.emits.call(null,f__$1,"(",cljs.compiler.comma_sep.call(null,cljs.core.take.call(null,mfa_31558,args)),(((mfa_31558 === (0)))?null:","),"cljs.core.array_seq([",cljs.compiler.comma_sep.call(null,cljs.core.drop.call(null,mfa_31558,args)),"], 0))");
} else {
if(cljs.core.truth_((function (){var or__22885__auto__ = fn_QMARK_;
if(cljs.core.truth_(or__22885__auto__)){
return or__22885__auto__;
} else {
var or__22885__auto____$1 = js_QMARK_;
if(or__22885__auto____$1){
return or__22885__auto____$1;
} else {
return goog_QMARK_;
}
}
})())){
cljs.compiler.emits.call(null,f__$1,"(",cljs.compiler.comma_sep.call(null,args),")");
} else {
if(cljs.core.truth_((function (){var and__22873__auto__ = cljs.analyzer._STAR_cljs_static_fns_STAR_;
if(cljs.core.truth_(and__22873__auto__)){
return cljs.core._EQ_.call(null,new cljs.core.Keyword(null,"op","op",-1882987955).cljs$core$IFn$_invoke$arity$1(f__$1),new cljs.core.Keyword(null,"var","var",-769682797));
} else {
return and__22873__auto__;
}
})())){
var fprop_31559 = [cljs.core.str(".cljs$core$IFn$_invoke$arity$"),cljs.core.str(cljs.core.count.call(null,args))].join('');
cljs.compiler.emits.call(null,"(",f__$1,fprop_31559," ? ",f__$1,fprop_31559,"(",cljs.compiler.comma_sep.call(null,args),") : ",f__$1,".call(",cljs.compiler.comma_sep.call(null,cljs.core.cons.call(null,"null",args)),"))");
} else {
cljs.compiler.emits.call(null,f__$1,".call(",cljs.compiler.comma_sep.call(null,cljs.core.cons.call(null,"null",args)),")");
}

}
}
}
}
}

if(cljs.core._EQ_.call(null,new cljs.core.Keyword(null,"expr","expr",745722291),new cljs.core.Keyword(null,"context","context",-830191113).cljs$core$IFn$_invoke$arity$1(env__24998__auto__))){
return null;
} else {
return cljs.compiler.emitln.call(null,";");
}
}));
cljs.core._add_method.call(null,cljs.compiler.emit_STAR_,new cljs.core.Keyword(null,"new","new",-2085437848),(function (p__31560){
var map__31561 = p__31560;
var map__31561__$1 = ((((!((map__31561 == null)))?((((map__31561.cljs$lang$protocol_mask$partition0$ & (64))) || (map__31561.cljs$core$ISeq$))?true:false):false))?cljs.core.apply.call(null,cljs.core.hash_map,map__31561):map__31561);
var ctor = cljs.core.get.call(null,map__31561__$1,new cljs.core.Keyword(null,"ctor","ctor",1750864802));
var args = cljs.core.get.call(null,map__31561__$1,new cljs.core.Keyword(null,"args","args",1315556576));
var env = cljs.core.get.call(null,map__31561__$1,new cljs.core.Keyword(null,"env","env",-1815813235));
var env__24998__auto__ = env;
if(cljs.core._EQ_.call(null,new cljs.core.Keyword(null,"return","return",-1891502105),new cljs.core.Keyword(null,"context","context",-830191113).cljs$core$IFn$_invoke$arity$1(env__24998__auto__))){
cljs.compiler.emits.call(null,"return ");
} else {
}

cljs.compiler.emits.call(null,"(new ",ctor,"(",cljs.compiler.comma_sep.call(null,args),"))");

if(cljs.core._EQ_.call(null,new cljs.core.Keyword(null,"expr","expr",745722291),new cljs.core.Keyword(null,"context","context",-830191113).cljs$core$IFn$_invoke$arity$1(env__24998__auto__))){
return null;
} else {
return cljs.compiler.emitln.call(null,";");
}
}));
cljs.core._add_method.call(null,cljs.compiler.emit_STAR_,new cljs.core.Keyword(null,"set!","set!",-1389817006),(function (p__31563){
var map__31564 = p__31563;
var map__31564__$1 = ((((!((map__31564 == null)))?((((map__31564.cljs$lang$protocol_mask$partition0$ & (64))) || (map__31564.cljs$core$ISeq$))?true:false):false))?cljs.core.apply.call(null,cljs.core.hash_map,map__31564):map__31564);
var target = cljs.core.get.call(null,map__31564__$1,new cljs.core.Keyword(null,"target","target",253001721));
var val = cljs.core.get.call(null,map__31564__$1,new cljs.core.Keyword(null,"val","val",128701612));
var env = cljs.core.get.call(null,map__31564__$1,new cljs.core.Keyword(null,"env","env",-1815813235));
var env__24998__auto__ = env;
if(cljs.core._EQ_.call(null,new cljs.core.Keyword(null,"return","return",-1891502105),new cljs.core.Keyword(null,"context","context",-830191113).cljs$core$IFn$_invoke$arity$1(env__24998__auto__))){
cljs.compiler.emits.call(null,"return ");
} else {
}

cljs.compiler.emits.call(null,target," = ",val);

if(cljs.core._EQ_.call(null,new cljs.core.Keyword(null,"expr","expr",745722291),new cljs.core.Keyword(null,"context","context",-830191113).cljs$core$IFn$_invoke$arity$1(env__24998__auto__))){
return null;
} else {
return cljs.compiler.emitln.call(null,";");
}
}));
cljs.compiler.load_libs = (function cljs$compiler$load_libs(libs,seen,reloads){
var loaded_libs = cljs.compiler.munge.call(null,new cljs.core.Symbol(null,"cljs.core.*loaded-libs*","cljs.core.*loaded-libs*",-1847086525,null));
var loaded_libs_temp = cljs.compiler.munge.call(null,cljs.core.gensym.call(null,new cljs.core.Symbol(null,"cljs.core.*loaded-libs*","cljs.core.*loaded-libs*",-1847086525,null)));
if(cljs.core.truth_(new cljs.core.Keyword(null,"reload-all","reload-all",761570200).cljs$core$IFn$_invoke$arity$1(cljs.core.meta.call(null,libs)))){
cljs.compiler.emitln.call(null,"if(!COMPILED) ",loaded_libs_temp," = ",loaded_libs," || cljs.core.set();");

cljs.compiler.emitln.call(null,"if(!COMPILED) ",loaded_libs," = cljs.core.set();");
} else {
}

var seq__31570_31574 = cljs.core.seq.call(null,cljs.core.remove.call(null,cljs.core.set.call(null,cljs.core.vals.call(null,seen)),cljs.core.distinct.call(null,cljs.core.vals.call(null,libs))));
var chunk__31571_31575 = null;
var count__31572_31576 = (0);
var i__31573_31577 = (0);
while(true){
if((i__31573_31577 < count__31572_31576)){
var lib_31578 = cljs.core._nth.call(null,chunk__31571_31575,i__31573_31577);
if(cljs.core.truth_((function (){var or__22885__auto__ = new cljs.core.Keyword(null,"reload","reload",863702807).cljs$core$IFn$_invoke$arity$1(cljs.core.meta.call(null,libs));
if(cljs.core.truth_(or__22885__auto__)){
return or__22885__auto__;
} else {
return cljs.core._EQ_.call(null,cljs.core.get.call(null,reloads,lib_31578),new cljs.core.Keyword(null,"reload","reload",863702807));
}
})())){
cljs.compiler.emitln.call(null,"goog.require('",cljs.compiler.munge.call(null,lib_31578),"', 'reload');");
} else {
if(cljs.core.truth_((function (){var or__22885__auto__ = new cljs.core.Keyword(null,"reload-all","reload-all",761570200).cljs$core$IFn$_invoke$arity$1(cljs.core.meta.call(null,libs));
if(cljs.core.truth_(or__22885__auto__)){
return or__22885__auto__;
} else {
return cljs.core._EQ_.call(null,cljs.core.get.call(null,reloads,lib_31578),new cljs.core.Keyword(null,"reload-all","reload-all",761570200));
}
})())){
cljs.compiler.emitln.call(null,"goog.require('",cljs.compiler.munge.call(null,lib_31578),"', 'reload-all');");
} else {
cljs.compiler.emitln.call(null,"goog.require('",cljs.compiler.munge.call(null,lib_31578),"');");

}
}

var G__31579 = seq__31570_31574;
var G__31580 = chunk__31571_31575;
var G__31581 = count__31572_31576;
var G__31582 = (i__31573_31577 + (1));
seq__31570_31574 = G__31579;
chunk__31571_31575 = G__31580;
count__31572_31576 = G__31581;
i__31573_31577 = G__31582;
continue;
} else {
var temp__4657__auto___31583 = cljs.core.seq.call(null,seq__31570_31574);
if(temp__4657__auto___31583){
var seq__31570_31584__$1 = temp__4657__auto___31583;
if(cljs.core.chunked_seq_QMARK_.call(null,seq__31570_31584__$1)){
var c__23696__auto___31585 = cljs.core.chunk_first.call(null,seq__31570_31584__$1);
var G__31586 = cljs.core.chunk_rest.call(null,seq__31570_31584__$1);
var G__31587 = c__23696__auto___31585;
var G__31588 = cljs.core.count.call(null,c__23696__auto___31585);
var G__31589 = (0);
seq__31570_31574 = G__31586;
chunk__31571_31575 = G__31587;
count__31572_31576 = G__31588;
i__31573_31577 = G__31589;
continue;
} else {
var lib_31590 = cljs.core.first.call(null,seq__31570_31584__$1);
if(cljs.core.truth_((function (){var or__22885__auto__ = new cljs.core.Keyword(null,"reload","reload",863702807).cljs$core$IFn$_invoke$arity$1(cljs.core.meta.call(null,libs));
if(cljs.core.truth_(or__22885__auto__)){
return or__22885__auto__;
} else {
return cljs.core._EQ_.call(null,cljs.core.get.call(null,reloads,lib_31590),new cljs.core.Keyword(null,"reload","reload",863702807));
}
})())){
cljs.compiler.emitln.call(null,"goog.require('",cljs.compiler.munge.call(null,lib_31590),"', 'reload');");
} else {
if(cljs.core.truth_((function (){var or__22885__auto__ = new cljs.core.Keyword(null,"reload-all","reload-all",761570200).cljs$core$IFn$_invoke$arity$1(cljs.core.meta.call(null,libs));
if(cljs.core.truth_(or__22885__auto__)){
return or__22885__auto__;
} else {
return cljs.core._EQ_.call(null,cljs.core.get.call(null,reloads,lib_31590),new cljs.core.Keyword(null,"reload-all","reload-all",761570200));
}
})())){
cljs.compiler.emitln.call(null,"goog.require('",cljs.compiler.munge.call(null,lib_31590),"', 'reload-all');");
} else {
cljs.compiler.emitln.call(null,"goog.require('",cljs.compiler.munge.call(null,lib_31590),"');");

}
}

var G__31591 = cljs.core.next.call(null,seq__31570_31584__$1);
var G__31592 = null;
var G__31593 = (0);
var G__31594 = (0);
seq__31570_31574 = G__31591;
chunk__31571_31575 = G__31592;
count__31572_31576 = G__31593;
i__31573_31577 = G__31594;
continue;
}
} else {
}
}
break;
}

if(cljs.core.truth_(new cljs.core.Keyword(null,"reload-all","reload-all",761570200).cljs$core$IFn$_invoke$arity$1(cljs.core.meta.call(null,libs)))){
return cljs.compiler.emitln.call(null,"if(!COMPILED) ",loaded_libs," = cljs.core.into(",loaded_libs_temp,", ",loaded_libs,");");
} else {
return null;
}
});
cljs.core._add_method.call(null,cljs.compiler.emit_STAR_,new cljs.core.Keyword(null,"ns","ns",441598760),(function (p__31595){
var map__31596 = p__31595;
var map__31596__$1 = ((((!((map__31596 == null)))?((((map__31596.cljs$lang$protocol_mask$partition0$ & (64))) || (map__31596.cljs$core$ISeq$))?true:false):false))?cljs.core.apply.call(null,cljs.core.hash_map,map__31596):map__31596);
var name = cljs.core.get.call(null,map__31596__$1,new cljs.core.Keyword(null,"name","name",1843675177));
var requires = cljs.core.get.call(null,map__31596__$1,new cljs.core.Keyword(null,"requires","requires",-1201390927));
var uses = cljs.core.get.call(null,map__31596__$1,new cljs.core.Keyword(null,"uses","uses",232664692));
var require_macros = cljs.core.get.call(null,map__31596__$1,new cljs.core.Keyword(null,"require-macros","require-macros",707947416));
var reloads = cljs.core.get.call(null,map__31596__$1,new cljs.core.Keyword(null,"reloads","reloads",610698522));
var env = cljs.core.get.call(null,map__31596__$1,new cljs.core.Keyword(null,"env","env",-1815813235));
cljs.compiler.emitln.call(null,"goog.provide('",cljs.compiler.munge.call(null,name),"');");

if(cljs.core._EQ_.call(null,name,new cljs.core.Symbol(null,"cljs.core","cljs.core",770546058,null))){
} else {
cljs.compiler.emitln.call(null,"goog.require('cljs.core');");
}

cljs.compiler.load_libs.call(null,requires,null,new cljs.core.Keyword(null,"require","require",-468001333).cljs$core$IFn$_invoke$arity$1(reloads));

return cljs.compiler.load_libs.call(null,uses,requires,new cljs.core.Keyword(null,"use","use",-1846382424).cljs$core$IFn$_invoke$arity$1(reloads));
}));
cljs.core._add_method.call(null,cljs.compiler.emit_STAR_,new cljs.core.Keyword(null,"deftype*","deftype*",-677871637),(function (p__31598){
var map__31599 = p__31598;
var map__31599__$1 = ((((!((map__31599 == null)))?((((map__31599.cljs$lang$protocol_mask$partition0$ & (64))) || (map__31599.cljs$core$ISeq$))?true:false):false))?cljs.core.apply.call(null,cljs.core.hash_map,map__31599):map__31599);
var t = cljs.core.get.call(null,map__31599__$1,new cljs.core.Keyword(null,"t","t",-1397832519));
var fields = cljs.core.get.call(null,map__31599__$1,new cljs.core.Keyword(null,"fields","fields",-1932066230));
var pmasks = cljs.core.get.call(null,map__31599__$1,new cljs.core.Keyword(null,"pmasks","pmasks",-871416698));
var body = cljs.core.get.call(null,map__31599__$1,new cljs.core.Keyword(null,"body","body",-2049205669));
var protocols = cljs.core.get.call(null,map__31599__$1,new cljs.core.Keyword(null,"protocols","protocols",-5615896));
var fields__$1 = cljs.core.map.call(null,cljs.compiler.munge,fields);
cljs.compiler.emitln.call(null,"");

cljs.compiler.emitln.call(null,"/**");

cljs.compiler.emitln.call(null,"* @constructor");

var seq__31601_31615 = cljs.core.seq.call(null,protocols);
var chunk__31602_31616 = null;
var count__31603_31617 = (0);
var i__31604_31618 = (0);
while(true){
if((i__31604_31618 < count__31603_31617)){
var protocol_31619 = cljs.core._nth.call(null,chunk__31602_31616,i__31604_31618);
cljs.compiler.emitln.call(null," * @implements {",cljs.compiler.munge.call(null,[cljs.core.str(protocol_31619)].join('')),"}");

var G__31620 = seq__31601_31615;
var G__31621 = chunk__31602_31616;
var G__31622 = count__31603_31617;
var G__31623 = (i__31604_31618 + (1));
seq__31601_31615 = G__31620;
chunk__31602_31616 = G__31621;
count__31603_31617 = G__31622;
i__31604_31618 = G__31623;
continue;
} else {
var temp__4657__auto___31624 = cljs.core.seq.call(null,seq__31601_31615);
if(temp__4657__auto___31624){
var seq__31601_31625__$1 = temp__4657__auto___31624;
if(cljs.core.chunked_seq_QMARK_.call(null,seq__31601_31625__$1)){
var c__23696__auto___31626 = cljs.core.chunk_first.call(null,seq__31601_31625__$1);
var G__31627 = cljs.core.chunk_rest.call(null,seq__31601_31625__$1);
var G__31628 = c__23696__auto___31626;
var G__31629 = cljs.core.count.call(null,c__23696__auto___31626);
var G__31630 = (0);
seq__31601_31615 = G__31627;
chunk__31602_31616 = G__31628;
count__31603_31617 = G__31629;
i__31604_31618 = G__31630;
continue;
} else {
var protocol_31631 = cljs.core.first.call(null,seq__31601_31625__$1);
cljs.compiler.emitln.call(null," * @implements {",cljs.compiler.munge.call(null,[cljs.core.str(protocol_31631)].join('')),"}");

var G__31632 = cljs.core.next.call(null,seq__31601_31625__$1);
var G__31633 = null;
var G__31634 = (0);
var G__31635 = (0);
seq__31601_31615 = G__31632;
chunk__31602_31616 = G__31633;
count__31603_31617 = G__31634;
i__31604_31618 = G__31635;
continue;
}
} else {
}
}
break;
}

cljs.compiler.emitln.call(null,"*/");

cljs.compiler.emitln.call(null,cljs.compiler.munge.call(null,t)," = (function (",cljs.compiler.comma_sep.call(null,fields__$1),"){");

var seq__31605_31636 = cljs.core.seq.call(null,fields__$1);
var chunk__31606_31637 = null;
var count__31607_31638 = (0);
var i__31608_31639 = (0);
while(true){
if((i__31608_31639 < count__31607_31638)){
var fld_31640 = cljs.core._nth.call(null,chunk__31606_31637,i__31608_31639);
cljs.compiler.emitln.call(null,"this.",fld_31640," = ",fld_31640,";");

var G__31641 = seq__31605_31636;
var G__31642 = chunk__31606_31637;
var G__31643 = count__31607_31638;
var G__31644 = (i__31608_31639 + (1));
seq__31605_31636 = G__31641;
chunk__31606_31637 = G__31642;
count__31607_31638 = G__31643;
i__31608_31639 = G__31644;
continue;
} else {
var temp__4657__auto___31645 = cljs.core.seq.call(null,seq__31605_31636);
if(temp__4657__auto___31645){
var seq__31605_31646__$1 = temp__4657__auto___31645;
if(cljs.core.chunked_seq_QMARK_.call(null,seq__31605_31646__$1)){
var c__23696__auto___31647 = cljs.core.chunk_first.call(null,seq__31605_31646__$1);
var G__31648 = cljs.core.chunk_rest.call(null,seq__31605_31646__$1);
var G__31649 = c__23696__auto___31647;
var G__31650 = cljs.core.count.call(null,c__23696__auto___31647);
var G__31651 = (0);
seq__31605_31636 = G__31648;
chunk__31606_31637 = G__31649;
count__31607_31638 = G__31650;
i__31608_31639 = G__31651;
continue;
} else {
var fld_31652 = cljs.core.first.call(null,seq__31605_31646__$1);
cljs.compiler.emitln.call(null,"this.",fld_31652," = ",fld_31652,";");

var G__31653 = cljs.core.next.call(null,seq__31605_31646__$1);
var G__31654 = null;
var G__31655 = (0);
var G__31656 = (0);
seq__31605_31636 = G__31653;
chunk__31606_31637 = G__31654;
count__31607_31638 = G__31655;
i__31608_31639 = G__31656;
continue;
}
} else {
}
}
break;
}

var seq__31609_31657 = cljs.core.seq.call(null,pmasks);
var chunk__31610_31658 = null;
var count__31611_31659 = (0);
var i__31612_31660 = (0);
while(true){
if((i__31612_31660 < count__31611_31659)){
var vec__31613_31661 = cljs.core._nth.call(null,chunk__31610_31658,i__31612_31660);
var pno_31662 = cljs.core.nth.call(null,vec__31613_31661,(0),null);
var pmask_31663 = cljs.core.nth.call(null,vec__31613_31661,(1),null);
cljs.compiler.emitln.call(null,"this.cljs$lang$protocol_mask$partition",pno_31662,"$ = ",pmask_31663,";");

var G__31664 = seq__31609_31657;
var G__31665 = chunk__31610_31658;
var G__31666 = count__31611_31659;
var G__31667 = (i__31612_31660 + (1));
seq__31609_31657 = G__31664;
chunk__31610_31658 = G__31665;
count__31611_31659 = G__31666;
i__31612_31660 = G__31667;
continue;
} else {
var temp__4657__auto___31668 = cljs.core.seq.call(null,seq__31609_31657);
if(temp__4657__auto___31668){
var seq__31609_31669__$1 = temp__4657__auto___31668;
if(cljs.core.chunked_seq_QMARK_.call(null,seq__31609_31669__$1)){
var c__23696__auto___31670 = cljs.core.chunk_first.call(null,seq__31609_31669__$1);
var G__31671 = cljs.core.chunk_rest.call(null,seq__31609_31669__$1);
var G__31672 = c__23696__auto___31670;
var G__31673 = cljs.core.count.call(null,c__23696__auto___31670);
var G__31674 = (0);
seq__31609_31657 = G__31671;
chunk__31610_31658 = G__31672;
count__31611_31659 = G__31673;
i__31612_31660 = G__31674;
continue;
} else {
var vec__31614_31675 = cljs.core.first.call(null,seq__31609_31669__$1);
var pno_31676 = cljs.core.nth.call(null,vec__31614_31675,(0),null);
var pmask_31677 = cljs.core.nth.call(null,vec__31614_31675,(1),null);
cljs.compiler.emitln.call(null,"this.cljs$lang$protocol_mask$partition",pno_31676,"$ = ",pmask_31677,";");

var G__31678 = cljs.core.next.call(null,seq__31609_31669__$1);
var G__31679 = null;
var G__31680 = (0);
var G__31681 = (0);
seq__31609_31657 = G__31678;
chunk__31610_31658 = G__31679;
count__31611_31659 = G__31680;
i__31612_31660 = G__31681;
continue;
}
} else {
}
}
break;
}

cljs.compiler.emitln.call(null,"})");

return cljs.compiler.emit.call(null,body);
}));
cljs.core._add_method.call(null,cljs.compiler.emit_STAR_,new cljs.core.Keyword(null,"defrecord*","defrecord*",718069562),(function (p__31682){
var map__31683 = p__31682;
var map__31683__$1 = ((((!((map__31683 == null)))?((((map__31683.cljs$lang$protocol_mask$partition0$ & (64))) || (map__31683.cljs$core$ISeq$))?true:false):false))?cljs.core.apply.call(null,cljs.core.hash_map,map__31683):map__31683);
var t = cljs.core.get.call(null,map__31683__$1,new cljs.core.Keyword(null,"t","t",-1397832519));
var fields = cljs.core.get.call(null,map__31683__$1,new cljs.core.Keyword(null,"fields","fields",-1932066230));
var pmasks = cljs.core.get.call(null,map__31683__$1,new cljs.core.Keyword(null,"pmasks","pmasks",-871416698));
var body = cljs.core.get.call(null,map__31683__$1,new cljs.core.Keyword(null,"body","body",-2049205669));
var protocols = cljs.core.get.call(null,map__31683__$1,new cljs.core.Keyword(null,"protocols","protocols",-5615896));
var fields__$1 = cljs.core.concat.call(null,cljs.core.map.call(null,cljs.compiler.munge,fields),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Symbol(null,"__meta","__meta",-946752628,null),new cljs.core.Symbol(null,"__extmap","__extmap",-1435580931,null),new cljs.core.Symbol(null,"__hash","__hash",-1328796629,null)], null));
cljs.compiler.emitln.call(null,"");

cljs.compiler.emitln.call(null,"/**");

cljs.compiler.emitln.call(null,"* @constructor");

var seq__31685_31699 = cljs.core.seq.call(null,protocols);
var chunk__31686_31700 = null;
var count__31687_31701 = (0);
var i__31688_31702 = (0);
while(true){
if((i__31688_31702 < count__31687_31701)){
var protocol_31703 = cljs.core._nth.call(null,chunk__31686_31700,i__31688_31702);
cljs.compiler.emitln.call(null," * @implements {",cljs.compiler.munge.call(null,[cljs.core.str(protocol_31703)].join('')),"}");

var G__31704 = seq__31685_31699;
var G__31705 = chunk__31686_31700;
var G__31706 = count__31687_31701;
var G__31707 = (i__31688_31702 + (1));
seq__31685_31699 = G__31704;
chunk__31686_31700 = G__31705;
count__31687_31701 = G__31706;
i__31688_31702 = G__31707;
continue;
} else {
var temp__4657__auto___31708 = cljs.core.seq.call(null,seq__31685_31699);
if(temp__4657__auto___31708){
var seq__31685_31709__$1 = temp__4657__auto___31708;
if(cljs.core.chunked_seq_QMARK_.call(null,seq__31685_31709__$1)){
var c__23696__auto___31710 = cljs.core.chunk_first.call(null,seq__31685_31709__$1);
var G__31711 = cljs.core.chunk_rest.call(null,seq__31685_31709__$1);
var G__31712 = c__23696__auto___31710;
var G__31713 = cljs.core.count.call(null,c__23696__auto___31710);
var G__31714 = (0);
seq__31685_31699 = G__31711;
chunk__31686_31700 = G__31712;
count__31687_31701 = G__31713;
i__31688_31702 = G__31714;
continue;
} else {
var protocol_31715 = cljs.core.first.call(null,seq__31685_31709__$1);
cljs.compiler.emitln.call(null," * @implements {",cljs.compiler.munge.call(null,[cljs.core.str(protocol_31715)].join('')),"}");

var G__31716 = cljs.core.next.call(null,seq__31685_31709__$1);
var G__31717 = null;
var G__31718 = (0);
var G__31719 = (0);
seq__31685_31699 = G__31716;
chunk__31686_31700 = G__31717;
count__31687_31701 = G__31718;
i__31688_31702 = G__31719;
continue;
}
} else {
}
}
break;
}

cljs.compiler.emitln.call(null,"*/");

cljs.compiler.emitln.call(null,cljs.compiler.munge.call(null,t)," = (function (",cljs.compiler.comma_sep.call(null,fields__$1),"){");

var seq__31689_31720 = cljs.core.seq.call(null,fields__$1);
var chunk__31690_31721 = null;
var count__31691_31722 = (0);
var i__31692_31723 = (0);
while(true){
if((i__31692_31723 < count__31691_31722)){
var fld_31724 = cljs.core._nth.call(null,chunk__31690_31721,i__31692_31723);
cljs.compiler.emitln.call(null,"this.",fld_31724," = ",fld_31724,";");

var G__31725 = seq__31689_31720;
var G__31726 = chunk__31690_31721;
var G__31727 = count__31691_31722;
var G__31728 = (i__31692_31723 + (1));
seq__31689_31720 = G__31725;
chunk__31690_31721 = G__31726;
count__31691_31722 = G__31727;
i__31692_31723 = G__31728;
continue;
} else {
var temp__4657__auto___31729 = cljs.core.seq.call(null,seq__31689_31720);
if(temp__4657__auto___31729){
var seq__31689_31730__$1 = temp__4657__auto___31729;
if(cljs.core.chunked_seq_QMARK_.call(null,seq__31689_31730__$1)){
var c__23696__auto___31731 = cljs.core.chunk_first.call(null,seq__31689_31730__$1);
var G__31732 = cljs.core.chunk_rest.call(null,seq__31689_31730__$1);
var G__31733 = c__23696__auto___31731;
var G__31734 = cljs.core.count.call(null,c__23696__auto___31731);
var G__31735 = (0);
seq__31689_31720 = G__31732;
chunk__31690_31721 = G__31733;
count__31691_31722 = G__31734;
i__31692_31723 = G__31735;
continue;
} else {
var fld_31736 = cljs.core.first.call(null,seq__31689_31730__$1);
cljs.compiler.emitln.call(null,"this.",fld_31736," = ",fld_31736,";");

var G__31737 = cljs.core.next.call(null,seq__31689_31730__$1);
var G__31738 = null;
var G__31739 = (0);
var G__31740 = (0);
seq__31689_31720 = G__31737;
chunk__31690_31721 = G__31738;
count__31691_31722 = G__31739;
i__31692_31723 = G__31740;
continue;
}
} else {
}
}
break;
}

var seq__31693_31741 = cljs.core.seq.call(null,pmasks);
var chunk__31694_31742 = null;
var count__31695_31743 = (0);
var i__31696_31744 = (0);
while(true){
if((i__31696_31744 < count__31695_31743)){
var vec__31697_31745 = cljs.core._nth.call(null,chunk__31694_31742,i__31696_31744);
var pno_31746 = cljs.core.nth.call(null,vec__31697_31745,(0),null);
var pmask_31747 = cljs.core.nth.call(null,vec__31697_31745,(1),null);
cljs.compiler.emitln.call(null,"this.cljs$lang$protocol_mask$partition",pno_31746,"$ = ",pmask_31747,";");

var G__31748 = seq__31693_31741;
var G__31749 = chunk__31694_31742;
var G__31750 = count__31695_31743;
var G__31751 = (i__31696_31744 + (1));
seq__31693_31741 = G__31748;
chunk__31694_31742 = G__31749;
count__31695_31743 = G__31750;
i__31696_31744 = G__31751;
continue;
} else {
var temp__4657__auto___31752 = cljs.core.seq.call(null,seq__31693_31741);
if(temp__4657__auto___31752){
var seq__31693_31753__$1 = temp__4657__auto___31752;
if(cljs.core.chunked_seq_QMARK_.call(null,seq__31693_31753__$1)){
var c__23696__auto___31754 = cljs.core.chunk_first.call(null,seq__31693_31753__$1);
var G__31755 = cljs.core.chunk_rest.call(null,seq__31693_31753__$1);
var G__31756 = c__23696__auto___31754;
var G__31757 = cljs.core.count.call(null,c__23696__auto___31754);
var G__31758 = (0);
seq__31693_31741 = G__31755;
chunk__31694_31742 = G__31756;
count__31695_31743 = G__31757;
i__31696_31744 = G__31758;
continue;
} else {
var vec__31698_31759 = cljs.core.first.call(null,seq__31693_31753__$1);
var pno_31760 = cljs.core.nth.call(null,vec__31698_31759,(0),null);
var pmask_31761 = cljs.core.nth.call(null,vec__31698_31759,(1),null);
cljs.compiler.emitln.call(null,"this.cljs$lang$protocol_mask$partition",pno_31760,"$ = ",pmask_31761,";");

var G__31762 = cljs.core.next.call(null,seq__31693_31753__$1);
var G__31763 = null;
var G__31764 = (0);
var G__31765 = (0);
seq__31693_31741 = G__31762;
chunk__31694_31742 = G__31763;
count__31695_31743 = G__31764;
i__31696_31744 = G__31765;
continue;
}
} else {
}
}
break;
}

cljs.compiler.emitln.call(null,"})");

return cljs.compiler.emit.call(null,body);
}));
cljs.core._add_method.call(null,cljs.compiler.emit_STAR_,new cljs.core.Keyword(null,"dot","dot",1442709401),(function (p__31766){
var map__31767 = p__31766;
var map__31767__$1 = ((((!((map__31767 == null)))?((((map__31767.cljs$lang$protocol_mask$partition0$ & (64))) || (map__31767.cljs$core$ISeq$))?true:false):false))?cljs.core.apply.call(null,cljs.core.hash_map,map__31767):map__31767);
var target = cljs.core.get.call(null,map__31767__$1,new cljs.core.Keyword(null,"target","target",253001721));
var field = cljs.core.get.call(null,map__31767__$1,new cljs.core.Keyword(null,"field","field",-1302436500));
var method = cljs.core.get.call(null,map__31767__$1,new cljs.core.Keyword(null,"method","method",55703592));
var args = cljs.core.get.call(null,map__31767__$1,new cljs.core.Keyword(null,"args","args",1315556576));
var env = cljs.core.get.call(null,map__31767__$1,new cljs.core.Keyword(null,"env","env",-1815813235));
var env__24998__auto__ = env;
if(cljs.core._EQ_.call(null,new cljs.core.Keyword(null,"return","return",-1891502105),new cljs.core.Keyword(null,"context","context",-830191113).cljs$core$IFn$_invoke$arity$1(env__24998__auto__))){
cljs.compiler.emits.call(null,"return ");
} else {
}

if(cljs.core.truth_(field)){
cljs.compiler.emits.call(null,target,".",cljs.compiler.munge.call(null,field,cljs.core.PersistentHashSet.EMPTY));
} else {
cljs.compiler.emits.call(null,target,".",cljs.compiler.munge.call(null,method,cljs.core.PersistentHashSet.EMPTY),"(",cljs.compiler.comma_sep.call(null,args),")");
}

if(cljs.core._EQ_.call(null,new cljs.core.Keyword(null,"expr","expr",745722291),new cljs.core.Keyword(null,"context","context",-830191113).cljs$core$IFn$_invoke$arity$1(env__24998__auto__))){
return null;
} else {
return cljs.compiler.emitln.call(null,";");
}
}));
cljs.core._add_method.call(null,cljs.compiler.emit_STAR_,new cljs.core.Keyword(null,"js","js",1768080579),(function (p__31769){
var map__31770 = p__31769;
var map__31770__$1 = ((((!((map__31770 == null)))?((((map__31770.cljs$lang$protocol_mask$partition0$ & (64))) || (map__31770.cljs$core$ISeq$))?true:false):false))?cljs.core.apply.call(null,cljs.core.hash_map,map__31770):map__31770);
var op = cljs.core.get.call(null,map__31770__$1,new cljs.core.Keyword(null,"op","op",-1882987955));
var env = cljs.core.get.call(null,map__31770__$1,new cljs.core.Keyword(null,"env","env",-1815813235));
var code = cljs.core.get.call(null,map__31770__$1,new cljs.core.Keyword(null,"code","code",1586293142));
var segs = cljs.core.get.call(null,map__31770__$1,new cljs.core.Keyword(null,"segs","segs",-1940299576));
var args = cljs.core.get.call(null,map__31770__$1,new cljs.core.Keyword(null,"args","args",1315556576));
if(cljs.core.truth_((function (){var and__22873__auto__ = code;
if(cljs.core.truth_(and__22873__auto__)){
return goog.string.startsWith(clojure.string.trim.call(null,code),"/*");
} else {
return and__22873__auto__;
}
})())){
return cljs.compiler.emits.call(null,code);
} else {
var env__24998__auto__ = env;
if(cljs.core._EQ_.call(null,new cljs.core.Keyword(null,"return","return",-1891502105),new cljs.core.Keyword(null,"context","context",-830191113).cljs$core$IFn$_invoke$arity$1(env__24998__auto__))){
cljs.compiler.emits.call(null,"return ");
} else {
}

if(cljs.core.truth_(code)){
cljs.compiler.emits.call(null,code);
} else {
cljs.compiler.emits.call(null,cljs.core.interleave.call(null,cljs.core.concat.call(null,segs,cljs.core.repeat.call(null,null)),cljs.core.concat.call(null,args,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [null], null))));
}

if(cljs.core._EQ_.call(null,new cljs.core.Keyword(null,"expr","expr",745722291),new cljs.core.Keyword(null,"context","context",-830191113).cljs$core$IFn$_invoke$arity$1(env__24998__auto__))){
return null;
} else {
return cljs.compiler.emitln.call(null,";");
}
}
}));
cljs.compiler.build_affecting_options = (function cljs$compiler$build_affecting_options(opts){
return cljs.core.select_keys.call(null,opts,new cljs.core.PersistentVector(null, 4, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword(null,"static-fns","static-fns",-501950748),new cljs.core.Keyword(null,"optimize-constants","optimize-constants",232704518),new cljs.core.Keyword(null,"elide-asserts","elide-asserts",537063272),new cljs.core.Keyword(null,"target","target",253001721)], null));
});
cljs.compiler.emit_constants_table = (function cljs$compiler$emit_constants_table(table){
var seq__31780 = cljs.core.seq.call(null,table);
var chunk__31781 = null;
var count__31782 = (0);
var i__31783 = (0);
while(true){
if((i__31783 < count__31782)){
var vec__31784 = cljs.core._nth.call(null,chunk__31781,i__31783);
var sym = cljs.core.nth.call(null,vec__31784,(0),null);
var value = cljs.core.nth.call(null,vec__31784,(1),null);
var ns_31786 = cljs.core.namespace.call(null,sym);
var name_31787 = cljs.core.name.call(null,sym);
cljs.compiler.emits.call(null,"cljs.core.",value," = ");

if((sym instanceof cljs.core.Keyword)){
cljs.compiler.emits_keyword.call(null,sym);
} else {
if((sym instanceof cljs.core.Symbol)){
cljs.compiler.emits_symbol.call(null,sym);
} else {
throw cljs.core.ex_info.call(null,[cljs.core.str("Cannot emit constant for type "),cljs.core.str(cljs.core.type.call(null,sym))].join(''),new cljs.core.PersistentArrayMap(null, 1, [new cljs.core.Keyword(null,"error","error",-978969032),new cljs.core.Keyword(null,"invalid-constant-type","invalid-constant-type",1294847471)], null));

}
}

cljs.compiler.emits.call(null,";\n");

var G__31788 = seq__31780;
var G__31789 = chunk__31781;
var G__31790 = count__31782;
var G__31791 = (i__31783 + (1));
seq__31780 = G__31788;
chunk__31781 = G__31789;
count__31782 = G__31790;
i__31783 = G__31791;
continue;
} else {
var temp__4657__auto__ = cljs.core.seq.call(null,seq__31780);
if(temp__4657__auto__){
var seq__31780__$1 = temp__4657__auto__;
if(cljs.core.chunked_seq_QMARK_.call(null,seq__31780__$1)){
var c__23696__auto__ = cljs.core.chunk_first.call(null,seq__31780__$1);
var G__31792 = cljs.core.chunk_rest.call(null,seq__31780__$1);
var G__31793 = c__23696__auto__;
var G__31794 = cljs.core.count.call(null,c__23696__auto__);
var G__31795 = (0);
seq__31780 = G__31792;
chunk__31781 = G__31793;
count__31782 = G__31794;
i__31783 = G__31795;
continue;
} else {
var vec__31785 = cljs.core.first.call(null,seq__31780__$1);
var sym = cljs.core.nth.call(null,vec__31785,(0),null);
var value = cljs.core.nth.call(null,vec__31785,(1),null);
var ns_31796 = cljs.core.namespace.call(null,sym);
var name_31797 = cljs.core.name.call(null,sym);
cljs.compiler.emits.call(null,"cljs.core.",value," = ");

if((sym instanceof cljs.core.Keyword)){
cljs.compiler.emits_keyword.call(null,sym);
} else {
if((sym instanceof cljs.core.Symbol)){
cljs.compiler.emits_symbol.call(null,sym);
} else {
throw cljs.core.ex_info.call(null,[cljs.core.str("Cannot emit constant for type "),cljs.core.str(cljs.core.type.call(null,sym))].join(''),new cljs.core.PersistentArrayMap(null, 1, [new cljs.core.Keyword(null,"error","error",-978969032),new cljs.core.Keyword(null,"invalid-constant-type","invalid-constant-type",1294847471)], null));

}
}

cljs.compiler.emits.call(null,";\n");

var G__31798 = cljs.core.next.call(null,seq__31780__$1);
var G__31799 = null;
var G__31800 = (0);
var G__31801 = (0);
seq__31780 = G__31798;
chunk__31781 = G__31799;
count__31782 = G__31800;
i__31783 = G__31801;
continue;
}
} else {
return null;
}
}
break;
}
});

//# sourceMappingURL=compiler.js.map