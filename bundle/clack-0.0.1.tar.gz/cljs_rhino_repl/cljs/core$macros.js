// Compiled by ClojureScript 1.8.51 {}
goog.provide('cljs.core$macros');
goog.require('cljs.core');
goog.require('cljs.compiler');
goog.require('cljs.core');
goog.require('cljs.env');
goog.require('cljs.analyzer');
goog.require('clojure.set');
goog.require('clojure.string');
goog.require('clojure.walk');
/**
 * Threads the expr through the forms. Inserts x as the
 *   second item in the first form, making a list of it if it is not a
 *   list already. If there are more forms, inserts the first form as the
 *   second item in second form, etc.
 */
cljs.core$macros.__GT_ = (function cljs$core$macros$__GT_(var_args){
var args__23962__auto__ = [];
var len__23955__auto___27894 = arguments.length;
var i__23956__auto___27895 = (0);
while(true){
if((i__23956__auto___27895 < len__23955__auto___27894)){
args__23962__auto__.push((arguments[i__23956__auto___27895]));

var G__27896 = (i__23956__auto___27895 + (1));
i__23956__auto___27895 = G__27896;
continue;
} else {
}
break;
}

var argseq__23963__auto__ = ((((3) < args__23962__auto__.length))?(new cljs.core.IndexedSeq(args__23962__auto__.slice((3)),(0),null)):null);
return cljs.core$macros.__GT_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),argseq__23963__auto__);
});

cljs.core$macros.__GT_.cljs$core$IFn$_invoke$arity$variadic = (function (_AMPERSAND_form,_AMPERSAND_env,x,forms){
var x__$1 = x;
var forms__$1 = forms;
while(true){
if(cljs.core.truth_(forms__$1)){
var form = cljs.core.first.call(null,forms__$1);
var threaded = ((cljs.core.seq_QMARK_.call(null,form))?cljs.core.with_meta.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,(function (){var x__23719__auto__ = cljs.core.first.call(null,form);
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = x__$1;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),cljs.core.next.call(null,form)))),cljs.core.meta.call(null,form)):(function (){var x__23719__auto__ = form;
return cljs.core._conj.call(null,(function (){var x__23719__auto____$1 = x__$1;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto____$1);
})(),x__23719__auto__);
})());
var G__27897 = threaded;
var G__27898 = cljs.core.next.call(null,forms__$1);
x__$1 = G__27897;
forms__$1 = G__27898;
continue;
} else {
return x__$1;
}
break;
}
});

cljs.core$macros.__GT_.cljs$lang$maxFixedArity = (3);

cljs.core$macros.__GT_.cljs$lang$applyTo = (function (seq27890){
var G__27891 = cljs.core.first.call(null,seq27890);
var seq27890__$1 = cljs.core.next.call(null,seq27890);
var G__27892 = cljs.core.first.call(null,seq27890__$1);
var seq27890__$2 = cljs.core.next.call(null,seq27890__$1);
var G__27893 = cljs.core.first.call(null,seq27890__$2);
var seq27890__$3 = cljs.core.next.call(null,seq27890__$2);
return cljs.core$macros.__GT_.cljs$core$IFn$_invoke$arity$variadic(G__27891,G__27892,G__27893,seq27890__$3);
});

cljs.core$macros.__GT_.cljs$lang$macro = true;
/**
 * Threads the expr through the forms. Inserts x as the
 *   last item in the first form, making a list of it if it is not a
 *   list already. If there are more forms, inserts the first form as the
 *   last item in second form, etc.
 */
cljs.core$macros.__GT__GT_ = (function cljs$core$macros$__GT__GT_(var_args){
var args__23962__auto__ = [];
var len__23955__auto___27903 = arguments.length;
var i__23956__auto___27904 = (0);
while(true){
if((i__23956__auto___27904 < len__23955__auto___27903)){
args__23962__auto__.push((arguments[i__23956__auto___27904]));

var G__27905 = (i__23956__auto___27904 + (1));
i__23956__auto___27904 = G__27905;
continue;
} else {
}
break;
}

var argseq__23963__auto__ = ((((3) < args__23962__auto__.length))?(new cljs.core.IndexedSeq(args__23962__auto__.slice((3)),(0),null)):null);
return cljs.core$macros.__GT__GT_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),argseq__23963__auto__);
});

cljs.core$macros.__GT__GT_.cljs$core$IFn$_invoke$arity$variadic = (function (_AMPERSAND_form,_AMPERSAND_env,x,forms){
var x__$1 = x;
var forms__$1 = forms;
while(true){
if(cljs.core.truth_(forms__$1)){
var form = cljs.core.first.call(null,forms__$1);
var threaded = ((cljs.core.seq_QMARK_.call(null,form))?cljs.core.with_meta.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,(function (){var x__23719__auto__ = cljs.core.first.call(null,form);
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),cljs.core.next.call(null,form),(function (){var x__23719__auto__ = x__$1;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})()))),cljs.core.meta.call(null,form)):(function (){var x__23719__auto__ = form;
return cljs.core._conj.call(null,(function (){var x__23719__auto____$1 = x__$1;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto____$1);
})(),x__23719__auto__);
})());
var G__27906 = threaded;
var G__27907 = cljs.core.next.call(null,forms__$1);
x__$1 = G__27906;
forms__$1 = G__27907;
continue;
} else {
return x__$1;
}
break;
}
});

cljs.core$macros.__GT__GT_.cljs$lang$maxFixedArity = (3);

cljs.core$macros.__GT__GT_.cljs$lang$applyTo = (function (seq27899){
var G__27900 = cljs.core.first.call(null,seq27899);
var seq27899__$1 = cljs.core.next.call(null,seq27899);
var G__27901 = cljs.core.first.call(null,seq27899__$1);
var seq27899__$2 = cljs.core.next.call(null,seq27899__$1);
var G__27902 = cljs.core.first.call(null,seq27899__$2);
var seq27899__$3 = cljs.core.next.call(null,seq27899__$2);
return cljs.core$macros.__GT__GT_.cljs$core$IFn$_invoke$arity$variadic(G__27900,G__27901,G__27902,seq27899__$3);
});

cljs.core$macros.__GT__GT_.cljs$lang$macro = true;
/**
 * form => fieldName-symbol or (instanceMethodName-symbol args*)
 * 
 *   Expands into a member access (.) of the first member on the first
 *   argument, followed by the next member on the result, etc. For
 *   instance:
 * 
 *   (.. System (getProperties) (get "os.name"))
 * 
 *   expands to:
 * 
 *   (. (. System (getProperties)) (get "os.name"))
 * 
 *   but is easier to write, read, and understand.
 */
cljs.core$macros._DOT__DOT_ = (function cljs$core$macros$_DOT__DOT_(var_args){
var args27908 = [];
var len__23955__auto___27916 = arguments.length;
var i__23956__auto___27917 = (0);
while(true){
if((i__23956__auto___27917 < len__23955__auto___27916)){
args27908.push((arguments[i__23956__auto___27917]));

var G__27918 = (i__23956__auto___27917 + (1));
i__23956__auto___27917 = G__27918;
continue;
} else {
}
break;
}

var G__27915 = args27908.length;
switch (G__27915) {
case 4:
return cljs.core$macros._DOT__DOT_.cljs$core$IFn$_invoke$arity$4((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]));

break;
default:
var argseq__23974__auto__ = (new cljs.core.IndexedSeq(args27908.slice((4)),(0),null));
return cljs.core$macros._DOT__DOT_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]),argseq__23974__auto__);

}
});

cljs.core$macros._DOT__DOT_.cljs$core$IFn$_invoke$arity$4 = (function (_AMPERSAND_form,_AMPERSAND_env,x,form){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,".",".",1975675962,null)),(function (){var x__23719__auto__ = x;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = form;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
});

cljs.core$macros._DOT__DOT_.cljs$core$IFn$_invoke$arity$variadic = (function (_AMPERSAND_form,_AMPERSAND_env,x,form,more){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"..","..",-300507420,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,".",".",1975675962,null)),(function (){var x__23719__auto__ = x;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = form;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),more)));
});

cljs.core$macros._DOT__DOT_.cljs$lang$applyTo = (function (seq27909){
var G__27910 = cljs.core.first.call(null,seq27909);
var seq27909__$1 = cljs.core.next.call(null,seq27909);
var G__27911 = cljs.core.first.call(null,seq27909__$1);
var seq27909__$2 = cljs.core.next.call(null,seq27909__$1);
var G__27912 = cljs.core.first.call(null,seq27909__$2);
var seq27909__$3 = cljs.core.next.call(null,seq27909__$2);
var G__27913 = cljs.core.first.call(null,seq27909__$3);
var seq27909__$4 = cljs.core.next.call(null,seq27909__$3);
return cljs.core$macros._DOT__DOT_.cljs$core$IFn$_invoke$arity$variadic(G__27910,G__27911,G__27912,G__27913,seq27909__$4);
});

cljs.core$macros._DOT__DOT_.cljs$lang$maxFixedArity = (4);

cljs.core$macros._DOT__DOT_.cljs$lang$macro = true;
/**
 * Ignores body, yields nil
 */
cljs.core$macros.comment = (function cljs$core$macros$comment(var_args){
var args__23962__auto__ = [];
var len__23955__auto___27923 = arguments.length;
var i__23956__auto___27924 = (0);
while(true){
if((i__23956__auto___27924 < len__23955__auto___27923)){
args__23962__auto__.push((arguments[i__23956__auto___27924]));

var G__27925 = (i__23956__auto___27924 + (1));
i__23956__auto___27924 = G__27925;
continue;
} else {
}
break;
}

var argseq__23963__auto__ = ((((2) < args__23962__auto__.length))?(new cljs.core.IndexedSeq(args__23962__auto__.slice((2)),(0),null)):null);
return cljs.core$macros.comment.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__23963__auto__);
});

cljs.core$macros.comment.cljs$core$IFn$_invoke$arity$variadic = (function (_AMPERSAND_form,_AMPERSAND_env,body){
return null;
});

cljs.core$macros.comment.cljs$lang$maxFixedArity = (2);

cljs.core$macros.comment.cljs$lang$applyTo = (function (seq27920){
var G__27921 = cljs.core.first.call(null,seq27920);
var seq27920__$1 = cljs.core.next.call(null,seq27920);
var G__27922 = cljs.core.first.call(null,seq27920__$1);
var seq27920__$2 = cljs.core.next.call(null,seq27920__$1);
return cljs.core$macros.comment.cljs$core$IFn$_invoke$arity$variadic(G__27921,G__27922,seq27920__$2);
});

cljs.core$macros.comment.cljs$lang$macro = true;
/**
 * Takes a set of test/expr pairs. It evaluates each test one at a
 *   time.  If a test returns logical true, cond evaluates and returns
 *   the value of the corresponding expr and doesn't evaluate any of the
 *   other tests or exprs. (cond) returns nil.
 */
cljs.core$macros.cond = (function cljs$core$macros$cond(var_args){
var args__23962__auto__ = [];
var len__23955__auto___27929 = arguments.length;
var i__23956__auto___27930 = (0);
while(true){
if((i__23956__auto___27930 < len__23955__auto___27929)){
args__23962__auto__.push((arguments[i__23956__auto___27930]));

var G__27931 = (i__23956__auto___27930 + (1));
i__23956__auto___27930 = G__27931;
continue;
} else {
}
break;
}

var argseq__23963__auto__ = ((((2) < args__23962__auto__.length))?(new cljs.core.IndexedSeq(args__23962__auto__.slice((2)),(0),null)):null);
return cljs.core$macros.cond.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__23963__auto__);
});

cljs.core$macros.cond.cljs$core$IFn$_invoke$arity$variadic = (function (_AMPERSAND_form,_AMPERSAND_env,clauses){
if(cljs.core.truth_(clauses)){
return cljs.core._conj.call(null,(function (){var x__23719__auto__ = cljs.core.first.call(null,clauses);
return cljs.core._conj.call(null,(function (){var x__23719__auto____$1 = ((cljs.core.next.call(null,clauses))?cljs.core.second.call(null,clauses):(function(){throw (new Error("cond requires an even number of forms"))})());
return cljs.core._conj.call(null,(function (){var x__23719__auto____$2 = cljs.core.cons.call(null,new cljs.core.Symbol("cljs.core","cond","cljs.core/cond",2005388338,null),cljs.core.next.call(null,cljs.core.next.call(null,clauses)));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto____$2);
})(),x__23719__auto____$1);
})(),x__23719__auto__);
})(),new cljs.core.Symbol(null,"if","if",1181717262,null));
} else {
return null;
}
});

cljs.core$macros.cond.cljs$lang$maxFixedArity = (2);

cljs.core$macros.cond.cljs$lang$applyTo = (function (seq27926){
var G__27927 = cljs.core.first.call(null,seq27926);
var seq27926__$1 = cljs.core.next.call(null,seq27926);
var G__27928 = cljs.core.first.call(null,seq27926__$1);
var seq27926__$2 = cljs.core.next.call(null,seq27926__$1);
return cljs.core$macros.cond.cljs$core$IFn$_invoke$arity$variadic(G__27927,G__27928,seq27926__$2);
});

cljs.core$macros.cond.cljs$lang$macro = true;
/**
 * defs the supplied var names with no bindings, useful for making forward declarations.
 */
cljs.core$macros.declare = (function cljs$core$macros$declare(var_args){
var args__23962__auto__ = [];
var len__23955__auto___27936 = arguments.length;
var i__23956__auto___27937 = (0);
while(true){
if((i__23956__auto___27937 < len__23955__auto___27936)){
args__23962__auto__.push((arguments[i__23956__auto___27937]));

var G__27938 = (i__23956__auto___27937 + (1));
i__23956__auto___27937 = G__27938;
continue;
} else {
}
break;
}

var argseq__23963__auto__ = ((((2) < args__23962__auto__.length))?(new cljs.core.IndexedSeq(args__23962__auto__.slice((2)),(0),null)):null);
return cljs.core$macros.declare.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__23963__auto__);
});

cljs.core$macros.declare.cljs$core$IFn$_invoke$arity$variadic = (function (_AMPERSAND_form,_AMPERSAND_env,names){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"do","do",1686842252,null)),cljs.core.map.call(null,(function (p1__27932_SHARP_){
return cljs.core._conj.call(null,(function (){var x__23719__auto__ = cljs.core.vary_meta.call(null,p1__27932_SHARP_,cljs.core.assoc,new cljs.core.Keyword(null,"declared","declared",92336021),true);
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),new cljs.core.Symbol(null,"def","def",597100991,null));
}),names))));
});

cljs.core$macros.declare.cljs$lang$maxFixedArity = (2);

cljs.core$macros.declare.cljs$lang$applyTo = (function (seq27933){
var G__27934 = cljs.core.first.call(null,seq27933);
var seq27933__$1 = cljs.core.next.call(null,seq27933);
var G__27935 = cljs.core.first.call(null,seq27933__$1);
var seq27933__$2 = cljs.core.next.call(null,seq27933__$1);
return cljs.core$macros.declare.cljs$core$IFn$_invoke$arity$variadic(G__27934,G__27935,seq27933__$2);
});

cljs.core$macros.declare.cljs$lang$macro = true;
/**
 * Evaluates x then calls all of the methods and functions with the
 *   value of x supplied at the front of the given arguments.  The forms
 *   are evaluated in order.  Returns x.
 * 
 *   (doto (new java.util.HashMap) (.put "a" 1) (.put "b" 2))
 */
cljs.core$macros.doto = (function cljs$core$macros$doto(var_args){
var args__23962__auto__ = [];
var len__23955__auto___27943 = arguments.length;
var i__23956__auto___27944 = (0);
while(true){
if((i__23956__auto___27944 < len__23955__auto___27943)){
args__23962__auto__.push((arguments[i__23956__auto___27944]));

var G__27945 = (i__23956__auto___27944 + (1));
i__23956__auto___27944 = G__27945;
continue;
} else {
}
break;
}

var argseq__23963__auto__ = ((((3) < args__23962__auto__.length))?(new cljs.core.IndexedSeq(args__23962__auto__.slice((3)),(0),null)):null);
return cljs.core$macros.doto.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),argseq__23963__auto__);
});

cljs.core$macros.doto.cljs$core$IFn$_invoke$arity$variadic = (function (_AMPERSAND_form,_AMPERSAND_env,x,forms){
var gx = cljs.core.gensym.call(null);
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","let","cljs.core$macros/let",-160286726,null)),(function (){var x__23719__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,(function (){var x__23719__auto__ = gx;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = x;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})()))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),cljs.core.map.call(null,((function (gx){
return (function (f){
if(cljs.core.seq_QMARK_.call(null,f)){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,(function (){var x__23719__auto__ = cljs.core.first.call(null,f);
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = gx;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),cljs.core.next.call(null,f))));
} else {
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,(function (){var x__23719__auto__ = f;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = gx;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
}
});})(gx))
,forms),(function (){var x__23719__auto__ = gx;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
});

cljs.core$macros.doto.cljs$lang$maxFixedArity = (3);

cljs.core$macros.doto.cljs$lang$applyTo = (function (seq27939){
var G__27940 = cljs.core.first.call(null,seq27939);
var seq27939__$1 = cljs.core.next.call(null,seq27939);
var G__27941 = cljs.core.first.call(null,seq27939__$1);
var seq27939__$2 = cljs.core.next.call(null,seq27939__$1);
var G__27942 = cljs.core.first.call(null,seq27939__$2);
var seq27939__$3 = cljs.core.next.call(null,seq27939__$2);
return cljs.core$macros.doto.cljs$core$IFn$_invoke$arity$variadic(G__27940,G__27941,G__27942,seq27939__$3);
});

cljs.core$macros.doto.cljs$lang$macro = true;
cljs.core$macros.parse_impls = (function cljs$core$macros$parse_impls(specs){
var ret = cljs.core.PersistentArrayMap.EMPTY;
var s = specs;
while(true){
if(cljs.core.seq.call(null,s)){
var G__27946 = cljs.core.assoc.call(null,ret,cljs.core.first.call(null,s),cljs.core.take_while.call(null,cljs.core.seq_QMARK_,cljs.core.next.call(null,s)));
var G__27947 = cljs.core.drop_while.call(null,cljs.core.seq_QMARK_,cljs.core.next.call(null,s));
ret = G__27946;
s = G__27947;
continue;
} else {
return ret;
}
break;
}
});
cljs.core$macros.emit_extend_protocol = (function cljs$core$macros$emit_extend_protocol(p,specs){
var impls = cljs.core$macros.parse_impls.call(null,specs);
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"do","do",1686842252,null)),cljs.core.map.call(null,((function (impls){
return (function (p__27950){
var vec__27951 = p__27950;
var t = cljs.core.nth.call(null,vec__27951,(0),null);
var fs = cljs.core.nth.call(null,vec__27951,(1),null);
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","extend-type","cljs.core$macros/extend-type",1713295201,null)),(function (){var x__23719__auto__ = t;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = p;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),fs)));
});})(impls))
,impls))));
});
/**
 * Useful when you want to provide several implementations of the same
 *   protocol all at once. Takes a single protocol and the implementation
 *   of that protocol for one or more types. Expands into calls to
 *   extend-type:
 * 
 *   (extend-protocol Protocol
 *     AType
 *       (foo [x] ...)
 *       (bar [x y] ...)
 *     BType
 *       (foo [x] ...)
 *       (bar [x y] ...)
 *     AClass
 *       (foo [x] ...)
 *       (bar [x y] ...)
 *     nil
 *       (foo [x] ...)
 *       (bar [x y] ...))
 * 
 *   expands into:
 * 
 *   (do
 *    (clojure.core/extend-type AType Protocol
 *      (foo [x] ...)
 *      (bar [x y] ...))
 *    (clojure.core/extend-type BType Protocol
 *      (foo [x] ...)
 *      (bar [x y] ...))
 *    (clojure.core/extend-type AClass Protocol
 *      (foo [x] ...)
 *      (bar [x y] ...))
 *    (clojure.core/extend-type nil Protocol
 *      (foo [x] ...)
 *      (bar [x y] ...)))
 */
cljs.core$macros.extend_protocol = (function cljs$core$macros$extend_protocol(var_args){
var args__23962__auto__ = [];
var len__23955__auto___27956 = arguments.length;
var i__23956__auto___27957 = (0);
while(true){
if((i__23956__auto___27957 < len__23955__auto___27956)){
args__23962__auto__.push((arguments[i__23956__auto___27957]));

var G__27958 = (i__23956__auto___27957 + (1));
i__23956__auto___27957 = G__27958;
continue;
} else {
}
break;
}

var argseq__23963__auto__ = ((((3) < args__23962__auto__.length))?(new cljs.core.IndexedSeq(args__23962__auto__.slice((3)),(0),null)):null);
return cljs.core$macros.extend_protocol.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),argseq__23963__auto__);
});

cljs.core$macros.extend_protocol.cljs$core$IFn$_invoke$arity$variadic = (function (_AMPERSAND_form,_AMPERSAND_env,p,specs){
return cljs.core$macros.emit_extend_protocol.call(null,p,specs);
});

cljs.core$macros.extend_protocol.cljs$lang$maxFixedArity = (3);

cljs.core$macros.extend_protocol.cljs$lang$applyTo = (function (seq27952){
var G__27953 = cljs.core.first.call(null,seq27952);
var seq27952__$1 = cljs.core.next.call(null,seq27952);
var G__27954 = cljs.core.first.call(null,seq27952__$1);
var seq27952__$2 = cljs.core.next.call(null,seq27952__$1);
var G__27955 = cljs.core.first.call(null,seq27952__$2);
var seq27952__$3 = cljs.core.next.call(null,seq27952__$2);
return cljs.core$macros.extend_protocol.cljs$core$IFn$_invoke$arity$variadic(G__27953,G__27954,G__27955,seq27952__$3);
});

cljs.core$macros.extend_protocol.cljs$lang$macro = true;
cljs.core$macros.maybe_destructured = (function cljs$core$macros$maybe_destructured(params,body){
if(cljs.core.every_QMARK_.call(null,cljs.core.symbol_QMARK_,params)){
return cljs.core.cons.call(null,params,body);
} else {
var params__$1 = params;
var new_params = cljs.core.with_meta.call(null,cljs.core.PersistentVector.EMPTY,cljs.core.meta.call(null,params__$1));
var lets = cljs.core.PersistentVector.EMPTY;
while(true){
if(cljs.core.truth_(params__$1)){
if((cljs.core.first.call(null,params__$1) instanceof cljs.core.Symbol)){
var G__27959 = cljs.core.next.call(null,params__$1);
var G__27960 = cljs.core.conj.call(null,new_params,cljs.core.first.call(null,params__$1));
var G__27961 = lets;
params__$1 = G__27959;
new_params = G__27960;
lets = G__27961;
continue;
} else {
var gparam = cljs.core.gensym.call(null,"p__");
var G__27962 = cljs.core.next.call(null,params__$1);
var G__27963 = cljs.core.conj.call(null,new_params,gparam);
var G__27964 = cljs.core.conj.call(null,cljs.core.conj.call(null,lets,cljs.core.first.call(null,params__$1)),gparam);
params__$1 = G__27962;
new_params = G__27963;
lets = G__27964;
continue;
}
} else {
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,(function (){var x__23719__auto__ = new_params;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","let","cljs.core$macros/let",-160286726,null)),(function (){var x__23719__auto__ = lets;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),body)));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
}
break;
}
}
});
/**
 * params => positional-params* , or positional-params* & next-param
 *   positional-param => binding-form
 *   next-param => binding-form
 *   name => symbol
 * 
 *   Defines a function
 */
cljs.core$macros.fn = (function cljs$core$macros$fn(var_args){
var args__23962__auto__ = [];
var len__23955__auto___27969 = arguments.length;
var i__23956__auto___27970 = (0);
while(true){
if((i__23956__auto___27970 < len__23955__auto___27969)){
args__23962__auto__.push((arguments[i__23956__auto___27970]));

var G__27971 = (i__23956__auto___27970 + (1));
i__23956__auto___27970 = G__27971;
continue;
} else {
}
break;
}

var argseq__23963__auto__ = ((((2) < args__23962__auto__.length))?(new cljs.core.IndexedSeq(args__23962__auto__.slice((2)),(0),null)):null);
return cljs.core$macros.fn.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__23963__auto__);
});

cljs.core$macros.fn.cljs$core$IFn$_invoke$arity$variadic = (function (_AMPERSAND_form,_AMPERSAND_env,sigs){
var name = (((cljs.core.first.call(null,sigs) instanceof cljs.core.Symbol))?cljs.core.first.call(null,sigs):null);
var sigs__$1 = (cljs.core.truth_(name)?cljs.core.next.call(null,sigs):sigs);
var sigs__$2 = ((cljs.core.vector_QMARK_.call(null,cljs.core.first.call(null,sigs__$1)))?(function (){var x__23719__auto__ = sigs__$1;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})():((cljs.core.seq_QMARK_.call(null,cljs.core.first.call(null,sigs__$1)))?sigs__$1:(function(){throw (new Error(((cljs.core.seq.call(null,sigs__$1))?[cljs.core.str("Parameter declaration "),cljs.core.str(cljs.core.first.call(null,sigs__$1)),cljs.core.str(" should be a vector")].join(''):[cljs.core.str("Parameter declaration missing")].join(''))))})()));
var psig = ((function (name,sigs__$1,sigs__$2){
return (function (sig){
if(!(cljs.core.seq_QMARK_.call(null,sig))){
throw (new Error([cljs.core.str("Invalid signature "),cljs.core.str(sig),cljs.core.str(" should be a list")].join('')));
} else {
}

var vec__27968 = sig;
var params = cljs.core.nth.call(null,vec__27968,(0),null);
var body = cljs.core.nthnext.call(null,vec__27968,(1));
var _ = ((!(cljs.core.vector_QMARK_.call(null,params)))?(function(){throw (new Error(((cljs.core.seq_QMARK_.call(null,cljs.core.first.call(null,sigs__$2)))?[cljs.core.str("Parameter declaration "),cljs.core.str(params),cljs.core.str(" should be a vector")].join(''):[cljs.core.str("Invalid signature "),cljs.core.str(sig),cljs.core.str(" should be a list")].join(''))))})():null);
var conds = (((cljs.core.next.call(null,body)) && (cljs.core.map_QMARK_.call(null,cljs.core.first.call(null,body))))?cljs.core.first.call(null,body):null);
var body__$1 = (cljs.core.truth_(conds)?cljs.core.next.call(null,body):body);
var conds__$1 = (function (){var or__22885__auto__ = conds;
if(cljs.core.truth_(or__22885__auto__)){
return or__22885__auto__;
} else {
return cljs.core.meta.call(null,params);
}
})();
var pre = new cljs.core.Keyword(null,"pre","pre",2118456869).cljs$core$IFn$_invoke$arity$1(conds__$1);
var post = new cljs.core.Keyword(null,"post","post",269697687).cljs$core$IFn$_invoke$arity$1(conds__$1);
var body__$2 = (cljs.core.truth_(post)?cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","let","cljs.core$macros/let",-160286726,null)),(function (){var x__23719__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"%","%",-950237169,null)),(function (){var x__23719__auto__ = ((((1) < cljs.core.count.call(null,body__$1)))?cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"do","do",1686842252,null)),body__$1))):cljs.core.first.call(null,body__$1));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})()))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),cljs.core.map.call(null,((function (vec__27968,params,body,_,conds,body__$1,conds__$1,pre,post,name,sigs__$1,sigs__$2){
return (function (c){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","assert","cljs.core$macros/assert",1333198789,null)),(function (){var x__23719__auto__ = c;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
});})(vec__27968,params,body,_,conds,body__$1,conds__$1,pre,post,name,sigs__$1,sigs__$2))
,post),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"%","%",-950237169,null)))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})()))):body__$1);
var body__$3 = (cljs.core.truth_(pre)?cljs.core.concat.call(null,cljs.core.map.call(null,((function (vec__27968,params,body,_,conds,body__$1,conds__$1,pre,post,body__$2,name,sigs__$1,sigs__$2){
return (function (c){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","assert","cljs.core$macros/assert",1333198789,null)),(function (){var x__23719__auto__ = c;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
});})(vec__27968,params,body,_,conds,body__$1,conds__$1,pre,post,body__$2,name,sigs__$1,sigs__$2))
,pre),body__$2):body__$2);
return cljs.core$macros.maybe_destructured.call(null,params,body__$3);
});})(name,sigs__$1,sigs__$2))
;
var new_sigs = cljs.core.map.call(null,psig,sigs__$2);
return cljs.core.with_meta.call(null,(cljs.core.truth_(name)?cljs.core.list_STAR_.call(null,new cljs.core.Symbol(null,"fn*","fn*",-752876845,null),name,new_sigs):cljs.core.cons.call(null,new cljs.core.Symbol(null,"fn*","fn*",-752876845,null),new_sigs)),cljs.core.meta.call(null,_AMPERSAND_form));
});

cljs.core$macros.fn.cljs$lang$maxFixedArity = (2);

cljs.core$macros.fn.cljs$lang$applyTo = (function (seq27965){
var G__27966 = cljs.core.first.call(null,seq27965);
var seq27965__$1 = cljs.core.next.call(null,seq27965);
var G__27967 = cljs.core.first.call(null,seq27965__$1);
var seq27965__$2 = cljs.core.next.call(null,seq27965__$1);
return cljs.core$macros.fn.cljs$core$IFn$_invoke$arity$variadic(G__27966,G__27967,seq27965__$2);
});

cljs.core$macros.fn.cljs$lang$macro = true;
/**
 * same as defn, yielding non-public def
 */
cljs.core$macros.defn_ = (function cljs$core$macros$defn_(var_args){
var args__23962__auto__ = [];
var len__23955__auto___27976 = arguments.length;
var i__23956__auto___27977 = (0);
while(true){
if((i__23956__auto___27977 < len__23955__auto___27976)){
args__23962__auto__.push((arguments[i__23956__auto___27977]));

var G__27978 = (i__23956__auto___27977 + (1));
i__23956__auto___27977 = G__27978;
continue;
} else {
}
break;
}

var argseq__23963__auto__ = ((((3) < args__23962__auto__.length))?(new cljs.core.IndexedSeq(args__23962__auto__.slice((3)),(0),null)):null);
return cljs.core$macros.defn_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),argseq__23963__auto__);
});

cljs.core$macros.defn_.cljs$core$IFn$_invoke$arity$variadic = (function (_AMPERSAND_form,_AMPERSAND_env,name,decls){
return cljs.core.list_STAR_.call(null,new cljs.core.Symbol("cljs.core$macros","defn","cljs.core$macros/defn",-728332354,null),cljs.core.with_meta.call(null,name,cljs.core.assoc.call(null,cljs.core.meta.call(null,name),new cljs.core.Keyword(null,"private","private",-558947994),true)),decls);
});

cljs.core$macros.defn_.cljs$lang$maxFixedArity = (3);

cljs.core$macros.defn_.cljs$lang$applyTo = (function (seq27972){
var G__27973 = cljs.core.first.call(null,seq27972);
var seq27972__$1 = cljs.core.next.call(null,seq27972);
var G__27974 = cljs.core.first.call(null,seq27972__$1);
var seq27972__$2 = cljs.core.next.call(null,seq27972__$1);
var G__27975 = cljs.core.first.call(null,seq27972__$2);
var seq27972__$3 = cljs.core.next.call(null,seq27972__$2);
return cljs.core$macros.defn_.cljs$core$IFn$_invoke$arity$variadic(G__27973,G__27974,G__27975,seq27972__$3);
});

cljs.core$macros.defn_.cljs$lang$macro = true;
/**
 * bindings => binding-form test
 * 
 *   If test is true, evaluates then with binding-form bound to the value of
 *   test, if not, yields else
 */
cljs.core$macros.if_let = (function cljs$core$macros$if_let(var_args){
var args27980 = [];
var len__23955__auto___27989 = arguments.length;
var i__23956__auto___27990 = (0);
while(true){
if((i__23956__auto___27990 < len__23955__auto___27989)){
args27980.push((arguments[i__23956__auto___27990]));

var G__27991 = (i__23956__auto___27990 + (1));
i__23956__auto___27990 = G__27991;
continue;
} else {
}
break;
}

var G__27988 = args27980.length;
switch (G__27988) {
case 4:
return cljs.core$macros.if_let.cljs$core$IFn$_invoke$arity$4((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]));

break;
default:
var argseq__23974__auto__ = (new cljs.core.IndexedSeq(args27980.slice((5)),(0),null));
return cljs.core$macros.if_let.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]),(arguments[(4)]),argseq__23974__auto__);

}
});

cljs.core$macros.if_let.cljs$core$IFn$_invoke$arity$4 = (function (_AMPERSAND_form,_AMPERSAND_env,bindings,then){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","if-let","cljs.core$macros/if-let",1291543946,null)),(function (){var x__23719__auto__ = bindings;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = then;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,null))));
});

cljs.core$macros.if_let.cljs$core$IFn$_invoke$arity$variadic = (function (_AMPERSAND_form,_AMPERSAND_env,bindings,then,else$,oldform){
if(cljs.core.vector_QMARK_.call(null,bindings)){
} else {
throw cljs.core.ex_info.call(null,"if-let requires a vector for its binding",cljs.core.PersistentArrayMap.EMPTY);
}

if(cljs.core.empty_QMARK_.call(null,oldform)){
} else {
throw cljs.core.ex_info.call(null,"if-let requires 1 or 2 forms after binding vector",cljs.core.PersistentArrayMap.EMPTY);
}

if(cljs.core._EQ_.call(null,(2),cljs.core.count.call(null,bindings))){
} else {
throw cljs.core.ex_info.call(null,"if-let requires exactly 2 forms in binding vector",cljs.core.PersistentArrayMap.EMPTY);
}


var form = bindings.call(null,(0));
var tst = bindings.call(null,(1));
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","let","cljs.core$macros/let",-160286726,null)),(function (){var x__23719__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"temp__27979__auto__","temp__27979__auto__",462611651,null)),(function (){var x__23719__auto__ = tst;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})()))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"if","if",1181717262,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"temp__27979__auto__","temp__27979__auto__",462611651,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","let","cljs.core$macros/let",-160286726,null)),(function (){var x__23719__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,(function (){var x__23719__auto__ = form;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"temp__27979__auto__","temp__27979__auto__",462611651,null))))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = then;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = else$;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
});

cljs.core$macros.if_let.cljs$lang$applyTo = (function (seq27981){
var G__27982 = cljs.core.first.call(null,seq27981);
var seq27981__$1 = cljs.core.next.call(null,seq27981);
var G__27983 = cljs.core.first.call(null,seq27981__$1);
var seq27981__$2 = cljs.core.next.call(null,seq27981__$1);
var G__27984 = cljs.core.first.call(null,seq27981__$2);
var seq27981__$3 = cljs.core.next.call(null,seq27981__$2);
var G__27985 = cljs.core.first.call(null,seq27981__$3);
var seq27981__$4 = cljs.core.next.call(null,seq27981__$3);
var G__27986 = cljs.core.first.call(null,seq27981__$4);
var seq27981__$5 = cljs.core.next.call(null,seq27981__$4);
return cljs.core$macros.if_let.cljs$core$IFn$_invoke$arity$variadic(G__27982,G__27983,G__27984,G__27985,G__27986,seq27981__$5);
});

cljs.core$macros.if_let.cljs$lang$maxFixedArity = (5);

cljs.core$macros.if_let.cljs$lang$macro = true;
/**
 * Evaluates test. If logical false, evaluates and returns then expr,
 *   otherwise else expr, if supplied, else nil.
 */
cljs.core$macros.if_not = (function cljs$core$macros$if_not(var_args){
var args27993 = [];
var len__23955__auto___27996 = arguments.length;
var i__23956__auto___27997 = (0);
while(true){
if((i__23956__auto___27997 < len__23955__auto___27996)){
args27993.push((arguments[i__23956__auto___27997]));

var G__27998 = (i__23956__auto___27997 + (1));
i__23956__auto___27997 = G__27998;
continue;
} else {
}
break;
}

var G__27995 = args27993.length;
switch (G__27995) {
case 4:
return cljs.core$macros.if_not.cljs$core$IFn$_invoke$arity$4((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]));

break;
case 5:
return cljs.core$macros.if_not.cljs$core$IFn$_invoke$arity$5((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]),(arguments[(4)]));

break;
default:
throw (new Error([cljs.core.str("Invalid arity: "),cljs.core.str((args27993.length - (2)))].join('')));

}
});

cljs.core$macros.if_not.cljs$core$IFn$_invoke$arity$4 = (function (_AMPERSAND_form,_AMPERSAND_env,test,then){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","if-not","cljs.core$macros/if-not",-1825285737,null)),(function (){var x__23719__auto__ = test;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = then;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,null))));
});

cljs.core$macros.if_not.cljs$core$IFn$_invoke$arity$5 = (function (_AMPERSAND_form,_AMPERSAND_env,test,then,else$){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"if","if",1181717262,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","not","cljs.core/not",100665144,null)),(function (){var x__23719__auto__ = test;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = then;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = else$;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
});

cljs.core$macros.if_not.cljs$lang$maxFixedArity = 5;

cljs.core$macros.if_not.cljs$lang$macro = true;
/**
 * fnspec ==> (fname [params*] exprs) or (fname ([params*] exprs)+)
 * 
 *   Takes a vector of function specs and a body, and generates a set of
 *   bindings of functions to their names. All of the names are available
 *   in all of the definitions of the functions, as well as the body.
 */
cljs.core$macros.letfn = (function cljs$core$macros$letfn(var_args){
var args__23962__auto__ = [];
var len__23955__auto___28005 = arguments.length;
var i__23956__auto___28006 = (0);
while(true){
if((i__23956__auto___28006 < len__23955__auto___28005)){
args__23962__auto__.push((arguments[i__23956__auto___28006]));

var G__28007 = (i__23956__auto___28006 + (1));
i__23956__auto___28006 = G__28007;
continue;
} else {
}
break;
}

var argseq__23963__auto__ = ((((3) < args__23962__auto__.length))?(new cljs.core.IndexedSeq(args__23962__auto__.slice((3)),(0),null)):null);
return cljs.core$macros.letfn.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),argseq__23963__auto__);
});

cljs.core$macros.letfn.cljs$core$IFn$_invoke$arity$variadic = (function (_AMPERSAND_form,_AMPERSAND_env,fnspecs,body){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"letfn*","letfn*",-110097810,null)),(function (){var x__23719__auto__ = cljs.core.vec.call(null,cljs.core.interleave.call(null,cljs.core.map.call(null,cljs.core.first,fnspecs),cljs.core.map.call(null,(function (p1__28000_SHARP_){
return cljs.core.cons.call(null,new cljs.core.Symbol("cljs.core$macros","fn","cljs.core$macros/fn",-187522821,null),p1__28000_SHARP_);
}),fnspecs)));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),body)));
});

cljs.core$macros.letfn.cljs$lang$maxFixedArity = (3);

cljs.core$macros.letfn.cljs$lang$applyTo = (function (seq28001){
var G__28002 = cljs.core.first.call(null,seq28001);
var seq28001__$1 = cljs.core.next.call(null,seq28001);
var G__28003 = cljs.core.first.call(null,seq28001__$1);
var seq28001__$2 = cljs.core.next.call(null,seq28001__$1);
var G__28004 = cljs.core.first.call(null,seq28001__$2);
var seq28001__$3 = cljs.core.next.call(null,seq28001__$2);
return cljs.core$macros.letfn.cljs$core$IFn$_invoke$arity$variadic(G__28002,G__28003,G__28004,seq28001__$3);
});

cljs.core$macros.letfn.cljs$lang$macro = true;
/**
 * Expands into code that creates a fn that expects to be passed an
 *   object and any args and calls the named instance method on the
 *   object passing the args. Use when you want to treat a Java method as
 *   a first-class fn. name may be type-hinted with the method receiver's
 *   type in order to avoid reflective calls.
 */
cljs.core$macros.memfn = (function cljs$core$macros$memfn(var_args){
var args__23962__auto__ = [];
var len__23955__auto___28012 = arguments.length;
var i__23956__auto___28013 = (0);
while(true){
if((i__23956__auto___28013 < len__23955__auto___28012)){
args__23962__auto__.push((arguments[i__23956__auto___28013]));

var G__28014 = (i__23956__auto___28013 + (1));
i__23956__auto___28013 = G__28014;
continue;
} else {
}
break;
}

var argseq__23963__auto__ = ((((3) < args__23962__auto__.length))?(new cljs.core.IndexedSeq(args__23962__auto__.slice((3)),(0),null)):null);
return cljs.core$macros.memfn.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),argseq__23963__auto__);
});

cljs.core$macros.memfn.cljs$core$IFn$_invoke$arity$variadic = (function (_AMPERSAND_form,_AMPERSAND_env,name,args){
var t = cljs.core.with_meta.call(null,cljs.core.gensym.call(null,"target"),cljs.core.meta.call(null,name));
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","fn","cljs.core$macros/fn",-187522821,null)),(function (){var x__23719__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,(function (){var x__23719__auto__ = t;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),args))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,".",".",1975675962,null)),(function (){var x__23719__auto__ = t;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,(function (){var x__23719__auto__ = name;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),args)));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
});

cljs.core$macros.memfn.cljs$lang$maxFixedArity = (3);

cljs.core$macros.memfn.cljs$lang$applyTo = (function (seq28008){
var G__28009 = cljs.core.first.call(null,seq28008);
var seq28008__$1 = cljs.core.next.call(null,seq28008);
var G__28010 = cljs.core.first.call(null,seq28008__$1);
var seq28008__$2 = cljs.core.next.call(null,seq28008__$1);
var G__28011 = cljs.core.first.call(null,seq28008__$2);
var seq28008__$3 = cljs.core.next.call(null,seq28008__$2);
return cljs.core$macros.memfn.cljs$core$IFn$_invoke$arity$variadic(G__28009,G__28010,G__28011,seq28008__$3);
});

cljs.core$macros.memfn.cljs$lang$macro = true;
/**
 * Evaluates test. If logical true, evaluates body in an implicit do.
 */
cljs.core$macros.when = (function cljs$core$macros$when(var_args){
var args__23962__auto__ = [];
var len__23955__auto___28019 = arguments.length;
var i__23956__auto___28020 = (0);
while(true){
if((i__23956__auto___28020 < len__23955__auto___28019)){
args__23962__auto__.push((arguments[i__23956__auto___28020]));

var G__28021 = (i__23956__auto___28020 + (1));
i__23956__auto___28020 = G__28021;
continue;
} else {
}
break;
}

var argseq__23963__auto__ = ((((3) < args__23962__auto__.length))?(new cljs.core.IndexedSeq(args__23962__auto__.slice((3)),(0),null)):null);
return cljs.core$macros.when.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),argseq__23963__auto__);
});

cljs.core$macros.when.cljs$core$IFn$_invoke$arity$variadic = (function (_AMPERSAND_form,_AMPERSAND_env,test,body){
return cljs.core._conj.call(null,(function (){var x__23719__auto__ = test;
return cljs.core._conj.call(null,(function (){var x__23719__auto____$1 = cljs.core.cons.call(null,new cljs.core.Symbol(null,"do","do",1686842252,null),body);
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto____$1);
})(),x__23719__auto__);
})(),new cljs.core.Symbol(null,"if","if",1181717262,null));
});

cljs.core$macros.when.cljs$lang$maxFixedArity = (3);

cljs.core$macros.when.cljs$lang$applyTo = (function (seq28015){
var G__28016 = cljs.core.first.call(null,seq28015);
var seq28015__$1 = cljs.core.next.call(null,seq28015);
var G__28017 = cljs.core.first.call(null,seq28015__$1);
var seq28015__$2 = cljs.core.next.call(null,seq28015__$1);
var G__28018 = cljs.core.first.call(null,seq28015__$2);
var seq28015__$3 = cljs.core.next.call(null,seq28015__$2);
return cljs.core$macros.when.cljs$core$IFn$_invoke$arity$variadic(G__28016,G__28017,G__28018,seq28015__$3);
});

cljs.core$macros.when.cljs$lang$macro = true;
/**
 * bindings => x xs
 * 
 *   Roughly the same as (when (seq xs) (let [x (first xs)] body)) but xs is evaluated only once
 */
cljs.core$macros.when_first = (function cljs$core$macros$when_first(var_args){
var args__23962__auto__ = [];
var len__23955__auto___28028 = arguments.length;
var i__23956__auto___28029 = (0);
while(true){
if((i__23956__auto___28029 < len__23955__auto___28028)){
args__23962__auto__.push((arguments[i__23956__auto___28029]));

var G__28030 = (i__23956__auto___28029 + (1));
i__23956__auto___28029 = G__28030;
continue;
} else {
}
break;
}

var argseq__23963__auto__ = ((((3) < args__23962__auto__.length))?(new cljs.core.IndexedSeq(args__23962__auto__.slice((3)),(0),null)):null);
return cljs.core$macros.when_first.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),argseq__23963__auto__);
});

cljs.core$macros.when_first.cljs$core$IFn$_invoke$arity$variadic = (function (_AMPERSAND_form,_AMPERSAND_env,bindings,body){
if(cljs.core.vector_QMARK_.call(null,bindings)){
} else {
throw cljs.core.ex_info.call(null,"when-first requires a vector for its binding",cljs.core.PersistentArrayMap.EMPTY);
}

if(cljs.core._EQ_.call(null,(2),cljs.core.count.call(null,bindings))){
} else {
throw cljs.core.ex_info.call(null,"when-first requires exactly 2 forms in binding vector",cljs.core.PersistentArrayMap.EMPTY);
}


var vec__28027 = bindings;
var x = cljs.core.nth.call(null,vec__28027,(0),null);
var xs = cljs.core.nth.call(null,vec__28027,(1),null);
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","when-let","cljs.core$macros/when-let",-2004472648,null)),(function (){var x__23719__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"xs__28022__auto__","xs__28022__auto__",-810350564,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","seq","cljs.core/seq",-1649497689,null)),(function (){var x__23719__auto__ = xs;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})()))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","let","cljs.core$macros/let",-160286726,null)),(function (){var x__23719__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,(function (){var x__23719__auto__ = x;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","first","cljs.core/first",-752535972,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"xs__28022__auto__","xs__28022__auto__",-810350564,null)))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})()))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),body)));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
});

cljs.core$macros.when_first.cljs$lang$maxFixedArity = (3);

cljs.core$macros.when_first.cljs$lang$applyTo = (function (seq28023){
var G__28024 = cljs.core.first.call(null,seq28023);
var seq28023__$1 = cljs.core.next.call(null,seq28023);
var G__28025 = cljs.core.first.call(null,seq28023__$1);
var seq28023__$2 = cljs.core.next.call(null,seq28023__$1);
var G__28026 = cljs.core.first.call(null,seq28023__$2);
var seq28023__$3 = cljs.core.next.call(null,seq28023__$2);
return cljs.core$macros.when_first.cljs$core$IFn$_invoke$arity$variadic(G__28024,G__28025,G__28026,seq28023__$3);
});

cljs.core$macros.when_first.cljs$lang$macro = true;
/**
 * bindings => binding-form test
 * 
 *   When test is true, evaluates body with binding-form bound to the value of test
 */
cljs.core$macros.when_let = (function cljs$core$macros$when_let(var_args){
var args__23962__auto__ = [];
var len__23955__auto___28036 = arguments.length;
var i__23956__auto___28037 = (0);
while(true){
if((i__23956__auto___28037 < len__23955__auto___28036)){
args__23962__auto__.push((arguments[i__23956__auto___28037]));

var G__28038 = (i__23956__auto___28037 + (1));
i__23956__auto___28037 = G__28038;
continue;
} else {
}
break;
}

var argseq__23963__auto__ = ((((3) < args__23962__auto__.length))?(new cljs.core.IndexedSeq(args__23962__auto__.slice((3)),(0),null)):null);
return cljs.core$macros.when_let.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),argseq__23963__auto__);
});

cljs.core$macros.when_let.cljs$core$IFn$_invoke$arity$variadic = (function (_AMPERSAND_form,_AMPERSAND_env,bindings,body){
if(cljs.core.vector_QMARK_.call(null,bindings)){
} else {
throw cljs.core.ex_info.call(null,"when-let requires a vector for its binding",cljs.core.PersistentArrayMap.EMPTY);
}

if(cljs.core._EQ_.call(null,(2),cljs.core.count.call(null,bindings))){
} else {
throw cljs.core.ex_info.call(null,"when-let requires exactly 2 forms in binding vector",cljs.core.PersistentArrayMap.EMPTY);
}


var form = bindings.call(null,(0));
var tst = bindings.call(null,(1));
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","let","cljs.core$macros/let",-160286726,null)),(function (){var x__23719__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"temp__28031__auto__","temp__28031__auto__",1176408453,null)),(function (){var x__23719__auto__ = tst;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})()))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","when","cljs.core$macros/when",328457725,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"temp__28031__auto__","temp__28031__auto__",1176408453,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","let","cljs.core$macros/let",-160286726,null)),(function (){var x__23719__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,(function (){var x__23719__auto__ = form;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"temp__28031__auto__","temp__28031__auto__",1176408453,null))))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),body)));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
});

cljs.core$macros.when_let.cljs$lang$maxFixedArity = (3);

cljs.core$macros.when_let.cljs$lang$applyTo = (function (seq28032){
var G__28033 = cljs.core.first.call(null,seq28032);
var seq28032__$1 = cljs.core.next.call(null,seq28032);
var G__28034 = cljs.core.first.call(null,seq28032__$1);
var seq28032__$2 = cljs.core.next.call(null,seq28032__$1);
var G__28035 = cljs.core.first.call(null,seq28032__$2);
var seq28032__$3 = cljs.core.next.call(null,seq28032__$2);
return cljs.core$macros.when_let.cljs$core$IFn$_invoke$arity$variadic(G__28033,G__28034,G__28035,seq28032__$3);
});

cljs.core$macros.when_let.cljs$lang$macro = true;
/**
 * Evaluates test. If logical false, evaluates body in an implicit do.
 */
cljs.core$macros.when_not = (function cljs$core$macros$when_not(var_args){
var args__23962__auto__ = [];
var len__23955__auto___28043 = arguments.length;
var i__23956__auto___28044 = (0);
while(true){
if((i__23956__auto___28044 < len__23955__auto___28043)){
args__23962__auto__.push((arguments[i__23956__auto___28044]));

var G__28045 = (i__23956__auto___28044 + (1));
i__23956__auto___28044 = G__28045;
continue;
} else {
}
break;
}

var argseq__23963__auto__ = ((((3) < args__23962__auto__.length))?(new cljs.core.IndexedSeq(args__23962__auto__.slice((3)),(0),null)):null);
return cljs.core$macros.when_not.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),argseq__23963__auto__);
});

cljs.core$macros.when_not.cljs$core$IFn$_invoke$arity$variadic = (function (_AMPERSAND_form,_AMPERSAND_env,test,body){
return cljs.core._conj.call(null,(function (){var x__23719__auto__ = test;
return cljs.core._conj.call(null,cljs.core._conj.call(null,(function (){var x__23719__auto____$1 = cljs.core.cons.call(null,new cljs.core.Symbol(null,"do","do",1686842252,null),body);
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto____$1);
})(),null),x__23719__auto__);
})(),new cljs.core.Symbol(null,"if","if",1181717262,null));
});

cljs.core$macros.when_not.cljs$lang$maxFixedArity = (3);

cljs.core$macros.when_not.cljs$lang$applyTo = (function (seq28039){
var G__28040 = cljs.core.first.call(null,seq28039);
var seq28039__$1 = cljs.core.next.call(null,seq28039);
var G__28041 = cljs.core.first.call(null,seq28039__$1);
var seq28039__$2 = cljs.core.next.call(null,seq28039__$1);
var G__28042 = cljs.core.first.call(null,seq28039__$2);
var seq28039__$3 = cljs.core.next.call(null,seq28039__$2);
return cljs.core$macros.when_not.cljs$core$IFn$_invoke$arity$variadic(G__28040,G__28041,G__28042,seq28039__$3);
});

cljs.core$macros.when_not.cljs$lang$macro = true;
/**
 * Repeatedly executes body while test expression is true. Presumes
 *   some side-effect will cause test to become false/nil. Returns nil
 */
cljs.core$macros.while$ = (function cljs$core$macros$while(var_args){
var args__23962__auto__ = [];
var len__23955__auto___28050 = arguments.length;
var i__23956__auto___28051 = (0);
while(true){
if((i__23956__auto___28051 < len__23955__auto___28050)){
args__23962__auto__.push((arguments[i__23956__auto___28051]));

var G__28052 = (i__23956__auto___28051 + (1));
i__23956__auto___28051 = G__28052;
continue;
} else {
}
break;
}

var argseq__23963__auto__ = ((((3) < args__23962__auto__.length))?(new cljs.core.IndexedSeq(args__23962__auto__.slice((3)),(0),null)):null);
return cljs.core$macros.while$.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),argseq__23963__auto__);
});

cljs.core$macros.while$.cljs$core$IFn$_invoke$arity$variadic = (function (_AMPERSAND_form,_AMPERSAND_env,test,body){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","loop","cljs.core$macros/loop",1731108390,null)),(function (){var x__23719__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","when","cljs.core$macros/when",328457725,null)),(function (){var x__23719__auto__ = test;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),body,(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"recur","recur",1202958259,null)))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
});

cljs.core$macros.while$.cljs$lang$maxFixedArity = (3);

cljs.core$macros.while$.cljs$lang$applyTo = (function (seq28046){
var G__28047 = cljs.core.first.call(null,seq28046);
var seq28046__$1 = cljs.core.next.call(null,seq28046);
var G__28048 = cljs.core.first.call(null,seq28046__$1);
var seq28046__$2 = cljs.core.next.call(null,seq28046__$1);
var G__28049 = cljs.core.first.call(null,seq28046__$2);
var seq28046__$3 = cljs.core.next.call(null,seq28046__$2);
return cljs.core$macros.while$.cljs$core$IFn$_invoke$arity$variadic(G__28047,G__28048,G__28049,seq28046__$3);
});

cljs.core$macros.while$.cljs$lang$macro = true;
/**
 * Takes an expression and a set of test/form pairs. Threads expr (via ->)
 *   through each form for which the corresponding test
 *   expression is true. Note that, unlike cond branching, cond-> threading does
 *   not short circuit after the first true test expression.
 */
cljs.core$macros.cond__GT_ = (function cljs$core$macros$cond__GT_(var_args){
var args__23962__auto__ = [];
var len__23955__auto___28059 = arguments.length;
var i__23956__auto___28060 = (0);
while(true){
if((i__23956__auto___28060 < len__23955__auto___28059)){
args__23962__auto__.push((arguments[i__23956__auto___28060]));

var G__28061 = (i__23956__auto___28060 + (1));
i__23956__auto___28060 = G__28061;
continue;
} else {
}
break;
}

var argseq__23963__auto__ = ((((3) < args__23962__auto__.length))?(new cljs.core.IndexedSeq(args__23962__auto__.slice((3)),(0),null)):null);
return cljs.core$macros.cond__GT_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),argseq__23963__auto__);
});

cljs.core$macros.cond__GT_.cljs$core$IFn$_invoke$arity$variadic = (function (_AMPERSAND_form,_AMPERSAND_env,expr,clauses){
if(cljs.core.even_QMARK_.call(null,cljs.core.count.call(null,clauses))){
} else {
throw (new Error("Assert failed: (even? (count clauses))"));
}

var g = cljs.core.gensym.call(null);
var pstep = ((function (g){
return (function (p__28057){
var vec__28058 = p__28057;
var test = cljs.core.nth.call(null,vec__28058,(0),null);
var step = cljs.core.nth.call(null,vec__28058,(1),null);
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"if","if",1181717262,null)),(function (){var x__23719__auto__ = test;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","->","cljs.core$macros/->",-1519455206,null)),(function (){var x__23719__auto__ = g;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = step;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = g;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
});})(g))
;
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","let","cljs.core$macros/let",-160286726,null)),(function (){var x__23719__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,(function (){var x__23719__auto__ = g;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = expr;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),cljs.core.interleave.call(null,cljs.core.repeat.call(null,g),cljs.core.map.call(null,pstep,cljs.core.partition.call(null,(2),clauses)))))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = g;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
});

cljs.core$macros.cond__GT_.cljs$lang$maxFixedArity = (3);

cljs.core$macros.cond__GT_.cljs$lang$applyTo = (function (seq28053){
var G__28054 = cljs.core.first.call(null,seq28053);
var seq28053__$1 = cljs.core.next.call(null,seq28053);
var G__28055 = cljs.core.first.call(null,seq28053__$1);
var seq28053__$2 = cljs.core.next.call(null,seq28053__$1);
var G__28056 = cljs.core.first.call(null,seq28053__$2);
var seq28053__$3 = cljs.core.next.call(null,seq28053__$2);
return cljs.core$macros.cond__GT_.cljs$core$IFn$_invoke$arity$variadic(G__28054,G__28055,G__28056,seq28053__$3);
});

cljs.core$macros.cond__GT_.cljs$lang$macro = true;
/**
 * Takes an expression and a set of test/form pairs. Threads expr (via ->>)
 *   through each form for which the corresponding test expression
 *   is true.  Note that, unlike cond branching, cond->> threading does not short circuit
 *   after the first true test expression.
 */
cljs.core$macros.cond__GT__GT_ = (function cljs$core$macros$cond__GT__GT_(var_args){
var args__23962__auto__ = [];
var len__23955__auto___28068 = arguments.length;
var i__23956__auto___28069 = (0);
while(true){
if((i__23956__auto___28069 < len__23955__auto___28068)){
args__23962__auto__.push((arguments[i__23956__auto___28069]));

var G__28070 = (i__23956__auto___28069 + (1));
i__23956__auto___28069 = G__28070;
continue;
} else {
}
break;
}

var argseq__23963__auto__ = ((((3) < args__23962__auto__.length))?(new cljs.core.IndexedSeq(args__23962__auto__.slice((3)),(0),null)):null);
return cljs.core$macros.cond__GT__GT_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),argseq__23963__auto__);
});

cljs.core$macros.cond__GT__GT_.cljs$core$IFn$_invoke$arity$variadic = (function (_AMPERSAND_form,_AMPERSAND_env,expr,clauses){
if(cljs.core.even_QMARK_.call(null,cljs.core.count.call(null,clauses))){
} else {
throw (new Error("Assert failed: (even? (count clauses))"));
}

var g = cljs.core.gensym.call(null);
var pstep = ((function (g){
return (function (p__28066){
var vec__28067 = p__28066;
var test = cljs.core.nth.call(null,vec__28067,(0),null);
var step = cljs.core.nth.call(null,vec__28067,(1),null);
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"if","if",1181717262,null)),(function (){var x__23719__auto__ = test;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","->>","cljs.core$macros/->>",-1353108561,null)),(function (){var x__23719__auto__ = g;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = step;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = g;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
});})(g))
;
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","let","cljs.core$macros/let",-160286726,null)),(function (){var x__23719__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,(function (){var x__23719__auto__ = g;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = expr;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),cljs.core.interleave.call(null,cljs.core.repeat.call(null,g),cljs.core.map.call(null,pstep,cljs.core.partition.call(null,(2),clauses)))))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = g;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
});

cljs.core$macros.cond__GT__GT_.cljs$lang$maxFixedArity = (3);

cljs.core$macros.cond__GT__GT_.cljs$lang$applyTo = (function (seq28062){
var G__28063 = cljs.core.first.call(null,seq28062);
var seq28062__$1 = cljs.core.next.call(null,seq28062);
var G__28064 = cljs.core.first.call(null,seq28062__$1);
var seq28062__$2 = cljs.core.next.call(null,seq28062__$1);
var G__28065 = cljs.core.first.call(null,seq28062__$2);
var seq28062__$3 = cljs.core.next.call(null,seq28062__$2);
return cljs.core$macros.cond__GT__GT_.cljs$core$IFn$_invoke$arity$variadic(G__28063,G__28064,G__28065,seq28062__$3);
});

cljs.core$macros.cond__GT__GT_.cljs$lang$macro = true;
/**
 * Binds name to expr, evaluates the first form in the lexical context
 *   of that binding, then binds name to that result, repeating for each
 *   successive form, returning the result of the last form.
 */
cljs.core$macros.as__GT_ = (function cljs$core$macros$as__GT_(var_args){
var args__23962__auto__ = [];
var len__23955__auto___28076 = arguments.length;
var i__23956__auto___28077 = (0);
while(true){
if((i__23956__auto___28077 < len__23955__auto___28076)){
args__23962__auto__.push((arguments[i__23956__auto___28077]));

var G__28078 = (i__23956__auto___28077 + (1));
i__23956__auto___28077 = G__28078;
continue;
} else {
}
break;
}

var argseq__23963__auto__ = ((((4) < args__23962__auto__.length))?(new cljs.core.IndexedSeq(args__23962__auto__.slice((4)),(0),null)):null);
return cljs.core$macros.as__GT_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]),argseq__23963__auto__);
});

cljs.core$macros.as__GT_.cljs$core$IFn$_invoke$arity$variadic = (function (_AMPERSAND_form,_AMPERSAND_env,expr,name,forms){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","let","cljs.core$macros/let",-160286726,null)),(function (){var x__23719__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,(function (){var x__23719__auto__ = name;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = expr;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),cljs.core.interleave.call(null,cljs.core.repeat.call(null,name),forms)))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = name;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
});

cljs.core$macros.as__GT_.cljs$lang$maxFixedArity = (4);

cljs.core$macros.as__GT_.cljs$lang$applyTo = (function (seq28071){
var G__28072 = cljs.core.first.call(null,seq28071);
var seq28071__$1 = cljs.core.next.call(null,seq28071);
var G__28073 = cljs.core.first.call(null,seq28071__$1);
var seq28071__$2 = cljs.core.next.call(null,seq28071__$1);
var G__28074 = cljs.core.first.call(null,seq28071__$2);
var seq28071__$3 = cljs.core.next.call(null,seq28071__$2);
var G__28075 = cljs.core.first.call(null,seq28071__$3);
var seq28071__$4 = cljs.core.next.call(null,seq28071__$3);
return cljs.core$macros.as__GT_.cljs$core$IFn$_invoke$arity$variadic(G__28072,G__28073,G__28074,G__28075,seq28071__$4);
});

cljs.core$macros.as__GT_.cljs$lang$macro = true;
/**
 * When expr is not nil, threads it into the first form (via ->),
 *   and when that result is not nil, through the next etc
 */
cljs.core$macros.some__GT_ = (function cljs$core$macros$some__GT_(var_args){
var args__23962__auto__ = [];
var len__23955__auto___28083 = arguments.length;
var i__23956__auto___28084 = (0);
while(true){
if((i__23956__auto___28084 < len__23955__auto___28083)){
args__23962__auto__.push((arguments[i__23956__auto___28084]));

var G__28085 = (i__23956__auto___28084 + (1));
i__23956__auto___28084 = G__28085;
continue;
} else {
}
break;
}

var argseq__23963__auto__ = ((((3) < args__23962__auto__.length))?(new cljs.core.IndexedSeq(args__23962__auto__.slice((3)),(0),null)):null);
return cljs.core$macros.some__GT_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),argseq__23963__auto__);
});

cljs.core$macros.some__GT_.cljs$core$IFn$_invoke$arity$variadic = (function (_AMPERSAND_form,_AMPERSAND_env,expr,forms){
var g = cljs.core.gensym.call(null);
var pstep = ((function (g){
return (function (step){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"if","if",1181717262,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","nil?","cljs.core$macros/nil?",83624258,null)),(function (){var x__23719__auto__ = g;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,null),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","->","cljs.core$macros/->",-1519455206,null)),(function (){var x__23719__auto__ = g;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = step;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
});})(g))
;
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","let","cljs.core$macros/let",-160286726,null)),(function (){var x__23719__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,(function (){var x__23719__auto__ = g;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = expr;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),cljs.core.interleave.call(null,cljs.core.repeat.call(null,g),cljs.core.map.call(null,pstep,forms))))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = g;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
});

cljs.core$macros.some__GT_.cljs$lang$maxFixedArity = (3);

cljs.core$macros.some__GT_.cljs$lang$applyTo = (function (seq28079){
var G__28080 = cljs.core.first.call(null,seq28079);
var seq28079__$1 = cljs.core.next.call(null,seq28079);
var G__28081 = cljs.core.first.call(null,seq28079__$1);
var seq28079__$2 = cljs.core.next.call(null,seq28079__$1);
var G__28082 = cljs.core.first.call(null,seq28079__$2);
var seq28079__$3 = cljs.core.next.call(null,seq28079__$2);
return cljs.core$macros.some__GT_.cljs$core$IFn$_invoke$arity$variadic(G__28080,G__28081,G__28082,seq28079__$3);
});

cljs.core$macros.some__GT_.cljs$lang$macro = true;
/**
 * When expr is not nil, threads it into the first form (via ->>),
 *   and when that result is not nil, through the next etc
 */
cljs.core$macros.some__GT__GT_ = (function cljs$core$macros$some__GT__GT_(var_args){
var args__23962__auto__ = [];
var len__23955__auto___28090 = arguments.length;
var i__23956__auto___28091 = (0);
while(true){
if((i__23956__auto___28091 < len__23955__auto___28090)){
args__23962__auto__.push((arguments[i__23956__auto___28091]));

var G__28092 = (i__23956__auto___28091 + (1));
i__23956__auto___28091 = G__28092;
continue;
} else {
}
break;
}

var argseq__23963__auto__ = ((((3) < args__23962__auto__.length))?(new cljs.core.IndexedSeq(args__23962__auto__.slice((3)),(0),null)):null);
return cljs.core$macros.some__GT__GT_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),argseq__23963__auto__);
});

cljs.core$macros.some__GT__GT_.cljs$core$IFn$_invoke$arity$variadic = (function (_AMPERSAND_form,_AMPERSAND_env,expr,forms){
var g = cljs.core.gensym.call(null);
var pstep = ((function (g){
return (function (step){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"if","if",1181717262,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","nil?","cljs.core$macros/nil?",83624258,null)),(function (){var x__23719__auto__ = g;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,null),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","->>","cljs.core$macros/->>",-1353108561,null)),(function (){var x__23719__auto__ = g;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = step;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
});})(g))
;
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","let","cljs.core$macros/let",-160286726,null)),(function (){var x__23719__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,(function (){var x__23719__auto__ = g;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = expr;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),cljs.core.interleave.call(null,cljs.core.repeat.call(null,g),cljs.core.map.call(null,pstep,forms))))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = g;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
});

cljs.core$macros.some__GT__GT_.cljs$lang$maxFixedArity = (3);

cljs.core$macros.some__GT__GT_.cljs$lang$applyTo = (function (seq28086){
var G__28087 = cljs.core.first.call(null,seq28086);
var seq28086__$1 = cljs.core.next.call(null,seq28086);
var G__28088 = cljs.core.first.call(null,seq28086__$1);
var seq28086__$2 = cljs.core.next.call(null,seq28086__$1);
var G__28089 = cljs.core.first.call(null,seq28086__$2);
var seq28086__$3 = cljs.core.next.call(null,seq28086__$2);
return cljs.core$macros.some__GT__GT_.cljs$core$IFn$_invoke$arity$variadic(G__28087,G__28088,G__28089,seq28086__$3);
});

cljs.core$macros.some__GT__GT_.cljs$lang$macro = true;
/**
 * bindings => binding-form test
 * 
 *    If test is not nil, evaluates then with binding-form bound to the
 *    value of test, if not, yields else
 */
cljs.core$macros.if_some = (function cljs$core$macros$if_some(var_args){
var args28094 = [];
var len__23955__auto___28103 = arguments.length;
var i__23956__auto___28104 = (0);
while(true){
if((i__23956__auto___28104 < len__23955__auto___28103)){
args28094.push((arguments[i__23956__auto___28104]));

var G__28105 = (i__23956__auto___28104 + (1));
i__23956__auto___28104 = G__28105;
continue;
} else {
}
break;
}

var G__28102 = args28094.length;
switch (G__28102) {
case 4:
return cljs.core$macros.if_some.cljs$core$IFn$_invoke$arity$4((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]));

break;
default:
var argseq__23974__auto__ = (new cljs.core.IndexedSeq(args28094.slice((5)),(0),null));
return cljs.core$macros.if_some.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]),(arguments[(4)]),argseq__23974__auto__);

}
});

cljs.core$macros.if_some.cljs$core$IFn$_invoke$arity$4 = (function (_AMPERSAND_form,_AMPERSAND_env,bindings,then){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","if-some","cljs.core$macros/if-some",1405341529,null)),(function (){var x__23719__auto__ = bindings;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = then;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,null))));
});

cljs.core$macros.if_some.cljs$core$IFn$_invoke$arity$variadic = (function (_AMPERSAND_form,_AMPERSAND_env,bindings,then,else$,oldform){
if(cljs.core.vector_QMARK_.call(null,bindings)){
} else {
throw cljs.core.ex_info.call(null,"if-some requires a vector for its binding",cljs.core.PersistentArrayMap.EMPTY);
}

if(cljs.core.empty_QMARK_.call(null,oldform)){
} else {
throw cljs.core.ex_info.call(null,"if-some requires 1 or 2 forms after binding vector",cljs.core.PersistentArrayMap.EMPTY);
}

if(cljs.core._EQ_.call(null,(2),cljs.core.count.call(null,bindings))){
} else {
throw cljs.core.ex_info.call(null,"if-some requires exactly 2 forms in binding vector",cljs.core.PersistentArrayMap.EMPTY);
}


var form = bindings.call(null,(0));
var tst = bindings.call(null,(1));
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","let","cljs.core$macros/let",-160286726,null)),(function (){var x__23719__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"temp__28093__auto__","temp__28093__auto__",319927375,null)),(function (){var x__23719__auto__ = tst;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})()))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"if","if",1181717262,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","nil?","cljs.core$macros/nil?",83624258,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"temp__28093__auto__","temp__28093__auto__",319927375,null)))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = else$;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","let","cljs.core$macros/let",-160286726,null)),(function (){var x__23719__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,(function (){var x__23719__auto__ = form;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"temp__28093__auto__","temp__28093__auto__",319927375,null))))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = then;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
});

cljs.core$macros.if_some.cljs$lang$applyTo = (function (seq28095){
var G__28096 = cljs.core.first.call(null,seq28095);
var seq28095__$1 = cljs.core.next.call(null,seq28095);
var G__28097 = cljs.core.first.call(null,seq28095__$1);
var seq28095__$2 = cljs.core.next.call(null,seq28095__$1);
var G__28098 = cljs.core.first.call(null,seq28095__$2);
var seq28095__$3 = cljs.core.next.call(null,seq28095__$2);
var G__28099 = cljs.core.first.call(null,seq28095__$3);
var seq28095__$4 = cljs.core.next.call(null,seq28095__$3);
var G__28100 = cljs.core.first.call(null,seq28095__$4);
var seq28095__$5 = cljs.core.next.call(null,seq28095__$4);
return cljs.core$macros.if_some.cljs$core$IFn$_invoke$arity$variadic(G__28096,G__28097,G__28098,G__28099,G__28100,seq28095__$5);
});

cljs.core$macros.if_some.cljs$lang$maxFixedArity = (5);

cljs.core$macros.if_some.cljs$lang$macro = true;
/**
 * bindings => binding-form test
 * 
 *    When test is not nil, evaluates body with binding-form bound to the
 *    value of test
 */
cljs.core$macros.when_some = (function cljs$core$macros$when_some(var_args){
var args__23962__auto__ = [];
var len__23955__auto___28112 = arguments.length;
var i__23956__auto___28113 = (0);
while(true){
if((i__23956__auto___28113 < len__23955__auto___28112)){
args__23962__auto__.push((arguments[i__23956__auto___28113]));

var G__28114 = (i__23956__auto___28113 + (1));
i__23956__auto___28113 = G__28114;
continue;
} else {
}
break;
}

var argseq__23963__auto__ = ((((3) < args__23962__auto__.length))?(new cljs.core.IndexedSeq(args__23962__auto__.slice((3)),(0),null)):null);
return cljs.core$macros.when_some.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),argseq__23963__auto__);
});

cljs.core$macros.when_some.cljs$core$IFn$_invoke$arity$variadic = (function (_AMPERSAND_form,_AMPERSAND_env,bindings,body){
if(cljs.core.vector_QMARK_.call(null,bindings)){
} else {
throw cljs.core.ex_info.call(null,"when-some requires a vector for its binding",cljs.core.PersistentArrayMap.EMPTY);
}

if(cljs.core._EQ_.call(null,(2),cljs.core.count.call(null,bindings))){
} else {
throw cljs.core.ex_info.call(null,"when-some requires exactly 2 forms in binding vector",cljs.core.PersistentArrayMap.EMPTY);
}


var form = bindings.call(null,(0));
var tst = bindings.call(null,(1));
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","let","cljs.core$macros/let",-160286726,null)),(function (){var x__23719__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"temp__28107__auto__","temp__28107__auto__",2031172362,null)),(function (){var x__23719__auto__ = tst;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})()))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"if","if",1181717262,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","nil?","cljs.core$macros/nil?",83624258,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"temp__28107__auto__","temp__28107__auto__",2031172362,null)))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,null),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","let","cljs.core$macros/let",-160286726,null)),(function (){var x__23719__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,(function (){var x__23719__auto__ = form;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"temp__28107__auto__","temp__28107__auto__",2031172362,null))))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),body)));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
});

cljs.core$macros.when_some.cljs$lang$maxFixedArity = (3);

cljs.core$macros.when_some.cljs$lang$applyTo = (function (seq28108){
var G__28109 = cljs.core.first.call(null,seq28108);
var seq28108__$1 = cljs.core.next.call(null,seq28108);
var G__28110 = cljs.core.first.call(null,seq28108__$1);
var seq28108__$2 = cljs.core.next.call(null,seq28108__$1);
var G__28111 = cljs.core.first.call(null,seq28108__$2);
var seq28108__$3 = cljs.core.next.call(null,seq28108__$2);
return cljs.core$macros.when_some.cljs$core$IFn$_invoke$arity$variadic(G__28109,G__28110,G__28111,seq28108__$3);
});

cljs.core$macros.when_some.cljs$lang$macro = true;
/**
 * A good fdecl looks like (([a] ...) ([a b] ...)) near the end of defn.
 */
cljs.core$macros.assert_valid_fdecl = (function cljs$core$macros$assert_valid_fdecl(fdecl){
if(cljs.core.empty_QMARK_.call(null,fdecl)){
throw (new Error("Parameter declaration missing"));
} else {
}

var argdecls = cljs.core.map.call(null,(function (p1__28115_SHARP_){
if(cljs.core.seq_QMARK_.call(null,p1__28115_SHARP_)){
return cljs.core.first.call(null,p1__28115_SHARP_);
} else {
throw (new Error(((cljs.core.seq_QMARK_.call(null,cljs.core.first.call(null,fdecl)))?[cljs.core.str("Invalid signature \""),cljs.core.str(p1__28115_SHARP_),cljs.core.str("\" should be a list")].join(''):[cljs.core.str("Parameter declaration \""),cljs.core.str(p1__28115_SHARP_),cljs.core.str("\" should be a vector")].join(''))));
}
}),fdecl);
var bad_args = cljs.core.seq.call(null,cljs.core.remove.call(null,((function (argdecls){
return (function (p1__28116_SHARP_){
return cljs.core.vector_QMARK_.call(null,p1__28116_SHARP_);
});})(argdecls))
,argdecls));
if(bad_args){
throw (new Error([cljs.core.str("Parameter declaration \""),cljs.core.str(cljs.core.first.call(null,bad_args)),cljs.core.str("\" should be a vector")].join('')));
} else {
return null;
}
});
cljs.core$macros.sigs = (function cljs$core$macros$sigs(fdecl){
cljs.core$macros.assert_valid_fdecl.call(null,fdecl);

var asig = (function (fdecl__$1){
var arglist = cljs.core.first.call(null,fdecl__$1);
var arglist__$1 = ((cljs.core._EQ_.call(null,new cljs.core.Symbol(null,"&form","&form",1482799337,null),cljs.core.first.call(null,arglist)))?cljs.core.subvec.call(null,arglist,(2),cljs.core.count.call(null,arglist)):arglist);
var body = cljs.core.next.call(null,fdecl__$1);
if(cljs.core.map_QMARK_.call(null,cljs.core.first.call(null,body))){
if(cljs.core.next.call(null,body)){
return cljs.core.with_meta.call(null,arglist__$1,cljs.core.conj.call(null,(cljs.core.truth_(cljs.core.meta.call(null,arglist__$1))?cljs.core.meta.call(null,arglist__$1):cljs.core.PersistentArrayMap.EMPTY),cljs.core.first.call(null,body)));
} else {
return arglist__$1;
}
} else {
return arglist__$1;
}
});
if(cljs.core.seq_QMARK_.call(null,cljs.core.first.call(null,fdecl))){
var ret = cljs.core.PersistentVector.EMPTY;
var fdecls = fdecl;
while(true){
if(cljs.core.truth_(fdecls)){
var G__28117 = cljs.core.conj.call(null,ret,asig.call(null,cljs.core.first.call(null,fdecls)));
var G__28118 = cljs.core.next.call(null,fdecls);
ret = G__28117;
fdecls = G__28118;
continue;
} else {
return cljs.core.seq.call(null,ret);
}
break;
}
} else {
var x__23719__auto__ = asig.call(null,fdecl);
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
}
});
cljs.core$macros.defonce = (function cljs$core$macros$defonce(_AMPERSAND_form,_AMPERSAND_env,x,init){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","when-not","cljs.core$macros/when-not",-764302244,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","exists?","cljs.core$macros/exists?",-1828590389,null)),(function (){var x__23719__auto__ = x;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"def","def",597100991,null)),(function (){var x__23719__auto__ = x;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = init;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
});

cljs.core$macros.defonce.cljs$lang$macro = true;
cljs.core$macros.destructure = (function cljs$core$macros$destructure(bindings){
var bents = cljs.core.partition.call(null,(2),bindings);
var pb = ((function (bents){
return (function cljs$core$macros$destructure_$_pb(bvec,b,v){
var pvec = ((function (bents){
return (function (bvec__$1,b__$1,val){
var gvec = cljs.core.gensym.call(null,"vec__");
var ret = cljs.core.conj.call(null,cljs.core.conj.call(null,bvec__$1,gvec),val);
var n = (0);
var bs = b__$1;
var seen_rest_QMARK_ = false;
while(true){
if(cljs.core.seq.call(null,bs)){
var firstb = cljs.core.first.call(null,bs);
if(cljs.core._EQ_.call(null,firstb,new cljs.core.Symbol(null,"&","&",-2144855648,null))){
var G__28124 = cljs$core$macros$destructure_$_pb.call(null,ret,cljs.core.second.call(null,bs),cljs.core._conj.call(null,(function (){var x__23719__auto__ = gvec;
return cljs.core._conj.call(null,(function (){var x__23719__auto____$1 = n;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto____$1);
})(),x__23719__auto__);
})(),new cljs.core.Symbol("cljs.core","nthnext","cljs.core/nthnext",-1690777327,null)));
var G__28125 = n;
var G__28126 = cljs.core.nnext.call(null,bs);
var G__28127 = true;
ret = G__28124;
n = G__28125;
bs = G__28126;
seen_rest_QMARK_ = G__28127;
continue;
} else {
if(cljs.core._EQ_.call(null,firstb,new cljs.core.Keyword(null,"as","as",1148689641))){
return cljs$core$macros$destructure_$_pb.call(null,ret,cljs.core.second.call(null,bs),gvec);
} else {
if(seen_rest_QMARK_){
throw (new Error("Unsupported binding form, only :as can follow & parameter"));
} else {
var G__28128 = cljs$core$macros$destructure_$_pb.call(null,ret,firstb,cljs.core._conj.call(null,(function (){var x__23719__auto__ = gvec;
return cljs.core._conj.call(null,(function (){var x__23719__auto____$1 = n;
return cljs.core._conj.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,null),x__23719__auto____$1);
})(),x__23719__auto__);
})(),new cljs.core.Symbol("cljs.core","nth","cljs.core/nth",1961052085,null)));
var G__28129 = (n + (1));
var G__28130 = cljs.core.next.call(null,bs);
var G__28131 = seen_rest_QMARK_;
ret = G__28128;
n = G__28129;
bs = G__28130;
seen_rest_QMARK_ = G__28131;
continue;
}

}
}
} else {
return ret;
}
break;
}
});})(bents))
;
var pmap = ((function (pvec,bents){
return (function (bvec__$1,b__$1,v__$1){
var gmap = cljs.core.gensym.call(null,"map__");
var defaults = new cljs.core.Keyword(null,"or","or",235744169).cljs$core$IFn$_invoke$arity$1(b__$1);
var ret = ((function (gmap,defaults,pvec,bents){
return (function (ret){
if(cljs.core.truth_(new cljs.core.Keyword(null,"as","as",1148689641).cljs$core$IFn$_invoke$arity$1(b__$1))){
return cljs.core.conj.call(null,ret,new cljs.core.Keyword(null,"as","as",1148689641).cljs$core$IFn$_invoke$arity$1(b__$1),gmap);
} else {
return ret;
}
});})(gmap,defaults,pvec,bents))
.call(null,cljs.core.conj.call(null,cljs.core.conj.call(null,cljs.core.conj.call(null,cljs.core.conj.call(null,bvec__$1,gmap),v__$1),gmap),cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"if","if",1181717262,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","implements?","cljs.core$macros/implements?",-94762250,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","ISeq","cljs.core/ISeq",230133392,null)),(function (){var x__23719__auto__ = gmap;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","apply","cljs.core/apply",1757277831,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","hash-map","cljs.core/hash-map",303385767,null)),(function (){var x__23719__auto__ = gmap;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = gmap;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())))));
var bes = cljs.core.reduce.call(null,((function (ret,gmap,defaults,pvec,bents){
return (function (bes,entry){
return cljs.core.reduce.call(null,((function (ret,gmap,defaults,pvec,bents){
return (function (p1__28119_SHARP_,p2__28120_SHARP_){
return cljs.core.assoc.call(null,p1__28119_SHARP_,p2__28120_SHARP_,cljs.core.val.call(null,entry).call(null,p2__28120_SHARP_));
});})(ret,gmap,defaults,pvec,bents))
,cljs.core.dissoc.call(null,bes,cljs.core.key.call(null,entry)),cljs.core.key.call(null,entry).call(null,bes));
});})(ret,gmap,defaults,pvec,bents))
,cljs.core.dissoc.call(null,b__$1,new cljs.core.Keyword(null,"as","as",1148689641),new cljs.core.Keyword(null,"or","or",235744169)),new cljs.core.PersistentArrayMap(null, 3, [new cljs.core.Keyword(null,"keys","keys",1068423698),((function (ret,gmap,defaults,pvec,bents){
return (function (p1__28121_SHARP_){
if((p1__28121_SHARP_ instanceof cljs.core.Keyword)){
return p1__28121_SHARP_;
} else {
return cljs.core.keyword.call(null,[cljs.core.str(p1__28121_SHARP_)].join(''));
}
});})(ret,gmap,defaults,pvec,bents))
,new cljs.core.Keyword(null,"strs","strs",1175537277),cljs.core.str,new cljs.core.Keyword(null,"syms","syms",-1575891762),((function (ret,gmap,defaults,pvec,bents){
return (function (p1__28122_SHARP_){
return cljs.core._conj.call(null,(function (){var x__23719__auto__ = p1__28122_SHARP_;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),new cljs.core.Symbol(null,"quote","quote",1377916282,null));
});})(ret,gmap,defaults,pvec,bents))
], null));
while(true){
if(cljs.core.seq.call(null,bes)){
var bb = cljs.core.key.call(null,cljs.core.first.call(null,bes));
var bk = cljs.core.val.call(null,cljs.core.first.call(null,bes));
var has_default = cljs.core.contains_QMARK_.call(null,defaults,bb);
var G__28132 = cljs$core$macros$destructure_$_pb.call(null,ret,bb,((has_default)?cljs.core._conj.call(null,(function (){var x__23719__auto__ = gmap;
return cljs.core._conj.call(null,(function (){var x__23719__auto____$1 = bk;
return cljs.core._conj.call(null,(function (){var x__23719__auto____$2 = defaults.call(null,bb);
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto____$2);
})(),x__23719__auto____$1);
})(),x__23719__auto__);
})(),new cljs.core.Symbol("cljs.core","get","cljs.core/get",-296075407,null)):cljs.core._conj.call(null,(function (){var x__23719__auto__ = gmap;
return cljs.core._conj.call(null,(function (){var x__23719__auto____$1 = bk;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto____$1);
})(),x__23719__auto__);
})(),new cljs.core.Symbol("cljs.core","get","cljs.core/get",-296075407,null))));
var G__28133 = cljs.core.next.call(null,bes);
ret = G__28132;
bes = G__28133;
continue;
} else {
return ret;
}
break;
}
});})(pvec,bents))
;
if((b instanceof cljs.core.Symbol)){
return cljs.core.conj.call(null,cljs.core.conj.call(null,bvec,(cljs.core.truth_(cljs.core.namespace.call(null,b))?cljs.core.symbol.call(null,cljs.core.name.call(null,b)):b)),v);
} else {
if((b instanceof cljs.core.Keyword)){
return cljs.core.conj.call(null,cljs.core.conj.call(null,bvec,cljs.core.symbol.call(null,cljs.core.name.call(null,b))),v);
} else {
if(cljs.core.vector_QMARK_.call(null,b)){
return pvec.call(null,bvec,b,v);
} else {
if(cljs.core.map_QMARK_.call(null,b)){
return pmap.call(null,bvec,b,v);
} else {
throw (new Error([cljs.core.str("Unsupported binding form: "),cljs.core.str(b)].join('')));

}
}
}
}
});})(bents))
;
var process_entry = ((function (bents,pb){
return (function (bvec,b){
return pb.call(null,bvec,cljs.core.first.call(null,b),cljs.core.second.call(null,b));
});})(bents,pb))
;
if(cljs.core.every_QMARK_.call(null,cljs.core.symbol_QMARK_,cljs.core.map.call(null,cljs.core.first,bents))){
return bindings;
} else {
var temp__4655__auto__ = cljs.core.seq.call(null,cljs.core.filter.call(null,((function (bents,pb,process_entry){
return (function (p1__28123_SHARP_){
return (cljs.core.first.call(null,p1__28123_SHARP_) instanceof cljs.core.Keyword);
});})(bents,pb,process_entry))
,bents));
if(temp__4655__auto__){
var kwbs = temp__4655__auto__;
throw (new Error([cljs.core.str("Unsupported binding key: "),cljs.core.str(cljs.core.ffirst.call(null,kwbs))].join('')));
} else {
return cljs.core.reduce.call(null,process_entry,cljs.core.PersistentVector.EMPTY,bents);
}
}
});
/**
 * Defines a var using `goog.define`. Passed default value must be
 *   string, number or boolean.
 * 
 *   Default value can be overridden at compile time using the
 *   compiler option `:closure-defines`.
 * 
 *   Example:
 *  (ns your-app.core)
 *  (goog-define DEBUG! false)
 *  ;; can be overridden with
 *  :closure-defines {"your_app.core.DEBUG_BANG_" true}
 *  or
 *  :closure-defines {'your-app.core/DEBUG! true}
 */
cljs.core$macros.goog_define = (function cljs$core$macros$goog_define(_AMPERSAND_form,_AMPERSAND_env,sym,default$){
if((typeof default$ === 'string') || (typeof default$ === 'number') || (default$ === true) || (default$ === false)){
} else {
throw cljs.core.ex_info.call(null,"goog-define requires a string, number or boolean as default value",cljs.core.PersistentArrayMap.EMPTY);
}


var defname = cljs.compiler.munge.call(null,[cljs.core.str(cljs.core._STAR_ns_STAR_),cljs.core.str("/"),cljs.core.str(sym)].join(''));
var type = ((typeof default$ === 'string')?"string":((typeof default$ === 'number')?"number":(((default$ === true) || (default$ === false))?"boolean":null)));
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"do","do",1686842252,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","declare","cljs.core$macros/declare",1172642527,null)),(function (){var x__23719__auto__ = cljs.core.symbol.call(null,sym);
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"js*","js*",-1134233646,null)),(function (){var x__23719__auto__ = [cljs.core.str("/** @define {"),cljs.core.str(type),cljs.core.str("} */")].join('');
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("goog","define","goog/define",-352722538,null)),(function (){var x__23719__auto__ = defname;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = default$;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
});

cljs.core$macros.goog_define.cljs$lang$macro = true;
/**
 * binding => binding-form init-expr
 * 
 *   Evaluates the exprs in a lexical context in which the symbols in
 *   the binding-forms are bound to their respective init-exprs or parts
 *   therein.
 */
cljs.core$macros.let$ = (function cljs$core$macros$let(var_args){
var args__23962__auto__ = [];
var len__23955__auto___28138 = arguments.length;
var i__23956__auto___28139 = (0);
while(true){
if((i__23956__auto___28139 < len__23955__auto___28138)){
args__23962__auto__.push((arguments[i__23956__auto___28139]));

var G__28140 = (i__23956__auto___28139 + (1));
i__23956__auto___28139 = G__28140;
continue;
} else {
}
break;
}

var argseq__23963__auto__ = ((((3) < args__23962__auto__.length))?(new cljs.core.IndexedSeq(args__23962__auto__.slice((3)),(0),null)):null);
return cljs.core$macros.let$.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),argseq__23963__auto__);
});

cljs.core$macros.let$.cljs$core$IFn$_invoke$arity$variadic = (function (_AMPERSAND_form,_AMPERSAND_env,bindings,body){
if(cljs.core.vector_QMARK_.call(null,bindings)){
} else {
throw cljs.core.ex_info.call(null,"let requires a vector for its binding",cljs.core.PersistentArrayMap.EMPTY);
}

if(cljs.core.even_QMARK_.call(null,cljs.core.count.call(null,bindings))){
} else {
throw cljs.core.ex_info.call(null,"let requires an even number of forms in binding vector",cljs.core.PersistentArrayMap.EMPTY);
}


return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"let*","let*",1920721458,null)),(function (){var x__23719__auto__ = cljs.core$macros.destructure.call(null,bindings);
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),body)));
});

cljs.core$macros.let$.cljs$lang$maxFixedArity = (3);

cljs.core$macros.let$.cljs$lang$applyTo = (function (seq28134){
var G__28135 = cljs.core.first.call(null,seq28134);
var seq28134__$1 = cljs.core.next.call(null,seq28134);
var G__28136 = cljs.core.first.call(null,seq28134__$1);
var seq28134__$2 = cljs.core.next.call(null,seq28134__$1);
var G__28137 = cljs.core.first.call(null,seq28134__$2);
var seq28134__$3 = cljs.core.next.call(null,seq28134__$2);
return cljs.core$macros.let$.cljs$core$IFn$_invoke$arity$variadic(G__28135,G__28136,G__28137,seq28134__$3);
});

cljs.core$macros.let$.cljs$lang$macro = true;
/**
 * Evaluates the exprs in a lexical context in which the symbols in
 *   the binding-forms are bound to their respective init-exprs or parts
 *   therein. Acts as a recur target.
 */
cljs.core$macros.loop = (function cljs$core$macros$loop(var_args){
var args__23962__auto__ = [];
var len__23955__auto___28147 = arguments.length;
var i__23956__auto___28148 = (0);
while(true){
if((i__23956__auto___28148 < len__23955__auto___28147)){
args__23962__auto__.push((arguments[i__23956__auto___28148]));

var G__28149 = (i__23956__auto___28148 + (1));
i__23956__auto___28148 = G__28149;
continue;
} else {
}
break;
}

var argseq__23963__auto__ = ((((3) < args__23962__auto__.length))?(new cljs.core.IndexedSeq(args__23962__auto__.slice((3)),(0),null)):null);
return cljs.core$macros.loop.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),argseq__23963__auto__);
});

cljs.core$macros.loop.cljs$core$IFn$_invoke$arity$variadic = (function (_AMPERSAND_form,_AMPERSAND_env,bindings,body){
if(cljs.core.vector_QMARK_.call(null,bindings)){
} else {
throw cljs.core.ex_info.call(null,"loop requires a vector for its binding",cljs.core.PersistentArrayMap.EMPTY);
}

if(cljs.core.even_QMARK_.call(null,cljs.core.count.call(null,bindings))){
} else {
throw cljs.core.ex_info.call(null,"loop requires an even number of forms in binding vector",cljs.core.PersistentArrayMap.EMPTY);
}


var db = cljs.core$macros.destructure.call(null,bindings);
if(cljs.core._EQ_.call(null,db,bindings)){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"loop*","loop*",615029416,null)),(function (){var x__23719__auto__ = bindings;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),body)));
} else {
var vs = cljs.core.take_nth.call(null,(2),cljs.core.drop.call(null,(1),bindings));
var bs = cljs.core.take_nth.call(null,(2),bindings);
var gs = cljs.core.map.call(null,((function (vs,bs,db){
return (function (b){
if((b instanceof cljs.core.Symbol)){
return b;
} else {
return cljs.core.gensym.call(null);
}
});})(vs,bs,db))
,bs);
var bfs = cljs.core.reduce.call(null,((function (vs,bs,gs,db){
return (function (ret,p__28145){
var vec__28146 = p__28145;
var b = cljs.core.nth.call(null,vec__28146,(0),null);
var v = cljs.core.nth.call(null,vec__28146,(1),null);
var g = cljs.core.nth.call(null,vec__28146,(2),null);
if((b instanceof cljs.core.Symbol)){
return cljs.core.conj.call(null,ret,g,v);
} else {
return cljs.core.conj.call(null,ret,g,v,b,g);
}
});})(vs,bs,gs,db))
,cljs.core.PersistentVector.EMPTY,cljs.core.map.call(null,cljs.core.vector,bs,vs,gs));
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","let","cljs.core$macros/let",-160286726,null)),(function (){var x__23719__auto__ = bfs;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"loop*","loop*",615029416,null)),(function (){var x__23719__auto__ = cljs.core.vec.call(null,cljs.core.interleave.call(null,gs,gs));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","let","cljs.core$macros/let",-160286726,null)),(function (){var x__23719__auto__ = cljs.core.vec.call(null,cljs.core.interleave.call(null,bs,gs));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),body)));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
}
});

cljs.core$macros.loop.cljs$lang$maxFixedArity = (3);

cljs.core$macros.loop.cljs$lang$applyTo = (function (seq28141){
var G__28142 = cljs.core.first.call(null,seq28141);
var seq28141__$1 = cljs.core.next.call(null,seq28141);
var G__28143 = cljs.core.first.call(null,seq28141__$1);
var seq28141__$2 = cljs.core.next.call(null,seq28141__$1);
var G__28144 = cljs.core.first.call(null,seq28141__$2);
var seq28141__$3 = cljs.core.next.call(null,seq28141__$2);
return cljs.core$macros.loop.cljs$core$IFn$_invoke$arity$variadic(G__28142,G__28143,G__28144,seq28141__$3);
});

cljs.core$macros.loop.cljs$lang$macro = true;
/**
 * protocol fqn -> [partition number, bit]
 */
cljs.core$macros.fast_path_protocols = cljs.core.zipmap.call(null,cljs.core.map.call(null,(function (p1__28150_SHARP_){
return cljs.core.symbol.call(null,"cljs.core",[cljs.core.str(p1__28150_SHARP_)].join(''));
}),cljs.core.PersistentVector.fromArray([new cljs.core.Symbol(null,"IFn","IFn",-244881638,null),new cljs.core.Symbol(null,"ICounted","ICounted",-1705786327,null),new cljs.core.Symbol(null,"IEmptyableCollection","IEmptyableCollection",1477271438,null),new cljs.core.Symbol(null,"ICollection","ICollection",-686709190,null),new cljs.core.Symbol(null,"IIndexed","IIndexed",-574812826,null),new cljs.core.Symbol(null,"ASeq","ASeq",266390234,null),new cljs.core.Symbol(null,"ISeq","ISeq",1517365813,null),new cljs.core.Symbol(null,"INext","INext",562211849,null),new cljs.core.Symbol(null,"ILookup","ILookup",784647298,null),new cljs.core.Symbol(null,"IAssociative","IAssociative",-1306431882,null),new cljs.core.Symbol(null,"IMap","IMap",992876629,null),new cljs.core.Symbol(null,"IMapEntry","IMapEntry",-943754199,null),new cljs.core.Symbol(null,"ISet","ISet",-1398072657,null),new cljs.core.Symbol(null,"IStack","IStack",1136769449,null),new cljs.core.Symbol(null,"IVector","IVector",-1120721434,null),new cljs.core.Symbol(null,"IDeref","IDeref",1738423197,null),new cljs.core.Symbol(null,"IDerefWithTimeout","IDerefWithTimeout",2140974319,null),new cljs.core.Symbol(null,"IMeta","IMeta",1095313672,null),new cljs.core.Symbol(null,"IWithMeta","IWithMeta",-509493158,null),new cljs.core.Symbol(null,"IReduce","IReduce",-440384974,null),new cljs.core.Symbol(null,"IKVReduce","IKVReduce",-870856862,null),new cljs.core.Symbol(null,"IEquiv","IEquiv",-1912850869,null),new cljs.core.Symbol(null,"IHash","IHash",-1495374645,null),new cljs.core.Symbol(null,"ISeqable","ISeqable",1349682102,null),new cljs.core.Symbol(null,"ISequential","ISequential",-1626174217,null),new cljs.core.Symbol(null,"IList","IList",1682281311,null),new cljs.core.Symbol(null,"IRecord","IRecord",-903221169,null),new cljs.core.Symbol(null,"IReversible","IReversible",-723048599,null),new cljs.core.Symbol(null,"ISorted","ISorted",-253627362,null),new cljs.core.Symbol(null,"IPrintWithWriter","IPrintWithWriter",-1205316154,null),new cljs.core.Symbol(null,"IWriter","IWriter",-1681087107,null),new cljs.core.Symbol(null,"IPrintWithWriter","IPrintWithWriter",-1205316154,null),new cljs.core.Symbol(null,"IPending","IPending",1229113039,null),new cljs.core.Symbol(null,"IWatchable","IWatchable",-1929659016,null),new cljs.core.Symbol(null,"IEditableCollection","IEditableCollection",-906687187,null),new cljs.core.Symbol(null,"ITransientCollection","ITransientCollection",252832402,null),new cljs.core.Symbol(null,"ITransientAssociative","ITransientAssociative",-1612754624,null),new cljs.core.Symbol(null,"ITransientMap","ITransientMap",298423651,null),new cljs.core.Symbol(null,"ITransientVector","ITransientVector",1978793164,null),new cljs.core.Symbol(null,"ITransientSet","ITransientSet",-575559912,null),new cljs.core.Symbol(null,"IMultiFn","IMultiFn",-1848282794,null),new cljs.core.Symbol(null,"IChunkedSeq","IChunkedSeq",-1299765705,null),new cljs.core.Symbol(null,"IChunkedNext","IChunkedNext",1193289532,null),new cljs.core.Symbol(null,"IComparable","IComparable",1834481627,null),new cljs.core.Symbol(null,"INamed","INamed",357992946,null),new cljs.core.Symbol(null,"ICloneable","ICloneable",1882653160,null),new cljs.core.Symbol(null,"IAtom","IAtom",-1411134312,null),new cljs.core.Symbol(null,"IReset","IReset",-1893729426,null),new cljs.core.Symbol(null,"ISwap","ISwap",484378193,null)], true)),cljs.core.iterate.call(null,(function (p__28151){
var vec__28152 = p__28151;
var p = cljs.core.nth.call(null,vec__28152,(0),null);
var b = cljs.core.nth.call(null,vec__28152,(1),null);
if(((2147483648) === b)){
return new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [(p + (1)),(1)], null);
} else {
return new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [p,((2) * b)], null);
}
}),new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [(0),(1)], null)));
/**
 * total number of partitions
 */
cljs.core$macros.fast_path_protocol_partitions_count = (function (){var c = cljs.core.count.call(null,cljs.core$macros.fast_path_protocols);
var m = cljs.core.mod.call(null,c,(32));
if((m === (0))){
return cljs.core.quot.call(null,c,(32));
} else {
return (cljs.core.quot.call(null,c,(32)) + (1));
}
})();
cljs.core$macros.str = (function cljs$core$macros$str(var_args){
var args__23962__auto__ = [];
var len__23955__auto___28156 = arguments.length;
var i__23956__auto___28157 = (0);
while(true){
if((i__23956__auto___28157 < len__23955__auto___28156)){
args__23962__auto__.push((arguments[i__23956__auto___28157]));

var G__28158 = (i__23956__auto___28157 + (1));
i__23956__auto___28157 = G__28158;
continue;
} else {
}
break;
}

var argseq__23963__auto__ = ((((2) < args__23962__auto__.length))?(new cljs.core.IndexedSeq(args__23962__auto__.slice((2)),(0),null)):null);
return cljs.core$macros.str.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__23963__auto__);
});

cljs.core$macros.str.cljs$core$IFn$_invoke$arity$variadic = (function (_AMPERSAND_form,_AMPERSAND_env,xs){
var strs = cljs.core.apply.call(null,cljs.core.str,cljs.core.interpose.call(null,",",cljs.core.repeat.call(null,cljs.core.count.call(null,xs),"cljs.core.str(~{})")));
return cljs.core.list_STAR_.call(null,new cljs.core.Symbol(null,"js*","js*",-1134233646,null),[cljs.core.str("["),cljs.core.str(strs),cljs.core.str("].join('')")].join(''),xs);
});

cljs.core$macros.str.cljs$lang$maxFixedArity = (2);

cljs.core$macros.str.cljs$lang$applyTo = (function (seq28153){
var G__28154 = cljs.core.first.call(null,seq28153);
var seq28153__$1 = cljs.core.next.call(null,seq28153);
var G__28155 = cljs.core.first.call(null,seq28153__$1);
var seq28153__$2 = cljs.core.next.call(null,seq28153__$1);
return cljs.core$macros.str.cljs$core$IFn$_invoke$arity$variadic(G__28154,G__28155,seq28153__$2);
});

cljs.core$macros.str.cljs$lang$macro = true;
cljs.core$macros.bool_expr = (function cljs$core$macros$bool_expr(e){
return cljs.core.vary_meta.call(null,e,cljs.core.assoc,new cljs.core.Keyword(null,"tag","tag",-1290361223),new cljs.core.Symbol(null,"boolean","boolean",-278886877,null));
});
cljs.core$macros.simple_test_expr_QMARK_ = (function cljs$core$macros$simple_test_expr_QMARK_(env,ast){
var and__22873__auto__ = new cljs.core.PersistentHashSet(null, new cljs.core.PersistentArrayMap(null, 5, [new cljs.core.Keyword(null,"js","js",1768080579),null,new cljs.core.Keyword(null,"constant","constant",-379609303),null,new cljs.core.Keyword(null,"var","var",-769682797),null,new cljs.core.Keyword(null,"invoke","invoke",1145927159),null,new cljs.core.Keyword(null,"dot","dot",1442709401),null], null), null).call(null,new cljs.core.Keyword(null,"op","op",-1882987955).cljs$core$IFn$_invoke$arity$1(ast));
if(cljs.core.truth_(and__22873__auto__)){
return new cljs.core.PersistentHashSet(null, new cljs.core.PersistentArrayMap(null, 2, [new cljs.core.Symbol(null,"seq","seq",-177272256,null),null,new cljs.core.Symbol(null,"boolean","boolean",-278886877,null),null], null), null).call(null,cljs.analyzer.infer_tag.call(null,env,ast));
} else {
return and__22873__auto__;
}
});
/**
 * Evaluates exprs one at a time, from left to right. If a form
 *   returns logical false (nil or false), and returns that value and
 *   doesn't evaluate any of the other expressions, otherwise it returns
 *   the value of the last expr. (and) returns true.
 */
cljs.core$macros.and = (function cljs$core$macros$and(var_args){
var args28162 = [];
var len__23955__auto___28169 = arguments.length;
var i__23956__auto___28170 = (0);
while(true){
if((i__23956__auto___28170 < len__23955__auto___28169)){
args28162.push((arguments[i__23956__auto___28170]));

var G__28171 = (i__23956__auto___28170 + (1));
i__23956__auto___28170 = G__28171;
continue;
} else {
}
break;
}

var G__28168 = args28162.length;
switch (G__28168) {
case 2:
return cljs.core$macros.and.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core$macros.and.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
var argseq__23974__auto__ = (new cljs.core.IndexedSeq(args28162.slice((3)),(0),null));
return cljs.core$macros.and.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),argseq__23974__auto__);

}
});

cljs.core$macros.and.cljs$core$IFn$_invoke$arity$2 = (function (_AMPERSAND_form,_AMPERSAND_env){
return true;
});

cljs.core$macros.and.cljs$core$IFn$_invoke$arity$3 = (function (_AMPERSAND_form,_AMPERSAND_env,x){
return x;
});

cljs.core$macros.and.cljs$core$IFn$_invoke$arity$variadic = (function (_AMPERSAND_form,_AMPERSAND_env,x,next){
var forms = cljs.core.concat.call(null,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [x], null),next);
if(cljs.core.every_QMARK_.call(null,((function (forms){
return (function (p1__28159_SHARP_){
return cljs.core$macros.simple_test_expr_QMARK_.call(null,_AMPERSAND_env,p1__28159_SHARP_);
});})(forms))
,cljs.core.map.call(null,((function (forms){
return (function (p1__28160_SHARP_){
return cljs.analyzer.analyze.call(null,_AMPERSAND_env,p1__28160_SHARP_);
});})(forms))
,forms))){
var and_str = cljs.core.apply.call(null,cljs.core.str,cljs.core.interpose.call(null," && ",cljs.core.repeat.call(null,cljs.core.count.call(null,forms),"(~{})")));
return cljs.core$macros.bool_expr.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"js*","js*",-1134233646,null)),(function (){var x__23719__auto__ = and_str;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),forms))));
} else {
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","let","cljs.core$macros/let",-160286726,null)),(function (){var x__23719__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"and__28161__auto__","and__28161__auto__",-1921019955,null)),(function (){var x__23719__auto__ = x;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})()))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"if","if",1181717262,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"and__28161__auto__","and__28161__auto__",-1921019955,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","and","cljs.core$macros/and",48320334,null)),next)));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"and__28161__auto__","and__28161__auto__",-1921019955,null)))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
}
});

cljs.core$macros.and.cljs$lang$applyTo = (function (seq28163){
var G__28164 = cljs.core.first.call(null,seq28163);
var seq28163__$1 = cljs.core.next.call(null,seq28163);
var G__28165 = cljs.core.first.call(null,seq28163__$1);
var seq28163__$2 = cljs.core.next.call(null,seq28163__$1);
var G__28166 = cljs.core.first.call(null,seq28163__$2);
var seq28163__$3 = cljs.core.next.call(null,seq28163__$2);
return cljs.core$macros.and.cljs$core$IFn$_invoke$arity$variadic(G__28164,G__28165,G__28166,seq28163__$3);
});

cljs.core$macros.and.cljs$lang$maxFixedArity = (3);

cljs.core$macros.and.cljs$lang$macro = true;
/**
 * Evaluates exprs one at a time, from left to right. If a form
 *   returns a logical true value, or returns that value and doesn't
 *   evaluate any of the other expressions, otherwise it returns the
 *   value of the last expression. (or) returns nil.
 */
cljs.core$macros.or = (function cljs$core$macros$or(var_args){
var args28176 = [];
var len__23955__auto___28183 = arguments.length;
var i__23956__auto___28184 = (0);
while(true){
if((i__23956__auto___28184 < len__23955__auto___28183)){
args28176.push((arguments[i__23956__auto___28184]));

var G__28185 = (i__23956__auto___28184 + (1));
i__23956__auto___28184 = G__28185;
continue;
} else {
}
break;
}

var G__28182 = args28176.length;
switch (G__28182) {
case 2:
return cljs.core$macros.or.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core$macros.or.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
var argseq__23974__auto__ = (new cljs.core.IndexedSeq(args28176.slice((3)),(0),null));
return cljs.core$macros.or.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),argseq__23974__auto__);

}
});

cljs.core$macros.or.cljs$core$IFn$_invoke$arity$2 = (function (_AMPERSAND_form,_AMPERSAND_env){
return null;
});

cljs.core$macros.or.cljs$core$IFn$_invoke$arity$3 = (function (_AMPERSAND_form,_AMPERSAND_env,x){
return x;
});

cljs.core$macros.or.cljs$core$IFn$_invoke$arity$variadic = (function (_AMPERSAND_form,_AMPERSAND_env,x,next){
var forms = cljs.core.concat.call(null,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [x], null),next);
if(cljs.core.every_QMARK_.call(null,((function (forms){
return (function (p1__28173_SHARP_){
return cljs.core$macros.simple_test_expr_QMARK_.call(null,_AMPERSAND_env,p1__28173_SHARP_);
});})(forms))
,cljs.core.map.call(null,((function (forms){
return (function (p1__28174_SHARP_){
return cljs.analyzer.analyze.call(null,_AMPERSAND_env,p1__28174_SHARP_);
});})(forms))
,forms))){
var or_str = cljs.core.apply.call(null,cljs.core.str,cljs.core.interpose.call(null," || ",cljs.core.repeat.call(null,cljs.core.count.call(null,forms),"(~{})")));
return cljs.core$macros.bool_expr.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"js*","js*",-1134233646,null)),(function (){var x__23719__auto__ = or_str;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),forms))));
} else {
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","let","cljs.core$macros/let",-160286726,null)),(function (){var x__23719__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"or__28175__auto__","or__28175__auto__",-1550931625,null)),(function (){var x__23719__auto__ = x;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})()))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"if","if",1181717262,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"or__28175__auto__","or__28175__auto__",-1550931625,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"or__28175__auto__","or__28175__auto__",-1550931625,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","or","cljs.core$macros/or",1346243648,null)),next)));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
}
});

cljs.core$macros.or.cljs$lang$applyTo = (function (seq28177){
var G__28178 = cljs.core.first.call(null,seq28177);
var seq28177__$1 = cljs.core.next.call(null,seq28177);
var G__28179 = cljs.core.first.call(null,seq28177__$1);
var seq28177__$2 = cljs.core.next.call(null,seq28177__$1);
var G__28180 = cljs.core.first.call(null,seq28177__$2);
var seq28177__$3 = cljs.core.next.call(null,seq28177__$2);
return cljs.core$macros.or.cljs$core$IFn$_invoke$arity$variadic(G__28178,G__28179,G__28180,seq28177__$3);
});

cljs.core$macros.or.cljs$lang$maxFixedArity = (3);

cljs.core$macros.or.cljs$lang$macro = true;
cljs.core$macros.nil_QMARK_ = (function cljs$core$macros$nil_QMARK_(_AMPERSAND_form,_AMPERSAND_env,x){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","coercive-=","cljs.core$macros/coercive-=",-1655776086,null)),(function (){var x__23719__auto__ = x;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,null))));
});

cljs.core$macros.nil_QMARK_.cljs$lang$macro = true;
cljs.core$macros.coercive_not = (function cljs$core$macros$coercive_not(_AMPERSAND_form,_AMPERSAND_env,x){
return cljs.core$macros.bool_expr.call(null,cljs.core._conj.call(null,cljs.core._conj.call(null,(function (){var x__23719__auto__ = x;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),"(!~{})"),new cljs.core.Symbol(null,"js*","js*",-1134233646,null)));
});

cljs.core$macros.coercive_not.cljs$lang$macro = true;
cljs.core$macros.coercive_not_EQ_ = (function cljs$core$macros$coercive_not_EQ_(_AMPERSAND_form,_AMPERSAND_env,x,y){
return cljs.core$macros.bool_expr.call(null,cljs.core._conj.call(null,cljs.core._conj.call(null,(function (){var x__23719__auto__ = x;
return cljs.core._conj.call(null,(function (){var x__23719__auto____$1 = y;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto____$1);
})(),x__23719__auto__);
})(),"(~{} != ~{})"),new cljs.core.Symbol(null,"js*","js*",-1134233646,null)));
});

cljs.core$macros.coercive_not_EQ_.cljs$lang$macro = true;
cljs.core$macros.coercive__EQ_ = (function cljs$core$macros$coercive__EQ_(_AMPERSAND_form,_AMPERSAND_env,x,y){
return cljs.core$macros.bool_expr.call(null,cljs.core._conj.call(null,cljs.core._conj.call(null,(function (){var x__23719__auto__ = x;
return cljs.core._conj.call(null,(function (){var x__23719__auto____$1 = y;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto____$1);
})(),x__23719__auto__);
})(),"(~{} == ~{})"),new cljs.core.Symbol(null,"js*","js*",-1134233646,null)));
});

cljs.core$macros.coercive__EQ_.cljs$lang$macro = true;
cljs.core$macros.coercive_boolean = (function cljs$core$macros$coercive_boolean(_AMPERSAND_form,_AMPERSAND_env,x){
return cljs.core.with_meta.call(null,cljs.core._conj.call(null,cljs.core._conj.call(null,(function (){var x__23719__auto__ = x;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),"~{}"),new cljs.core.Symbol(null,"js*","js*",-1134233646,null)),new cljs.core.PersistentArrayMap(null, 1, [new cljs.core.Keyword(null,"tag","tag",-1290361223),new cljs.core.Symbol(null,"boolean","boolean",-278886877,null)], null));
});

cljs.core$macros.coercive_boolean.cljs$lang$macro = true;
cljs.core$macros.truth_ = (function cljs$core$macros$truth_(_AMPERSAND_form,_AMPERSAND_env,x){
if((x instanceof cljs.core.Symbol)){
} else {
throw (new Error([cljs.core.str("Assert failed: "),cljs.core.str("x is substituted twice"),cljs.core.str("\n"),cljs.core.str("(core/symbol? x)")].join('')));
}

return cljs.core._conj.call(null,cljs.core._conj.call(null,(function (){var x__23719__auto__ = x;
return cljs.core._conj.call(null,(function (){var x__23719__auto____$1 = x;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto____$1);
})(),x__23719__auto__);
})(),"(~{} != null && ~{} !== false)"),new cljs.core.Symbol(null,"js*","js*",-1134233646,null));
});

cljs.core$macros.truth_.cljs$lang$macro = true;
cljs.core$macros.js_arguments = (function cljs$core$macros$js_arguments(_AMPERSAND_form,_AMPERSAND_env){
return cljs.core._conj.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,"arguments"),new cljs.core.Symbol(null,"js*","js*",-1134233646,null));
});

cljs.core$macros.js_arguments.cljs$lang$macro = true;
cljs.core$macros.js_delete = (function cljs$core$macros$js_delete(_AMPERSAND_form,_AMPERSAND_env,obj,key){
return cljs.core._conj.call(null,cljs.core._conj.call(null,(function (){var x__23719__auto__ = obj;
return cljs.core._conj.call(null,(function (){var x__23719__auto____$1 = key;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto____$1);
})(),x__23719__auto__);
})(),"delete ~{}[~{}]"),new cljs.core.Symbol(null,"js*","js*",-1134233646,null));
});

cljs.core$macros.js_delete.cljs$lang$macro = true;
cljs.core$macros.js_in = (function cljs$core$macros$js_in(_AMPERSAND_form,_AMPERSAND_env,key,obj){
return cljs.core._conj.call(null,cljs.core._conj.call(null,(function (){var x__23719__auto__ = key;
return cljs.core._conj.call(null,(function (){var x__23719__auto____$1 = obj;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto____$1);
})(),x__23719__auto__);
})(),"~{} in ~{}"),new cljs.core.Symbol(null,"js*","js*",-1134233646,null));
});

cljs.core$macros.js_in.cljs$lang$macro = true;
/**
 * Emit JavaScript "debugger;" statement
 */
cljs.core$macros.js_debugger = (function cljs$core$macros$js_debugger(_AMPERSAND_form,_AMPERSAND_env){
return cljs.core._conj.call(null,(function (){var x__23719__auto__ = cljs.core._conj.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,"debugger"),new cljs.core.Symbol(null,"js*","js*",-1134233646,null));
return cljs.core._conj.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,null),x__23719__auto__);
})(),new cljs.core.Symbol(null,"do","do",1686842252,null));
});

cljs.core$macros.js_debugger.cljs$lang$macro = true;
/**
 * Emit a top-level JavaScript multi-line comment. New lines will create a
 *   new comment line. Comment block will be preceded and followed by a newline
 */
cljs.core$macros.js_comment = (function cljs$core$macros$js_comment(_AMPERSAND_form,_AMPERSAND_env,comment){
var vec__28189 = clojure.string.split.call(null,comment,/\n/);
var x = cljs.core.nth.call(null,vec__28189,(0),null);
var ys = cljs.core.nthnext.call(null,vec__28189,(1));
return cljs.core._conj.call(null,(function (){var x__23719__auto__ = [cljs.core.str("\n/**\n"),cljs.core.str([cljs.core.str(" * "),cljs.core.str(x),cljs.core.str("\n")].join('')),cljs.core.str(cljs.core.reduce.call(null,cljs.core.str,"",cljs.core.map.call(null,((function (vec__28189,x,ys){
return (function (p1__28187_SHARP_){
return [cljs.core.str(" * "),cljs.core.str(clojure.string.replace.call(null,p1__28187_SHARP_,/^   /,"")),cljs.core.str("\n")].join('');
});})(vec__28189,x,ys))
,ys))),cljs.core.str(" */\n")].join('');
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),new cljs.core.Symbol(null,"js*","js*",-1134233646,null));
});

cljs.core$macros.js_comment.cljs$lang$macro = true;
/**
 * EXPERIMENTAL: Subject to change. Unsafely cast a value to a different type.
 */
cljs.core$macros.unsafe_cast = (function cljs$core$macros$unsafe_cast(_AMPERSAND_form,_AMPERSAND_env,t,x){
var cast_expr = [cljs.core.str("~{} = /** @type {"),cljs.core.str(t),cljs.core.str("} */ (~{})")].join('');
return cljs.core._conj.call(null,(function (){var x__23719__auto__ = cast_expr;
return cljs.core._conj.call(null,(function (){var x__23719__auto____$1 = x;
return cljs.core._conj.call(null,(function (){var x__23719__auto____$2 = x;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto____$2);
})(),x__23719__auto____$1);
})(),x__23719__auto__);
})(),new cljs.core.Symbol(null,"js*","js*",-1134233646,null));
});

cljs.core$macros.unsafe_cast.cljs$lang$macro = true;
/**
 * Emit an inline JavaScript comment.
 */
cljs.core$macros.js_inline_comment = (function cljs$core$macros$js_inline_comment(_AMPERSAND_form,_AMPERSAND_env,comment){
return cljs.core._conj.call(null,(function (){var x__23719__auto__ = [cljs.core.str("/**"),cljs.core.str(comment),cljs.core.str("*/")].join('');
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),new cljs.core.Symbol(null,"js*","js*",-1134233646,null));
});

cljs.core$macros.js_inline_comment.cljs$lang$macro = true;
cljs.core$macros.true_QMARK_ = (function cljs$core$macros$true_QMARK_(_AMPERSAND_form,_AMPERSAND_env,x){
return cljs.core$macros.bool_expr.call(null,cljs.core._conj.call(null,cljs.core._conj.call(null,(function (){var x__23719__auto__ = x;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),"~{} === true"),new cljs.core.Symbol(null,"js*","js*",-1134233646,null)));
});

cljs.core$macros.true_QMARK_.cljs$lang$macro = true;
cljs.core$macros.false_QMARK_ = (function cljs$core$macros$false_QMARK_(_AMPERSAND_form,_AMPERSAND_env,x){
return cljs.core$macros.bool_expr.call(null,cljs.core._conj.call(null,cljs.core._conj.call(null,(function (){var x__23719__auto__ = x;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),"~{} === false"),new cljs.core.Symbol(null,"js*","js*",-1134233646,null)));
});

cljs.core$macros.false_QMARK_.cljs$lang$macro = true;
cljs.core$macros.string_QMARK_ = (function cljs$core$macros$string_QMARK_(_AMPERSAND_form,_AMPERSAND_env,x){
return cljs.core$macros.bool_expr.call(null,cljs.core._conj.call(null,cljs.core._conj.call(null,(function (){var x__23719__auto__ = x;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),"typeof ~{} === 'string'"),new cljs.core.Symbol(null,"js*","js*",-1134233646,null)));
});

cljs.core$macros.string_QMARK_.cljs$lang$macro = true;
/**
 * Return true if argument exists, analogous to usage of typeof operator
 * in JavaScript.
 */
cljs.core$macros.exists_QMARK_ = (function cljs$core$macros$exists_QMARK_(_AMPERSAND_form,_AMPERSAND_env,x){
return cljs.core$macros.bool_expr.call(null,cljs.core._conj.call(null,cljs.core._conj.call(null,(function (){var x__23719__auto__ = cljs.core.vary_meta.call(null,x,cljs.core.assoc,new cljs.core.Keyword("cljs.analyzer","no-resolve","cljs.analyzer/no-resolve",-1872351017),true);
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),"typeof ~{} !== 'undefined'"),new cljs.core.Symbol(null,"js*","js*",-1134233646,null)));
});

cljs.core$macros.exists_QMARK_.cljs$lang$macro = true;
/**
 * Return true if argument is identical to the JavaScript undefined value.
 */
cljs.core$macros.undefined_QMARK_ = (function cljs$core$macros$undefined_QMARK_(_AMPERSAND_form,_AMPERSAND_env,x){
return cljs.core$macros.bool_expr.call(null,cljs.core._conj.call(null,cljs.core._conj.call(null,(function (){var x__23719__auto__ = x;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),"(void 0 === ~{})"),new cljs.core.Symbol(null,"js*","js*",-1134233646,null)));
});

cljs.core$macros.undefined_QMARK_.cljs$lang$macro = true;
cljs.core$macros.identical_QMARK_ = (function cljs$core$macros$identical_QMARK_(_AMPERSAND_form,_AMPERSAND_env,a,b){
return cljs.core$macros.bool_expr.call(null,cljs.core._conj.call(null,cljs.core._conj.call(null,(function (){var x__23719__auto__ = a;
return cljs.core._conj.call(null,(function (){var x__23719__auto____$1 = b;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto____$1);
})(),x__23719__auto__);
})(),"(~{} === ~{})"),new cljs.core.Symbol(null,"js*","js*",-1134233646,null)));
});

cljs.core$macros.identical_QMARK_.cljs$lang$macro = true;
cljs.core$macros.instance_QMARK_ = (function cljs$core$macros$instance_QMARK_(_AMPERSAND_form,_AMPERSAND_env,c,x){
return cljs.core$macros.bool_expr.call(null,(((c instanceof cljs.core.Symbol))?cljs.core._conj.call(null,cljs.core._conj.call(null,(function (){var x__23719__auto__ = x;
return cljs.core._conj.call(null,(function (){var x__23719__auto____$1 = c;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto____$1);
})(),x__23719__auto__);
})(),"(~{} instanceof ~{})"),new cljs.core.Symbol(null,"js*","js*",-1134233646,null)):cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","let","cljs.core$macros/let",-160286726,null)),(function (){var x__23719__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"c__28190__auto__","c__28190__auto__",1104629156,null)),(function (){var x__23719__auto__ = c;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"x__28191__auto__","x__28191__auto__",-1762833089,null)),(function (){var x__23719__auto__ = x;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})()))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"js*","js*",-1134233646,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,"(~{} instanceof ~{})"),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"x__28191__auto__","x__28191__auto__",-1762833089,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"c__28190__auto__","c__28190__auto__",1104629156,null)))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())))));
});

cljs.core$macros.instance_QMARK_.cljs$lang$macro = true;
cljs.core$macros.number_QMARK_ = (function cljs$core$macros$number_QMARK_(_AMPERSAND_form,_AMPERSAND_env,x){
return cljs.core$macros.bool_expr.call(null,cljs.core._conj.call(null,cljs.core._conj.call(null,(function (){var x__23719__auto__ = x;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),"typeof ~{} === 'number'"),new cljs.core.Symbol(null,"js*","js*",-1134233646,null)));
});

cljs.core$macros.number_QMARK_.cljs$lang$macro = true;
cljs.core$macros.symbol_QMARK_ = (function cljs$core$macros$symbol_QMARK_(_AMPERSAND_form,_AMPERSAND_env,x){
return cljs.core$macros.bool_expr.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","instance?","cljs.core$macros/instance?",1829750179,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","Symbol","cljs.core/Symbol",292989338,null)),(function (){var x__23719__auto__ = x;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})()))));
});

cljs.core$macros.symbol_QMARK_.cljs$lang$macro = true;
cljs.core$macros.keyword_QMARK_ = (function cljs$core$macros$keyword_QMARK_(_AMPERSAND_form,_AMPERSAND_env,x){
return cljs.core$macros.bool_expr.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","instance?","cljs.core$macros/instance?",1829750179,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","Keyword","cljs.core/Keyword",-451434488,null)),(function (){var x__23719__auto__ = x;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})()))));
});

cljs.core$macros.keyword_QMARK_.cljs$lang$macro = true;
cljs.core$macros.aget = (function cljs$core$macros$aget(var_args){
var args28192 = [];
var len__23955__auto___28200 = arguments.length;
var i__23956__auto___28201 = (0);
while(true){
if((i__23956__auto___28201 < len__23955__auto___28200)){
args28192.push((arguments[i__23956__auto___28201]));

var G__28202 = (i__23956__auto___28201 + (1));
i__23956__auto___28201 = G__28202;
continue;
} else {
}
break;
}

var G__28199 = args28192.length;
switch (G__28199) {
case 4:
return cljs.core$macros.aget.cljs$core$IFn$_invoke$arity$4((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]));

break;
default:
var argseq__23974__auto__ = (new cljs.core.IndexedSeq(args28192.slice((4)),(0),null));
return cljs.core$macros.aget.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]),argseq__23974__auto__);

}
});

cljs.core$macros.aget.cljs$core$IFn$_invoke$arity$4 = (function (_AMPERSAND_form,_AMPERSAND_env,a,i){
return cljs.core._conj.call(null,cljs.core._conj.call(null,(function (){var x__23719__auto__ = a;
return cljs.core._conj.call(null,(function (){var x__23719__auto____$1 = i;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto____$1);
})(),x__23719__auto__);
})(),"(~{}[~{}])"),new cljs.core.Symbol(null,"js*","js*",-1134233646,null));
});

cljs.core$macros.aget.cljs$core$IFn$_invoke$arity$variadic = (function (_AMPERSAND_form,_AMPERSAND_env,a,i,idxs){
var astr = cljs.core.apply.call(null,cljs.core.str,cljs.core.repeat.call(null,cljs.core.count.call(null,idxs),"[~{}]"));
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"js*","js*",-1134233646,null)),(function (){var x__23719__auto__ = [cljs.core.str("(~{}[~{}]"),cljs.core.str(astr),cljs.core.str(")")].join('');
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = a;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = i;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),idxs)));
});

cljs.core$macros.aget.cljs$lang$applyTo = (function (seq28193){
var G__28194 = cljs.core.first.call(null,seq28193);
var seq28193__$1 = cljs.core.next.call(null,seq28193);
var G__28195 = cljs.core.first.call(null,seq28193__$1);
var seq28193__$2 = cljs.core.next.call(null,seq28193__$1);
var G__28196 = cljs.core.first.call(null,seq28193__$2);
var seq28193__$3 = cljs.core.next.call(null,seq28193__$2);
var G__28197 = cljs.core.first.call(null,seq28193__$3);
var seq28193__$4 = cljs.core.next.call(null,seq28193__$3);
return cljs.core$macros.aget.cljs$core$IFn$_invoke$arity$variadic(G__28194,G__28195,G__28196,G__28197,seq28193__$4);
});

cljs.core$macros.aget.cljs$lang$maxFixedArity = (4);

cljs.core$macros.aget.cljs$lang$macro = true;
cljs.core$macros.aset = (function cljs$core$macros$aset(var_args){
var args28204 = [];
var len__23955__auto___28213 = arguments.length;
var i__23956__auto___28214 = (0);
while(true){
if((i__23956__auto___28214 < len__23955__auto___28213)){
args28204.push((arguments[i__23956__auto___28214]));

var G__28215 = (i__23956__auto___28214 + (1));
i__23956__auto___28214 = G__28215;
continue;
} else {
}
break;
}

var G__28212 = args28204.length;
switch (G__28212) {
case 5:
return cljs.core$macros.aset.cljs$core$IFn$_invoke$arity$5((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]),(arguments[(4)]));

break;
default:
var argseq__23974__auto__ = (new cljs.core.IndexedSeq(args28204.slice((5)),(0),null));
return cljs.core$macros.aset.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]),(arguments[(4)]),argseq__23974__auto__);

}
});

cljs.core$macros.aset.cljs$core$IFn$_invoke$arity$5 = (function (_AMPERSAND_form,_AMPERSAND_env,a,i,v){
return cljs.core._conj.call(null,cljs.core._conj.call(null,(function (){var x__23719__auto__ = a;
return cljs.core._conj.call(null,(function (){var x__23719__auto____$1 = i;
return cljs.core._conj.call(null,(function (){var x__23719__auto____$2 = v;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto____$2);
})(),x__23719__auto____$1);
})(),x__23719__auto__);
})(),"(~{}[~{}] = ~{})"),new cljs.core.Symbol(null,"js*","js*",-1134233646,null));
});

cljs.core$macros.aset.cljs$core$IFn$_invoke$arity$variadic = (function (_AMPERSAND_form,_AMPERSAND_env,a,idx,idx2,idxv){
var n = (cljs.core.count.call(null,idxv) - (1));
var astr = cljs.core.apply.call(null,cljs.core.str,cljs.core.repeat.call(null,n,"[~{}]"));
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"js*","js*",-1134233646,null)),(function (){var x__23719__auto__ = [cljs.core.str("(~{}[~{}][~{}]"),cljs.core.str(astr),cljs.core.str(" = ~{})")].join('');
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = a;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = idx;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = idx2;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),idxv)));
});

cljs.core$macros.aset.cljs$lang$applyTo = (function (seq28205){
var G__28206 = cljs.core.first.call(null,seq28205);
var seq28205__$1 = cljs.core.next.call(null,seq28205);
var G__28207 = cljs.core.first.call(null,seq28205__$1);
var seq28205__$2 = cljs.core.next.call(null,seq28205__$1);
var G__28208 = cljs.core.first.call(null,seq28205__$2);
var seq28205__$3 = cljs.core.next.call(null,seq28205__$2);
var G__28209 = cljs.core.first.call(null,seq28205__$3);
var seq28205__$4 = cljs.core.next.call(null,seq28205__$3);
var G__28210 = cljs.core.first.call(null,seq28205__$4);
var seq28205__$5 = cljs.core.next.call(null,seq28205__$4);
return cljs.core$macros.aset.cljs$core$IFn$_invoke$arity$variadic(G__28206,G__28207,G__28208,G__28209,G__28210,seq28205__$5);
});

cljs.core$macros.aset.cljs$lang$maxFixedArity = (5);

cljs.core$macros.aset.cljs$lang$macro = true;
cljs.core$macros._PLUS_ = (function cljs$core$macros$_PLUS_(var_args){
var args28217 = [];
var len__23955__auto___28225 = arguments.length;
var i__23956__auto___28226 = (0);
while(true){
if((i__23956__auto___28226 < len__23955__auto___28225)){
args28217.push((arguments[i__23956__auto___28226]));

var G__28227 = (i__23956__auto___28226 + (1));
i__23956__auto___28226 = G__28227;
continue;
} else {
}
break;
}

var G__28224 = args28217.length;
switch (G__28224) {
case 2:
return cljs.core$macros._PLUS_.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core$macros._PLUS_.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
case 4:
return cljs.core$macros._PLUS_.cljs$core$IFn$_invoke$arity$4((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]));

break;
default:
var argseq__23974__auto__ = (new cljs.core.IndexedSeq(args28217.slice((4)),(0),null));
return cljs.core$macros._PLUS_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]),argseq__23974__auto__);

}
});

cljs.core$macros._PLUS_.cljs$core$IFn$_invoke$arity$2 = (function (_AMPERSAND_form,_AMPERSAND_env){
return (0);
});

cljs.core$macros._PLUS_.cljs$core$IFn$_invoke$arity$3 = (function (_AMPERSAND_form,_AMPERSAND_env,x){
return x;
});

cljs.core$macros._PLUS_.cljs$core$IFn$_invoke$arity$4 = (function (_AMPERSAND_form,_AMPERSAND_env,x,y){
return cljs.core._conj.call(null,cljs.core._conj.call(null,(function (){var x__23719__auto__ = x;
return cljs.core._conj.call(null,(function (){var x__23719__auto____$1 = y;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto____$1);
})(),x__23719__auto__);
})(),"(~{} + ~{})"),new cljs.core.Symbol(null,"js*","js*",-1134233646,null));
});

cljs.core$macros._PLUS_.cljs$core$IFn$_invoke$arity$variadic = (function (_AMPERSAND_form,_AMPERSAND_env,x,y,more){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","+","cljs.core$macros/+",-18260342,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","+","cljs.core$macros/+",-18260342,null)),(function (){var x__23719__auto__ = x;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = y;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),more)));
});

cljs.core$macros._PLUS_.cljs$lang$applyTo = (function (seq28218){
var G__28219 = cljs.core.first.call(null,seq28218);
var seq28218__$1 = cljs.core.next.call(null,seq28218);
var G__28220 = cljs.core.first.call(null,seq28218__$1);
var seq28218__$2 = cljs.core.next.call(null,seq28218__$1);
var G__28221 = cljs.core.first.call(null,seq28218__$2);
var seq28218__$3 = cljs.core.next.call(null,seq28218__$2);
var G__28222 = cljs.core.first.call(null,seq28218__$3);
var seq28218__$4 = cljs.core.next.call(null,seq28218__$3);
return cljs.core$macros._PLUS_.cljs$core$IFn$_invoke$arity$variadic(G__28219,G__28220,G__28221,G__28222,seq28218__$4);
});

cljs.core$macros._PLUS_.cljs$lang$maxFixedArity = (4);

cljs.core$macros._PLUS_.cljs$lang$macro = true;
cljs.core$macros.byte$ = (function cljs$core$macros$byte(_AMPERSAND_form,_AMPERSAND_env,x){
return x;
});

cljs.core$macros.byte$.cljs$lang$macro = true;
cljs.core$macros.short$ = (function cljs$core$macros$short(_AMPERSAND_form,_AMPERSAND_env,x){
return x;
});

cljs.core$macros.short$.cljs$lang$macro = true;
cljs.core$macros.float$ = (function cljs$core$macros$float(_AMPERSAND_form,_AMPERSAND_env,x){
return x;
});

cljs.core$macros.float$.cljs$lang$macro = true;
cljs.core$macros.double$ = (function cljs$core$macros$double(_AMPERSAND_form,_AMPERSAND_env,x){
return x;
});

cljs.core$macros.double$.cljs$lang$macro = true;
cljs.core$macros.unchecked_byte = (function cljs$core$macros$unchecked_byte(_AMPERSAND_form,_AMPERSAND_env,x){
return x;
});

cljs.core$macros.unchecked_byte.cljs$lang$macro = true;
cljs.core$macros.unchecked_char = (function cljs$core$macros$unchecked_char(_AMPERSAND_form,_AMPERSAND_env,x){
return x;
});

cljs.core$macros.unchecked_char.cljs$lang$macro = true;
cljs.core$macros.unchecked_short = (function cljs$core$macros$unchecked_short(_AMPERSAND_form,_AMPERSAND_env,x){
return x;
});

cljs.core$macros.unchecked_short.cljs$lang$macro = true;
cljs.core$macros.unchecked_float = (function cljs$core$macros$unchecked_float(_AMPERSAND_form,_AMPERSAND_env,x){
return x;
});

cljs.core$macros.unchecked_float.cljs$lang$macro = true;
cljs.core$macros.unchecked_double = (function cljs$core$macros$unchecked_double(_AMPERSAND_form,_AMPERSAND_env,x){
return x;
});

cljs.core$macros.unchecked_double.cljs$lang$macro = true;
cljs.core$macros.unchecked_add = (function cljs$core$macros$unchecked_add(var_args){
var args__23962__auto__ = [];
var len__23955__auto___28232 = arguments.length;
var i__23956__auto___28233 = (0);
while(true){
if((i__23956__auto___28233 < len__23955__auto___28232)){
args__23962__auto__.push((arguments[i__23956__auto___28233]));

var G__28234 = (i__23956__auto___28233 + (1));
i__23956__auto___28233 = G__28234;
continue;
} else {
}
break;
}

var argseq__23963__auto__ = ((((2) < args__23962__auto__.length))?(new cljs.core.IndexedSeq(args__23962__auto__.slice((2)),(0),null)):null);
return cljs.core$macros.unchecked_add.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__23963__auto__);
});

cljs.core$macros.unchecked_add.cljs$core$IFn$_invoke$arity$variadic = (function (_AMPERSAND_form,_AMPERSAND_env,xs){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","+","cljs.core$macros/+",-18260342,null)),xs)));
});

cljs.core$macros.unchecked_add.cljs$lang$maxFixedArity = (2);

cljs.core$macros.unchecked_add.cljs$lang$applyTo = (function (seq28229){
var G__28230 = cljs.core.first.call(null,seq28229);
var seq28229__$1 = cljs.core.next.call(null,seq28229);
var G__28231 = cljs.core.first.call(null,seq28229__$1);
var seq28229__$2 = cljs.core.next.call(null,seq28229__$1);
return cljs.core$macros.unchecked_add.cljs$core$IFn$_invoke$arity$variadic(G__28230,G__28231,seq28229__$2);
});

cljs.core$macros.unchecked_add.cljs$lang$macro = true;
cljs.core$macros.unchecked_add_int = (function cljs$core$macros$unchecked_add_int(var_args){
var args__23962__auto__ = [];
var len__23955__auto___28238 = arguments.length;
var i__23956__auto___28239 = (0);
while(true){
if((i__23956__auto___28239 < len__23955__auto___28238)){
args__23962__auto__.push((arguments[i__23956__auto___28239]));

var G__28240 = (i__23956__auto___28239 + (1));
i__23956__auto___28239 = G__28240;
continue;
} else {
}
break;
}

var argseq__23963__auto__ = ((((2) < args__23962__auto__.length))?(new cljs.core.IndexedSeq(args__23962__auto__.slice((2)),(0),null)):null);
return cljs.core$macros.unchecked_add_int.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__23963__auto__);
});

cljs.core$macros.unchecked_add_int.cljs$core$IFn$_invoke$arity$variadic = (function (_AMPERSAND_form,_AMPERSAND_env,xs){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","+","cljs.core$macros/+",-18260342,null)),xs)));
});

cljs.core$macros.unchecked_add_int.cljs$lang$maxFixedArity = (2);

cljs.core$macros.unchecked_add_int.cljs$lang$applyTo = (function (seq28235){
var G__28236 = cljs.core.first.call(null,seq28235);
var seq28235__$1 = cljs.core.next.call(null,seq28235);
var G__28237 = cljs.core.first.call(null,seq28235__$1);
var seq28235__$2 = cljs.core.next.call(null,seq28235__$1);
return cljs.core$macros.unchecked_add_int.cljs$core$IFn$_invoke$arity$variadic(G__28236,G__28237,seq28235__$2);
});

cljs.core$macros.unchecked_add_int.cljs$lang$macro = true;
cljs.core$macros.unchecked_dec = (function cljs$core$macros$unchecked_dec(_AMPERSAND_form,_AMPERSAND_env,x){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","dec","cljs.core$macros/dec",-247694061,null)),(function (){var x__23719__auto__ = x;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
});

cljs.core$macros.unchecked_dec.cljs$lang$macro = true;
cljs.core$macros.unchecked_dec_int = (function cljs$core$macros$unchecked_dec_int(_AMPERSAND_form,_AMPERSAND_env,x){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","dec","cljs.core$macros/dec",-247694061,null)),(function (){var x__23719__auto__ = x;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
});

cljs.core$macros.unchecked_dec_int.cljs$lang$macro = true;
cljs.core$macros.unchecked_divide_int = (function cljs$core$macros$unchecked_divide_int(var_args){
var args__23962__auto__ = [];
var len__23955__auto___28244 = arguments.length;
var i__23956__auto___28245 = (0);
while(true){
if((i__23956__auto___28245 < len__23955__auto___28244)){
args__23962__auto__.push((arguments[i__23956__auto___28245]));

var G__28246 = (i__23956__auto___28245 + (1));
i__23956__auto___28245 = G__28246;
continue;
} else {
}
break;
}

var argseq__23963__auto__ = ((((2) < args__23962__auto__.length))?(new cljs.core.IndexedSeq(args__23962__auto__.slice((2)),(0),null)):null);
return cljs.core$macros.unchecked_divide_int.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__23963__auto__);
});

cljs.core$macros.unchecked_divide_int.cljs$core$IFn$_invoke$arity$variadic = (function (_AMPERSAND_form,_AMPERSAND_env,xs){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","/","cljs.core$macros//",-893374331,null)),xs)));
});

cljs.core$macros.unchecked_divide_int.cljs$lang$maxFixedArity = (2);

cljs.core$macros.unchecked_divide_int.cljs$lang$applyTo = (function (seq28241){
var G__28242 = cljs.core.first.call(null,seq28241);
var seq28241__$1 = cljs.core.next.call(null,seq28241);
var G__28243 = cljs.core.first.call(null,seq28241__$1);
var seq28241__$2 = cljs.core.next.call(null,seq28241__$1);
return cljs.core$macros.unchecked_divide_int.cljs$core$IFn$_invoke$arity$variadic(G__28242,G__28243,seq28241__$2);
});

cljs.core$macros.unchecked_divide_int.cljs$lang$macro = true;
cljs.core$macros.unchecked_inc = (function cljs$core$macros$unchecked_inc(_AMPERSAND_form,_AMPERSAND_env,x){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","inc","cljs.core$macros/inc",876629257,null)),(function (){var x__23719__auto__ = x;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
});

cljs.core$macros.unchecked_inc.cljs$lang$macro = true;
cljs.core$macros.unchecked_inc_int = (function cljs$core$macros$unchecked_inc_int(_AMPERSAND_form,_AMPERSAND_env,x){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","inc","cljs.core$macros/inc",876629257,null)),(function (){var x__23719__auto__ = x;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
});

cljs.core$macros.unchecked_inc_int.cljs$lang$macro = true;
cljs.core$macros.unchecked_multiply = (function cljs$core$macros$unchecked_multiply(var_args){
var args__23962__auto__ = [];
var len__23955__auto___28250 = arguments.length;
var i__23956__auto___28251 = (0);
while(true){
if((i__23956__auto___28251 < len__23955__auto___28250)){
args__23962__auto__.push((arguments[i__23956__auto___28251]));

var G__28252 = (i__23956__auto___28251 + (1));
i__23956__auto___28251 = G__28252;
continue;
} else {
}
break;
}

var argseq__23963__auto__ = ((((2) < args__23962__auto__.length))?(new cljs.core.IndexedSeq(args__23962__auto__.slice((2)),(0),null)):null);
return cljs.core$macros.unchecked_multiply.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__23963__auto__);
});

cljs.core$macros.unchecked_multiply.cljs$core$IFn$_invoke$arity$variadic = (function (_AMPERSAND_form,_AMPERSAND_env,xs){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","*","cljs.core$macros/*",946321529,null)),xs)));
});

cljs.core$macros.unchecked_multiply.cljs$lang$maxFixedArity = (2);

cljs.core$macros.unchecked_multiply.cljs$lang$applyTo = (function (seq28247){
var G__28248 = cljs.core.first.call(null,seq28247);
var seq28247__$1 = cljs.core.next.call(null,seq28247);
var G__28249 = cljs.core.first.call(null,seq28247__$1);
var seq28247__$2 = cljs.core.next.call(null,seq28247__$1);
return cljs.core$macros.unchecked_multiply.cljs$core$IFn$_invoke$arity$variadic(G__28248,G__28249,seq28247__$2);
});

cljs.core$macros.unchecked_multiply.cljs$lang$macro = true;
cljs.core$macros.unchecked_multiply_int = (function cljs$core$macros$unchecked_multiply_int(var_args){
var args__23962__auto__ = [];
var len__23955__auto___28256 = arguments.length;
var i__23956__auto___28257 = (0);
while(true){
if((i__23956__auto___28257 < len__23955__auto___28256)){
args__23962__auto__.push((arguments[i__23956__auto___28257]));

var G__28258 = (i__23956__auto___28257 + (1));
i__23956__auto___28257 = G__28258;
continue;
} else {
}
break;
}

var argseq__23963__auto__ = ((((2) < args__23962__auto__.length))?(new cljs.core.IndexedSeq(args__23962__auto__.slice((2)),(0),null)):null);
return cljs.core$macros.unchecked_multiply_int.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__23963__auto__);
});

cljs.core$macros.unchecked_multiply_int.cljs$core$IFn$_invoke$arity$variadic = (function (_AMPERSAND_form,_AMPERSAND_env,xs){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","*","cljs.core$macros/*",946321529,null)),xs)));
});

cljs.core$macros.unchecked_multiply_int.cljs$lang$maxFixedArity = (2);

cljs.core$macros.unchecked_multiply_int.cljs$lang$applyTo = (function (seq28253){
var G__28254 = cljs.core.first.call(null,seq28253);
var seq28253__$1 = cljs.core.next.call(null,seq28253);
var G__28255 = cljs.core.first.call(null,seq28253__$1);
var seq28253__$2 = cljs.core.next.call(null,seq28253__$1);
return cljs.core$macros.unchecked_multiply_int.cljs$core$IFn$_invoke$arity$variadic(G__28254,G__28255,seq28253__$2);
});

cljs.core$macros.unchecked_multiply_int.cljs$lang$macro = true;
cljs.core$macros.unchecked_negate = (function cljs$core$macros$unchecked_negate(_AMPERSAND_form,_AMPERSAND_env,x){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","-","cljs.core$macros/-",13526976,null)),(function (){var x__23719__auto__ = x;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
});

cljs.core$macros.unchecked_negate.cljs$lang$macro = true;
cljs.core$macros.unchecked_negate_int = (function cljs$core$macros$unchecked_negate_int(_AMPERSAND_form,_AMPERSAND_env,x){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","-","cljs.core$macros/-",13526976,null)),(function (){var x__23719__auto__ = x;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
});

cljs.core$macros.unchecked_negate_int.cljs$lang$macro = true;
cljs.core$macros.unchecked_remainder_int = (function cljs$core$macros$unchecked_remainder_int(_AMPERSAND_form,_AMPERSAND_env,x,n){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","mod","cljs.core$macros/mod",2132457375,null)),(function (){var x__23719__auto__ = x;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = n;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
});

cljs.core$macros.unchecked_remainder_int.cljs$lang$macro = true;
cljs.core$macros.unchecked_subtract = (function cljs$core$macros$unchecked_subtract(var_args){
var args__23962__auto__ = [];
var len__23955__auto___28262 = arguments.length;
var i__23956__auto___28263 = (0);
while(true){
if((i__23956__auto___28263 < len__23955__auto___28262)){
args__23962__auto__.push((arguments[i__23956__auto___28263]));

var G__28264 = (i__23956__auto___28263 + (1));
i__23956__auto___28263 = G__28264;
continue;
} else {
}
break;
}

var argseq__23963__auto__ = ((((2) < args__23962__auto__.length))?(new cljs.core.IndexedSeq(args__23962__auto__.slice((2)),(0),null)):null);
return cljs.core$macros.unchecked_subtract.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__23963__auto__);
});

cljs.core$macros.unchecked_subtract.cljs$core$IFn$_invoke$arity$variadic = (function (_AMPERSAND_form,_AMPERSAND_env,xs){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","-","cljs.core$macros/-",13526976,null)),xs)));
});

cljs.core$macros.unchecked_subtract.cljs$lang$maxFixedArity = (2);

cljs.core$macros.unchecked_subtract.cljs$lang$applyTo = (function (seq28259){
var G__28260 = cljs.core.first.call(null,seq28259);
var seq28259__$1 = cljs.core.next.call(null,seq28259);
var G__28261 = cljs.core.first.call(null,seq28259__$1);
var seq28259__$2 = cljs.core.next.call(null,seq28259__$1);
return cljs.core$macros.unchecked_subtract.cljs$core$IFn$_invoke$arity$variadic(G__28260,G__28261,seq28259__$2);
});

cljs.core$macros.unchecked_subtract.cljs$lang$macro = true;
cljs.core$macros.unchecked_subtract_int = (function cljs$core$macros$unchecked_subtract_int(var_args){
var args__23962__auto__ = [];
var len__23955__auto___28268 = arguments.length;
var i__23956__auto___28269 = (0);
while(true){
if((i__23956__auto___28269 < len__23955__auto___28268)){
args__23962__auto__.push((arguments[i__23956__auto___28269]));

var G__28270 = (i__23956__auto___28269 + (1));
i__23956__auto___28269 = G__28270;
continue;
} else {
}
break;
}

var argseq__23963__auto__ = ((((2) < args__23962__auto__.length))?(new cljs.core.IndexedSeq(args__23962__auto__.slice((2)),(0),null)):null);
return cljs.core$macros.unchecked_subtract_int.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__23963__auto__);
});

cljs.core$macros.unchecked_subtract_int.cljs$core$IFn$_invoke$arity$variadic = (function (_AMPERSAND_form,_AMPERSAND_env,xs){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","-","cljs.core$macros/-",13526976,null)),xs)));
});

cljs.core$macros.unchecked_subtract_int.cljs$lang$maxFixedArity = (2);

cljs.core$macros.unchecked_subtract_int.cljs$lang$applyTo = (function (seq28265){
var G__28266 = cljs.core.first.call(null,seq28265);
var seq28265__$1 = cljs.core.next.call(null,seq28265);
var G__28267 = cljs.core.first.call(null,seq28265__$1);
var seq28265__$2 = cljs.core.next.call(null,seq28265__$1);
return cljs.core$macros.unchecked_subtract_int.cljs$core$IFn$_invoke$arity$variadic(G__28266,G__28267,seq28265__$2);
});

cljs.core$macros.unchecked_subtract_int.cljs$lang$macro = true;
cljs.core$macros._ = (function cljs$core$macros$_(var_args){
var args28271 = [];
var len__23955__auto___28279 = arguments.length;
var i__23956__auto___28280 = (0);
while(true){
if((i__23956__auto___28280 < len__23955__auto___28279)){
args28271.push((arguments[i__23956__auto___28280]));

var G__28281 = (i__23956__auto___28280 + (1));
i__23956__auto___28280 = G__28281;
continue;
} else {
}
break;
}

var G__28278 = args28271.length;
switch (G__28278) {
case 3:
return cljs.core$macros._.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
case 4:
return cljs.core$macros._.cljs$core$IFn$_invoke$arity$4((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]));

break;
default:
var argseq__23974__auto__ = (new cljs.core.IndexedSeq(args28271.slice((4)),(0),null));
return cljs.core$macros._.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]),argseq__23974__auto__);

}
});

cljs.core$macros._.cljs$core$IFn$_invoke$arity$3 = (function (_AMPERSAND_form,_AMPERSAND_env,x){
return cljs.core._conj.call(null,cljs.core._conj.call(null,(function (){var x__23719__auto__ = x;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),"(- ~{})"),new cljs.core.Symbol(null,"js*","js*",-1134233646,null));
});

cljs.core$macros._.cljs$core$IFn$_invoke$arity$4 = (function (_AMPERSAND_form,_AMPERSAND_env,x,y){
return cljs.core._conj.call(null,cljs.core._conj.call(null,(function (){var x__23719__auto__ = x;
return cljs.core._conj.call(null,(function (){var x__23719__auto____$1 = y;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto____$1);
})(),x__23719__auto__);
})(),"(~{} - ~{})"),new cljs.core.Symbol(null,"js*","js*",-1134233646,null));
});

cljs.core$macros._.cljs$core$IFn$_invoke$arity$variadic = (function (_AMPERSAND_form,_AMPERSAND_env,x,y,more){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","-","cljs.core$macros/-",13526976,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","-","cljs.core$macros/-",13526976,null)),(function (){var x__23719__auto__ = x;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = y;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),more)));
});

cljs.core$macros._.cljs$lang$applyTo = (function (seq28272){
var G__28273 = cljs.core.first.call(null,seq28272);
var seq28272__$1 = cljs.core.next.call(null,seq28272);
var G__28274 = cljs.core.first.call(null,seq28272__$1);
var seq28272__$2 = cljs.core.next.call(null,seq28272__$1);
var G__28275 = cljs.core.first.call(null,seq28272__$2);
var seq28272__$3 = cljs.core.next.call(null,seq28272__$2);
var G__28276 = cljs.core.first.call(null,seq28272__$3);
var seq28272__$4 = cljs.core.next.call(null,seq28272__$3);
return cljs.core$macros._.cljs$core$IFn$_invoke$arity$variadic(G__28273,G__28274,G__28275,G__28276,seq28272__$4);
});

cljs.core$macros._.cljs$lang$maxFixedArity = (4);

cljs.core$macros._.cljs$lang$macro = true;
cljs.core$macros._STAR_ = (function cljs$core$macros$_STAR_(var_args){
var args28283 = [];
var len__23955__auto___28291 = arguments.length;
var i__23956__auto___28292 = (0);
while(true){
if((i__23956__auto___28292 < len__23955__auto___28291)){
args28283.push((arguments[i__23956__auto___28292]));

var G__28293 = (i__23956__auto___28292 + (1));
i__23956__auto___28292 = G__28293;
continue;
} else {
}
break;
}

var G__28290 = args28283.length;
switch (G__28290) {
case 2:
return cljs.core$macros._STAR_.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core$macros._STAR_.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
case 4:
return cljs.core$macros._STAR_.cljs$core$IFn$_invoke$arity$4((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]));

break;
default:
var argseq__23974__auto__ = (new cljs.core.IndexedSeq(args28283.slice((4)),(0),null));
return cljs.core$macros._STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]),argseq__23974__auto__);

}
});

cljs.core$macros._STAR_.cljs$core$IFn$_invoke$arity$2 = (function (_AMPERSAND_form,_AMPERSAND_env){
return (1);
});

cljs.core$macros._STAR_.cljs$core$IFn$_invoke$arity$3 = (function (_AMPERSAND_form,_AMPERSAND_env,x){
return x;
});

cljs.core$macros._STAR_.cljs$core$IFn$_invoke$arity$4 = (function (_AMPERSAND_form,_AMPERSAND_env,x,y){
return cljs.core._conj.call(null,cljs.core._conj.call(null,(function (){var x__23719__auto__ = x;
return cljs.core._conj.call(null,(function (){var x__23719__auto____$1 = y;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto____$1);
})(),x__23719__auto__);
})(),"(~{} * ~{})"),new cljs.core.Symbol(null,"js*","js*",-1134233646,null));
});

cljs.core$macros._STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (_AMPERSAND_form,_AMPERSAND_env,x,y,more){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","*","cljs.core$macros/*",946321529,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","*","cljs.core$macros/*",946321529,null)),(function (){var x__23719__auto__ = x;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = y;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),more)));
});

cljs.core$macros._STAR_.cljs$lang$applyTo = (function (seq28284){
var G__28285 = cljs.core.first.call(null,seq28284);
var seq28284__$1 = cljs.core.next.call(null,seq28284);
var G__28286 = cljs.core.first.call(null,seq28284__$1);
var seq28284__$2 = cljs.core.next.call(null,seq28284__$1);
var G__28287 = cljs.core.first.call(null,seq28284__$2);
var seq28284__$3 = cljs.core.next.call(null,seq28284__$2);
var G__28288 = cljs.core.first.call(null,seq28284__$3);
var seq28284__$4 = cljs.core.next.call(null,seq28284__$3);
return cljs.core$macros._STAR_.cljs$core$IFn$_invoke$arity$variadic(G__28285,G__28286,G__28287,G__28288,seq28284__$4);
});

cljs.core$macros._STAR_.cljs$lang$maxFixedArity = (4);

cljs.core$macros._STAR_.cljs$lang$macro = true;
cljs.core$macros._SLASH_ = (function cljs$core$macros$_SLASH_(var_args){
var args28295 = [];
var len__23955__auto___28303 = arguments.length;
var i__23956__auto___28304 = (0);
while(true){
if((i__23956__auto___28304 < len__23955__auto___28303)){
args28295.push((arguments[i__23956__auto___28304]));

var G__28305 = (i__23956__auto___28304 + (1));
i__23956__auto___28304 = G__28305;
continue;
} else {
}
break;
}

var G__28302 = args28295.length;
switch (G__28302) {
case 3:
return cljs.core$macros._SLASH_.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
case 4:
return cljs.core$macros._SLASH_.cljs$core$IFn$_invoke$arity$4((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]));

break;
default:
var argseq__23974__auto__ = (new cljs.core.IndexedSeq(args28295.slice((4)),(0),null));
return cljs.core$macros._SLASH_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]),argseq__23974__auto__);

}
});

cljs.core$macros._SLASH_.cljs$core$IFn$_invoke$arity$3 = (function (_AMPERSAND_form,_AMPERSAND_env,x){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","/","cljs.core$macros//",-893374331,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,(1)),(function (){var x__23719__auto__ = x;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
});

cljs.core$macros._SLASH_.cljs$core$IFn$_invoke$arity$4 = (function (_AMPERSAND_form,_AMPERSAND_env,x,y){
return cljs.core._conj.call(null,cljs.core._conj.call(null,(function (){var x__23719__auto__ = x;
return cljs.core._conj.call(null,(function (){var x__23719__auto____$1 = y;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto____$1);
})(),x__23719__auto__);
})(),"(~{} / ~{})"),new cljs.core.Symbol(null,"js*","js*",-1134233646,null));
});

cljs.core$macros._SLASH_.cljs$core$IFn$_invoke$arity$variadic = (function (_AMPERSAND_form,_AMPERSAND_env,x,y,more){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","/","cljs.core$macros//",-893374331,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","/","cljs.core$macros//",-893374331,null)),(function (){var x__23719__auto__ = x;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = y;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),more)));
});

cljs.core$macros._SLASH_.cljs$lang$applyTo = (function (seq28296){
var G__28297 = cljs.core.first.call(null,seq28296);
var seq28296__$1 = cljs.core.next.call(null,seq28296);
var G__28298 = cljs.core.first.call(null,seq28296__$1);
var seq28296__$2 = cljs.core.next.call(null,seq28296__$1);
var G__28299 = cljs.core.first.call(null,seq28296__$2);
var seq28296__$3 = cljs.core.next.call(null,seq28296__$2);
var G__28300 = cljs.core.first.call(null,seq28296__$3);
var seq28296__$4 = cljs.core.next.call(null,seq28296__$3);
return cljs.core$macros._SLASH_.cljs$core$IFn$_invoke$arity$variadic(G__28297,G__28298,G__28299,G__28300,seq28296__$4);
});

cljs.core$macros._SLASH_.cljs$lang$maxFixedArity = (4);

cljs.core$macros._SLASH_.cljs$lang$macro = true;
cljs.core$macros.divide = (function cljs$core$macros$divide(var_args){
var args28307 = [];
var len__23955__auto___28315 = arguments.length;
var i__23956__auto___28316 = (0);
while(true){
if((i__23956__auto___28316 < len__23955__auto___28315)){
args28307.push((arguments[i__23956__auto___28316]));

var G__28317 = (i__23956__auto___28316 + (1));
i__23956__auto___28316 = G__28317;
continue;
} else {
}
break;
}

var G__28314 = args28307.length;
switch (G__28314) {
case 3:
return cljs.core$macros.divide.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
case 4:
return cljs.core$macros.divide.cljs$core$IFn$_invoke$arity$4((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]));

break;
default:
var argseq__23974__auto__ = (new cljs.core.IndexedSeq(args28307.slice((4)),(0),null));
return cljs.core$macros.divide.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]),argseq__23974__auto__);

}
});

cljs.core$macros.divide.cljs$core$IFn$_invoke$arity$3 = (function (_AMPERSAND_form,_AMPERSAND_env,x){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","/","cljs.core$macros//",-893374331,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,(1)),(function (){var x__23719__auto__ = x;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
});

cljs.core$macros.divide.cljs$core$IFn$_invoke$arity$4 = (function (_AMPERSAND_form,_AMPERSAND_env,x,y){
return cljs.core._conj.call(null,cljs.core._conj.call(null,(function (){var x__23719__auto__ = x;
return cljs.core._conj.call(null,(function (){var x__23719__auto____$1 = y;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto____$1);
})(),x__23719__auto__);
})(),"(~{} / ~{})"),new cljs.core.Symbol(null,"js*","js*",-1134233646,null));
});

cljs.core$macros.divide.cljs$core$IFn$_invoke$arity$variadic = (function (_AMPERSAND_form,_AMPERSAND_env,x,y,more){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","/","cljs.core$macros//",-893374331,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","/","cljs.core$macros//",-893374331,null)),(function (){var x__23719__auto__ = x;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = y;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),more)));
});

cljs.core$macros.divide.cljs$lang$applyTo = (function (seq28308){
var G__28309 = cljs.core.first.call(null,seq28308);
var seq28308__$1 = cljs.core.next.call(null,seq28308);
var G__28310 = cljs.core.first.call(null,seq28308__$1);
var seq28308__$2 = cljs.core.next.call(null,seq28308__$1);
var G__28311 = cljs.core.first.call(null,seq28308__$2);
var seq28308__$3 = cljs.core.next.call(null,seq28308__$2);
var G__28312 = cljs.core.first.call(null,seq28308__$3);
var seq28308__$4 = cljs.core.next.call(null,seq28308__$3);
return cljs.core$macros.divide.cljs$core$IFn$_invoke$arity$variadic(G__28309,G__28310,G__28311,G__28312,seq28308__$4);
});

cljs.core$macros.divide.cljs$lang$maxFixedArity = (4);

cljs.core$macros.divide.cljs$lang$macro = true;
cljs.core$macros._LT_ = (function cljs$core$macros$_LT_(var_args){
var args28319 = [];
var len__23955__auto___28327 = arguments.length;
var i__23956__auto___28328 = (0);
while(true){
if((i__23956__auto___28328 < len__23955__auto___28327)){
args28319.push((arguments[i__23956__auto___28328]));

var G__28329 = (i__23956__auto___28328 + (1));
i__23956__auto___28328 = G__28329;
continue;
} else {
}
break;
}

var G__28326 = args28319.length;
switch (G__28326) {
case 3:
return cljs.core$macros._LT_.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
case 4:
return cljs.core$macros._LT_.cljs$core$IFn$_invoke$arity$4((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]));

break;
default:
var argseq__23974__auto__ = (new cljs.core.IndexedSeq(args28319.slice((4)),(0),null));
return cljs.core$macros._LT_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]),argseq__23974__auto__);

}
});

cljs.core$macros._LT_.cljs$core$IFn$_invoke$arity$3 = (function (_AMPERSAND_form,_AMPERSAND_env,x){
return true;
});

cljs.core$macros._LT_.cljs$core$IFn$_invoke$arity$4 = (function (_AMPERSAND_form,_AMPERSAND_env,x,y){
return cljs.core$macros.bool_expr.call(null,cljs.core._conj.call(null,cljs.core._conj.call(null,(function (){var x__23719__auto__ = x;
return cljs.core._conj.call(null,(function (){var x__23719__auto____$1 = y;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto____$1);
})(),x__23719__auto__);
})(),"(~{} < ~{})"),new cljs.core.Symbol(null,"js*","js*",-1134233646,null)));
});

cljs.core$macros._LT_.cljs$core$IFn$_invoke$arity$variadic = (function (_AMPERSAND_form,_AMPERSAND_env,x,y,more){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","and","cljs.core$macros/and",48320334,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","<","cljs.core$macros/<",371512596,null)),(function (){var x__23719__auto__ = x;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = y;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","<","cljs.core$macros/<",371512596,null)),(function (){var x__23719__auto__ = y;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),more)));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
});

cljs.core$macros._LT_.cljs$lang$applyTo = (function (seq28320){
var G__28321 = cljs.core.first.call(null,seq28320);
var seq28320__$1 = cljs.core.next.call(null,seq28320);
var G__28322 = cljs.core.first.call(null,seq28320__$1);
var seq28320__$2 = cljs.core.next.call(null,seq28320__$1);
var G__28323 = cljs.core.first.call(null,seq28320__$2);
var seq28320__$3 = cljs.core.next.call(null,seq28320__$2);
var G__28324 = cljs.core.first.call(null,seq28320__$3);
var seq28320__$4 = cljs.core.next.call(null,seq28320__$3);
return cljs.core$macros._LT_.cljs$core$IFn$_invoke$arity$variadic(G__28321,G__28322,G__28323,G__28324,seq28320__$4);
});

cljs.core$macros._LT_.cljs$lang$maxFixedArity = (4);

cljs.core$macros._LT_.cljs$lang$macro = true;
cljs.core$macros._LT__EQ_ = (function cljs$core$macros$_LT__EQ_(var_args){
var args28331 = [];
var len__23955__auto___28339 = arguments.length;
var i__23956__auto___28340 = (0);
while(true){
if((i__23956__auto___28340 < len__23955__auto___28339)){
args28331.push((arguments[i__23956__auto___28340]));

var G__28341 = (i__23956__auto___28340 + (1));
i__23956__auto___28340 = G__28341;
continue;
} else {
}
break;
}

var G__28338 = args28331.length;
switch (G__28338) {
case 3:
return cljs.core$macros._LT__EQ_.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
case 4:
return cljs.core$macros._LT__EQ_.cljs$core$IFn$_invoke$arity$4((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]));

break;
default:
var argseq__23974__auto__ = (new cljs.core.IndexedSeq(args28331.slice((4)),(0),null));
return cljs.core$macros._LT__EQ_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]),argseq__23974__auto__);

}
});

cljs.core$macros._LT__EQ_.cljs$core$IFn$_invoke$arity$3 = (function (_AMPERSAND_form,_AMPERSAND_env,x){
return true;
});

cljs.core$macros._LT__EQ_.cljs$core$IFn$_invoke$arity$4 = (function (_AMPERSAND_form,_AMPERSAND_env,x,y){
return cljs.core$macros.bool_expr.call(null,cljs.core._conj.call(null,cljs.core._conj.call(null,(function (){var x__23719__auto__ = x;
return cljs.core._conj.call(null,(function (){var x__23719__auto____$1 = y;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto____$1);
})(),x__23719__auto__);
})(),"(~{} <= ~{})"),new cljs.core.Symbol(null,"js*","js*",-1134233646,null)));
});

cljs.core$macros._LT__EQ_.cljs$core$IFn$_invoke$arity$variadic = (function (_AMPERSAND_form,_AMPERSAND_env,x,y,more){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","and","cljs.core$macros/and",48320334,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","<=","cljs.core$macros/<=",1865244377,null)),(function (){var x__23719__auto__ = x;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = y;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","<=","cljs.core$macros/<=",1865244377,null)),(function (){var x__23719__auto__ = y;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),more)));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
});

cljs.core$macros._LT__EQ_.cljs$lang$applyTo = (function (seq28332){
var G__28333 = cljs.core.first.call(null,seq28332);
var seq28332__$1 = cljs.core.next.call(null,seq28332);
var G__28334 = cljs.core.first.call(null,seq28332__$1);
var seq28332__$2 = cljs.core.next.call(null,seq28332__$1);
var G__28335 = cljs.core.first.call(null,seq28332__$2);
var seq28332__$3 = cljs.core.next.call(null,seq28332__$2);
var G__28336 = cljs.core.first.call(null,seq28332__$3);
var seq28332__$4 = cljs.core.next.call(null,seq28332__$3);
return cljs.core$macros._LT__EQ_.cljs$core$IFn$_invoke$arity$variadic(G__28333,G__28334,G__28335,G__28336,seq28332__$4);
});

cljs.core$macros._LT__EQ_.cljs$lang$maxFixedArity = (4);

cljs.core$macros._LT__EQ_.cljs$lang$macro = true;
cljs.core$macros._GT_ = (function cljs$core$macros$_GT_(var_args){
var args28343 = [];
var len__23955__auto___28351 = arguments.length;
var i__23956__auto___28352 = (0);
while(true){
if((i__23956__auto___28352 < len__23955__auto___28351)){
args28343.push((arguments[i__23956__auto___28352]));

var G__28353 = (i__23956__auto___28352 + (1));
i__23956__auto___28352 = G__28353;
continue;
} else {
}
break;
}

var G__28350 = args28343.length;
switch (G__28350) {
case 3:
return cljs.core$macros._GT_.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
case 4:
return cljs.core$macros._GT_.cljs$core$IFn$_invoke$arity$4((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]));

break;
default:
var argseq__23974__auto__ = (new cljs.core.IndexedSeq(args28343.slice((4)),(0),null));
return cljs.core$macros._GT_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]),argseq__23974__auto__);

}
});

cljs.core$macros._GT_.cljs$core$IFn$_invoke$arity$3 = (function (_AMPERSAND_form,_AMPERSAND_env,x){
return true;
});

cljs.core$macros._GT_.cljs$core$IFn$_invoke$arity$4 = (function (_AMPERSAND_form,_AMPERSAND_env,x,y){
return cljs.core$macros.bool_expr.call(null,cljs.core._conj.call(null,cljs.core._conj.call(null,(function (){var x__23719__auto__ = x;
return cljs.core._conj.call(null,(function (){var x__23719__auto____$1 = y;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto____$1);
})(),x__23719__auto__);
})(),"(~{} > ~{})"),new cljs.core.Symbol(null,"js*","js*",-1134233646,null)));
});

cljs.core$macros._GT_.cljs$core$IFn$_invoke$arity$variadic = (function (_AMPERSAND_form,_AMPERSAND_env,x,y,more){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","and","cljs.core$macros/and",48320334,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros",">","cljs.core$macros/>",1703297853,null)),(function (){var x__23719__auto__ = x;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = y;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros",">","cljs.core$macros/>",1703297853,null)),(function (){var x__23719__auto__ = y;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),more)));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
});

cljs.core$macros._GT_.cljs$lang$applyTo = (function (seq28344){
var G__28345 = cljs.core.first.call(null,seq28344);
var seq28344__$1 = cljs.core.next.call(null,seq28344);
var G__28346 = cljs.core.first.call(null,seq28344__$1);
var seq28344__$2 = cljs.core.next.call(null,seq28344__$1);
var G__28347 = cljs.core.first.call(null,seq28344__$2);
var seq28344__$3 = cljs.core.next.call(null,seq28344__$2);
var G__28348 = cljs.core.first.call(null,seq28344__$3);
var seq28344__$4 = cljs.core.next.call(null,seq28344__$3);
return cljs.core$macros._GT_.cljs$core$IFn$_invoke$arity$variadic(G__28345,G__28346,G__28347,G__28348,seq28344__$4);
});

cljs.core$macros._GT_.cljs$lang$maxFixedArity = (4);

cljs.core$macros._GT_.cljs$lang$macro = true;
cljs.core$macros._GT__EQ_ = (function cljs$core$macros$_GT__EQ_(var_args){
var args28355 = [];
var len__23955__auto___28363 = arguments.length;
var i__23956__auto___28364 = (0);
while(true){
if((i__23956__auto___28364 < len__23955__auto___28363)){
args28355.push((arguments[i__23956__auto___28364]));

var G__28365 = (i__23956__auto___28364 + (1));
i__23956__auto___28364 = G__28365;
continue;
} else {
}
break;
}

var G__28362 = args28355.length;
switch (G__28362) {
case 3:
return cljs.core$macros._GT__EQ_.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
case 4:
return cljs.core$macros._GT__EQ_.cljs$core$IFn$_invoke$arity$4((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]));

break;
default:
var argseq__23974__auto__ = (new cljs.core.IndexedSeq(args28355.slice((4)),(0),null));
return cljs.core$macros._GT__EQ_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]),argseq__23974__auto__);

}
});

cljs.core$macros._GT__EQ_.cljs$core$IFn$_invoke$arity$3 = (function (_AMPERSAND_form,_AMPERSAND_env,x){
return true;
});

cljs.core$macros._GT__EQ_.cljs$core$IFn$_invoke$arity$4 = (function (_AMPERSAND_form,_AMPERSAND_env,x,y){
return cljs.core$macros.bool_expr.call(null,cljs.core._conj.call(null,cljs.core._conj.call(null,(function (){var x__23719__auto__ = x;
return cljs.core._conj.call(null,(function (){var x__23719__auto____$1 = y;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto____$1);
})(),x__23719__auto__);
})(),"(~{} >= ~{})"),new cljs.core.Symbol(null,"js*","js*",-1134233646,null)));
});

cljs.core$macros._GT__EQ_.cljs$core$IFn$_invoke$arity$variadic = (function (_AMPERSAND_form,_AMPERSAND_env,x,y,more){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","and","cljs.core$macros/and",48320334,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros",">=","cljs.core$macros/>=",527849062,null)),(function (){var x__23719__auto__ = x;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = y;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros",">=","cljs.core$macros/>=",527849062,null)),(function (){var x__23719__auto__ = y;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),more)));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
});

cljs.core$macros._GT__EQ_.cljs$lang$applyTo = (function (seq28356){
var G__28357 = cljs.core.first.call(null,seq28356);
var seq28356__$1 = cljs.core.next.call(null,seq28356);
var G__28358 = cljs.core.first.call(null,seq28356__$1);
var seq28356__$2 = cljs.core.next.call(null,seq28356__$1);
var G__28359 = cljs.core.first.call(null,seq28356__$2);
var seq28356__$3 = cljs.core.next.call(null,seq28356__$2);
var G__28360 = cljs.core.first.call(null,seq28356__$3);
var seq28356__$4 = cljs.core.next.call(null,seq28356__$3);
return cljs.core$macros._GT__EQ_.cljs$core$IFn$_invoke$arity$variadic(G__28357,G__28358,G__28359,G__28360,seq28356__$4);
});

cljs.core$macros._GT__EQ_.cljs$lang$maxFixedArity = (4);

cljs.core$macros._GT__EQ_.cljs$lang$macro = true;
cljs.core$macros._EQ__EQ_ = (function cljs$core$macros$_EQ__EQ_(var_args){
var args28367 = [];
var len__23955__auto___28375 = arguments.length;
var i__23956__auto___28376 = (0);
while(true){
if((i__23956__auto___28376 < len__23955__auto___28375)){
args28367.push((arguments[i__23956__auto___28376]));

var G__28377 = (i__23956__auto___28376 + (1));
i__23956__auto___28376 = G__28377;
continue;
} else {
}
break;
}

var G__28374 = args28367.length;
switch (G__28374) {
case 3:
return cljs.core$macros._EQ__EQ_.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
case 4:
return cljs.core$macros._EQ__EQ_.cljs$core$IFn$_invoke$arity$4((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]));

break;
default:
var argseq__23974__auto__ = (new cljs.core.IndexedSeq(args28367.slice((4)),(0),null));
return cljs.core$macros._EQ__EQ_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]),argseq__23974__auto__);

}
});

cljs.core$macros._EQ__EQ_.cljs$core$IFn$_invoke$arity$3 = (function (_AMPERSAND_form,_AMPERSAND_env,x){
return true;
});

cljs.core$macros._EQ__EQ_.cljs$core$IFn$_invoke$arity$4 = (function (_AMPERSAND_form,_AMPERSAND_env,x,y){
return cljs.core$macros.bool_expr.call(null,cljs.core._conj.call(null,cljs.core._conj.call(null,(function (){var x__23719__auto__ = x;
return cljs.core._conj.call(null,(function (){var x__23719__auto____$1 = y;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto____$1);
})(),x__23719__auto__);
})(),"(~{} === ~{})"),new cljs.core.Symbol(null,"js*","js*",-1134233646,null)));
});

cljs.core$macros._EQ__EQ_.cljs$core$IFn$_invoke$arity$variadic = (function (_AMPERSAND_form,_AMPERSAND_env,x,y,more){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","and","cljs.core$macros/and",48320334,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","==","cljs.core$macros/==",-818551413,null)),(function (){var x__23719__auto__ = x;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = y;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","==","cljs.core$macros/==",-818551413,null)),(function (){var x__23719__auto__ = y;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),more)));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
});

cljs.core$macros._EQ__EQ_.cljs$lang$applyTo = (function (seq28368){
var G__28369 = cljs.core.first.call(null,seq28368);
var seq28368__$1 = cljs.core.next.call(null,seq28368);
var G__28370 = cljs.core.first.call(null,seq28368__$1);
var seq28368__$2 = cljs.core.next.call(null,seq28368__$1);
var G__28371 = cljs.core.first.call(null,seq28368__$2);
var seq28368__$3 = cljs.core.next.call(null,seq28368__$2);
var G__28372 = cljs.core.first.call(null,seq28368__$3);
var seq28368__$4 = cljs.core.next.call(null,seq28368__$3);
return cljs.core$macros._EQ__EQ_.cljs$core$IFn$_invoke$arity$variadic(G__28369,G__28370,G__28371,G__28372,seq28368__$4);
});

cljs.core$macros._EQ__EQ_.cljs$lang$maxFixedArity = (4);

cljs.core$macros._EQ__EQ_.cljs$lang$macro = true;
cljs.core$macros.dec = (function cljs$core$macros$dec(_AMPERSAND_form,_AMPERSAND_env,x){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","-","cljs.core$macros/-",13526976,null)),(function (){var x__23719__auto__ = x;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,(1)))));
});

cljs.core$macros.dec.cljs$lang$macro = true;
cljs.core$macros.inc = (function cljs$core$macros$inc(_AMPERSAND_form,_AMPERSAND_env,x){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","+","cljs.core$macros/+",-18260342,null)),(function (){var x__23719__auto__ = x;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,(1)))));
});

cljs.core$macros.inc.cljs$lang$macro = true;
cljs.core$macros.zero_QMARK_ = (function cljs$core$macros$zero_QMARK_(_AMPERSAND_form,_AMPERSAND_env,x){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","==","cljs.core$macros/==",-818551413,null)),(function (){var x__23719__auto__ = x;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,(0)))));
});

cljs.core$macros.zero_QMARK_.cljs$lang$macro = true;
cljs.core$macros.pos_QMARK_ = (function cljs$core$macros$pos_QMARK_(_AMPERSAND_form,_AMPERSAND_env,x){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros",">","cljs.core$macros/>",1703297853,null)),(function (){var x__23719__auto__ = x;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,(0)))));
});

cljs.core$macros.pos_QMARK_.cljs$lang$macro = true;
cljs.core$macros.neg_QMARK_ = (function cljs$core$macros$neg_QMARK_(_AMPERSAND_form,_AMPERSAND_env,x){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","<","cljs.core$macros/<",371512596,null)),(function (){var x__23719__auto__ = x;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,(0)))));
});

cljs.core$macros.neg_QMARK_.cljs$lang$macro = true;
cljs.core$macros.max = (function cljs$core$macros$max(var_args){
var args28381 = [];
var len__23955__auto___28389 = arguments.length;
var i__23956__auto___28390 = (0);
while(true){
if((i__23956__auto___28390 < len__23955__auto___28389)){
args28381.push((arguments[i__23956__auto___28390]));

var G__28391 = (i__23956__auto___28390 + (1));
i__23956__auto___28390 = G__28391;
continue;
} else {
}
break;
}

var G__28388 = args28381.length;
switch (G__28388) {
case 3:
return cljs.core$macros.max.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
case 4:
return cljs.core$macros.max.cljs$core$IFn$_invoke$arity$4((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]));

break;
default:
var argseq__23974__auto__ = (new cljs.core.IndexedSeq(args28381.slice((4)),(0),null));
return cljs.core$macros.max.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]),argseq__23974__auto__);

}
});

cljs.core$macros.max.cljs$core$IFn$_invoke$arity$3 = (function (_AMPERSAND_form,_AMPERSAND_env,x){
return x;
});

cljs.core$macros.max.cljs$core$IFn$_invoke$arity$4 = (function (_AMPERSAND_form,_AMPERSAND_env,x,y){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","let","cljs.core$macros/let",-160286726,null)),(function (){var x__23719__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"x__28379__auto__","x__28379__auto__",2073547973,null)),(function (){var x__23719__auto__ = x;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"y__28380__auto__","y__28380__auto__",1133468470,null)),(function (){var x__23719__auto__ = y;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})()))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"js*","js*",-1134233646,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,"((~{} > ~{}) ? ~{} : ~{})"),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"x__28379__auto__","x__28379__auto__",2073547973,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"y__28380__auto__","y__28380__auto__",1133468470,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"x__28379__auto__","x__28379__auto__",2073547973,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"y__28380__auto__","y__28380__auto__",1133468470,null)))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
});

cljs.core$macros.max.cljs$core$IFn$_invoke$arity$variadic = (function (_AMPERSAND_form,_AMPERSAND_env,x,y,more){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","max","cljs.core$macros/max",1176150699,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","max","cljs.core$macros/max",1176150699,null)),(function (){var x__23719__auto__ = x;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = y;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),more)));
});

cljs.core$macros.max.cljs$lang$applyTo = (function (seq28382){
var G__28383 = cljs.core.first.call(null,seq28382);
var seq28382__$1 = cljs.core.next.call(null,seq28382);
var G__28384 = cljs.core.first.call(null,seq28382__$1);
var seq28382__$2 = cljs.core.next.call(null,seq28382__$1);
var G__28385 = cljs.core.first.call(null,seq28382__$2);
var seq28382__$3 = cljs.core.next.call(null,seq28382__$2);
var G__28386 = cljs.core.first.call(null,seq28382__$3);
var seq28382__$4 = cljs.core.next.call(null,seq28382__$3);
return cljs.core$macros.max.cljs$core$IFn$_invoke$arity$variadic(G__28383,G__28384,G__28385,G__28386,seq28382__$4);
});

cljs.core$macros.max.cljs$lang$maxFixedArity = (4);

cljs.core$macros.max.cljs$lang$macro = true;
cljs.core$macros.min = (function cljs$core$macros$min(var_args){
var args28395 = [];
var len__23955__auto___28403 = arguments.length;
var i__23956__auto___28404 = (0);
while(true){
if((i__23956__auto___28404 < len__23955__auto___28403)){
args28395.push((arguments[i__23956__auto___28404]));

var G__28405 = (i__23956__auto___28404 + (1));
i__23956__auto___28404 = G__28405;
continue;
} else {
}
break;
}

var G__28402 = args28395.length;
switch (G__28402) {
case 3:
return cljs.core$macros.min.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
case 4:
return cljs.core$macros.min.cljs$core$IFn$_invoke$arity$4((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]));

break;
default:
var argseq__23974__auto__ = (new cljs.core.IndexedSeq(args28395.slice((4)),(0),null));
return cljs.core$macros.min.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]),argseq__23974__auto__);

}
});

cljs.core$macros.min.cljs$core$IFn$_invoke$arity$3 = (function (_AMPERSAND_form,_AMPERSAND_env,x){
return x;
});

cljs.core$macros.min.cljs$core$IFn$_invoke$arity$4 = (function (_AMPERSAND_form,_AMPERSAND_env,x,y){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","let","cljs.core$macros/let",-160286726,null)),(function (){var x__23719__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"x__28393__auto__","x__28393__auto__",1723855042,null)),(function (){var x__23719__auto__ = x;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"y__28394__auto__","y__28394__auto__",-827334419,null)),(function (){var x__23719__auto__ = y;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})()))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"js*","js*",-1134233646,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,"((~{} < ~{}) ? ~{} : ~{})"),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"x__28393__auto__","x__28393__auto__",1723855042,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"y__28394__auto__","y__28394__auto__",-827334419,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"x__28393__auto__","x__28393__auto__",1723855042,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"y__28394__auto__","y__28394__auto__",-827334419,null)))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
});

cljs.core$macros.min.cljs$core$IFn$_invoke$arity$variadic = (function (_AMPERSAND_form,_AMPERSAND_env,x,y,more){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","min","cljs.core$macros/min",1499775161,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","min","cljs.core$macros/min",1499775161,null)),(function (){var x__23719__auto__ = x;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = y;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),more)));
});

cljs.core$macros.min.cljs$lang$applyTo = (function (seq28396){
var G__28397 = cljs.core.first.call(null,seq28396);
var seq28396__$1 = cljs.core.next.call(null,seq28396);
var G__28398 = cljs.core.first.call(null,seq28396__$1);
var seq28396__$2 = cljs.core.next.call(null,seq28396__$1);
var G__28399 = cljs.core.first.call(null,seq28396__$2);
var seq28396__$3 = cljs.core.next.call(null,seq28396__$2);
var G__28400 = cljs.core.first.call(null,seq28396__$3);
var seq28396__$4 = cljs.core.next.call(null,seq28396__$3);
return cljs.core$macros.min.cljs$core$IFn$_invoke$arity$variadic(G__28397,G__28398,G__28399,G__28400,seq28396__$4);
});

cljs.core$macros.min.cljs$lang$maxFixedArity = (4);

cljs.core$macros.min.cljs$lang$macro = true;
cljs.core$macros.js_mod = (function cljs$core$macros$js_mod(_AMPERSAND_form,_AMPERSAND_env,num,div){
return cljs.core._conj.call(null,cljs.core._conj.call(null,(function (){var x__23719__auto__ = num;
return cljs.core._conj.call(null,(function (){var x__23719__auto____$1 = div;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto____$1);
})(),x__23719__auto__);
})(),"(~{} % ~{})"),new cljs.core.Symbol(null,"js*","js*",-1134233646,null));
});

cljs.core$macros.js_mod.cljs$lang$macro = true;
cljs.core$macros.bit_not = (function cljs$core$macros$bit_not(_AMPERSAND_form,_AMPERSAND_env,x){
return cljs.core._conj.call(null,cljs.core._conj.call(null,(function (){var x__23719__auto__ = x;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),"(~ ~{})"),new cljs.core.Symbol(null,"js*","js*",-1134233646,null));
});

cljs.core$macros.bit_not.cljs$lang$macro = true;
cljs.core$macros.bit_and = (function cljs$core$macros$bit_and(var_args){
var args28407 = [];
var len__23955__auto___28415 = arguments.length;
var i__23956__auto___28416 = (0);
while(true){
if((i__23956__auto___28416 < len__23955__auto___28415)){
args28407.push((arguments[i__23956__auto___28416]));

var G__28417 = (i__23956__auto___28416 + (1));
i__23956__auto___28416 = G__28417;
continue;
} else {
}
break;
}

var G__28414 = args28407.length;
switch (G__28414) {
case 4:
return cljs.core$macros.bit_and.cljs$core$IFn$_invoke$arity$4((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]));

break;
default:
var argseq__23974__auto__ = (new cljs.core.IndexedSeq(args28407.slice((4)),(0),null));
return cljs.core$macros.bit_and.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]),argseq__23974__auto__);

}
});

cljs.core$macros.bit_and.cljs$core$IFn$_invoke$arity$4 = (function (_AMPERSAND_form,_AMPERSAND_env,x,y){
return cljs.core._conj.call(null,cljs.core._conj.call(null,(function (){var x__23719__auto__ = x;
return cljs.core._conj.call(null,(function (){var x__23719__auto____$1 = y;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto____$1);
})(),x__23719__auto__);
})(),"(~{} & ~{})"),new cljs.core.Symbol(null,"js*","js*",-1134233646,null));
});

cljs.core$macros.bit_and.cljs$core$IFn$_invoke$arity$variadic = (function (_AMPERSAND_form,_AMPERSAND_env,x,y,more){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","bit-and","cljs.core$macros/bit-and",-1069060797,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","bit-and","cljs.core$macros/bit-and",-1069060797,null)),(function (){var x__23719__auto__ = x;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = y;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),more)));
});

cljs.core$macros.bit_and.cljs$lang$applyTo = (function (seq28408){
var G__28409 = cljs.core.first.call(null,seq28408);
var seq28408__$1 = cljs.core.next.call(null,seq28408);
var G__28410 = cljs.core.first.call(null,seq28408__$1);
var seq28408__$2 = cljs.core.next.call(null,seq28408__$1);
var G__28411 = cljs.core.first.call(null,seq28408__$2);
var seq28408__$3 = cljs.core.next.call(null,seq28408__$2);
var G__28412 = cljs.core.first.call(null,seq28408__$3);
var seq28408__$4 = cljs.core.next.call(null,seq28408__$3);
return cljs.core$macros.bit_and.cljs$core$IFn$_invoke$arity$variadic(G__28409,G__28410,G__28411,G__28412,seq28408__$4);
});

cljs.core$macros.bit_and.cljs$lang$maxFixedArity = (4);

cljs.core$macros.bit_and.cljs$lang$macro = true;
cljs.core$macros.unsafe_bit_and = (function cljs$core$macros$unsafe_bit_and(var_args){
var args28419 = [];
var len__23955__auto___28427 = arguments.length;
var i__23956__auto___28428 = (0);
while(true){
if((i__23956__auto___28428 < len__23955__auto___28427)){
args28419.push((arguments[i__23956__auto___28428]));

var G__28429 = (i__23956__auto___28428 + (1));
i__23956__auto___28428 = G__28429;
continue;
} else {
}
break;
}

var G__28426 = args28419.length;
switch (G__28426) {
case 4:
return cljs.core$macros.unsafe_bit_and.cljs$core$IFn$_invoke$arity$4((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]));

break;
default:
var argseq__23974__auto__ = (new cljs.core.IndexedSeq(args28419.slice((4)),(0),null));
return cljs.core$macros.unsafe_bit_and.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]),argseq__23974__auto__);

}
});

cljs.core$macros.unsafe_bit_and.cljs$core$IFn$_invoke$arity$4 = (function (_AMPERSAND_form,_AMPERSAND_env,x,y){
return cljs.core$macros.bool_expr.call(null,cljs.core._conj.call(null,cljs.core._conj.call(null,(function (){var x__23719__auto__ = x;
return cljs.core._conj.call(null,(function (){var x__23719__auto____$1 = y;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto____$1);
})(),x__23719__auto__);
})(),"(~{} & ~{})"),new cljs.core.Symbol(null,"js*","js*",-1134233646,null)));
});

cljs.core$macros.unsafe_bit_and.cljs$core$IFn$_invoke$arity$variadic = (function (_AMPERSAND_form,_AMPERSAND_env,x,y,more){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","unsafe-bit-and","cljs.core$macros/unsafe-bit-and",1803731600,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","unsafe-bit-and","cljs.core$macros/unsafe-bit-and",1803731600,null)),(function (){var x__23719__auto__ = x;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = y;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),more)));
});

cljs.core$macros.unsafe_bit_and.cljs$lang$applyTo = (function (seq28420){
var G__28421 = cljs.core.first.call(null,seq28420);
var seq28420__$1 = cljs.core.next.call(null,seq28420);
var G__28422 = cljs.core.first.call(null,seq28420__$1);
var seq28420__$2 = cljs.core.next.call(null,seq28420__$1);
var G__28423 = cljs.core.first.call(null,seq28420__$2);
var seq28420__$3 = cljs.core.next.call(null,seq28420__$2);
var G__28424 = cljs.core.first.call(null,seq28420__$3);
var seq28420__$4 = cljs.core.next.call(null,seq28420__$3);
return cljs.core$macros.unsafe_bit_and.cljs$core$IFn$_invoke$arity$variadic(G__28421,G__28422,G__28423,G__28424,seq28420__$4);
});

cljs.core$macros.unsafe_bit_and.cljs$lang$maxFixedArity = (4);

cljs.core$macros.unsafe_bit_and.cljs$lang$macro = true;
cljs.core$macros.bit_or = (function cljs$core$macros$bit_or(var_args){
var args28431 = [];
var len__23955__auto___28439 = arguments.length;
var i__23956__auto___28440 = (0);
while(true){
if((i__23956__auto___28440 < len__23955__auto___28439)){
args28431.push((arguments[i__23956__auto___28440]));

var G__28441 = (i__23956__auto___28440 + (1));
i__23956__auto___28440 = G__28441;
continue;
} else {
}
break;
}

var G__28438 = args28431.length;
switch (G__28438) {
case 4:
return cljs.core$macros.bit_or.cljs$core$IFn$_invoke$arity$4((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]));

break;
default:
var argseq__23974__auto__ = (new cljs.core.IndexedSeq(args28431.slice((4)),(0),null));
return cljs.core$macros.bit_or.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]),argseq__23974__auto__);

}
});

cljs.core$macros.bit_or.cljs$core$IFn$_invoke$arity$4 = (function (_AMPERSAND_form,_AMPERSAND_env,x,y){
return cljs.core._conj.call(null,cljs.core._conj.call(null,(function (){var x__23719__auto__ = x;
return cljs.core._conj.call(null,(function (){var x__23719__auto____$1 = y;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto____$1);
})(),x__23719__auto__);
})(),"(~{} | ~{})"),new cljs.core.Symbol(null,"js*","js*",-1134233646,null));
});

cljs.core$macros.bit_or.cljs$core$IFn$_invoke$arity$variadic = (function (_AMPERSAND_form,_AMPERSAND_env,x,y,more){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","bit-or","cljs.core$macros/bit-or",1463236165,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","bit-or","cljs.core$macros/bit-or",1463236165,null)),(function (){var x__23719__auto__ = x;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = y;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),more)));
});

cljs.core$macros.bit_or.cljs$lang$applyTo = (function (seq28432){
var G__28433 = cljs.core.first.call(null,seq28432);
var seq28432__$1 = cljs.core.next.call(null,seq28432);
var G__28434 = cljs.core.first.call(null,seq28432__$1);
var seq28432__$2 = cljs.core.next.call(null,seq28432__$1);
var G__28435 = cljs.core.first.call(null,seq28432__$2);
var seq28432__$3 = cljs.core.next.call(null,seq28432__$2);
var G__28436 = cljs.core.first.call(null,seq28432__$3);
var seq28432__$4 = cljs.core.next.call(null,seq28432__$3);
return cljs.core$macros.bit_or.cljs$core$IFn$_invoke$arity$variadic(G__28433,G__28434,G__28435,G__28436,seq28432__$4);
});

cljs.core$macros.bit_or.cljs$lang$maxFixedArity = (4);

cljs.core$macros.bit_or.cljs$lang$macro = true;
cljs.core$macros.int$ = (function cljs$core$macros$int(_AMPERSAND_form,_AMPERSAND_env,x){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","bit-or","cljs.core$macros/bit-or",1463236165,null)),(function (){var x__23719__auto__ = x;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,(0)))));
});

cljs.core$macros.int$.cljs$lang$macro = true;
cljs.core$macros.bit_xor = (function cljs$core$macros$bit_xor(var_args){
var args28443 = [];
var len__23955__auto___28451 = arguments.length;
var i__23956__auto___28452 = (0);
while(true){
if((i__23956__auto___28452 < len__23955__auto___28451)){
args28443.push((arguments[i__23956__auto___28452]));

var G__28453 = (i__23956__auto___28452 + (1));
i__23956__auto___28452 = G__28453;
continue;
} else {
}
break;
}

var G__28450 = args28443.length;
switch (G__28450) {
case 4:
return cljs.core$macros.bit_xor.cljs$core$IFn$_invoke$arity$4((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]));

break;
default:
var argseq__23974__auto__ = (new cljs.core.IndexedSeq(args28443.slice((4)),(0),null));
return cljs.core$macros.bit_xor.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]),argseq__23974__auto__);

}
});

cljs.core$macros.bit_xor.cljs$core$IFn$_invoke$arity$4 = (function (_AMPERSAND_form,_AMPERSAND_env,x,y){
return cljs.core._conj.call(null,cljs.core._conj.call(null,(function (){var x__23719__auto__ = x;
return cljs.core._conj.call(null,(function (){var x__23719__auto____$1 = y;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto____$1);
})(),x__23719__auto__);
})(),"(~{} ^ ~{})"),new cljs.core.Symbol(null,"js*","js*",-1134233646,null));
});

cljs.core$macros.bit_xor.cljs$core$IFn$_invoke$arity$variadic = (function (_AMPERSAND_form,_AMPERSAND_env,x,y,more){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","bit-xor","cljs.core$macros/bit-xor",1284619191,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","bit-xor","cljs.core$macros/bit-xor",1284619191,null)),(function (){var x__23719__auto__ = x;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = y;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),more)));
});

cljs.core$macros.bit_xor.cljs$lang$applyTo = (function (seq28444){
var G__28445 = cljs.core.first.call(null,seq28444);
var seq28444__$1 = cljs.core.next.call(null,seq28444);
var G__28446 = cljs.core.first.call(null,seq28444__$1);
var seq28444__$2 = cljs.core.next.call(null,seq28444__$1);
var G__28447 = cljs.core.first.call(null,seq28444__$2);
var seq28444__$3 = cljs.core.next.call(null,seq28444__$2);
var G__28448 = cljs.core.first.call(null,seq28444__$3);
var seq28444__$4 = cljs.core.next.call(null,seq28444__$3);
return cljs.core$macros.bit_xor.cljs$core$IFn$_invoke$arity$variadic(G__28445,G__28446,G__28447,G__28448,seq28444__$4);
});

cljs.core$macros.bit_xor.cljs$lang$maxFixedArity = (4);

cljs.core$macros.bit_xor.cljs$lang$macro = true;
cljs.core$macros.bit_and_not = (function cljs$core$macros$bit_and_not(var_args){
var args28455 = [];
var len__23955__auto___28463 = arguments.length;
var i__23956__auto___28464 = (0);
while(true){
if((i__23956__auto___28464 < len__23955__auto___28463)){
args28455.push((arguments[i__23956__auto___28464]));

var G__28465 = (i__23956__auto___28464 + (1));
i__23956__auto___28464 = G__28465;
continue;
} else {
}
break;
}

var G__28462 = args28455.length;
switch (G__28462) {
case 4:
return cljs.core$macros.bit_and_not.cljs$core$IFn$_invoke$arity$4((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]));

break;
default:
var argseq__23974__auto__ = (new cljs.core.IndexedSeq(args28455.slice((4)),(0),null));
return cljs.core$macros.bit_and_not.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]),argseq__23974__auto__);

}
});

cljs.core$macros.bit_and_not.cljs$core$IFn$_invoke$arity$4 = (function (_AMPERSAND_form,_AMPERSAND_env,x,y){
return cljs.core._conj.call(null,cljs.core._conj.call(null,(function (){var x__23719__auto__ = x;
return cljs.core._conj.call(null,(function (){var x__23719__auto____$1 = y;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto____$1);
})(),x__23719__auto__);
})(),"(~{} & ~~{})"),new cljs.core.Symbol(null,"js*","js*",-1134233646,null));
});

cljs.core$macros.bit_and_not.cljs$core$IFn$_invoke$arity$variadic = (function (_AMPERSAND_form,_AMPERSAND_env,x,y,more){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","bit-and-not","cljs.core$macros/bit-and-not",-537076037,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","bit-and-not","cljs.core$macros/bit-and-not",-537076037,null)),(function (){var x__23719__auto__ = x;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = y;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),more)));
});

cljs.core$macros.bit_and_not.cljs$lang$applyTo = (function (seq28456){
var G__28457 = cljs.core.first.call(null,seq28456);
var seq28456__$1 = cljs.core.next.call(null,seq28456);
var G__28458 = cljs.core.first.call(null,seq28456__$1);
var seq28456__$2 = cljs.core.next.call(null,seq28456__$1);
var G__28459 = cljs.core.first.call(null,seq28456__$2);
var seq28456__$3 = cljs.core.next.call(null,seq28456__$2);
var G__28460 = cljs.core.first.call(null,seq28456__$3);
var seq28456__$4 = cljs.core.next.call(null,seq28456__$3);
return cljs.core$macros.bit_and_not.cljs$core$IFn$_invoke$arity$variadic(G__28457,G__28458,G__28459,G__28460,seq28456__$4);
});

cljs.core$macros.bit_and_not.cljs$lang$maxFixedArity = (4);

cljs.core$macros.bit_and_not.cljs$lang$macro = true;
cljs.core$macros.bit_clear = (function cljs$core$macros$bit_clear(_AMPERSAND_form,_AMPERSAND_env,x,n){
return cljs.core._conj.call(null,cljs.core._conj.call(null,(function (){var x__23719__auto__ = x;
return cljs.core._conj.call(null,(function (){var x__23719__auto____$1 = n;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto____$1);
})(),x__23719__auto__);
})(),"(~{} & ~(1 << ~{}))"),new cljs.core.Symbol(null,"js*","js*",-1134233646,null));
});

cljs.core$macros.bit_clear.cljs$lang$macro = true;
cljs.core$macros.bit_flip = (function cljs$core$macros$bit_flip(_AMPERSAND_form,_AMPERSAND_env,x,n){
return cljs.core._conj.call(null,cljs.core._conj.call(null,(function (){var x__23719__auto__ = x;
return cljs.core._conj.call(null,(function (){var x__23719__auto____$1 = n;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto____$1);
})(),x__23719__auto__);
})(),"(~{} ^ (1 << ~{}))"),new cljs.core.Symbol(null,"js*","js*",-1134233646,null));
});

cljs.core$macros.bit_flip.cljs$lang$macro = true;
cljs.core$macros.bit_test = (function cljs$core$macros$bit_test(_AMPERSAND_form,_AMPERSAND_env,x,n){
return cljs.core$macros.bool_expr.call(null,cljs.core._conj.call(null,cljs.core._conj.call(null,(function (){var x__23719__auto__ = x;
return cljs.core._conj.call(null,(function (){var x__23719__auto____$1 = n;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto____$1);
})(),x__23719__auto__);
})(),"((~{} & (1 << ~{})) != 0)"),new cljs.core.Symbol(null,"js*","js*",-1134233646,null)));
});

cljs.core$macros.bit_test.cljs$lang$macro = true;
cljs.core$macros.bit_shift_left = (function cljs$core$macros$bit_shift_left(_AMPERSAND_form,_AMPERSAND_env,x,n){
return cljs.core._conj.call(null,cljs.core._conj.call(null,(function (){var x__23719__auto__ = x;
return cljs.core._conj.call(null,(function (){var x__23719__auto____$1 = n;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto____$1);
})(),x__23719__auto__);
})(),"(~{} << ~{})"),new cljs.core.Symbol(null,"js*","js*",-1134233646,null));
});

cljs.core$macros.bit_shift_left.cljs$lang$macro = true;
cljs.core$macros.bit_shift_right = (function cljs$core$macros$bit_shift_right(_AMPERSAND_form,_AMPERSAND_env,x,n){
return cljs.core._conj.call(null,cljs.core._conj.call(null,(function (){var x__23719__auto__ = x;
return cljs.core._conj.call(null,(function (){var x__23719__auto____$1 = n;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto____$1);
})(),x__23719__auto__);
})(),"(~{} >> ~{})"),new cljs.core.Symbol(null,"js*","js*",-1134233646,null));
});

cljs.core$macros.bit_shift_right.cljs$lang$macro = true;
cljs.core$macros.bit_shift_right_zero_fill = (function cljs$core$macros$bit_shift_right_zero_fill(_AMPERSAND_form,_AMPERSAND_env,x,n){
return cljs.core._conj.call(null,cljs.core._conj.call(null,(function (){var x__23719__auto__ = x;
return cljs.core._conj.call(null,(function (){var x__23719__auto____$1 = n;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto____$1);
})(),x__23719__auto__);
})(),"(~{} >>> ~{})"),new cljs.core.Symbol(null,"js*","js*",-1134233646,null));
});

cljs.core$macros.bit_shift_right_zero_fill.cljs$lang$macro = true;
cljs.core$macros.unsigned_bit_shift_right = (function cljs$core$macros$unsigned_bit_shift_right(_AMPERSAND_form,_AMPERSAND_env,x,n){
return cljs.core._conj.call(null,cljs.core._conj.call(null,(function (){var x__23719__auto__ = x;
return cljs.core._conj.call(null,(function (){var x__23719__auto____$1 = n;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto____$1);
})(),x__23719__auto__);
})(),"(~{} >>> ~{})"),new cljs.core.Symbol(null,"js*","js*",-1134233646,null));
});

cljs.core$macros.unsigned_bit_shift_right.cljs$lang$macro = true;
cljs.core$macros.bit_set = (function cljs$core$macros$bit_set(_AMPERSAND_form,_AMPERSAND_env,x,n){
return cljs.core._conj.call(null,cljs.core._conj.call(null,(function (){var x__23719__auto__ = x;
return cljs.core._conj.call(null,(function (){var x__23719__auto____$1 = n;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto____$1);
})(),x__23719__auto__);
})(),"(~{} | (1 << ~{}))"),new cljs.core.Symbol(null,"js*","js*",-1134233646,null));
});

cljs.core$macros.bit_set.cljs$lang$macro = true;
cljs.core$macros.mask = (function cljs$core$macros$mask(_AMPERSAND_form,_AMPERSAND_env,hash,shift){
return cljs.core._conj.call(null,cljs.core._conj.call(null,(function (){var x__23719__auto__ = hash;
return cljs.core._conj.call(null,(function (){var x__23719__auto____$1 = shift;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto____$1);
})(),x__23719__auto__);
})(),"((~{} >>> ~{}) & 0x01f)"),new cljs.core.Symbol(null,"js*","js*",-1134233646,null));
});

cljs.core$macros.mask.cljs$lang$macro = true;
cljs.core$macros.bitpos = (function cljs$core$macros$bitpos(_AMPERSAND_form,_AMPERSAND_env,hash,shift){
return cljs.core._conj.call(null,cljs.core._conj.call(null,(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","mask","cljs.core$macros/mask",1575319768,null)),(function (){var x__23719__auto__ = hash;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = shift;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),"(1 << ~{})"),new cljs.core.Symbol(null,"js*","js*",-1134233646,null));
});

cljs.core$macros.bitpos.cljs$lang$macro = true;
cljs.core$macros.caching_hash = (function cljs$core$macros$caching_hash(_AMPERSAND_form,_AMPERSAND_env,coll,hash_fn,hash_key){
if((hash_key instanceof cljs.core.Symbol)){
} else {
throw (new Error([cljs.core.str("Assert failed: "),cljs.core.str("hash-key is substituted twice"),cljs.core.str("\n"),cljs.core.str("(clojure.core/symbol? hash-key)")].join('')));
}

return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","let","cljs.core$macros/let",-160286726,null)),(function (){var x__23719__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"h__28467__auto__","h__28467__auto__",-1966662148,null)),(function (){var x__23719__auto__ = hash_key;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})()))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","if-not","cljs.core$macros/if-not",-1825285737,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","nil?","cljs.core$macros/nil?",83624258,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"h__28467__auto__","h__28467__auto__",-1966662148,null)))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"h__28467__auto__","h__28467__auto__",-1966662148,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","let","cljs.core$macros/let",-160286726,null)),(function (){var x__23719__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"h__28467__auto__","h__28467__auto__",-1966662148,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,(function (){var x__23719__auto__ = hash_fn;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = coll;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})()))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"set!","set!",250714521,null)),(function (){var x__23719__auto__ = hash_key;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"h__28467__auto__","h__28467__auto__",-1966662148,null)))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"h__28467__auto__","h__28467__auto__",-1966662148,null)))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
});

cljs.core$macros.caching_hash.cljs$lang$macro = true;
cljs.core$macros.do_curried = (function cljs$core$macros$do_curried(name,doc,meta,args,body){
var cargs = cljs.core.vec.call(null,cljs.core.butlast.call(null,args));
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","defn","cljs.core$macros/defn",-728332354,null)),(function (){var x__23719__auto__ = name;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = doc;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = meta;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,(function (){var x__23719__auto__ = cargs;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","fn","cljs.core$macros/fn",-187522821,null)),(function (){var x__23719__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"x__28468__auto__","x__28468__auto__",-1482272891,null))))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,(function (){var x__23719__auto__ = name;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),cargs,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"x__28468__auto__","x__28468__auto__",-1482272891,null)))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,(function (){var x__23719__auto__ = args;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),body)));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
});
/**
 * Builds another arity of the fn that returns a fn awaiting the last
 *   param
 */
cljs.core$macros.defcurried = (function cljs$core$macros$defcurried(var_args){
var args__23962__auto__ = [];
var len__23955__auto___28476 = arguments.length;
var i__23956__auto___28477 = (0);
while(true){
if((i__23956__auto___28477 < len__23955__auto___28476)){
args__23962__auto__.push((arguments[i__23956__auto___28477]));

var G__28478 = (i__23956__auto___28477 + (1));
i__23956__auto___28477 = G__28478;
continue;
} else {
}
break;
}

var argseq__23963__auto__ = ((((6) < args__23962__auto__.length))?(new cljs.core.IndexedSeq(args__23962__auto__.slice((6)),(0),null)):null);
return cljs.core$macros.defcurried.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]),(arguments[(4)]),(arguments[(5)]),argseq__23963__auto__);
});

cljs.core$macros.defcurried.cljs$core$IFn$_invoke$arity$variadic = (function (_AMPERSAND_form,_AMPERSAND_env,name,doc,meta,args,body){
return cljs.core$macros.do_curried.call(null,name,doc,meta,args,body);
});

cljs.core$macros.defcurried.cljs$lang$maxFixedArity = (6);

cljs.core$macros.defcurried.cljs$lang$applyTo = (function (seq28469){
var G__28470 = cljs.core.first.call(null,seq28469);
var seq28469__$1 = cljs.core.next.call(null,seq28469);
var G__28471 = cljs.core.first.call(null,seq28469__$1);
var seq28469__$2 = cljs.core.next.call(null,seq28469__$1);
var G__28472 = cljs.core.first.call(null,seq28469__$2);
var seq28469__$3 = cljs.core.next.call(null,seq28469__$2);
var G__28473 = cljs.core.first.call(null,seq28469__$3);
var seq28469__$4 = cljs.core.next.call(null,seq28469__$3);
var G__28474 = cljs.core.first.call(null,seq28469__$4);
var seq28469__$5 = cljs.core.next.call(null,seq28469__$4);
var G__28475 = cljs.core.first.call(null,seq28469__$5);
var seq28469__$6 = cljs.core.next.call(null,seq28469__$5);
return cljs.core$macros.defcurried.cljs$core$IFn$_invoke$arity$variadic(G__28470,G__28471,G__28472,G__28473,G__28474,G__28475,seq28469__$6);
});

cljs.core$macros.defcurried.cljs$lang$macro = true;
cljs.core$macros.do_rfn = (function cljs$core$macros$do_rfn(f1,k,fkv){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","fn","cljs.core$macros/fn",-187522821,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,(function (){var x__23719__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,(function (){var x__23719__auto__ = f1;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = clojure.walk.postwalk.call(null,(function (p1__28479_SHARP_){
if(cljs.core.sequential_QMARK_.call(null,p1__28479_SHARP_)){
return ((cljs.core.vector_QMARK_.call(null,p1__28479_SHARP_))?cljs.core.vec:cljs.core.identity).call(null,cljs.core.remove.call(null,cljs.core.PersistentHashSet.fromArray([k], true),p1__28479_SHARP_));
} else {
return p1__28479_SHARP_;
}
}),fkv);
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = fkv;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
});
/**
 * Builds 3-arity reducing fn given names of wrapped fn and key, and k/v impl.
 */
cljs.core$macros.rfn = (function cljs$core$macros$rfn(_AMPERSAND_form,_AMPERSAND_env,p__28480,fkv){
var vec__28482 = p__28480;
var f1 = cljs.core.nth.call(null,vec__28482,(0),null);
var k = cljs.core.nth.call(null,vec__28482,(1),null);
return cljs.core$macros.do_rfn.call(null,f1,k,fkv);
});

cljs.core$macros.rfn.cljs$lang$macro = true;
cljs.core$macros.protocol_prefix = (function cljs$core$macros$protocol_prefix(psym){
return [cljs.core.str([cljs.core.str(psym)].join('').replace((new RegExp("\\.","g")),"$").replace("/","$")),cljs.core.str("$")].join('');
});
cljs.core$macros.base_type = new cljs.core.PersistentArrayMap(null, 8, [null,"null",new cljs.core.Symbol(null,"object","object",-1179821820,null),"object",new cljs.core.Symbol(null,"string","string",-349010059,null),"string",new cljs.core.Symbol(null,"number","number",-1084057331,null),"number",new cljs.core.Symbol(null,"array","array",-440182315,null),"array",new cljs.core.Symbol(null,"function","function",-486723946,null),"function",new cljs.core.Symbol(null,"boolean","boolean",-278886877,null),"boolean",new cljs.core.Symbol(null,"default","default",-347290801,null),"_"], null);
cljs.core$macros.js_base_type = new cljs.core.PersistentArrayMap(null, 6, [new cljs.core.Symbol("js","Boolean","js/Boolean",1661145260,null),"boolean",new cljs.core.Symbol("js","String","js/String",-2070054036,null),"string",new cljs.core.Symbol("js","Array","js/Array",-423508366,null),"array",new cljs.core.Symbol("js","Object","js/Object",61215323,null),"object",new cljs.core.Symbol("js","Number","js/Number",-508133572,null),"number",new cljs.core.Symbol("js","Function","js/Function",-749892063,null),"function"], null);
/**
 * reify is a macro with the following structure:
 * 
 *  (reify options* specs*)
 * 
 *   Currently there are no options.
 * 
 *   Each spec consists of the protocol name followed by zero
 *   or more method bodies:
 * 
 *   protocol
 *   (methodName [args+] body)*
 * 
 *   Methods should be supplied for all methods of the desired
 *   protocol(s). You can also define overrides for Object methods. Note that
 *   the first parameter must be supplied to correspond to the target object
 *   ('this' in JavaScript parlance). Note also that recur calls
 *   to the method head should *not* pass the target object, it will be supplied
 *   automatically and can not be substituted.
 * 
 *   recur works to method heads The method bodies of reify are lexical
 *   closures, and can refer to the surrounding local scope:
 * 
 *   (str (let [f "foo"]
 *     (reify Object
 *       (toString [this] f))))
 *   == "foo"
 * 
 *   (seq (let [f "foo"]
 *     (reify ISeqable
 *       (-seq [this] (-seq f)))))
 *   == (\f \o \o))
 * 
 *   reify always implements IMeta and IWithMeta and transfers meta
 *   data of the form to the created object.
 * 
 *   (meta ^{:k :v} (reify Object (toString [this] "foo")))
 *   == {:k :v}
 */
cljs.core$macros.reify = (function cljs$core$macros$reify(var_args){
var args__23962__auto__ = [];
var len__23955__auto___28486 = arguments.length;
var i__23956__auto___28487 = (0);
while(true){
if((i__23956__auto___28487 < len__23955__auto___28486)){
args__23962__auto__.push((arguments[i__23956__auto___28487]));

var G__28488 = (i__23956__auto___28487 + (1));
i__23956__auto___28487 = G__28488;
continue;
} else {
}
break;
}

var argseq__23963__auto__ = ((((2) < args__23962__auto__.length))?(new cljs.core.IndexedSeq(args__23962__auto__.slice((2)),(0),null)):null);
return cljs.core$macros.reify.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__23963__auto__);
});

cljs.core$macros.reify.cljs$core$IFn$_invoke$arity$variadic = (function (_AMPERSAND_form,_AMPERSAND_env,impls){
var t = cljs.core.with_meta.call(null,cljs.core.gensym.call(null,[cljs.core.str("t_"),cljs.core.str(clojure.string.replace.call(null,[cljs.core.str(cljs.core.munge.call(null,cljs.analyzer._STAR_cljs_ns_STAR_))].join(''),".","$"))].join('')),new cljs.core.PersistentArrayMap(null, 1, [new cljs.core.Keyword(null,"anonymous","anonymous",447897231),true], null));
var meta_sym = cljs.core.gensym.call(null,"meta");
var this_sym = cljs.core.gensym.call(null,"_");
var locals = cljs.core.keys.call(null,new cljs.core.Keyword(null,"locals","locals",535295783).cljs$core$IFn$_invoke$arity$1(_AMPERSAND_env));
var ns = new cljs.core.Keyword(null,"name","name",1843675177).cljs$core$IFn$_invoke$arity$1(new cljs.core.Keyword(null,"ns","ns",441598760).cljs$core$IFn$_invoke$arity$1(_AMPERSAND_env));
var munge = cljs.compiler.munge;
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"do","do",1686842252,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","when-not","cljs.core$macros/when-not",-764302244,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","exists?","cljs.core$macros/exists?",-1828590389,null)),(function (){var x__23719__auto__ = cljs.core.symbol.call(null,[cljs.core.str(ns)].join(''),[cljs.core.str(t)].join(''));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","deftype","cljs.core$macros/deftype",1799045688,null)),(function (){var x__23719__auto__ = t;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,locals,(function (){var x__23719__auto__ = meta_sym;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})()))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","IWithMeta","cljs.core/IWithMeta",-1981666051,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"-with-meta","-with-meta",-1610713823,null)),(function (){var x__23719__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,(function (){var x__23719__auto__ = this_sym;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = meta_sym;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})()))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"new","new",-444906321,null)),(function (){var x__23719__auto__ = t;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),locals,(function (){var x__23719__auto__ = meta_sym;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","IMeta","cljs.core/IMeta",-1459057517,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"-meta","-meta",494863156,null)),(function (){var x__23719__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,(function (){var x__23719__auto__ = this_sym;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})()))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = meta_sym;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),impls)));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"new","new",-444906321,null)),(function (){var x__23719__auto__ = t;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),locals,(function (){var x__23719__auto__ = cljs.analyzer.elide_reader_meta.call(null,cljs.core.meta.call(null,_AMPERSAND_form));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
});

cljs.core$macros.reify.cljs$lang$maxFixedArity = (2);

cljs.core$macros.reify.cljs$lang$applyTo = (function (seq28483){
var G__28484 = cljs.core.first.call(null,seq28483);
var seq28483__$1 = cljs.core.next.call(null,seq28483);
var G__28485 = cljs.core.first.call(null,seq28483__$1);
var seq28483__$2 = cljs.core.next.call(null,seq28483__$1);
return cljs.core$macros.reify.cljs$core$IFn$_invoke$arity$variadic(G__28484,G__28485,seq28483__$2);
});

cljs.core$macros.reify.cljs$lang$macro = true;
/**
 * Identical to reify but mutates its first argument.
 */
cljs.core$macros.specify_BANG_ = (function cljs$core$macros$specify_BANG_(var_args){
var args__23962__auto__ = [];
var len__23955__auto___28493 = arguments.length;
var i__23956__auto___28494 = (0);
while(true){
if((i__23956__auto___28494 < len__23955__auto___28493)){
args__23962__auto__.push((arguments[i__23956__auto___28494]));

var G__28495 = (i__23956__auto___28494 + (1));
i__23956__auto___28494 = G__28495;
continue;
} else {
}
break;
}

var argseq__23963__auto__ = ((((3) < args__23962__auto__.length))?(new cljs.core.IndexedSeq(args__23962__auto__.slice((3)),(0),null)):null);
return cljs.core$macros.specify_BANG_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),argseq__23963__auto__);
});

cljs.core$macros.specify_BANG_.cljs$core$IFn$_invoke$arity$variadic = (function (_AMPERSAND_form,_AMPERSAND_env,expr,impls){
var x = cljs.core.with_meta.call(null,cljs.core.gensym.call(null,"x"),new cljs.core.PersistentArrayMap(null, 1, [new cljs.core.Keyword(null,"extend","extend",1836484006),new cljs.core.Keyword(null,"instance","instance",-2121349050)], null));
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","let","cljs.core$macros/let",-160286726,null)),(function (){var x__23719__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,(function (){var x__23719__auto__ = x;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = expr;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})()))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","extend-type","cljs.core$macros/extend-type",1713295201,null)),(function (){var x__23719__auto__ = x;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),impls)));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = x;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
});

cljs.core$macros.specify_BANG_.cljs$lang$maxFixedArity = (3);

cljs.core$macros.specify_BANG_.cljs$lang$applyTo = (function (seq28489){
var G__28490 = cljs.core.first.call(null,seq28489);
var seq28489__$1 = cljs.core.next.call(null,seq28489);
var G__28491 = cljs.core.first.call(null,seq28489__$1);
var seq28489__$2 = cljs.core.next.call(null,seq28489__$1);
var G__28492 = cljs.core.first.call(null,seq28489__$2);
var seq28489__$3 = cljs.core.next.call(null,seq28489__$2);
return cljs.core$macros.specify_BANG_.cljs$core$IFn$_invoke$arity$variadic(G__28490,G__28491,G__28492,seq28489__$3);
});

cljs.core$macros.specify_BANG_.cljs$lang$macro = true;
/**
 * Identical to specify! but does not mutate its first argument. The first
 *   argument must be an ICloneable instance.
 */
cljs.core$macros.specify = (function cljs$core$macros$specify(var_args){
var args__23962__auto__ = [];
var len__23955__auto___28500 = arguments.length;
var i__23956__auto___28501 = (0);
while(true){
if((i__23956__auto___28501 < len__23955__auto___28500)){
args__23962__auto__.push((arguments[i__23956__auto___28501]));

var G__28502 = (i__23956__auto___28501 + (1));
i__23956__auto___28501 = G__28502;
continue;
} else {
}
break;
}

var argseq__23963__auto__ = ((((3) < args__23962__auto__.length))?(new cljs.core.IndexedSeq(args__23962__auto__.slice((3)),(0),null)):null);
return cljs.core$macros.specify.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),argseq__23963__auto__);
});

cljs.core$macros.specify.cljs$core$IFn$_invoke$arity$variadic = (function (_AMPERSAND_form,_AMPERSAND_env,expr,impls){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","specify!","cljs.core/specify!",-585401629,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","clone","cljs.core/clone",1417120092,null)),(function (){var x__23719__auto__ = expr;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),impls)));
});

cljs.core$macros.specify.cljs$lang$maxFixedArity = (3);

cljs.core$macros.specify.cljs$lang$applyTo = (function (seq28496){
var G__28497 = cljs.core.first.call(null,seq28496);
var seq28496__$1 = cljs.core.next.call(null,seq28496);
var G__28498 = cljs.core.first.call(null,seq28496__$1);
var seq28496__$2 = cljs.core.next.call(null,seq28496__$1);
var G__28499 = cljs.core.first.call(null,seq28496__$2);
var seq28496__$3 = cljs.core.next.call(null,seq28496__$2);
return cljs.core$macros.specify.cljs$core$IFn$_invoke$arity$variadic(G__28497,G__28498,G__28499,seq28496__$3);
});

cljs.core$macros.specify.cljs$lang$macro = true;
cljs.core$macros.js_this = (function cljs$core$macros$js_this(_AMPERSAND_form,_AMPERSAND_env){
return cljs.core._conj.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,"this"),new cljs.core.Symbol(null,"js*","js*",-1134233646,null));
});

cljs.core$macros.js_this.cljs$lang$macro = true;
/**
 * Defines a scope where JavaScript's implicit "this" is bound to the name provided.
 */
cljs.core$macros.this_as = (function cljs$core$macros$this_as(var_args){
var args__23962__auto__ = [];
var len__23955__auto___28507 = arguments.length;
var i__23956__auto___28508 = (0);
while(true){
if((i__23956__auto___28508 < len__23955__auto___28507)){
args__23962__auto__.push((arguments[i__23956__auto___28508]));

var G__28509 = (i__23956__auto___28508 + (1));
i__23956__auto___28508 = G__28509;
continue;
} else {
}
break;
}

var argseq__23963__auto__ = ((((3) < args__23962__auto__.length))?(new cljs.core.IndexedSeq(args__23962__auto__.slice((3)),(0),null)):null);
return cljs.core$macros.this_as.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),argseq__23963__auto__);
});

cljs.core$macros.this_as.cljs$core$IFn$_invoke$arity$variadic = (function (_AMPERSAND_form,_AMPERSAND_env,name,body){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","let","cljs.core$macros/let",-160286726,null)),(function (){var x__23719__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,(function (){var x__23719__auto__ = name;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","js-this","cljs.core$macros/js-this",353597180,null)))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})()))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),body)));
});

cljs.core$macros.this_as.cljs$lang$maxFixedArity = (3);

cljs.core$macros.this_as.cljs$lang$applyTo = (function (seq28503){
var G__28504 = cljs.core.first.call(null,seq28503);
var seq28503__$1 = cljs.core.next.call(null,seq28503);
var G__28505 = cljs.core.first.call(null,seq28503__$1);
var seq28503__$2 = cljs.core.next.call(null,seq28503__$1);
var G__28506 = cljs.core.first.call(null,seq28503__$2);
var seq28503__$3 = cljs.core.next.call(null,seq28503__$2);
return cljs.core$macros.this_as.cljs$core$IFn$_invoke$arity$variadic(G__28504,G__28505,G__28506,seq28503__$3);
});

cljs.core$macros.this_as.cljs$lang$macro = true;
cljs.core$macros.to_property = (function cljs$core$macros$to_property(sym){
return cljs.core.symbol.call(null,[cljs.core.str("-"),cljs.core.str(sym)].join(''));
});
cljs.core$macros.warn_and_update_protocol = (function cljs$core$macros$warn_and_update_protocol(p,type,env){
if(cljs.core._EQ_.call(null,new cljs.core.Symbol(null,"Object","Object",61210754,null),p)){
return null;
} else {
var temp__4655__auto__ = cljs.analyzer.resolve_existing_var.call(null,cljs.core.dissoc.call(null,env,new cljs.core.Keyword(null,"locals","locals",535295783)),p);
if(cljs.core.truth_(temp__4655__auto__)){
var var$ = temp__4655__auto__;
if(cljs.core.truth_(new cljs.core.Keyword(null,"protocol-symbol","protocol-symbol",1279552198).cljs$core$IFn$_invoke$arity$1(var$))){
} else {
cljs.analyzer.warning.call(null,new cljs.core.Keyword(null,"invalid-protocol-symbol","invalid-protocol-symbol",86246948),env,new cljs.core.PersistentArrayMap(null, 1, [new cljs.core.Keyword(null,"protocol","protocol",652470118),p], null));
}

if(cljs.core.truth_((function (){var and__22873__auto__ = new cljs.core.Keyword(null,"protocol-deprecated","protocol-deprecated",103233497).cljs$core$IFn$_invoke$arity$1(cljs.analyzer._STAR_cljs_warnings_STAR_);
if(cljs.core.truth_(and__22873__auto__)){
var and__22873__auto____$1 = new cljs.core.Keyword(null,"deprecated","deprecated",1498275348).cljs$core$IFn$_invoke$arity$1(var$);
if(cljs.core.truth_(and__22873__auto____$1)){
return cljs.core.not.call(null,new cljs.core.Keyword(null,"deprecation-nowarn","deprecation-nowarn",-1762828044).cljs$core$IFn$_invoke$arity$1(cljs.core.meta.call(null,p)));
} else {
return and__22873__auto____$1;
}
} else {
return and__22873__auto__;
}
})())){
cljs.analyzer.warning.call(null,new cljs.core.Keyword(null,"protocol-deprecated","protocol-deprecated",103233497),env,new cljs.core.PersistentArrayMap(null, 1, [new cljs.core.Keyword(null,"protocol","protocol",652470118),p], null));
} else {
}

if(cljs.core.truth_(new cljs.core.Keyword(null,"protocol-symbol","protocol-symbol",1279552198).cljs$core$IFn$_invoke$arity$1(var$))){
return cljs.core.swap_BANG_.call(null,cljs.env._STAR_compiler_STAR_,cljs.core.update_in,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword("cljs.analyzer","namespaces","cljs.analyzer/namespaces",-260788927)], null),((function (var$,temp__4655__auto__){
return (function (ns){
return cljs.core.update_in.call(null,ns,new cljs.core.PersistentVector(null, 4, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword(null,"ns","ns",441598760).cljs$core$IFn$_invoke$arity$1(var$),new cljs.core.Keyword(null,"defs","defs",1398449717),cljs.core.symbol.call(null,cljs.core.name.call(null,p)),new cljs.core.Keyword(null,"impls","impls",-1314014853)], null),cljs.core.conj,type);
});})(var$,temp__4655__auto__))
);
} else {
return null;
}
} else {
if(cljs.core.truth_(new cljs.core.Keyword(null,"undeclared","undeclared",1446667347).cljs$core$IFn$_invoke$arity$1(cljs.analyzer._STAR_cljs_warnings_STAR_))){
return cljs.analyzer.warning.call(null,new cljs.core.Keyword(null,"undeclared-protocol-symbol","undeclared-protocol-symbol",462882867),env,new cljs.core.PersistentArrayMap(null, 1, [new cljs.core.Keyword(null,"protocol","protocol",652470118),p], null));
} else {
return null;
}
}
}
});
cljs.core$macros.resolve_var = (function cljs$core$macros$resolve_var(env,sym){
var ret = new cljs.core.Keyword(null,"name","name",1843675177).cljs$core$IFn$_invoke$arity$1(cljs.analyzer.resolve_var.call(null,cljs.core.dissoc.call(null,env,new cljs.core.Keyword(null,"locals","locals",535295783)),sym));
if(cljs.core.truth_(ret)){
} else {
throw (new Error([cljs.core.str("Assert failed: "),cljs.core.str([cljs.core.str("Can't resolve: "),cljs.core.str(sym)].join('')),cljs.core.str("\n"),cljs.core.str("ret")].join('')));
}

return ret;
});
cljs.core$macros.__GT_impl_map = (function cljs$core$macros$__GT_impl_map(impls){
var ret = cljs.core.PersistentArrayMap.EMPTY;
var s = impls;
while(true){
if(cljs.core.seq.call(null,s)){
var G__28510 = cljs.core.assoc.call(null,ret,cljs.core.first.call(null,s),cljs.core.take_while.call(null,cljs.core.seq_QMARK_,cljs.core.next.call(null,s)));
var G__28511 = cljs.core.drop_while.call(null,cljs.core.seq_QMARK_,cljs.core.next.call(null,s));
ret = G__28510;
s = G__28511;
continue;
} else {
return ret;
}
break;
}
});
cljs.core$macros.base_assign_impls = (function cljs$core$macros$base_assign_impls(env,resolve,tsym,type,p__28512){
var vec__28516 = p__28512;
var p = cljs.core.nth.call(null,vec__28516,(0),null);
var sigs = cljs.core.nth.call(null,vec__28516,(1),null);
cljs.core$macros.warn_and_update_protocol.call(null,p,tsym,env);

var psym = resolve.call(null,p);
var pfn_prefix = cljs.core.subs.call(null,[cljs.core.str(psym)].join(''),(0),([cljs.core.str(psym)].join('').indexOf("/") + (1)));
return cljs.core.cons.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","aset","cljs.core$macros/aset",-693176374,null)),(function (){var x__23719__auto__ = psym;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = type;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,true)))),cljs.core.map.call(null,((function (psym,pfn_prefix,vec__28516,p,sigs){
return (function (p__28517){
var vec__28518 = p__28517;
var f = cljs.core.nth.call(null,vec__28518,(0),null);
var meths = cljs.core.nthnext.call(null,vec__28518,(1));
var form = vec__28518;
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","aset","cljs.core$macros/aset",-693176374,null)),(function (){var x__23719__auto__ = cljs.core.symbol.call(null,[cljs.core.str(pfn_prefix),cljs.core.str(f)].join(''));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = type;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.with_meta.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","fn","cljs.core$macros/fn",-187522821,null)),meths))),cljs.core.meta.call(null,form));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
});})(psym,pfn_prefix,vec__28516,p,sigs))
,sigs));
});
if(typeof cljs.core$macros.extend_prefix !== 'undefined'){
} else {
cljs.core$macros.extend_prefix = (function (){var method_table__23810__auto__ = cljs.core.atom.call(null,cljs.core.PersistentArrayMap.EMPTY);
var prefer_table__23811__auto__ = cljs.core.atom.call(null,cljs.core.PersistentArrayMap.EMPTY);
var method_cache__23812__auto__ = cljs.core.atom.call(null,cljs.core.PersistentArrayMap.EMPTY);
var cached_hierarchy__23813__auto__ = cljs.core.atom.call(null,cljs.core.PersistentArrayMap.EMPTY);
var hierarchy__23814__auto__ = cljs.core.get.call(null,cljs.core.PersistentArrayMap.EMPTY,new cljs.core.Keyword(null,"hierarchy","hierarchy",-1053470341),cljs.core.get_global_hierarchy.call(null));
return (new cljs.core.MultiFn(cljs.core.symbol.call(null,"cljs.core$macros","extend-prefix"),((function (method_table__23810__auto__,prefer_table__23811__auto__,method_cache__23812__auto__,cached_hierarchy__23813__auto__,hierarchy__23814__auto__){
return (function (tsym,sym){
return new cljs.core.Keyword(null,"extend","extend",1836484006).cljs$core$IFn$_invoke$arity$1(cljs.core.meta.call(null,tsym));
});})(method_table__23810__auto__,prefer_table__23811__auto__,method_cache__23812__auto__,cached_hierarchy__23813__auto__,hierarchy__23814__auto__))
,new cljs.core.Keyword(null,"default","default",-1987822328),hierarchy__23814__auto__,method_table__23810__auto__,prefer_table__23811__auto__,method_cache__23812__auto__,cached_hierarchy__23813__auto__));
})();
}
cljs.core._add_method.call(null,cljs.core$macros.extend_prefix,new cljs.core.Keyword(null,"instance","instance",-2121349050),(function (tsym,sym){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"..","..",-300507420,null)),(function (){var x__23719__auto__ = tsym;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core$macros.to_property.call(null,sym);
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
}));
cljs.core._add_method.call(null,cljs.core$macros.extend_prefix,new cljs.core.Keyword(null,"default","default",-1987822328),(function (tsym,sym){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"..","..",-300507420,null)),(function (){var x__23719__auto__ = tsym;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"-prototype","-prototype",-450831903,null)),(function (){var x__23719__auto__ = cljs.core$macros.to_property.call(null,sym);
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
}));
cljs.core$macros.adapt_obj_params = (function cljs$core$macros$adapt_obj_params(type,p__28519){
var vec__28522 = p__28519;
var vec__28523 = cljs.core.nth.call(null,vec__28522,(0),null);
var this$ = cljs.core.nth.call(null,vec__28523,(0),null);
var args = cljs.core.nthnext.call(null,vec__28523,(1));
var sig = vec__28523;
var body = cljs.core.nthnext.call(null,vec__28522,(1));
var x__23719__auto__ = cljs.core.vec.call(null,args);
return cljs.core._conj.call(null,(function (){var x__23719__auto____$1 = cljs.core.list_STAR_.call(null,new cljs.core.Symbol(null,"this-as","this-as",-848995740,null),cljs.core.vary_meta.call(null,this$,cljs.core.assoc,new cljs.core.Keyword(null,"tag","tag",-1290361223),type),body);
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto____$1);
})(),x__23719__auto__);
});
cljs.core$macros.adapt_ifn_params = (function cljs$core$macros$adapt_ifn_params(type,p__28524){
var vec__28527 = p__28524;
var vec__28528 = cljs.core.nth.call(null,vec__28527,(0),null);
var this$ = cljs.core.nth.call(null,vec__28528,(0),null);
var args = cljs.core.nthnext.call(null,vec__28528,(1));
var sig = vec__28528;
var body = cljs.core.nthnext.call(null,vec__28527,(1));
var self_sym = cljs.core.with_meta.call(null,new cljs.core.Symbol(null,"self__","self__",-153190816,null),new cljs.core.PersistentArrayMap(null, 1, [new cljs.core.Keyword(null,"tag","tag",-1290361223),type], null));
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,(function (){var x__23719__auto__ = cljs.core.vec.call(null,cljs.core.cons.call(null,self_sym,args));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","this-as","cljs.core$macros/this-as",-799075148,null)),(function (){var x__23719__auto__ = self_sym;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","let","cljs.core$macros/let",-160286726,null)),(function (){var x__23719__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,(function (){var x__23719__auto__ = this$;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = self_sym;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})()))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),body)));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
});
cljs.core$macros.adapt_ifn_invoke_params = (function cljs$core$macros$adapt_ifn_invoke_params(type,p__28529){
var vec__28532 = p__28529;
var vec__28533 = cljs.core.nth.call(null,vec__28532,(0),null);
var this$ = cljs.core.nth.call(null,vec__28533,(0),null);
var args = cljs.core.nthnext.call(null,vec__28533,(1));
var sig = vec__28533;
var body = cljs.core.nthnext.call(null,vec__28532,(1));
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,(function (){var x__23719__auto__ = cljs.core.vec.call(null,args);
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","this-as","cljs.core$macros/this-as",-799075148,null)),(function (){var x__23719__auto__ = cljs.core.vary_meta.call(null,this$,cljs.core.assoc,new cljs.core.Keyword(null,"tag","tag",-1290361223),type);
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),body)));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
});
cljs.core$macros.adapt_proto_params = (function cljs$core$macros$adapt_proto_params(type,p__28534){
var vec__28537 = p__28534;
var vec__28538 = cljs.core.nth.call(null,vec__28537,(0),null);
var this$ = cljs.core.nth.call(null,vec__28538,(0),null);
var args = cljs.core.nthnext.call(null,vec__28538,(1));
var sig = vec__28538;
var body = cljs.core.nthnext.call(null,vec__28537,(1));
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,(function (){var x__23719__auto__ = cljs.core.vec.call(null,cljs.core.cons.call(null,cljs.core.vary_meta.call(null,this$,cljs.core.assoc,new cljs.core.Keyword(null,"tag","tag",-1290361223),type),args));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","this-as","cljs.core$macros/this-as",-799075148,null)),(function (){var x__23719__auto__ = this$;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),body)));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
});
cljs.core$macros.add_obj_methods = (function cljs$core$macros$add_obj_methods(type,type_sym,sigs){
return cljs.core.map.call(null,(function (p__28543){
var vec__28544 = p__28543;
var f = cljs.core.nth.call(null,vec__28544,(0),null);
var meths = cljs.core.nthnext.call(null,vec__28544,(1));
var form = vec__28544;
var vec__28545 = ((cljs.core.vector_QMARK_.call(null,cljs.core.first.call(null,meths)))?new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [f,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.rest.call(null,form)], null)], null):new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [f,meths], null));
var f__$1 = cljs.core.nth.call(null,vec__28545,(0),null);
var meths__$1 = cljs.core.nth.call(null,vec__28545,(1),null);
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"set!","set!",250714521,null)),(function (){var x__23719__auto__ = cljs.core$macros.extend_prefix.call(null,type_sym,f__$1);
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.with_meta.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","fn","cljs.core$macros/fn",-187522821,null)),cljs.core.map.call(null,((function (vec__28545,f__$1,meths__$1,vec__28544,f,meths,form){
return (function (p1__28539_SHARP_){
return cljs.core$macros.adapt_obj_params.call(null,type,p1__28539_SHARP_);
});})(vec__28545,f__$1,meths__$1,vec__28544,f,meths,form))
,meths__$1)))),cljs.core.meta.call(null,form));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
}),sigs);
});
cljs.core$macros.ifn_invoke_methods = (function cljs$core$macros$ifn_invoke_methods(type,type_sym,p__28547){
var vec__28549 = p__28547;
var f = cljs.core.nth.call(null,vec__28549,(0),null);
var meths = cljs.core.nthnext.call(null,vec__28549,(1));
var form = vec__28549;
return cljs.core.map.call(null,((function (vec__28549,f,meths,form){
return (function (meth){
var arity = cljs.core.count.call(null,cljs.core.first.call(null,meth));
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"set!","set!",250714521,null)),(function (){var x__23719__auto__ = cljs.core$macros.extend_prefix.call(null,type_sym,cljs.core.symbol.call(null,[cljs.core.str("cljs$core$IFn$_invoke$arity$"),cljs.core.str(arity)].join('')));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.with_meta.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","fn","cljs.core$macros/fn",-187522821,null)),(function (){var x__23719__auto__ = meth;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})()))),cljs.core.meta.call(null,form));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
});})(vec__28549,f,meths,form))
,cljs.core.map.call(null,((function (vec__28549,f,meths,form){
return (function (p1__28546_SHARP_){
return cljs.core$macros.adapt_ifn_invoke_params.call(null,type,p1__28546_SHARP_);
});})(vec__28549,f,meths,form))
,meths));
});
cljs.core$macros.add_ifn_methods = (function cljs$core$macros$add_ifn_methods(type,type_sym,p__28551){
var vec__28553 = p__28551;
var f = cljs.core.nth.call(null,vec__28553,(0),null);
var meths = cljs.core.nthnext.call(null,vec__28553,(1));
var form = vec__28553;
var meths__$1 = cljs.core.map.call(null,((function (vec__28553,f,meths,form){
return (function (p1__28550_SHARP_){
return cljs.core$macros.adapt_ifn_params.call(null,type,p1__28550_SHARP_);
});})(vec__28553,f,meths,form))
,meths);
var this_sym = cljs.core.with_meta.call(null,new cljs.core.Symbol(null,"self__","self__",-153190816,null),new cljs.core.PersistentArrayMap(null, 1, [new cljs.core.Keyword(null,"tag","tag",-1290361223),type], null));
var argsym = cljs.core.gensym.call(null,"args");
return cljs.core.concat.call(null,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"set!","set!",250714521,null)),(function (){var x__23719__auto__ = cljs.core$macros.extend_prefix.call(null,type_sym,new cljs.core.Symbol(null,"call","call",1120531661,null));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.with_meta.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","fn","cljs.core$macros/fn",-187522821,null)),meths__$1))),cljs.core.meta.call(null,form));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})()))),cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"set!","set!",250714521,null)),(function (){var x__23719__auto__ = cljs.core$macros.extend_prefix.call(null,type_sym,new cljs.core.Symbol(null,"apply","apply",-1334050276,null));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.with_meta.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","fn","cljs.core$macros/fn",-187522821,null)),(function (){var x__23719__auto__ = new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [this_sym,argsym], null);
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","this-as","cljs.core$macros/this-as",-799075148,null)),(function (){var x__23719__auto__ = this_sym;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,".apply",".apply",-1176201338,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,".-call",".-call",1760541695,null)),(function (){var x__23719__auto__ = this_sym;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = this_sym;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,".concat",".concat",1180408684,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","array","cljs.core$macros/array",49650437,null)),(function (){var x__23719__auto__ = this_sym;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","aclone","cljs.core/aclone",-758078968,null)),(function (){var x__23719__auto__ = argsym;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})()))),cljs.core.meta.call(null,form));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())))], null),cljs.core$macros.ifn_invoke_methods.call(null,type,type_sym,form));
});
cljs.core$macros.add_proto_methods_STAR_ = (function cljs$core$macros$add_proto_methods_STAR_(pprefix,type,type_sym,p__28554){
var vec__28558 = p__28554;
var f = cljs.core.nth.call(null,vec__28558,(0),null);
var meths = cljs.core.nthnext.call(null,vec__28558,(1));
var form = vec__28558;
var pf = [cljs.core.str(pprefix),cljs.core.str(cljs.core.name.call(null,f))].join('');
if(cljs.core.vector_QMARK_.call(null,cljs.core.first.call(null,meths))){
var meth = meths;
return new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"set!","set!",250714521,null)),(function (){var x__23719__auto__ = cljs.core$macros.extend_prefix.call(null,type_sym,[cljs.core.str(pf),cljs.core.str("$arity$"),cljs.core.str(cljs.core.count.call(null,cljs.core.first.call(null,meth)))].join(''));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.with_meta.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","fn","cljs.core$macros/fn",-187522821,null)),cljs.core$macros.adapt_proto_params.call(null,type,meth)))),cljs.core.meta.call(null,form));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())))], null);
} else {
return cljs.core.map.call(null,((function (pf,vec__28558,f,meths,form){
return (function (p__28559){
var vec__28560 = p__28559;
var sig = cljs.core.nth.call(null,vec__28560,(0),null);
var body = cljs.core.nthnext.call(null,vec__28560,(1));
var meth = vec__28560;
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"set!","set!",250714521,null)),(function (){var x__23719__auto__ = cljs.core$macros.extend_prefix.call(null,type_sym,[cljs.core.str(pf),cljs.core.str("$arity$"),cljs.core.str(cljs.core.count.call(null,sig))].join(''));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.with_meta.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","fn","cljs.core$macros/fn",-187522821,null)),(function (){var x__23719__auto__ = cljs.core$macros.adapt_proto_params.call(null,type,meth);
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})()))),cljs.core.meta.call(null,form));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
});})(pf,vec__28558,f,meths,form))
,meths);
}
});
cljs.core$macros.proto_assign_impls = (function cljs$core$macros$proto_assign_impls(env,resolve,type_sym,type,p__28561){
var vec__28563 = p__28561;
var p = cljs.core.nth.call(null,vec__28563,(0),null);
var sigs = cljs.core.nth.call(null,vec__28563,(1),null);
cljs.core$macros.warn_and_update_protocol.call(null,p,type,env);

var psym = resolve.call(null,p);
var pprefix = cljs.core$macros.protocol_prefix.call(null,psym);
var skip_flag = cljs.core.set.call(null,new cljs.core.Keyword(null,"skip-protocol-flag","skip-protocol-flag",-1426798630).cljs$core$IFn$_invoke$arity$1(cljs.core.meta.call(null,type_sym)));
if(cljs.core._EQ_.call(null,p,new cljs.core.Symbol(null,"Object","Object",61210754,null))){
return cljs.core$macros.add_obj_methods.call(null,type,type_sym,sigs);
} else {
return cljs.core.concat.call(null,(cljs.core.truth_(skip_flag.call(null,psym))?null:new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"set!","set!",250714521,null)),(function (){var x__23719__auto__ = cljs.core$macros.extend_prefix.call(null,type_sym,pprefix);
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,true))))], null)),cljs.core.mapcat.call(null,((function (psym,pprefix,skip_flag,vec__28563,p,sigs){
return (function (sig){
if(cljs.core._EQ_.call(null,psym,new cljs.core.Symbol("cljs.core","IFn","cljs.core/IFn",-920223129,null))){
return cljs.core$macros.add_ifn_methods.call(null,type,type_sym,sig);
} else {
return cljs.core$macros.add_proto_methods_STAR_.call(null,pprefix,type,type_sym,sig);
}
});})(psym,pprefix,skip_flag,vec__28563,p,sigs))
,sigs));
}
});
cljs.core$macros.validate_impl_sigs = (function cljs$core$macros$validate_impl_sigs(env,p,method){
if(cljs.core._EQ_.call(null,p,new cljs.core.Symbol(null,"Object","Object",61210754,null))){
return null;
} else {
var var$ = cljs.analyzer.resolve_var.call(null,cljs.core.dissoc.call(null,env,new cljs.core.Keyword(null,"locals","locals",535295783)),p);
var minfo = new cljs.core.Keyword(null,"methods","methods",453930866).cljs$core$IFn$_invoke$arity$1(new cljs.core.Keyword(null,"protocol-info","protocol-info",1471745843).cljs$core$IFn$_invoke$arity$1(var$));
var method_name = cljs.core.first.call(null,method);
var __GT_name = cljs.core.comp.call(null,cljs.core.symbol,cljs.core.name);
var vec__28565 = ((cljs.core.vector_QMARK_.call(null,cljs.core.second.call(null,method)))?new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [__GT_name.call(null,method_name),new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.second.call(null,method)], null)], null):new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [__GT_name.call(null,method_name),cljs.core.map.call(null,cljs.core.first,cljs.core.rest.call(null,method))], null));
var fname = cljs.core.nth.call(null,vec__28565,(0),null);
var sigs = cljs.core.nth.call(null,vec__28565,(1),null);
var decmeths = cljs.core.get.call(null,minfo,fname,new cljs.core.Keyword("cljs.core$macros","not-found","cljs.core$macros/not-found",-1226326556));
if(cljs.core._EQ_.call(null,decmeths,new cljs.core.Keyword("cljs.core$macros","not-found","cljs.core$macros/not-found",-1226326556))){
cljs.analyzer.warning.call(null,new cljs.core.Keyword(null,"protocol-invalid-method","protocol-invalid-method",522647516),env,new cljs.core.PersistentArrayMap(null, 3, [new cljs.core.Keyword(null,"protocol","protocol",652470118),p,new cljs.core.Keyword(null,"fname","fname",1500291491),fname,new cljs.core.Keyword(null,"no-such-method","no-such-method",1087422840),true], null));
} else {
}

if(cljs.core.truth_(cljs.core.namespace.call(null,method_name))){
var method_var_28566 = cljs.analyzer.resolve_var.call(null,cljs.core.dissoc.call(null,env,new cljs.core.Keyword(null,"locals","locals",535295783)),method_name,cljs.analyzer.confirm_var_exist_warning);
if(cljs.core._EQ_.call(null,new cljs.core.Keyword(null,"name","name",1843675177).cljs$core$IFn$_invoke$arity$1(var$),new cljs.core.Keyword(null,"protocol","protocol",652470118).cljs$core$IFn$_invoke$arity$1(method_var_28566))){
} else {
cljs.analyzer.warning.call(null,new cljs.core.Keyword(null,"protocol-invalid-method","protocol-invalid-method",522647516),env,new cljs.core.PersistentArrayMap(null, 3, [new cljs.core.Keyword(null,"protocol","protocol",652470118),p,new cljs.core.Keyword(null,"fname","fname",1500291491),method_name,new cljs.core.Keyword(null,"no-such-method","no-such-method",1087422840),true], null));
}
} else {
}

var sigs__$1 = sigs;
var seen = cljs.core.PersistentHashSet.EMPTY;
while(true){
if(cljs.core.seq.call(null,sigs__$1)){
var sig = cljs.core.first.call(null,sigs__$1);
var c = cljs.core.count.call(null,sig);
if(cljs.core.contains_QMARK_.call(null,seen,c)){
cljs.analyzer.warning.call(null,new cljs.core.Keyword(null,"protocol-duped-method","protocol-duped-method",15128166),env,new cljs.core.PersistentArrayMap(null, 2, [new cljs.core.Keyword(null,"protocol","protocol",652470118),p,new cljs.core.Keyword(null,"fname","fname",1500291491),fname], null));
} else {
}

if((cljs.core.not_EQ_.call(null,decmeths,new cljs.core.Keyword("cljs.core$macros","not-found","cljs.core$macros/not-found",-1226326556))) && (cljs.core.not.call(null,cljs.core.some.call(null,cljs.core.PersistentHashSet.fromArray([c], true),cljs.core.map.call(null,cljs.core.count,decmeths))))){
cljs.analyzer.warning.call(null,new cljs.core.Keyword(null,"protocol-invalid-method","protocol-invalid-method",522647516),env,new cljs.core.PersistentArrayMap(null, 3, [new cljs.core.Keyword(null,"protocol","protocol",652470118),p,new cljs.core.Keyword(null,"fname","fname",1500291491),fname,new cljs.core.Keyword(null,"invalid-arity","invalid-arity",1335461949),c], null));
} else {
}

var G__28567 = cljs.core.next.call(null,sigs__$1);
var G__28568 = cljs.core.conj.call(null,seen,c);
sigs__$1 = G__28567;
seen = G__28568;
continue;
} else {
return null;
}
break;
}
}
});
cljs.core$macros.validate_impls = (function cljs$core$macros$validate_impls(env,impls){
var protos = cljs.core.PersistentHashSet.EMPTY;
var impls__$1 = impls;
while(true){
if(cljs.core.seq.call(null,impls__$1)){
var proto = cljs.core.first.call(null,impls__$1);
var methods$ = cljs.core.take_while.call(null,cljs.core.seq_QMARK_,cljs.core.next.call(null,impls__$1));
var impls__$2 = cljs.core.drop_while.call(null,cljs.core.seq_QMARK_,cljs.core.next.call(null,impls__$1));
if(cljs.core.contains_QMARK_.call(null,protos,proto)){
cljs.analyzer.warning.call(null,new cljs.core.Keyword(null,"protocol-multiple-impls","protocol-multiple-impls",794179260),env,new cljs.core.PersistentArrayMap(null, 1, [new cljs.core.Keyword(null,"protocol","protocol",652470118),proto], null));
} else {
}

var seen_28571 = cljs.core.PersistentHashSet.EMPTY;
var methods_28572__$1 = methods$;
while(true){
if(cljs.core.seq.call(null,methods_28572__$1)){
var vec__28570_28573 = cljs.core.first.call(null,methods_28572__$1);
var fname_28574 = cljs.core.nth.call(null,vec__28570_28573,(0),null);
var method_28575 = vec__28570_28573;
if(cljs.core.contains_QMARK_.call(null,seen_28571,fname_28574)){
cljs.analyzer.warning.call(null,new cljs.core.Keyword(null,"extend-type-invalid-method-shape","extend-type-invalid-method-shape",1424103549),env,new cljs.core.PersistentArrayMap(null, 2, [new cljs.core.Keyword(null,"protocol","protocol",652470118),proto,new cljs.core.Keyword(null,"method","method",55703592),fname_28574], null));
} else {
}

cljs.core$macros.validate_impl_sigs.call(null,env,proto,method_28575);

var G__28576 = cljs.core.conj.call(null,seen_28571,fname_28574);
var G__28577 = cljs.core.next.call(null,methods_28572__$1);
seen_28571 = G__28576;
methods_28572__$1 = G__28577;
continue;
} else {
}
break;
}

var G__28578 = cljs.core.conj.call(null,protos,proto);
var G__28579 = impls__$2;
protos = G__28578;
impls__$1 = G__28579;
continue;
} else {
return null;
}
break;
}
});
cljs.core$macros.type_hint_first_arg = (function cljs$core$macros$type_hint_first_arg(type_sym,argv){
return cljs.core.assoc.call(null,argv,(0),cljs.core.vary_meta.call(null,argv.call(null,(0)),cljs.core.assoc,new cljs.core.Keyword(null,"tag","tag",-1290361223),type_sym));
});
cljs.core$macros.type_hint_single_arity_sig = (function cljs$core$macros$type_hint_single_arity_sig(type_sym,sig){
return cljs.core.list_STAR_.call(null,cljs.core.first.call(null,sig),cljs.core$macros.type_hint_first_arg.call(null,type_sym,cljs.core.second.call(null,sig)),cljs.core.nnext.call(null,sig));
});
cljs.core$macros.type_hint_multi_arity_sig = (function cljs$core$macros$type_hint_multi_arity_sig(type_sym,sig){
return cljs.core.list_STAR_.call(null,cljs.core$macros.type_hint_first_arg.call(null,type_sym,cljs.core.first.call(null,sig)),cljs.core.next.call(null,sig));
});
cljs.core$macros.type_hint_multi_arity_sigs = (function cljs$core$macros$type_hint_multi_arity_sigs(type_sym,sigs){
return cljs.core.list_STAR_.call(null,cljs.core.first.call(null,sigs),cljs.core.map.call(null,cljs.core.partial.call(null,cljs.core$macros.type_hint_multi_arity_sig,type_sym),cljs.core.rest.call(null,sigs)));
});
cljs.core$macros.type_hint_sigs = (function cljs$core$macros$type_hint_sigs(type_sym,sig){
if(cljs.core.vector_QMARK_.call(null,cljs.core.second.call(null,sig))){
return cljs.core$macros.type_hint_single_arity_sig.call(null,type_sym,sig);
} else {
return cljs.core$macros.type_hint_multi_arity_sigs.call(null,type_sym,sig);
}
});
cljs.core$macros.type_hint_impl_map = (function cljs$core$macros$type_hint_impl_map(type_sym,impl_map){
return cljs.core.reduce_kv.call(null,(function (m,proto,sigs){
return cljs.core.assoc.call(null,m,proto,cljs.core.map.call(null,cljs.core.partial.call(null,cljs.core$macros.type_hint_sigs,type_sym),sigs));
}),cljs.core.PersistentArrayMap.EMPTY,impl_map);
});
/**
 * Extend a type to a series of protocols. Useful when you are
 *   supplying the definitions explicitly inline. Propagates the
 *   type as a type hint on the first argument of all fns.
 * 
 *   type-sym may be
 * 
 * * default, meaning the definitions will apply for any value,
 *   unless an extend-type exists for one of the more specific
 *   cases below.
 * * nil, meaning the definitions will apply for the nil value.
 * * any of object, boolean, number, string, array, or function,
 *   indicating the definitions will apply for values of the
 *   associated base JavaScript types. Note that, for example,
 *   string should be used instead of js/String.
 * * a JavaScript type not covered by the previous list, such
 *   as js/RegExp.
 * * a type defined by deftype or defrecord.
 * 
 *   (extend-type MyType
 *  ICounted
 *  (-count [c] ...)
 *  Foo
 *  (bar [x y] ...)
 *  (baz ([x] ...) ([x y & zs] ...))
 */
cljs.core$macros.extend_type = (function cljs$core$macros$extend_type(var_args){
var args__23962__auto__ = [];
var len__23955__auto___28586 = arguments.length;
var i__23956__auto___28587 = (0);
while(true){
if((i__23956__auto___28587 < len__23955__auto___28586)){
args__23962__auto__.push((arguments[i__23956__auto___28587]));

var G__28588 = (i__23956__auto___28587 + (1));
i__23956__auto___28587 = G__28588;
continue;
} else {
}
break;
}

var argseq__23963__auto__ = ((((3) < args__23962__auto__.length))?(new cljs.core.IndexedSeq(args__23962__auto__.slice((3)),(0),null)):null);
return cljs.core$macros.extend_type.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),argseq__23963__auto__);
});

cljs.core$macros.extend_type.cljs$core$IFn$_invoke$arity$variadic = (function (_AMPERSAND_form,_AMPERSAND_env,type_sym,impls){
var env = _AMPERSAND_env;
var _ = cljs.core$macros.validate_impls.call(null,env,impls);
var resolve = cljs.core.partial.call(null,cljs.core$macros.resolve_var,env);
var impl_map = cljs.core$macros.__GT_impl_map.call(null,impls);
var impl_map__$1 = (cljs.core.truth_(new cljs.core.PersistentHashSet(null, new cljs.core.PersistentArrayMap(null, 2, [new cljs.core.Symbol(null,"boolean","boolean",-278886877,null),null,new cljs.core.Symbol(null,"number","number",-1084057331,null),null], null), null).call(null,type_sym))?cljs.core$macros.type_hint_impl_map.call(null,type_sym,impl_map):impl_map);
var vec__28585 = (function (){var temp__4655__auto__ = cljs.core$macros.base_type.call(null,type_sym);
if(cljs.core.truth_(temp__4655__auto__)){
var type = temp__4655__auto__;
return new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [type,cljs.core$macros.base_assign_impls], null);
} else {
return new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [resolve.call(null,type_sym),cljs.core$macros.proto_assign_impls], null);
}
})();
var type = cljs.core.nth.call(null,vec__28585,(0),null);
var assign_impls = cljs.core.nth.call(null,vec__28585,(1),null);
if(cljs.core.truth_((function (){var and__22873__auto__ = new cljs.core.Keyword(null,"extending-base-js-type","extending-base-js-type",432787264).cljs$core$IFn$_invoke$arity$1(cljs.analyzer._STAR_cljs_warnings_STAR_);
if(cljs.core.truth_(and__22873__auto__)){
return cljs.core$macros.js_base_type.call(null,type_sym);
} else {
return and__22873__auto__;
}
})())){
cljs.analyzer.warning.call(null,new cljs.core.Keyword(null,"extending-base-js-type","extending-base-js-type",432787264),env,new cljs.core.PersistentArrayMap(null, 2, [new cljs.core.Keyword(null,"current-symbol","current-symbol",-932381075),type_sym,new cljs.core.Keyword(null,"suggested-symbol","suggested-symbol",-1329631875),cljs.core$macros.js_base_type.call(null,type_sym)], null));
} else {
}

return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"do","do",1686842252,null)),cljs.core.mapcat.call(null,((function (env,_,resolve,impl_map,impl_map__$1,vec__28585,type,assign_impls){
return (function (p1__28580_SHARP_){
return assign_impls.call(null,env,resolve,type_sym,type,p1__28580_SHARP_);
});})(env,_,resolve,impl_map,impl_map__$1,vec__28585,type,assign_impls))
,impl_map__$1))));
});

cljs.core$macros.extend_type.cljs$lang$maxFixedArity = (3);

cljs.core$macros.extend_type.cljs$lang$applyTo = (function (seq28581){
var G__28582 = cljs.core.first.call(null,seq28581);
var seq28581__$1 = cljs.core.next.call(null,seq28581);
var G__28583 = cljs.core.first.call(null,seq28581__$1);
var seq28581__$2 = cljs.core.next.call(null,seq28581__$1);
var G__28584 = cljs.core.first.call(null,seq28581__$2);
var seq28581__$3 = cljs.core.next.call(null,seq28581__$2);
return cljs.core$macros.extend_type.cljs$core$IFn$_invoke$arity$variadic(G__28582,G__28583,G__28584,seq28581__$3);
});

cljs.core$macros.extend_type.cljs$lang$macro = true;
cljs.core$macros.prepare_protocol_masks = (function cljs$core$macros$prepare_protocol_masks(env,impls){
var resolve = cljs.core.partial.call(null,cljs.core$macros.resolve_var,env);
var impl_map = cljs.core$macros.__GT_impl_map.call(null,impls);
var fpp_pbs = cljs.core.seq.call(null,cljs.core.keep.call(null,cljs.core$macros.fast_path_protocols,cljs.core.map.call(null,resolve,cljs.core.keys.call(null,impl_map))));
if(fpp_pbs){
var fpps = cljs.core.into.call(null,cljs.core.PersistentHashSet.EMPTY,cljs.core.filter.call(null,cljs.core.partial.call(null,cljs.core.contains_QMARK_,cljs.core$macros.fast_path_protocols),cljs.core.map.call(null,resolve,cljs.core.keys.call(null,impl_map))));
var parts = (function (){var parts = cljs.core.group_by.call(null,cljs.core.first,fpp_pbs);
var parts__$1 = cljs.core.into.call(null,cljs.core.PersistentArrayMap.EMPTY,cljs.core.map.call(null,cljs.core.juxt.call(null,cljs.core.key,cljs.core.comp.call(null,cljs.core.partial.call(null,cljs.core.map,cljs.core.peek),cljs.core.val)),parts));
return cljs.core.into.call(null,cljs.core.PersistentArrayMap.EMPTY,cljs.core.map.call(null,cljs.core.juxt.call(null,cljs.core.key,cljs.core.comp.call(null,cljs.core.partial.call(null,cljs.core.reduce,cljs.core.bit_or),cljs.core.val)),parts__$1));
})();
return new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [fpps,cljs.core.reduce.call(null,((function (fpps,parts,resolve,impl_map,fpp_pbs){
return (function (ps,p){
return cljs.core.update_in.call(null,ps,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [p], null),cljs.core.fnil.call(null,cljs.core.identity,(0)));
});})(fpps,parts,resolve,impl_map,fpp_pbs))
,parts,cljs.core.range.call(null,cljs.core$macros.fast_path_protocol_partitions_count))], null);
} else {
return null;
}
});
cljs.core$macros.annotate_specs = (function cljs$core$macros$annotate_specs(annots,v,p__28590){
var vec__28592 = p__28590;
var f = cljs.core.nth.call(null,vec__28592,(0),null);
var sigs = cljs.core.nth.call(null,vec__28592,(1),null);
return cljs.core.conj.call(null,v,cljs.core.vary_meta.call(null,cljs.core.cons.call(null,f,cljs.core.map.call(null,((function (vec__28592,f,sigs){
return (function (p1__28589_SHARP_){
return cljs.core.cons.call(null,cljs.core.second.call(null,p1__28589_SHARP_),cljs.core.nnext.call(null,p1__28589_SHARP_));
});})(vec__28592,f,sigs))
,sigs)),cljs.core.merge,annots));
});
cljs.core$macros.dt__GT_et = (function cljs$core$macros$dt__GT_et(var_args){
var args28593 = [];
var len__23955__auto___28596 = arguments.length;
var i__23956__auto___28597 = (0);
while(true){
if((i__23956__auto___28597 < len__23955__auto___28596)){
args28593.push((arguments[i__23956__auto___28597]));

var G__28598 = (i__23956__auto___28597 + (1));
i__23956__auto___28597 = G__28598;
continue;
} else {
}
break;
}

var G__28595 = args28593.length;
switch (G__28595) {
case 3:
return cljs.core$macros.dt__GT_et.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
case 4:
return cljs.core$macros.dt__GT_et.cljs$core$IFn$_invoke$arity$4((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]));

break;
default:
throw (new Error([cljs.core.str("Invalid arity: "),cljs.core.str(args28593.length)].join('')));

}
});

cljs.core$macros.dt__GT_et.cljs$core$IFn$_invoke$arity$3 = (function (type,specs,fields){
return cljs.core$macros.dt__GT_et.call(null,type,specs,fields,false);
});

cljs.core$macros.dt__GT_et.cljs$core$IFn$_invoke$arity$4 = (function (type,specs,fields,inline){
var annots = new cljs.core.PersistentArrayMap(null, 3, [new cljs.core.Keyword("cljs.analyzer","type","cljs.analyzer/type",478749742),type,new cljs.core.Keyword("cljs.analyzer","protocol-impl","cljs.analyzer/protocol-impl",-1523935409),true,new cljs.core.Keyword("cljs.analyzer","protocol-inline","cljs.analyzer/protocol-inline",-1611519026),inline], null);
var ret = cljs.core.PersistentVector.EMPTY;
var specs__$1 = specs;
while(true){
if(cljs.core.seq.call(null,specs__$1)){
var p = cljs.core.first.call(null,specs__$1);
var ret__$1 = cljs.core.into.call(null,cljs.core.conj.call(null,ret,p),cljs.core.reduce.call(null,cljs.core.partial.call(null,cljs.core$macros.annotate_specs,annots),cljs.core.PersistentVector.EMPTY,cljs.core.group_by.call(null,cljs.core.first,cljs.core.take_while.call(null,cljs.core.seq_QMARK_,cljs.core.next.call(null,specs__$1)))));
var specs__$2 = cljs.core.drop_while.call(null,cljs.core.seq_QMARK_,cljs.core.next.call(null,specs__$1));
var G__28600 = ret__$1;
var G__28601 = specs__$2;
ret = G__28600;
specs__$1 = G__28601;
continue;
} else {
return ret;
}
break;
}
});

cljs.core$macros.dt__GT_et.cljs$lang$maxFixedArity = 4;
cljs.core$macros.collect_protocols = (function cljs$core$macros$collect_protocols(impls,env){
return cljs.core.into.call(null,cljs.core.PersistentHashSet.EMPTY,cljs.core.map.call(null,(function (p1__28602_SHARP_){
return new cljs.core.Keyword(null,"name","name",1843675177).cljs$core$IFn$_invoke$arity$1(cljs.analyzer.resolve_var.call(null,cljs.core.dissoc.call(null,env,new cljs.core.Keyword(null,"locals","locals",535295783)),p1__28602_SHARP_));
}),cljs.core.filter.call(null,cljs.core.symbol_QMARK_,impls)));
});
cljs.core$macros.build_positional_factory = (function cljs$core$macros$build_positional_factory(rsym,rname,fields){
var fn_name = cljs.core.with_meta.call(null,cljs.core.symbol.call(null,[cljs.core.str(new cljs.core.Symbol(null,"->","->",-2139605430,null)),cljs.core.str(rsym)].join('')),cljs.core.assoc.call(null,cljs.core.meta.call(null,rsym),new cljs.core.Keyword(null,"factory","factory",63933746),new cljs.core.Keyword(null,"positional","positional",-203580463)));
var field_values = (cljs.core.truth_(new cljs.core.Keyword(null,"internal-ctor","internal-ctor",937392560).cljs$core$IFn$_invoke$arity$1(cljs.core.meta.call(null,rsym)))?cljs.core.conj.call(null,fields,null,null,null):fields);
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","defn","cljs.core$macros/defn",-728332354,null)),(function (){var x__23719__auto__ = fn_name;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,fields))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"new","new",-444906321,null)),(function (){var x__23719__auto__ = rname;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),field_values)));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
});
cljs.core$macros.validate_fields = (function cljs$core$macros$validate_fields(case$,name,fields){
if(cljs.core.vector_QMARK_.call(null,fields)){
return null;
} else {
throw (new Error([cljs.core.str(case$),cljs.core.str(" "),cljs.core.str(name),cljs.core.str(", no fields vector given.")].join('')));
}
});
/**
 * (deftype name [fields*]  options* specs*)
 * 
 *   Currently there are no options.
 * 
 *   Each spec consists of a protocol or interface name followed by zero
 *   or more method bodies:
 * 
 *   protocol-or-Object
 *   (methodName [args*] body)*
 * 
 *   The type will have the (by default, immutable) fields named by
 *   fields, which can have type hints. Protocols and methods
 *   are optional. The only methods that can be supplied are those
 *   declared in the protocols/interfaces.  Note that method bodies are
 *   not closures, the local environment includes only the named fields,
 *   and those fields can be accessed directly. Fields can be qualified
 *   with the metadata :mutable true at which point (set! afield aval) will be
 *   supported in method bodies. Note well that mutable fields are extremely
 *   difficult to use correctly, and are present only to facilitate the building
 *   of higherlevel constructs, such as ClojureScript's reference types, in
 *   ClojureScript itself. They are for experts only - if the semantics and
 *   implications of :mutable are not immediately apparent to you, you should not
 *   be using them.
 * 
 *   Method definitions take the form:
 * 
 *   (methodname [args*] body)
 * 
 *   The argument and return types can be hinted on the arg and
 *   methodname symbols. If not supplied, they will be inferred, so type
 *   hints should be reserved for disambiguation.
 * 
 *   Methods should be supplied for all methods of the desired
 *   protocol(s). You can also define overrides for methods of Object. Note that
 *   a parameter must be supplied to correspond to the target object
 *   ('this' in JavaScript parlance). Note also that recur calls to the method
 *   head should *not* pass the target object, it will be supplied
 *   automatically and can not be substituted.
 * 
 *   In the method bodies, the (unqualified) name can be used to name the
 *   class (for calls to new, instance? etc).
 * 
 *   One constructor will be defined, taking the designated fields.  Note
 *   that the field names __meta and __extmap are currently reserved and
 *   should not be used when defining your own types.
 * 
 *   Given (deftype TypeName ...), a factory function called ->TypeName
 *   will be defined, taking positional parameters for the fields
 */
cljs.core$macros.deftype = (function cljs$core$macros$deftype(var_args){
var args__23962__auto__ = [];
var len__23955__auto___28612 = arguments.length;
var i__23956__auto___28613 = (0);
while(true){
if((i__23956__auto___28613 < len__23955__auto___28612)){
args__23962__auto__.push((arguments[i__23956__auto___28613]));

var G__28614 = (i__23956__auto___28613 + (1));
i__23956__auto___28613 = G__28614;
continue;
} else {
}
break;
}

var argseq__23963__auto__ = ((((4) < args__23962__auto__.length))?(new cljs.core.IndexedSeq(args__23962__auto__.slice((4)),(0),null)):null);
return cljs.core$macros.deftype.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]),argseq__23963__auto__);
});

cljs.core$macros.deftype.cljs$core$IFn$_invoke$arity$variadic = (function (_AMPERSAND_form,_AMPERSAND_env,t,fields,impls){
cljs.core$macros.validate_fields.call(null,"deftype",t,fields);

var env = _AMPERSAND_env;
var r = new cljs.core.Keyword(null,"name","name",1843675177).cljs$core$IFn$_invoke$arity$1(cljs.analyzer.resolve_var.call(null,cljs.core.dissoc.call(null,env,new cljs.core.Keyword(null,"locals","locals",535295783)),t));
var vec__28611 = cljs.core$macros.prepare_protocol_masks.call(null,env,impls);
var fpps = cljs.core.nth.call(null,vec__28611,(0),null);
var pmasks = cljs.core.nth.call(null,vec__28611,(1),null);
var protocols = cljs.core$macros.collect_protocols.call(null,impls,env);
var t__$1 = cljs.core.vary_meta.call(null,t,cljs.core.assoc,new cljs.core.Keyword(null,"protocols","protocols",-5615896),protocols,new cljs.core.Keyword(null,"skip-protocol-flag","skip-protocol-flag",-1426798630),fpps);
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"do","do",1686842252,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"deftype*","deftype*",962659890,null)),(function (){var x__23719__auto__ = t__$1;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = fields;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = pmasks;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = ((cljs.core.seq.call(null,impls))?cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","extend-type","cljs.core$macros/extend-type",1713295201,null)),(function (){var x__23719__auto__ = t__$1;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),cljs.core$macros.dt__GT_et.call(null,t__$1,impls,fields)))):null);
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"set!","set!",250714521,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,".-getBasis",".-getBasis",-1306451468,null)),(function (){var x__23719__auto__ = t__$1;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","fn","cljs.core$macros/fn",-187522821,null)),(function (){var x__23719__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"quote","quote",1377916282,null)),(function (){var x__23719__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,fields))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"set!","set!",250714521,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,".-cljs$lang$type",".-cljs$lang$type",-1029307724,null)),(function (){var x__23719__auto__ = t__$1;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,true))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"set!","set!",250714521,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,".-cljs$lang$ctorStr",".-cljs$lang$ctorStr",-1820706991,null)),(function (){var x__23719__auto__ = t__$1;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = [cljs.core.str(r)].join('');
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"set!","set!",250714521,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,".-cljs$lang$ctorPrWriter",".-cljs$lang$ctorPrWriter",255834464,null)),(function (){var x__23719__auto__ = t__$1;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","fn","cljs.core$macros/fn",-187522821,null)),(function (){var x__23719__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"this__28603__auto__","this__28603__auto__",230659401,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"writer__28604__auto__","writer__28604__auto__",433705624,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"opt__28605__auto__","opt__28605__auto__",1986894145,null))))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","-write","cljs.core/-write",527220517,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"writer__28604__auto__","writer__28604__auto__",433705624,null)),(function (){var x__23719__auto__ = [cljs.core.str(r)].join('');
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core$macros.build_positional_factory.call(null,t__$1,r,fields);
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = t__$1;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
});

cljs.core$macros.deftype.cljs$lang$maxFixedArity = (4);

cljs.core$macros.deftype.cljs$lang$applyTo = (function (seq28606){
var G__28607 = cljs.core.first.call(null,seq28606);
var seq28606__$1 = cljs.core.next.call(null,seq28606);
var G__28608 = cljs.core.first.call(null,seq28606__$1);
var seq28606__$2 = cljs.core.next.call(null,seq28606__$1);
var G__28609 = cljs.core.first.call(null,seq28606__$2);
var seq28606__$3 = cljs.core.next.call(null,seq28606__$2);
var G__28610 = cljs.core.first.call(null,seq28606__$3);
var seq28606__$4 = cljs.core.next.call(null,seq28606__$3);
return cljs.core$macros.deftype.cljs$core$IFn$_invoke$arity$variadic(G__28607,G__28608,G__28609,G__28610,seq28606__$4);
});

cljs.core$macros.deftype.cljs$lang$macro = true;
/**
 * Do not use this directly - use defrecord
 */
cljs.core$macros.emit_defrecord = (function cljs$core$macros$emit_defrecord(env,tagname,rname,fields,impls){
var hinted_fields = fields;
var fields__$1 = cljs.core.vec.call(null,cljs.core.map.call(null,((function (hinted_fields){
return (function (p1__28615_SHARP_){
return cljs.core.with_meta.call(null,p1__28615_SHARP_,null);
});})(hinted_fields))
,fields));
var base_fields = fields__$1;
var pr_open = [cljs.core.str("#"),cljs.core.str(cljs.core.namespace.call(null,rname)),cljs.core.str("."),cljs.core.str(cljs.core.name.call(null,rname)),cljs.core.str("{")].join('');
var fields__$2 = cljs.core.conj.call(null,fields__$1,new cljs.core.Symbol(null,"__meta","__meta",-946752628,null),new cljs.core.Symbol(null,"__extmap","__extmap",-1435580931,null),cljs.core.with_meta.call(null,new cljs.core.Symbol(null,"__hash","__hash",-1328796629,null),new cljs.core.PersistentArrayMap(null, 1, [new cljs.core.Keyword(null,"mutable","mutable",875778266),true], null)));
var gs = cljs.core.gensym.call(null);
var ksym = cljs.core.gensym.call(null,"k");
var impls__$1 = cljs.core.concat.call(null,impls,new cljs.core.PersistentVector(null, 28, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Symbol(null,"IRecord","IRecord",-903221169,null),new cljs.core.Symbol(null,"ICloneable","ICloneable",1882653160,null),cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"-clone","-clone",227130084,null)),(function (){var x__23719__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"this__28616__auto__","this__28616__auto__",216504486,null))))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"new","new",-444906321,null)),(function (){var x__23719__auto__ = tagname;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),fields__$2)));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})()))),new cljs.core.Symbol(null,"IHash","IHash",-1495374645,null),cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"-hash","-hash",-630070274,null)),(function (){var x__23719__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"this__28617__auto__","this__28617__auto__",2076342253,null))))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","caching-hash","cljs.core$macros/caching-hash",-1892393069,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"this__28617__auto__","this__28617__auto__",2076342253,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"hash-imap","hash-imap",-1047446478,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"__hash","__hash",-1328796629,null)))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})()))),new cljs.core.Symbol(null,"IEquiv","IEquiv",-1912850869,null),cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"-equiv","-equiv",320124272,null)),(function (){var x__23719__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"this__28618__auto__","this__28618__auto__",2008985410,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"other__28619__auto__","other__28619__auto__",1699091544,null))))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"if","if",1181717262,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","and","cljs.core$macros/and",48320334,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"other__28619__auto__","other__28619__auto__",1699091544,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","identical?","cljs.core$macros/identical?",815580547,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,".-constructor",".-constructor",279801701,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"this__28618__auto__","this__28618__auto__",2008985410,null)))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,".-constructor",".-constructor",279801701,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"other__28619__auto__","other__28619__auto__",1699091544,null)))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","equiv-map","cljs.core/equiv-map",-1185609892,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"this__28618__auto__","this__28618__auto__",2008985410,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"other__28619__auto__","other__28619__auto__",1699091544,null)))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,true),cljs.core._conj.call(null,cljs.core.List.EMPTY,false))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})()))),new cljs.core.Symbol(null,"IMeta","IMeta",1095313672,null),cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"-meta","-meta",494863156,null)),(function (){var x__23719__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"this__28620__auto__","this__28620__auto__",1186346750,null))))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"__meta","__meta",-946752628,null))))),new cljs.core.Symbol(null,"IWithMeta","IWithMeta",-509493158,null),cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"-with-meta","-with-meta",-1610713823,null)),(function (){var x__23719__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"this__28621__auto__","this__28621__auto__",1493356180,null)),(function (){var x__23719__auto__ = gs;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})()))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"new","new",-444906321,null)),(function (){var x__23719__auto__ = tagname;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),cljs.core.replace.call(null,new cljs.core.PersistentArrayMap(null, 1, [new cljs.core.Symbol(null,"__meta","__meta",-946752628,null),gs], null),fields__$2))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})()))),new cljs.core.Symbol(null,"ILookup","ILookup",784647298,null),cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"-lookup","-lookup",-1438393944,null)),(function (){var x__23719__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"this__28622__auto__","this__28622__auto__",-974913784,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"k__28623__auto__","k__28623__auto__",161033620,null))))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","-lookup","cljs.core/-lookup",-1845674443,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"this__28622__auto__","this__28622__auto__",-974913784,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"k__28623__auto__","k__28623__auto__",161033620,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,null))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})()))),cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"-lookup","-lookup",-1438393944,null)),(function (){var x__23719__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"this__28624__auto__","this__28624__auto__",501693799,null)),(function (){var x__23719__auto__ = ksym;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"else__28625__auto__","else__28625__auto__",1901316972,null))))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","case","cljs.core$macros/case",-2131866965,null)),(function (){var x__23719__auto__ = ksym;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),cljs.core.mapcat.call(null,((function (gs,ksym,hinted_fields,fields__$1,base_fields,pr_open,fields__$2){
return (function (f){
return new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.keyword.call(null,f),f], null);
});})(gs,ksym,hinted_fields,fields__$1,base_fields,pr_open,fields__$2))
,base_fields),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","get","cljs.core/get",-296075407,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"__extmap","__extmap",-1435580931,null)),(function (){var x__23719__auto__ = ksym;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"else__28625__auto__","else__28625__auto__",1901316972,null)))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})()))),new cljs.core.Symbol(null,"ICounted","ICounted",-1705786327,null),cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"-count","-count",416049189,null)),(function (){var x__23719__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"this__28626__auto__","this__28626__auto__",303013008,null))))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","+","cljs.core$macros/+",-18260342,null)),(function (){var x__23719__auto__ = cljs.core.count.call(null,base_fields);
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","count","cljs.core/count",-921270233,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"__extmap","__extmap",-1435580931,null)))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})()))),new cljs.core.Symbol(null,"ICollection","ICollection",-686709190,null),cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"-conj","-conj",1373798691,null)),(function (){var x__23719__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"this__28627__auto__","this__28627__auto__",-647605773,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"entry__28628__auto__","entry__28628__auto__",1462020452,null))))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"if","if",1181717262,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","vector?","cljs.core/vector?",-1550392028,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"entry__28628__auto__","entry__28628__auto__",1462020452,null)))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","-assoc","cljs.core/-assoc",-814539323,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"this__28627__auto__","this__28627__auto__",-647605773,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","-nth","cljs.core/-nth",504234802,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"entry__28628__auto__","entry__28628__auto__",1462020452,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,(0)))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","-nth","cljs.core/-nth",504234802,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"entry__28628__auto__","entry__28628__auto__",1462020452,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,(1)))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","reduce","cljs.core/reduce",2025430439,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","-conj","cljs.core/-conj",2040622670,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"this__28627__auto__","this__28627__auto__",-647605773,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"entry__28628__auto__","entry__28628__auto__",1462020452,null)))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})()))),new cljs.core.Symbol(null,"IAssociative","IAssociative",-1306431882,null),cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"-assoc","-assoc",-416089758,null)),(function (){var x__23719__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"this__28629__auto__","this__28629__auto__",489882794,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"k__28630__auto__","k__28630__auto__",-1203191715,null)),(function (){var x__23719__auto__ = gs;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})()))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","condp","cljs.core$macros/condp",431619047,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","keyword-identical?","cljs.core/keyword-identical?",1598491177,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"k__28630__auto__","k__28630__auto__",-1203191715,null)),cljs.core.mapcat.call(null,((function (gs,ksym,hinted_fields,fields__$1,base_fields,pr_open,fields__$2){
return (function (fld){
return new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.keyword.call(null,fld),cljs.core.list_STAR_.call(null,new cljs.core.Symbol(null,"new","new",-444906321,null),tagname,cljs.core.replace.call(null,cljs.core.PersistentArrayMap.fromArray([fld,gs,new cljs.core.Symbol(null,"__hash","__hash",-1328796629,null),null], true, false),fields__$2))], null);
});})(gs,ksym,hinted_fields,fields__$1,base_fields,pr_open,fields__$2))
,base_fields),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"new","new",-444906321,null)),(function (){var x__23719__auto__ = tagname;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),cljs.core.remove.call(null,new cljs.core.PersistentHashSet(null, new cljs.core.PersistentArrayMap(null, 2, [new cljs.core.Symbol(null,"__hash","__hash",-1328796629,null),null,new cljs.core.Symbol(null,"__extmap","__extmap",-1435580931,null),null], null), null),fields__$2),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","assoc","cljs.core/assoc",322326297,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"__extmap","__extmap",-1435580931,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"k__28630__auto__","k__28630__auto__",-1203191715,null)),(function (){var x__23719__auto__ = gs;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,null))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})()))),new cljs.core.Symbol(null,"IMap","IMap",992876629,null),cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"-dissoc","-dissoc",1638079447,null)),(function (){var x__23719__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"this__28631__auto__","this__28631__auto__",203902314,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"k__28632__auto__","k__28632__auto__",-1291896997,null))))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"if","if",1181717262,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","contains?","cljs.core/contains?",-976526835,null)),(function (){var x__23719__auto__ = cljs.core.apply.call(null,cljs.core.hash_set,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core.map.call(null,cljs.core.keyword,base_fields)))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"k__28632__auto__","k__28632__auto__",-1291896997,null)))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","dissoc","cljs.core/dissoc",-432349815,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","with-meta","cljs.core/with-meta",749126446,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","into","cljs.core/into",1879938733,null)),(function (){var x__23719__auto__ = cljs.core.apply.call(null,cljs.core.array_map,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"this__28631__auto__","this__28631__auto__",203902314,null)))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"__meta","__meta",-946752628,null)))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"k__28632__auto__","k__28632__auto__",-1291896997,null)))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"new","new",-444906321,null)),(function (){var x__23719__auto__ = tagname;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),cljs.core.remove.call(null,new cljs.core.PersistentHashSet(null, new cljs.core.PersistentArrayMap(null, 2, [new cljs.core.Symbol(null,"__hash","__hash",-1328796629,null),null,new cljs.core.Symbol(null,"__extmap","__extmap",-1435580931,null),null], null), null),fields__$2),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","not-empty","cljs.core/not-empty",540057011,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","dissoc","cljs.core/dissoc",-432349815,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"__extmap","__extmap",-1435580931,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"k__28632__auto__","k__28632__auto__",-1291896997,null)))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,null))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})()))),new cljs.core.Symbol(null,"ISeqable","ISeqable",1349682102,null),cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"-seq","-seq",1019896831,null)),(function (){var x__23719__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"this__28634__auto__","this__28634__auto__",-974517631,null))))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","seq","cljs.core/seq",-1649497689,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","concat","cljs.core/concat",-1133584918,null)),(function (){var x__23719__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core.map.call(null,((function (gs,ksym,hinted_fields,fields__$1,base_fields,pr_open,fields__$2){
return (function (p1__28633_SHARP_){
return cljs.core._conj.call(null,(function (){var x__23719__auto__ = cljs.core.keyword.call(null,p1__28633_SHARP_);
return cljs.core._conj.call(null,(function (){var x__23719__auto____$1 = p1__28633_SHARP_;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto____$1);
})(),x__23719__auto__);
})(),new cljs.core.Symbol("cljs.core$macros","vector","cljs.core$macros/vector",912237829,null));
});})(gs,ksym,hinted_fields,fields__$1,base_fields,pr_open,fields__$2))
,base_fields)))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"__extmap","__extmap",-1435580931,null)))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})()))),new cljs.core.Symbol(null,"IIterable","IIterable",577191430,null),cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"-iterator","-iterator",310937281,null)),(function (){var x__23719__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,(function (){var x__23719__auto__ = gs;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})()))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"RecordIter.","RecordIter.",-265283060,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,(0)),(function (){var x__23719__auto__ = gs;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.count.call(null,base_fields);
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core.map.call(null,cljs.core.keyword,base_fields)))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","-iterator","cljs.core/-iterator",1833427494,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"__extmap","__extmap",-1435580931,null)))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})()))),new cljs.core.Symbol(null,"IPrintWithWriter","IPrintWithWriter",-1205316154,null),cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"-pr-writer","-pr-writer",-445354136,null)),(function (){var x__23719__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"this__28636__auto__","this__28636__auto__",-425798841,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"writer__28637__auto__","writer__28637__auto__",-1827430804,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"opts__28638__auto__","opts__28638__auto__",-535417934,null))))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","let","cljs.core$macros/let",-160286726,null)),(function (){var x__23719__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"pr-pair__28639__auto__","pr-pair__28639__auto__",952558421,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","fn","cljs.core$macros/fn",-187522821,null)),(function (){var x__23719__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"keyval__28640__auto__","keyval__28640__auto__",430455906,null))))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","pr-sequential-writer","cljs.core/pr-sequential-writer",-1101677821,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"writer__28637__auto__","writer__28637__auto__",-1827430804,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","pr-writer","cljs.core/pr-writer",133956070,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,""),cljs.core._conj.call(null,cljs.core.List.EMPTY," "),cljs.core._conj.call(null,cljs.core.List.EMPTY,""),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"opts__28638__auto__","opts__28638__auto__",-535417934,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"keyval__28640__auto__","keyval__28640__auto__",430455906,null)))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})()))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","pr-sequential-writer","cljs.core/pr-sequential-writer",-1101677821,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"writer__28637__auto__","writer__28637__auto__",-1827430804,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"pr-pair__28639__auto__","pr-pair__28639__auto__",952558421,null)),(function (){var x__23719__auto__ = pr_open;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,", "),cljs.core._conj.call(null,cljs.core.List.EMPTY,"}"),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"opts__28638__auto__","opts__28638__auto__",-535417934,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","concat","cljs.core/concat",-1133584918,null)),(function (){var x__23719__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core.map.call(null,((function (gs,ksym,hinted_fields,fields__$1,base_fields,pr_open,fields__$2){
return (function (p1__28635_SHARP_){
return cljs.core._conj.call(null,(function (){var x__23719__auto__ = cljs.core.keyword.call(null,p1__28635_SHARP_);
return cljs.core._conj.call(null,(function (){var x__23719__auto____$1 = p1__28635_SHARP_;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto____$1);
})(),x__23719__auto__);
})(),new cljs.core.Symbol("cljs.core$macros","vector","cljs.core$macros/vector",912237829,null));
});})(gs,ksym,hinted_fields,fields__$1,base_fields,pr_open,fields__$2))
,base_fields)))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"__extmap","__extmap",-1435580931,null)))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())))], null));
var vec__28642 = cljs.core$macros.prepare_protocol_masks.call(null,env,impls__$1);
var fpps = cljs.core.nth.call(null,vec__28642,(0),null);
var pmasks = cljs.core.nth.call(null,vec__28642,(1),null);
var protocols = cljs.core$macros.collect_protocols.call(null,impls__$1,env);
var tagname__$1 = cljs.core.vary_meta.call(null,tagname,cljs.core.assoc,new cljs.core.Keyword(null,"protocols","protocols",-5615896),protocols,new cljs.core.Keyword(null,"skip-protocol-flag","skip-protocol-flag",-1426798630),fpps);
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"do","do",1686842252,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"defrecord*","defrecord*",-1936366207,null)),(function (){var x__23719__auto__ = tagname__$1;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = hinted_fields;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = pmasks;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","extend-type","cljs.core$macros/extend-type",1713295201,null)),(function (){var x__23719__auto__ = tagname__$1;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),cljs.core$macros.dt__GT_et.call(null,tagname__$1,impls__$1,fields__$2,true))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
});
cljs.core$macros.build_map_factory = (function cljs$core$macros$build_map_factory(rsym,rname,fields){
var fn_name = cljs.core.with_meta.call(null,cljs.core.symbol.call(null,[cljs.core.str(new cljs.core.Symbol(null,"map->","map->",-999714600,null)),cljs.core.str(rsym)].join('')),cljs.core.assoc.call(null,cljs.core.meta.call(null,rsym),new cljs.core.Keyword(null,"factory","factory",63933746),new cljs.core.Keyword(null,"map","map",1371690461)));
var ms = cljs.core.gensym.call(null);
var ks = cljs.core.map.call(null,cljs.core.keyword,fields);
var getters = cljs.core.map.call(null,((function (fn_name,ms,ks){
return (function (k){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,(function (){var x__23719__auto__ = k;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = ms;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
});})(fn_name,ms,ks))
,ks);
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","defn","cljs.core$macros/defn",-728332354,null)),(function (){var x__23719__auto__ = fn_name;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,(function (){var x__23719__auto__ = ms;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})()))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"new","new",-444906321,null)),(function (){var x__23719__auto__ = rname;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),getters,cljs.core._conj.call(null,cljs.core.List.EMPTY,null),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","dissoc","cljs.core/dissoc",-432349815,null)),(function (){var x__23719__auto__ = ms;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),ks)));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,null))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
});
/**
 * (defrecord name [fields*]  options* specs*)
 * 
 *   Currently there are no options.
 * 
 *   Each spec consists of a protocol or interface name followed by zero
 *   or more method bodies:
 * 
 *   protocol-or-Object
 *   (methodName [args*] body)*
 * 
 *   The record will have the (immutable) fields named by
 *   fields, which can have type hints. Protocols and methods
 *   are optional. The only methods that can be supplied are those
 *   declared in the protocols.  Note that method bodies are
 *   not closures, the local environment includes only the named fields,
 *   and those fields can be accessed directly.
 * 
 *   Method definitions take the form:
 * 
 *   (methodname [args*] body)
 * 
 *   The argument and return types can be hinted on the arg and
 *   methodname symbols. If not supplied, they will be inferred, so type
 *   hints should be reserved for disambiguation.
 * 
 *   Methods should be supplied for all methods of the desired
 *   protocol(s). You can also define overrides for
 *   methods of Object. Note that a parameter must be supplied to
 *   correspond to the target object ('this' in JavaScript parlance). Note also
 *   that recur calls to the method head should *not* pass the target object, it
 *   will be supplied automatically and can not be substituted.
 * 
 *   In the method bodies, the (unqualified) name can be used to name the
 *   class (for calls to new, instance? etc).
 * 
 *   The type will have implementations of several ClojureScript
 *   protocol generated automatically: IMeta/IWithMeta (metadata support) and
 *   IMap, etc.
 * 
 *   In addition, defrecord will define type-and-value-based =,
 *   and will define ClojureScript IHash and IEquiv.
 * 
 *   Two constructors will be defined, one taking the designated fields
 *   followed by a metadata map (nil for none) and an extension field
 *   map (nil for none), and one taking only the fields (using nil for
 *   meta and extension fields). Note that the field names __meta
 *   and __extmap are currently reserved and should not be used when
 *   defining your own records.
 * 
 *   Given (defrecord TypeName ...), two factory functions will be
 *   defined: ->TypeName, taking positional parameters for the fields,
 *   and map->TypeName, taking a map of keywords to field values.
 */
cljs.core$macros.defrecord = (function cljs$core$macros$defrecord(var_args){
var args__23962__auto__ = [];
var len__23955__auto___28650 = arguments.length;
var i__23956__auto___28651 = (0);
while(true){
if((i__23956__auto___28651 < len__23955__auto___28650)){
args__23962__auto__.push((arguments[i__23956__auto___28651]));

var G__28652 = (i__23956__auto___28651 + (1));
i__23956__auto___28651 = G__28652;
continue;
} else {
}
break;
}

var argseq__23963__auto__ = ((((4) < args__23962__auto__.length))?(new cljs.core.IndexedSeq(args__23962__auto__.slice((4)),(0),null)):null);
return cljs.core$macros.defrecord.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]),argseq__23963__auto__);
});

cljs.core$macros.defrecord.cljs$core$IFn$_invoke$arity$variadic = (function (_AMPERSAND_form,_AMPERSAND_env,rsym,fields,impls){
cljs.core$macros.validate_fields.call(null,"defrecord",rsym,fields);

var rsym__$1 = cljs.core.vary_meta.call(null,rsym,cljs.core.assoc,new cljs.core.Keyword(null,"internal-ctor","internal-ctor",937392560),true);
var r = cljs.core.vary_meta.call(null,new cljs.core.Keyword(null,"name","name",1843675177).cljs$core$IFn$_invoke$arity$1(cljs.analyzer.resolve_var.call(null,cljs.core.dissoc.call(null,_AMPERSAND_env,new cljs.core.Keyword(null,"locals","locals",535295783)),rsym__$1)),cljs.core.assoc,new cljs.core.Keyword(null,"internal-ctor","internal-ctor",937392560),true);
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","let","cljs.core$macros/let",-160286726,null)),(function (){var x__23719__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core$macros.emit_defrecord.call(null,_AMPERSAND_env,rsym__$1,r,fields,impls);
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"set!","set!",250714521,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,".-getBasis",".-getBasis",-1306451468,null)),(function (){var x__23719__auto__ = r;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","fn","cljs.core$macros/fn",-187522821,null)),(function (){var x__23719__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"quote","quote",1377916282,null)),(function (){var x__23719__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,fields))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"set!","set!",250714521,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,".-cljs$lang$type",".-cljs$lang$type",-1029307724,null)),(function (){var x__23719__auto__ = r;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,true))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"set!","set!",250714521,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,".-cljs$lang$ctorPrSeq",".-cljs$lang$ctorPrSeq",41132414,null)),(function (){var x__23719__auto__ = r;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","fn","cljs.core$macros/fn",-187522821,null)),(function (){var x__23719__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"this__28643__auto__","this__28643__auto__",841860383,null))))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","list","cljs.core/list",-1331406371,null)),(function (){var x__23719__auto__ = [cljs.core.str(r)].join('');
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"set!","set!",250714521,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,".-cljs$lang$ctorPrWriter",".-cljs$lang$ctorPrWriter",255834464,null)),(function (){var x__23719__auto__ = r;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","fn","cljs.core$macros/fn",-187522821,null)),(function (){var x__23719__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"this__28643__auto__","this__28643__auto__",841860383,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"writer__28644__auto__","writer__28644__auto__",825376603,null))))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","-write","cljs.core/-write",527220517,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"writer__28644__auto__","writer__28644__auto__",825376603,null)),(function (){var x__23719__auto__ = [cljs.core.str(r)].join('');
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core$macros.build_positional_factory.call(null,rsym__$1,r,fields);
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core$macros.build_map_factory.call(null,rsym__$1,r,fields);
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = r;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
});

cljs.core$macros.defrecord.cljs$lang$maxFixedArity = (4);

cljs.core$macros.defrecord.cljs$lang$applyTo = (function (seq28645){
var G__28646 = cljs.core.first.call(null,seq28645);
var seq28645__$1 = cljs.core.next.call(null,seq28645);
var G__28647 = cljs.core.first.call(null,seq28645__$1);
var seq28645__$2 = cljs.core.next.call(null,seq28645__$1);
var G__28648 = cljs.core.first.call(null,seq28645__$2);
var seq28645__$3 = cljs.core.next.call(null,seq28645__$2);
var G__28649 = cljs.core.first.call(null,seq28645__$3);
var seq28645__$4 = cljs.core.next.call(null,seq28645__$3);
return cljs.core$macros.defrecord.cljs$core$IFn$_invoke$arity$variadic(G__28646,G__28647,G__28648,G__28649,seq28645__$4);
});

cljs.core$macros.defrecord.cljs$lang$macro = true;
/**
 * A protocol is a named set of named methods and their signatures:
 * 
 *   (defprotocol AProtocolName
 *  ;optional doc string
 *  "A doc string for AProtocol abstraction"
 * 
 *   ;method signatures
 *  (bar [this a b] "bar docs")
 *  (baz [this a] [this a b] [this a b c] "baz docs"))
 * 
 *   No implementations are provided. Docs can be specified for the
 *   protocol overall and for each method. The above yields a set of
 *   polymorphic functions and a protocol object. All are
 *   namespace-qualified by the ns enclosing the definition The resulting
 *   functions dispatch on the type of their first argument, which is
 *   required and corresponds to the implicit target object ('this' in
 *   JavaScript parlance). defprotocol is dynamic, has no special compile-time
 *   effect, and defines no new types.
 * 
 *   (defprotocol P
 *  (foo [this])
 *  (bar-me [this] [this y]))
 * 
 *   (deftype Foo [a b c]
 *  P
 *  (foo [this] a)
 *  (bar-me [this] b)
 *  (bar-me [this y] (+ c y)))
 * 
 *   (bar-me (Foo. 1 2 3) 42)
 *   => 45
 * 
 *   (foo
 *  (let [x 42]
 *    (reify P
 *      (foo [this] 17)
 *      (bar-me [this] x)
 *      (bar-me [this y] x))))
 *   => 17
 */
cljs.core$macros.defprotocol = (function cljs$core$macros$defprotocol(var_args){
var args__23962__auto__ = [];
var len__23955__auto___28670 = arguments.length;
var i__23956__auto___28671 = (0);
while(true){
if((i__23956__auto___28671 < len__23955__auto___28670)){
args__23962__auto__.push((arguments[i__23956__auto___28671]));

var G__28672 = (i__23956__auto___28671 + (1));
i__23956__auto___28671 = G__28672;
continue;
} else {
}
break;
}

var argseq__23963__auto__ = ((((3) < args__23962__auto__.length))?(new cljs.core.IndexedSeq(args__23962__auto__.slice((3)),(0),null)):null);
return cljs.core$macros.defprotocol.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),argseq__23963__auto__);
});

cljs.core$macros.defprotocol.cljs$core$IFn$_invoke$arity$variadic = (function (_AMPERSAND_form,_AMPERSAND_env,psym,doc_PLUS_methods){
var p = new cljs.core.Keyword(null,"name","name",1843675177).cljs$core$IFn$_invoke$arity$1(cljs.analyzer.resolve_var.call(null,cljs.core.dissoc.call(null,_AMPERSAND_env,new cljs.core.Keyword(null,"locals","locals",535295783)),psym));
var vec__28659 = ((typeof cljs.core.first.call(null,doc_PLUS_methods) === 'string')?new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.first.call(null,doc_PLUS_methods),cljs.core.next.call(null,doc_PLUS_methods)], null):new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [null,doc_PLUS_methods], null));
var doc = cljs.core.nth.call(null,vec__28659,(0),null);
var methods$ = cljs.core.nth.call(null,vec__28659,(1),null);
var psym__$1 = cljs.core.vary_meta.call(null,psym,cljs.core.assoc,new cljs.core.Keyword(null,"doc","doc",1913296891),doc,new cljs.core.Keyword(null,"protocol-symbol","protocol-symbol",1279552198),true);
var ns_name = new cljs.core.Keyword(null,"name","name",1843675177).cljs$core$IFn$_invoke$arity$1(new cljs.core.Keyword(null,"ns","ns",441598760).cljs$core$IFn$_invoke$arity$1(_AMPERSAND_env));
var fqn = ((function (p,vec__28659,doc,methods$,psym__$1,ns_name){
return (function (n){
return cljs.core.symbol.call(null,[cljs.core.str(ns_name),cljs.core.str("."),cljs.core.str(n)].join(''));
});})(p,vec__28659,doc,methods$,psym__$1,ns_name))
;
var prefix = cljs.core$macros.protocol_prefix.call(null,p);
var _ = (function (){var seq__28660 = cljs.core.seq.call(null,methods$);
var chunk__28661 = null;
var count__28662 = (0);
var i__28663 = (0);
while(true){
if((i__28663 < count__28662)){
var vec__28664 = cljs.core._nth.call(null,chunk__28661,i__28663);
var mname = cljs.core.nth.call(null,vec__28664,(0),null);
var arities = cljs.core.nthnext.call(null,vec__28664,(1));
if(cljs.core.truth_(cljs.core.some.call(null,new cljs.core.PersistentHashSet(null, new cljs.core.PersistentArrayMap(null, 1, [(0),null], null), null),cljs.core.map.call(null,cljs.core.count,cljs.core.filter.call(null,cljs.core.vector_QMARK_,arities))))){
throw (new Error([cljs.core.str("Invalid protocol, "),cljs.core.str(psym__$1),cljs.core.str(" defines method "),cljs.core.str(mname),cljs.core.str(" with arity 0")].join('')));
} else {
}

var G__28673 = seq__28660;
var G__28674 = chunk__28661;
var G__28675 = count__28662;
var G__28676 = (i__28663 + (1));
seq__28660 = G__28673;
chunk__28661 = G__28674;
count__28662 = G__28675;
i__28663 = G__28676;
continue;
} else {
var temp__4657__auto__ = cljs.core.seq.call(null,seq__28660);
if(temp__4657__auto__){
var seq__28660__$1 = temp__4657__auto__;
if(cljs.core.chunked_seq_QMARK_.call(null,seq__28660__$1)){
var c__23696__auto__ = cljs.core.chunk_first.call(null,seq__28660__$1);
var G__28677 = cljs.core.chunk_rest.call(null,seq__28660__$1);
var G__28678 = c__23696__auto__;
var G__28679 = cljs.core.count.call(null,c__23696__auto__);
var G__28680 = (0);
seq__28660 = G__28677;
chunk__28661 = G__28678;
count__28662 = G__28679;
i__28663 = G__28680;
continue;
} else {
var vec__28665 = cljs.core.first.call(null,seq__28660__$1);
var mname = cljs.core.nth.call(null,vec__28665,(0),null);
var arities = cljs.core.nthnext.call(null,vec__28665,(1));
if(cljs.core.truth_(cljs.core.some.call(null,new cljs.core.PersistentHashSet(null, new cljs.core.PersistentArrayMap(null, 1, [(0),null], null), null),cljs.core.map.call(null,cljs.core.count,cljs.core.filter.call(null,cljs.core.vector_QMARK_,arities))))){
throw (new Error([cljs.core.str("Invalid protocol, "),cljs.core.str(psym__$1),cljs.core.str(" defines method "),cljs.core.str(mname),cljs.core.str(" with arity 0")].join('')));
} else {
}

var G__28681 = cljs.core.next.call(null,seq__28660__$1);
var G__28682 = null;
var G__28683 = (0);
var G__28684 = (0);
seq__28660 = G__28681;
chunk__28661 = G__28682;
count__28662 = G__28683;
i__28663 = G__28684;
continue;
}
} else {
return null;
}
}
break;
}
})();
var expand_sig = ((function (p,vec__28659,doc,methods$,psym__$1,ns_name,fqn,prefix,_){
return (function (fname,slot,sig){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,(function (){var x__23719__auto__ = sig;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"if","if",1181717262,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","and","cljs.core$macros/and",48320334,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","not","cljs.core/not",100665144,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","nil?","cljs.core$macros/nil?",83624258,null)),(function (){var x__23719__auto__ = cljs.core.first.call(null,sig);
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","not","cljs.core/not",100665144,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","nil?","cljs.core$macros/nil?",83624258,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,".",".",1975675962,null)),(function (){var x__23719__auto__ = cljs.core.first.call(null,sig);
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.symbol.call(null,[cljs.core.str("-"),cljs.core.str(slot)].join(''));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,".",".",1975675962,null)),(function (){var x__23719__auto__ = cljs.core.first.call(null,sig);
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = slot;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),sig)));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","let","cljs.core$macros/let",-160286726,null)),(function (){var x__23719__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"x__28653__auto__","x__28653__auto__",1981220593,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"if","if",1181717262,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","nil?","cljs.core$macros/nil?",83624258,null)),(function (){var x__23719__auto__ = cljs.core.first.call(null,sig);
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,null),(function (){var x__23719__auto__ = cljs.core.first.call(null,sig);
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"m__28654__auto__","m__28654__auto__",1382178250,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","aget","cljs.core$macros/aget",1976136178,null)),(function (){var x__23719__auto__ = fqn.call(null,fname);
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("goog","typeOf","goog/typeOf",539097255,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"x__28653__auto__","x__28653__auto__",1981220593,null)))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})()))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","if-not","cljs.core$macros/if-not",-1825285737,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","nil?","cljs.core$macros/nil?",83624258,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"m__28654__auto__","m__28654__auto__",1382178250,null)))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"m__28654__auto__","m__28654__auto__",1382178250,null)),sig)));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","let","cljs.core$macros/let",-160286726,null)),(function (){var x__23719__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"m__28654__auto__","m__28654__auto__",1382178250,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","aget","cljs.core$macros/aget",1976136178,null)),(function (){var x__23719__auto__ = fqn.call(null,fname);
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,"_"))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})()))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","if-not","cljs.core$macros/if-not",-1825285737,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","nil?","cljs.core$macros/nil?",83624258,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"m__28654__auto__","m__28654__auto__",1382178250,null)))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"m__28654__auto__","m__28654__auto__",1382178250,null)),sig)));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"throw","throw",595905694,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","missing-protocol","cljs.core/missing-protocol",531539732,null)),(function (){var x__23719__auto__ = [cljs.core.str(psym__$1),cljs.core.str("."),cljs.core.str(fname)].join('');
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.first.call(null,sig);
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
});})(p,vec__28659,doc,methods$,psym__$1,ns_name,fqn,prefix,_))
;
var psym__$2 = cljs.core.vary_meta.call(null,cljs.core.vary_meta.call(null,psym__$1,cljs.core.update_in,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword(null,"jsdoc","jsdoc",1745183516)], null),cljs.core.conj,"@interface"),cljs.core.assoc_in,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword(null,"protocol-info","protocol-info",1471745843),new cljs.core.Keyword(null,"methods","methods",453930866)], null),cljs.core.into.call(null,cljs.core.PersistentArrayMap.EMPTY,cljs.core.map.call(null,((function (p,vec__28659,doc,methods$,psym__$1,ns_name,fqn,prefix,_,expand_sig){
return (function (p__28666){
var vec__28667 = p__28666;
var fname = cljs.core.nth.call(null,vec__28667,(0),null);
var sigs = cljs.core.nthnext.call(null,vec__28667,(1));
var doc__$1 = (function (){var doc__$1 = cljs.core.last.call(null,sigs);
if(typeof doc__$1 === 'string'){
return doc__$1;
} else {
return null;
}
})();
var sigs__$1 = cljs.core.take_while.call(null,cljs.core.vector_QMARK_,sigs);
return new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.vary_meta.call(null,fname,cljs.core.assoc,new cljs.core.Keyword(null,"doc","doc",1913296891),doc__$1),cljs.core.vec.call(null,sigs__$1)], null);
});})(p,vec__28659,doc,methods$,psym__$1,ns_name,fqn,prefix,_,expand_sig))
,methods$)));
var method = ((function (p,vec__28659,doc,methods$,psym__$1,ns_name,fqn,prefix,_,expand_sig,psym__$2){
return (function (p__28668){
var vec__28669 = p__28668;
var fname = cljs.core.nth.call(null,vec__28669,(0),null);
var sigs = cljs.core.nthnext.call(null,vec__28669,(1));
var doc__$1 = (function (){var doc__$1 = cljs.core.last.call(null,sigs);
if(typeof doc__$1 === 'string'){
return doc__$1;
} else {
return null;
}
})();
var sigs__$1 = cljs.core.take_while.call(null,cljs.core.vector_QMARK_,sigs);
var amp = (cljs.core.truth_(cljs.core.some.call(null,new cljs.core.PersistentHashSet(null, new cljs.core.PersistentArrayMap(null, 1, [new cljs.core.Symbol(null,"&","&",-2144855648,null),null], null), null),cljs.core.apply.call(null,cljs.core.concat,sigs__$1)))?cljs.analyzer.warning.call(null,new cljs.core.Keyword(null,"protocol-with-variadic-method","protocol-with-variadic-method",-693368178),_AMPERSAND_env,new cljs.core.PersistentArrayMap(null, 2, [new cljs.core.Keyword(null,"protocol","protocol",652470118),psym__$2,new cljs.core.Keyword(null,"name","name",1843675177),fname], null)):null);
var slot = cljs.core.symbol.call(null,[cljs.core.str(prefix),cljs.core.str(cljs.core.name.call(null,fname))].join(''));
var fname__$1 = cljs.core.vary_meta.call(null,fname,cljs.core.assoc,new cljs.core.Keyword(null,"protocol","protocol",652470118),p,new cljs.core.Keyword(null,"doc","doc",1913296891),doc__$1);
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","defn","cljs.core$macros/defn",-728332354,null)),(function (){var x__23719__auto__ = fname__$1;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),cljs.core.map.call(null,((function (doc__$1,sigs__$1,amp,slot,fname__$1,vec__28669,fname,sigs,p,vec__28659,doc,methods$,psym__$1,ns_name,fqn,prefix,_,expand_sig,psym__$2){
return (function (sig){
return expand_sig.call(null,fname__$1,cljs.core.symbol.call(null,[cljs.core.str(slot),cljs.core.str("$arity$"),cljs.core.str(cljs.core.count.call(null,sig))].join('')),sig);
});})(doc__$1,sigs__$1,amp,slot,fname__$1,vec__28669,fname,sigs,p,vec__28659,doc,methods$,psym__$1,ns_name,fqn,prefix,_,expand_sig,psym__$2))
,sigs__$1))));
});})(p,vec__28659,doc,methods$,psym__$1,ns_name,fqn,prefix,_,expand_sig,psym__$2))
;
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"do","do",1686842252,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"set!","set!",250714521,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"*unchecked-if*","*unchecked-if*",1542408350,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,true))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"def","def",597100991,null)),(function (){var x__23719__auto__ = psym__$2;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"js*","js*",-1134233646,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,"function(){}"))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),cljs.core.map.call(null,method,methods$),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"set!","set!",250714521,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"*unchecked-if*","*unchecked-if*",1542408350,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,false))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
});

cljs.core$macros.defprotocol.cljs$lang$maxFixedArity = (3);

cljs.core$macros.defprotocol.cljs$lang$applyTo = (function (seq28655){
var G__28656 = cljs.core.first.call(null,seq28655);
var seq28655__$1 = cljs.core.next.call(null,seq28655);
var G__28657 = cljs.core.first.call(null,seq28655__$1);
var seq28655__$2 = cljs.core.next.call(null,seq28655__$1);
var G__28658 = cljs.core.first.call(null,seq28655__$2);
var seq28655__$3 = cljs.core.next.call(null,seq28655__$2);
return cljs.core$macros.defprotocol.cljs$core$IFn$_invoke$arity$variadic(G__28656,G__28657,G__28658,seq28655__$3);
});

cljs.core$macros.defprotocol.cljs$lang$macro = true;
/**
 * EXPERIMENTAL
 */
cljs.core$macros.implements_QMARK_ = (function cljs$core$macros$implements_QMARK_(_AMPERSAND_form,_AMPERSAND_env,psym,x){
var p = new cljs.core.Keyword(null,"name","name",1843675177).cljs$core$IFn$_invoke$arity$1(cljs.analyzer.resolve_var.call(null,cljs.core.dissoc.call(null,_AMPERSAND_env,new cljs.core.Keyword(null,"locals","locals",535295783)),psym));
var prefix = cljs.core$macros.protocol_prefix.call(null,p);
var xsym = cljs.core$macros.bool_expr.call(null,cljs.core.gensym.call(null));
var vec__28686 = cljs.core$macros.fast_path_protocols.call(null,p);
var part = cljs.core.nth.call(null,vec__28686,(0),null);
var bit = cljs.core.nth.call(null,vec__28686,(1),null);
var msym = cljs.core.symbol.call(null,[cljs.core.str("-cljs$lang$protocol_mask$partition"),cljs.core.str(part),cljs.core.str("$")].join(''));
if(!((x instanceof cljs.core.Symbol))){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","let","cljs.core$macros/let",-160286726,null)),(function (){var x__23719__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,(function (){var x__23719__auto__ = xsym;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = x;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})()))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"if","if",1181717262,null)),(function (){var x__23719__auto__ = xsym;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"if","if",1181717262,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","or","cljs.core$macros/or",1346243648,null)),(function (){var x__23719__auto__ = (cljs.core.truth_(bit)?cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","unsafe-bit-and","cljs.core$macros/unsafe-bit-and",1803731600,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,".",".",1975675962,null)),(function (){var x__23719__auto__ = xsym;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = msym;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = bit;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})()))):false);
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core$macros.bool_expr.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,".",".",1975675962,null)),(function (){var x__23719__auto__ = xsym;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.symbol.call(null,[cljs.core.str("-"),cljs.core.str(prefix)].join(''));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})()))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,true),cljs.core._conj.call(null,cljs.core.List.EMPTY,false))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,false))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
} else {
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","if-not","cljs.core$macros/if-not",-1825285737,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","nil?","cljs.core$macros/nil?",83624258,null)),(function (){var x__23719__auto__ = x;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"if","if",1181717262,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","or","cljs.core$macros/or",1346243648,null)),(function (){var x__23719__auto__ = (cljs.core.truth_(bit)?cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","unsafe-bit-and","cljs.core$macros/unsafe-bit-and",1803731600,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,".",".",1975675962,null)),(function (){var x__23719__auto__ = x;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = msym;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = bit;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})()))):false);
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core$macros.bool_expr.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,".",".",1975675962,null)),(function (){var x__23719__auto__ = x;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.symbol.call(null,[cljs.core.str("-"),cljs.core.str(prefix)].join(''));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})()))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,true),cljs.core._conj.call(null,cljs.core.List.EMPTY,false))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,false))));
}
});

cljs.core$macros.implements_QMARK_.cljs$lang$macro = true;
/**
 * Returns true if x satisfies the protocol
 */
cljs.core$macros.satisfies_QMARK_ = (function cljs$core$macros$satisfies_QMARK_(_AMPERSAND_form,_AMPERSAND_env,psym,x){
var p = new cljs.core.Keyword(null,"name","name",1843675177).cljs$core$IFn$_invoke$arity$1(cljs.analyzer.resolve_var.call(null,cljs.core.dissoc.call(null,_AMPERSAND_env,new cljs.core.Keyword(null,"locals","locals",535295783)),psym));
var prefix = cljs.core$macros.protocol_prefix.call(null,p);
var xsym = cljs.core$macros.bool_expr.call(null,cljs.core.gensym.call(null));
var vec__28688 = cljs.core$macros.fast_path_protocols.call(null,p);
var part = cljs.core.nth.call(null,vec__28688,(0),null);
var bit = cljs.core.nth.call(null,vec__28688,(1),null);
var msym = cljs.core.symbol.call(null,[cljs.core.str("-cljs$lang$protocol_mask$partition"),cljs.core.str(part),cljs.core.str("$")].join(''));
if(!((x instanceof cljs.core.Symbol))){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","let","cljs.core$macros/let",-160286726,null)),(function (){var x__23719__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,(function (){var x__23719__auto__ = xsym;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = x;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})()))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","if-not","cljs.core$macros/if-not",-1825285737,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","nil?","cljs.core$macros/nil?",83624258,null)),(function (){var x__23719__auto__ = xsym;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"if","if",1181717262,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","or","cljs.core$macros/or",1346243648,null)),(function (){var x__23719__auto__ = (cljs.core.truth_(bit)?cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","unsafe-bit-and","cljs.core$macros/unsafe-bit-and",1803731600,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,".",".",1975675962,null)),(function (){var x__23719__auto__ = xsym;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = msym;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = bit;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})()))):false);
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core$macros.bool_expr.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,".",".",1975675962,null)),(function (){var x__23719__auto__ = xsym;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.symbol.call(null,[cljs.core.str("-"),cljs.core.str(prefix)].join(''));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})()))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,true),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"if","if",1181717262,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","coercive-not","cljs.core$macros/coercive-not",115999987,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,".",".",1975675962,null)),(function (){var x__23719__auto__ = xsym;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = msym;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","native-satisfies?","cljs.core/native-satisfies?",1482305036,null)),(function (){var x__23719__auto__ = psym;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = xsym;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,false))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","native-satisfies?","cljs.core/native-satisfies?",1482305036,null)),(function (){var x__23719__auto__ = psym;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = xsym;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
} else {
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","if-not","cljs.core$macros/if-not",-1825285737,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","nil?","cljs.core$macros/nil?",83624258,null)),(function (){var x__23719__auto__ = x;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"if","if",1181717262,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","or","cljs.core$macros/or",1346243648,null)),(function (){var x__23719__auto__ = (cljs.core.truth_(bit)?cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","unsafe-bit-and","cljs.core$macros/unsafe-bit-and",1803731600,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,".",".",1975675962,null)),(function (){var x__23719__auto__ = x;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = msym;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = bit;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})()))):false);
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core$macros.bool_expr.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,".",".",1975675962,null)),(function (){var x__23719__auto__ = x;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.symbol.call(null,[cljs.core.str("-"),cljs.core.str(prefix)].join(''));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})()))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,true),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"if","if",1181717262,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","coercive-not","cljs.core$macros/coercive-not",115999987,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,".",".",1975675962,null)),(function (){var x__23719__auto__ = x;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = msym;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","native-satisfies?","cljs.core/native-satisfies?",1482305036,null)),(function (){var x__23719__auto__ = psym;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = x;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,false))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","native-satisfies?","cljs.core/native-satisfies?",1482305036,null)),(function (){var x__23719__auto__ = psym;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = x;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
}
});

cljs.core$macros.satisfies_QMARK_.cljs$lang$macro = true;
/**
 * Takes a body of expressions that returns an ISeq or nil, and yields
 *   a ISeqable object that will invoke the body only the first time seq
 *   is called, and will cache the result and return it on all subsequent
 *   seq calls.
 */
cljs.core$macros.lazy_seq = (function cljs$core$macros$lazy_seq(var_args){
var args__23962__auto__ = [];
var len__23955__auto___28692 = arguments.length;
var i__23956__auto___28693 = (0);
while(true){
if((i__23956__auto___28693 < len__23955__auto___28692)){
args__23962__auto__.push((arguments[i__23956__auto___28693]));

var G__28694 = (i__23956__auto___28693 + (1));
i__23956__auto___28693 = G__28694;
continue;
} else {
}
break;
}

var argseq__23963__auto__ = ((((2) < args__23962__auto__.length))?(new cljs.core.IndexedSeq(args__23962__auto__.slice((2)),(0),null)):null);
return cljs.core$macros.lazy_seq.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__23963__auto__);
});

cljs.core$macros.lazy_seq.cljs$core$IFn$_invoke$arity$variadic = (function (_AMPERSAND_form,_AMPERSAND_env,body){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"new","new",-444906321,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","LazySeq","cljs.core/LazySeq",1986389673,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,null),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","fn","cljs.core$macros/fn",-187522821,null)),(function (){var x__23719__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),body)));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,null),cljs.core._conj.call(null,cljs.core.List.EMPTY,null))));
});

cljs.core$macros.lazy_seq.cljs$lang$maxFixedArity = (2);

cljs.core$macros.lazy_seq.cljs$lang$applyTo = (function (seq28689){
var G__28690 = cljs.core.first.call(null,seq28689);
var seq28689__$1 = cljs.core.next.call(null,seq28689);
var G__28691 = cljs.core.first.call(null,seq28689__$1);
var seq28689__$2 = cljs.core.next.call(null,seq28689__$1);
return cljs.core$macros.lazy_seq.cljs$core$IFn$_invoke$arity$variadic(G__28690,G__28691,seq28689__$2);
});

cljs.core$macros.lazy_seq.cljs$lang$macro = true;
/**
 * Takes a body of expressions and yields a Delay object that will
 *   invoke the body only the first time it is forced (with force or deref/@), and
 *   will cache the result and return it on all subsequent force
 *   calls.
 */
cljs.core$macros.delay = (function cljs$core$macros$delay(var_args){
var args__23962__auto__ = [];
var len__23955__auto___28698 = arguments.length;
var i__23956__auto___28699 = (0);
while(true){
if((i__23956__auto___28699 < len__23955__auto___28698)){
args__23962__auto__.push((arguments[i__23956__auto___28699]));

var G__28700 = (i__23956__auto___28699 + (1));
i__23956__auto___28699 = G__28700;
continue;
} else {
}
break;
}

var argseq__23963__auto__ = ((((2) < args__23962__auto__.length))?(new cljs.core.IndexedSeq(args__23962__auto__.slice((2)),(0),null)):null);
return cljs.core$macros.delay.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__23963__auto__);
});

cljs.core$macros.delay.cljs$core$IFn$_invoke$arity$variadic = (function (_AMPERSAND_form,_AMPERSAND_env,body){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"new","new",-444906321,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","Delay","cljs.core/Delay",-21574999,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","fn","cljs.core$macros/fn",-187522821,null)),(function (){var x__23719__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),body)));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,null))));
});

cljs.core$macros.delay.cljs$lang$maxFixedArity = (2);

cljs.core$macros.delay.cljs$lang$applyTo = (function (seq28695){
var G__28696 = cljs.core.first.call(null,seq28695);
var seq28695__$1 = cljs.core.next.call(null,seq28695);
var G__28697 = cljs.core.first.call(null,seq28695__$1);
var seq28695__$2 = cljs.core.next.call(null,seq28695__$1);
return cljs.core$macros.delay.cljs$core$IFn$_invoke$arity$variadic(G__28696,G__28697,seq28695__$2);
});

cljs.core$macros.delay.cljs$lang$macro = true;
/**
 * binding => var-symbol temp-value-expr
 * 
 *   Temporarily redefines vars while executing the body.  The
 *   temp-value-exprs will be evaluated and each resulting value will
 *   replace in parallel the root value of its var.  After the body is
 *   executed, the root values of all the vars will be set back to their
 *   old values. Useful for mocking out functions during testing.
 */
cljs.core$macros.with_redefs = (function cljs$core$macros$with_redefs(var_args){
var args__23962__auto__ = [];
var len__23955__auto___28707 = arguments.length;
var i__23956__auto___28708 = (0);
while(true){
if((i__23956__auto___28708 < len__23955__auto___28707)){
args__23962__auto__.push((arguments[i__23956__auto___28708]));

var G__28709 = (i__23956__auto___28708 + (1));
i__23956__auto___28708 = G__28709;
continue;
} else {
}
break;
}

var argseq__23963__auto__ = ((((3) < args__23962__auto__.length))?(new cljs.core.IndexedSeq(args__23962__auto__.slice((3)),(0),null)):null);
return cljs.core$macros.with_redefs.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),argseq__23963__auto__);
});

cljs.core$macros.with_redefs.cljs$core$IFn$_invoke$arity$variadic = (function (_AMPERSAND_form,_AMPERSAND_env,bindings,body){
var names = cljs.core.take_nth.call(null,(2),bindings);
var vals = cljs.core.take_nth.call(null,(2),cljs.core.drop.call(null,(1),bindings));
var tempnames = cljs.core.map.call(null,cljs.core.comp.call(null,cljs.core.gensym,cljs.core.name),names);
var binds = cljs.core.map.call(null,cljs.core.vector,names,vals);
var resets = cljs.core.reverse.call(null,cljs.core.map.call(null,cljs.core.vector,names,tempnames));
var bind_value = ((function (names,vals,tempnames,binds,resets){
return (function (p__28705){
var vec__28706 = p__28705;
var k = cljs.core.nth.call(null,vec__28706,(0),null);
var v = cljs.core.nth.call(null,vec__28706,(1),null);
return cljs.core._conj.call(null,(function (){var x__23719__auto__ = k;
return cljs.core._conj.call(null,(function (){var x__23719__auto____$1 = v;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto____$1);
})(),x__23719__auto__);
})(),new cljs.core.Symbol(null,"set!","set!",250714521,null));
});})(names,vals,tempnames,binds,resets))
;
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","let","cljs.core$macros/let",-160286726,null)),(function (){var x__23719__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core.interleave.call(null,tempnames,names)))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),cljs.core.map.call(null,bind_value,binds),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"try","try",-1273693247,null)),body,(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"finally","finally",-1065347064,null)),cljs.core.map.call(null,bind_value,resets))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
});

cljs.core$macros.with_redefs.cljs$lang$maxFixedArity = (3);

cljs.core$macros.with_redefs.cljs$lang$applyTo = (function (seq28701){
var G__28702 = cljs.core.first.call(null,seq28701);
var seq28701__$1 = cljs.core.next.call(null,seq28701);
var G__28703 = cljs.core.first.call(null,seq28701__$1);
var seq28701__$2 = cljs.core.next.call(null,seq28701__$1);
var G__28704 = cljs.core.first.call(null,seq28701__$2);
var seq28701__$3 = cljs.core.next.call(null,seq28701__$2);
return cljs.core$macros.with_redefs.cljs$core$IFn$_invoke$arity$variadic(G__28702,G__28703,G__28704,seq28701__$3);
});

cljs.core$macros.with_redefs.cljs$lang$macro = true;
/**
 * binding => var-symbol init-expr
 * 
 *   Creates new bindings for the (already-existing) vars, with the
 *   supplied initial values, executes the exprs in an implicit do, then
 *   re-establishes the bindings that existed before.  The new bindings
 *   are made in parallel (unlike let); all init-exprs are evaluated
 *   before the vars are bound to their new values.
 */
cljs.core$macros.binding = (function cljs$core$macros$binding(var_args){
var args__23962__auto__ = [];
var len__23955__auto___28714 = arguments.length;
var i__23956__auto___28715 = (0);
while(true){
if((i__23956__auto___28715 < len__23955__auto___28714)){
args__23962__auto__.push((arguments[i__23956__auto___28715]));

var G__28716 = (i__23956__auto___28715 + (1));
i__23956__auto___28715 = G__28716;
continue;
} else {
}
break;
}

var argseq__23963__auto__ = ((((3) < args__23962__auto__.length))?(new cljs.core.IndexedSeq(args__23962__auto__.slice((3)),(0),null)):null);
return cljs.core$macros.binding.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),argseq__23963__auto__);
});

cljs.core$macros.binding.cljs$core$IFn$_invoke$arity$variadic = (function (_AMPERSAND_form,_AMPERSAND_env,bindings,body){
var names = cljs.core.take_nth.call(null,(2),bindings);
cljs.analyzer.confirm_bindings.call(null,_AMPERSAND_env,names);

return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","with-redefs","cljs.core$macros/with-redefs",1489217801,null)),(function (){var x__23719__auto__ = bindings;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),body)));
});

cljs.core$macros.binding.cljs$lang$maxFixedArity = (3);

cljs.core$macros.binding.cljs$lang$applyTo = (function (seq28710){
var G__28711 = cljs.core.first.call(null,seq28710);
var seq28710__$1 = cljs.core.next.call(null,seq28710);
var G__28712 = cljs.core.first.call(null,seq28710__$1);
var seq28710__$2 = cljs.core.next.call(null,seq28710__$1);
var G__28713 = cljs.core.first.call(null,seq28710__$2);
var seq28710__$3 = cljs.core.next.call(null,seq28710__$2);
return cljs.core$macros.binding.cljs$core$IFn$_invoke$arity$variadic(G__28711,G__28712,G__28713,seq28710__$3);
});

cljs.core$macros.binding.cljs$lang$macro = true;
/**
 * Takes a binary predicate, an expression, and a set of clauses.
 *   Each clause can take the form of either:
 * 
 *   test-expr result-expr
 * 
 *   test-expr :>> result-fn
 * 
 *   Note :>> is an ordinary keyword.
 * 
 *   For each clause, (pred test-expr expr) is evaluated. If it returns
 *   logical true, the clause is a match. If a binary clause matches, the
 *   result-expr is returned, if a ternary clause matches, its result-fn,
 *   which must be a unary function, is called with the result of the
 *   predicate as its argument, the result of that call being the return
 *   value of condp. A single default expression can follow the clauses,
 *   and its value will be returned if no clause matches. If no default
 *   expression is provided and no clause matches, an
 *   IllegalArgumentException is thrown.
 */
cljs.core$macros.condp = (function cljs$core$macros$condp(var_args){
var args__23962__auto__ = [];
var len__23955__auto___28727 = arguments.length;
var i__23956__auto___28728 = (0);
while(true){
if((i__23956__auto___28728 < len__23955__auto___28727)){
args__23962__auto__.push((arguments[i__23956__auto___28728]));

var G__28729 = (i__23956__auto___28728 + (1));
i__23956__auto___28728 = G__28729;
continue;
} else {
}
break;
}

var argseq__23963__auto__ = ((((4) < args__23962__auto__.length))?(new cljs.core.IndexedSeq(args__23962__auto__.slice((4)),(0),null)):null);
return cljs.core$macros.condp.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]),argseq__23963__auto__);
});

cljs.core$macros.condp.cljs$core$IFn$_invoke$arity$variadic = (function (_AMPERSAND_form,_AMPERSAND_env,pred,expr,clauses){
var gpred = cljs.core.gensym.call(null,"pred__");
var gexpr = cljs.core.gensym.call(null,"expr__");
var emit = ((function (gpred,gexpr){
return (function cljs$core$macros$emit(pred__$1,expr__$1,args){
var vec__28725 = cljs.core.split_at.call(null,((cljs.core._EQ_.call(null,new cljs.core.Keyword(null,">>",">>",-277509267),cljs.core.second.call(null,args)))?(3):(2)),args);
var vec__28726 = cljs.core.nth.call(null,vec__28725,(0),null);
var a = cljs.core.nth.call(null,vec__28726,(0),null);
var b = cljs.core.nth.call(null,vec__28726,(1),null);
var c = cljs.core.nth.call(null,vec__28726,(2),null);
var clause = vec__28726;
var more = cljs.core.nth.call(null,vec__28725,(1),null);
var n = cljs.core.count.call(null,clause);
if(cljs.core._EQ_.call(null,(0),n)){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"throw","throw",595905694,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("js","Error.","js/Error.",750655924,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","str","cljs.core/str",-1971828991,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,"No matching clause: "),(function (){var x__23719__auto__ = expr__$1;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
} else {
if(cljs.core._EQ_.call(null,(1),n)){
return a;
} else {
if(cljs.core._EQ_.call(null,(2),n)){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"if","if",1181717262,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,(function (){var x__23719__auto__ = pred__$1;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = a;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = expr__$1;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = b;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs$core$macros$emit.call(null,pred__$1,expr__$1,more);
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
} else {
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","if-let","cljs.core$macros/if-let",1291543946,null)),(function (){var x__23719__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"p__28717__auto__","p__28717__auto__",1887811086,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,(function (){var x__23719__auto__ = pred__$1;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = a;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = expr__$1;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})()))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,(function (){var x__23719__auto__ = c;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"p__28717__auto__","p__28717__auto__",1887811086,null)))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs$core$macros$emit.call(null,pred__$1,expr__$1,more);
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));

}
}
}
});})(gpred,gexpr))
;
var gres = cljs.core.gensym.call(null,"res__");
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","let","cljs.core$macros/let",-160286726,null)),(function (){var x__23719__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,(function (){var x__23719__auto__ = gpred;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = pred;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = gexpr;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = expr;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})()))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = emit.call(null,gpred,gexpr,clauses);
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
});

cljs.core$macros.condp.cljs$lang$maxFixedArity = (4);

cljs.core$macros.condp.cljs$lang$applyTo = (function (seq28718){
var G__28719 = cljs.core.first.call(null,seq28718);
var seq28718__$1 = cljs.core.next.call(null,seq28718);
var G__28720 = cljs.core.first.call(null,seq28718__$1);
var seq28718__$2 = cljs.core.next.call(null,seq28718__$1);
var G__28721 = cljs.core.first.call(null,seq28718__$2);
var seq28718__$3 = cljs.core.next.call(null,seq28718__$2);
var G__28722 = cljs.core.first.call(null,seq28718__$3);
var seq28718__$4 = cljs.core.next.call(null,seq28718__$3);
return cljs.core$macros.condp.cljs$core$IFn$_invoke$arity$variadic(G__28719,G__28720,G__28721,G__28722,seq28718__$4);
});

cljs.core$macros.condp.cljs$lang$macro = true;
cljs.core$macros.assoc_test = (function cljs$core$macros$assoc_test(m,test,expr,env){
if(cljs.core.contains_QMARK_.call(null,m,test)){
throw (new Error([cljs.core.str("Duplicate case test constant '"),cljs.core.str(test),cljs.core.str("'"),cljs.core.str((cljs.core.truth_(new cljs.core.Keyword(null,"line","line",212345235).cljs$core$IFn$_invoke$arity$1(env))?[cljs.core.str(" on line "),cljs.core.str(new cljs.core.Keyword(null,"line","line",212345235).cljs$core$IFn$_invoke$arity$1(env)),cljs.core.str(" "),cljs.core.str(cljs.analyzer._STAR_cljs_file_STAR_)].join(''):null))].join('')));
} else {
return cljs.core.assoc.call(null,m,test,expr);
}
});
cljs.core$macros.const_QMARK_ = (function cljs$core$macros$const_QMARK_(env,x){
var m = (function (){var and__22873__auto__ = cljs.core.list_QMARK_.call(null,x);
if(and__22873__auto__){
return cljs.analyzer.resolve_var.call(null,env,cljs.core.last.call(null,x));
} else {
return and__22873__auto__;
}
})();
if(cljs.core.truth_(m)){
return cljs.core.get.call(null,m,new cljs.core.Keyword(null,"const","const",1709929842));
} else {
return null;
}
});
/**
 * Takes an expression, and a set of clauses.
 * 
 *   Each clause can take the form of either:
 * 
 *   test-constant result-expr
 * 
 *   (test-constant1 ... test-constantN)  result-expr
 * 
 *   The test-constants are not evaluated. They must be compile-time
 *   literals, and need not be quoted.  If the expression is equal to a
 *   test-constant, the corresponding result-expr is returned. A single
 *   default expression can follow the clauses, and its value will be
 *   returned if no clause matches. If no default expression is provided
 *   and no clause matches, an Error is thrown.
 * 
 *   Unlike cond and condp, case does a constant-time dispatch, the
 *   clauses are not considered sequentially.  All manner of constant
 *   expressions are acceptable in case, including numbers, strings,
 *   symbols, keywords, and (ClojureScript) composites thereof. Note that since
 *   lists are used to group multiple constants that map to the same
 *   expression, a vector can be used to match a list if needed. The
 *   test-constants need not be all of the same type.
 */
cljs.core$macros.case$ = (function cljs$core$macros$case(var_args){
var args__23962__auto__ = [];
var len__23955__auto___28744 = arguments.length;
var i__23956__auto___28745 = (0);
while(true){
if((i__23956__auto___28745 < len__23955__auto___28744)){
args__23962__auto__.push((arguments[i__23956__auto___28745]));

var G__28746 = (i__23956__auto___28745 + (1));
i__23956__auto___28745 = G__28746;
continue;
} else {
}
break;
}

var argseq__23963__auto__ = ((((3) < args__23962__auto__.length))?(new cljs.core.IndexedSeq(args__23962__auto__.slice((3)),(0),null)):null);
return cljs.core$macros.case$.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),argseq__23963__auto__);
});

cljs.core$macros.case$.cljs$core$IFn$_invoke$arity$variadic = (function (_AMPERSAND_form,_AMPERSAND_env,e,clauses){
var default$ = ((cljs.core.odd_QMARK_.call(null,cljs.core.count.call(null,clauses)))?cljs.core.last.call(null,clauses):cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"throw","throw",595905694,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("js","Error.","js/Error.",750655924,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","str","cljs.core/str",-1971828991,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,"No matching clause: "),(function (){var x__23719__auto__ = e;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})()))));
var env = _AMPERSAND_env;
var pairs = cljs.core.reduce.call(null,((function (default$,env){
return (function (m,p__28738){
var vec__28739 = p__28738;
var test = cljs.core.nth.call(null,vec__28739,(0),null);
var expr = cljs.core.nth.call(null,vec__28739,(1),null);
if(cljs.core.seq_QMARK_.call(null,test)){
return cljs.core.reduce.call(null,((function (vec__28739,test,expr,default$,env){
return (function (m__$1,test__$1){
var test__$2 = (((test__$1 instanceof cljs.core.Symbol))?cljs.core._conj.call(null,(function (){var x__23719__auto__ = test__$1;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),new cljs.core.Symbol(null,"quote","quote",1377916282,null)):test__$1);
return cljs.core$macros.assoc_test.call(null,m__$1,test__$2,expr,env);
});})(vec__28739,test,expr,default$,env))
,m,test);
} else {
if((test instanceof cljs.core.Symbol)){
return cljs.core$macros.assoc_test.call(null,m,cljs.core._conj.call(null,(function (){var x__23719__auto__ = test;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),new cljs.core.Symbol(null,"quote","quote",1377916282,null)),expr,env);
} else {
return cljs.core$macros.assoc_test.call(null,m,test,expr,env);

}
}
});})(default$,env))
,cljs.core.PersistentArrayMap.EMPTY,cljs.core.partition.call(null,(2),clauses));
var esym = cljs.core.gensym.call(null);
var tests = cljs.core.keys.call(null,pairs);
if(cljs.core.every_QMARK_.call(null,cljs.core.some_fn.call(null,cljs.core.number_QMARK_,cljs.core.string_QMARK_,cljs.core.fnil.call(null,cljs.core.char_QMARK_,new cljs.core.Keyword(null,"nonchar","nonchar",-421759703)),((function (default$,env,pairs,esym,tests){
return (function (p1__28730_SHARP_){
return cljs.core$macros.const_QMARK_.call(null,env,p1__28730_SHARP_);
});})(default$,env,pairs,esym,tests))
),tests)){
var no_default = ((cljs.core.odd_QMARK_.call(null,cljs.core.count.call(null,clauses)))?cljs.core.butlast.call(null,clauses):clauses);
var tests__$1 = cljs.core.mapv.call(null,((function (no_default,default$,env,pairs,esym,tests){
return (function (p1__28731_SHARP_){
if(cljs.core.seq_QMARK_.call(null,p1__28731_SHARP_)){
return cljs.core.vec.call(null,p1__28731_SHARP_);
} else {
return new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [p1__28731_SHARP_], null);
}
});})(no_default,default$,env,pairs,esym,tests))
,cljs.core.take_nth.call(null,(2),no_default));
var thens = cljs.core.vec.call(null,cljs.core.take_nth.call(null,(2),cljs.core.drop.call(null,(1),no_default)));
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","let","cljs.core$macros/let",-160286726,null)),(function (){var x__23719__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,(function (){var x__23719__auto__ = esym;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = e;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})()))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"case*","case*",-1938255072,null)),(function (){var x__23719__auto__ = esym;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = tests__$1;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = thens;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = default$;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
} else {
if(cljs.core.every_QMARK_.call(null,cljs.core.keyword_QMARK_,tests)){
var tests__$1 = cljs.core.mapv.call(null,((function (default$,env,pairs,esym,tests){
return (function (p1__28733_SHARP_){
if(cljs.core.seq_QMARK_.call(null,p1__28733_SHARP_)){
return cljs.core.vec.call(null,p1__28733_SHARP_);
} else {
return new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [p1__28733_SHARP_], null);
}
});})(default$,env,pairs,esym,tests))
,cljs.core.vec.call(null,cljs.core.map.call(null,((function (default$,env,pairs,esym,tests){
return (function (p1__28732_SHARP_){
return [cljs.core.str(p1__28732_SHARP_)].join('').substring((1));
});})(default$,env,pairs,esym,tests))
,tests)));
var thens = cljs.core.vec.call(null,cljs.core.vals.call(null,pairs));
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","let","cljs.core$macros/let",-160286726,null)),(function (){var x__23719__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,(function (){var x__23719__auto__ = esym;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"if","if",1181717262,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","keyword?","cljs.core$macros/keyword?",1362730141,null)),(function (){var x__23719__auto__ = e;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,".-fqn",".-fqn",1246113027,null)),(function (){var x__23719__auto__ = e;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,null))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})()))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"case*","case*",-1938255072,null)),(function (){var x__23719__auto__ = esym;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = tests__$1;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = thens;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = default$;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
} else {
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","let","cljs.core$macros/let",-160286726,null)),(function (){var x__23719__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,(function (){var x__23719__auto__ = esym;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = e;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})()))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","cond","cljs.core$macros/cond",1626318471,null)),cljs.core.mapcat.call(null,((function (default$,env,pairs,esym,tests){
return (function (p__28742){
var vec__28743 = p__28742;
var m = cljs.core.nth.call(null,vec__28743,(0),null);
var c = cljs.core.nth.call(null,vec__28743,(1),null);
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","=","cljs.core/=",-1891498332,null)),(function (){var x__23719__auto__ = m;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = esym;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = c;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
});})(default$,env,pairs,esym,tests))
,pairs),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Keyword(null,"else","else",-1508377146)),(function (){var x__23719__auto__ = default$;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));

}
}
});

cljs.core$macros.case$.cljs$lang$maxFixedArity = (3);

cljs.core$macros.case$.cljs$lang$applyTo = (function (seq28734){
var G__28735 = cljs.core.first.call(null,seq28734);
var seq28734__$1 = cljs.core.next.call(null,seq28734);
var G__28736 = cljs.core.first.call(null,seq28734__$1);
var seq28734__$2 = cljs.core.next.call(null,seq28734__$1);
var G__28737 = cljs.core.first.call(null,seq28734__$2);
var seq28734__$3 = cljs.core.next.call(null,seq28734__$2);
return cljs.core$macros.case$.cljs$core$IFn$_invoke$arity$variadic(G__28735,G__28736,G__28737,seq28734__$3);
});

cljs.core$macros.case$.cljs$lang$macro = true;
/**
 * Evaluates expr and throws an exception if it does not evaluate to
 *   logical true.
 */
cljs.core$macros.assert = (function cljs$core$macros$assert(var_args){
var args28747 = [];
var len__23955__auto___28750 = arguments.length;
var i__23956__auto___28751 = (0);
while(true){
if((i__23956__auto___28751 < len__23955__auto___28750)){
args28747.push((arguments[i__23956__auto___28751]));

var G__28752 = (i__23956__auto___28751 + (1));
i__23956__auto___28751 = G__28752;
continue;
} else {
}
break;
}

var G__28749 = args28747.length;
switch (G__28749) {
case 3:
return cljs.core$macros.assert.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
case 4:
return cljs.core$macros.assert.cljs$core$IFn$_invoke$arity$4((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]));

break;
default:
throw (new Error([cljs.core.str("Invalid arity: "),cljs.core.str((args28747.length - (2)))].join('')));

}
});

cljs.core$macros.assert.cljs$core$IFn$_invoke$arity$3 = (function (_AMPERSAND_form,_AMPERSAND_env,x){
if(cljs.core.truth_(cljs.core._STAR_assert_STAR_)){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","when-not","cljs.core$macros/when-not",-764302244,null)),(function (){var x__23719__auto__ = x;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"throw","throw",595905694,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("js","Error.","js/Error.",750655924,null)),(function (){var x__23719__auto__ = [cljs.core.str("Assert failed: "),cljs.core.str(cljs.core.pr_str.call(null,x))].join('');
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
} else {
return null;
}
});

cljs.core$macros.assert.cljs$core$IFn$_invoke$arity$4 = (function (_AMPERSAND_form,_AMPERSAND_env,x,message){
if(cljs.core.truth_(cljs.core._STAR_assert_STAR_)){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","when-not","cljs.core$macros/when-not",-764302244,null)),(function (){var x__23719__auto__ = x;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"throw","throw",595905694,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("js","Error.","js/Error.",750655924,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","str","cljs.core/str",-1971828991,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,"Assert failed: "),(function (){var x__23719__auto__ = message;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,"\n"),(function (){var x__23719__auto__ = cljs.core.pr_str.call(null,x);
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
} else {
return null;
}
});

cljs.core$macros.assert.cljs$lang$maxFixedArity = 4;

cljs.core$macros.assert.cljs$lang$macro = true;
/**
 * List comprehension. Takes a vector of one or more
 * binding-form/collection-expr pairs, each followed by zero or more
 * modifiers, and yields a lazy sequence of evaluations of expr.
 * Collections are iterated in a nested fashion, rightmost fastest,
 * and nested coll-exprs can refer to bindings created in prior
 * binding-forms.  Supported modifiers are: :let [binding-form expr ...],
 * :while test, :when test.
 * 
 *   (take 100 (for [x (range 100000000) y (range 1000000) :while (< y x)]  [x y]))
 */
cljs.core$macros.for$ = (function cljs$core$macros$for(_AMPERSAND_form,_AMPERSAND_env,seq_exprs,body_expr){
if(cljs.core.vector_QMARK_.call(null,seq_exprs)){
} else {
throw cljs.core.ex_info.call(null,"for requires a vector for its binding",cljs.core.PersistentArrayMap.EMPTY);
}

if(cljs.core.even_QMARK_.call(null,cljs.core.count.call(null,seq_exprs))){
} else {
throw cljs.core.ex_info.call(null,"for requires an even number of forms in binding vector",cljs.core.PersistentArrayMap.EMPTY);
}


var to_groups = (function (seq_exprs__$1){
return cljs.core.reduce.call(null,(function (groups,p__28790){
var vec__28791 = p__28790;
var k = cljs.core.nth.call(null,vec__28791,(0),null);
var v = cljs.core.nth.call(null,vec__28791,(1),null);
if((k instanceof cljs.core.Keyword)){
return cljs.core.conj.call(null,cljs.core.pop.call(null,groups),cljs.core.conj.call(null,cljs.core.peek.call(null,groups),new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [k,v], null)));
} else {
return cljs.core.conj.call(null,groups,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [k,v], null));
}
}),cljs.core.PersistentVector.EMPTY,cljs.core.partition.call(null,(2),seq_exprs__$1));
});
var err = ((function (to_groups){
return (function() { 
var G__28821__delegate = function (msg){
throw cljs.core.ex_info.call(null,cljs.core.apply.call(null,cljs.core.str,msg),cljs.core.PersistentArrayMap.EMPTY);
};
var G__28821 = function (var_args){
var msg = null;
if (arguments.length > 0) {
var G__28822__i = 0, G__28822__a = new Array(arguments.length -  0);
while (G__28822__i < G__28822__a.length) {G__28822__a[G__28822__i] = arguments[G__28822__i + 0]; ++G__28822__i;}
  msg = new cljs.core.IndexedSeq(G__28822__a,0);
} 
return G__28821__delegate.call(this,msg);};
G__28821.cljs$lang$maxFixedArity = 0;
G__28821.cljs$lang$applyTo = (function (arglist__28823){
var msg = cljs.core.seq(arglist__28823);
return G__28821__delegate(msg);
});
G__28821.cljs$core$IFn$_invoke$arity$variadic = G__28821__delegate;
return G__28821;
})()
;})(to_groups))
;
var emit_bind = ((function (to_groups,err){
return (function cljs$core$macros$for_$_emit_bind(p__28792){
var vec__28807 = p__28792;
var vec__28808 = cljs.core.nth.call(null,vec__28807,(0),null);
var bind = cljs.core.nth.call(null,vec__28808,(0),null);
var expr = cljs.core.nth.call(null,vec__28808,(1),null);
var mod_pairs = cljs.core.nthnext.call(null,vec__28808,(2));
var vec__28809 = cljs.core.nthnext.call(null,vec__28807,(1));
var vec__28810 = cljs.core.nth.call(null,vec__28809,(0),null);
var _ = cljs.core.nth.call(null,vec__28810,(0),null);
var next_expr = cljs.core.nth.call(null,vec__28810,(1),null);
var next_groups = vec__28809;
var giter = cljs.core.gensym.call(null,"iter__");
var gxs = cljs.core.gensym.call(null,"s__");
var do_mod = ((function (giter,gxs,vec__28807,vec__28808,bind,expr,mod_pairs,vec__28809,vec__28810,_,next_expr,next_groups,to_groups,err){
return (function cljs$core$macros$for_$_emit_bind_$_do_mod(p__28811){
var vec__28814 = p__28811;
var vec__28815 = cljs.core.nth.call(null,vec__28814,(0),null);
var k = cljs.core.nth.call(null,vec__28815,(0),null);
var v = cljs.core.nth.call(null,vec__28815,(1),null);
var pair = vec__28815;
var etc = cljs.core.nthnext.call(null,vec__28814,(1));
if(cljs.core._EQ_.call(null,k,new cljs.core.Keyword(null,"let","let",-1282412701))){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","let","cljs.core$macros/let",-160286726,null)),(function (){var x__23719__auto__ = v;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs$core$macros$for_$_emit_bind_$_do_mod.call(null,etc);
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
} else {
if(cljs.core._EQ_.call(null,k,new cljs.core.Keyword(null,"while","while",963117786))){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","when","cljs.core$macros/when",328457725,null)),(function (){var x__23719__auto__ = v;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs$core$macros$for_$_emit_bind_$_do_mod.call(null,etc);
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
} else {
if(cljs.core._EQ_.call(null,k,new cljs.core.Keyword(null,"when","when",-576417306))){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"if","if",1181717262,null)),(function (){var x__23719__auto__ = v;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs$core$macros$for_$_emit_bind_$_do_mod.call(null,etc);
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"recur","recur",1202958259,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","rest","cljs.core/rest",-285075455,null)),(function (){var x__23719__auto__ = gxs;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
} else {
if((k instanceof cljs.core.Keyword)){
return err.call(null,"Invalid 'for' keyword ",k);
} else {
if(cljs.core.truth_(next_groups)){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","let","cljs.core$macros/let",-160286726,null)),(function (){var x__23719__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"iterys__28754__auto__","iterys__28754__auto__",1286199222,null)),(function (){var x__23719__auto__ = cljs$core$macros$for_$_emit_bind.call(null,next_groups);
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"fs__28755__auto__","fs__28755__auto__",1100487672,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","seq","cljs.core/seq",-1649497689,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"iterys__28754__auto__","iterys__28754__auto__",1286199222,null)),(function (){var x__23719__auto__ = next_expr;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})()))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"if","if",1181717262,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"fs__28755__auto__","fs__28755__auto__",1100487672,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","concat","cljs.core/concat",-1133584918,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"fs__28755__auto__","fs__28755__auto__",1100487672,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,(function (){var x__23719__auto__ = giter;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","rest","cljs.core/rest",-285075455,null)),(function (){var x__23719__auto__ = gxs;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"recur","recur",1202958259,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","rest","cljs.core/rest",-285075455,null)),(function (){var x__23719__auto__ = gxs;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
} else {
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","cons","cljs.core/cons",96507417,null)),(function (){var x__23719__auto__ = body_expr;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,(function (){var x__23719__auto__ = giter;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","rest","cljs.core/rest",-285075455,null)),(function (){var x__23719__auto__ = gxs;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));

}
}
}
}
}
});})(giter,gxs,vec__28807,vec__28808,bind,expr,mod_pairs,vec__28809,vec__28810,_,next_expr,next_groups,to_groups,err))
;
if(cljs.core.truth_(next_groups)){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","fn","cljs.core$macros/fn",-187522821,null)),(function (){var x__23719__auto__ = giter;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,(function (){var x__23719__auto__ = gxs;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})()))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","lazy-seq","cljs.core$macros/lazy-seq",806482650,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","loop","cljs.core$macros/loop",1731108390,null)),(function (){var x__23719__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,(function (){var x__23719__auto__ = gxs;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = gxs;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})()))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","when-first","cljs.core$macros/when-first",-840670160,null)),(function (){var x__23719__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,(function (){var x__23719__auto__ = bind;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = gxs;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})()))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = do_mod.call(null,mod_pairs);
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
} else {
var gi = cljs.core.gensym.call(null,"i__");
var gb = cljs.core.gensym.call(null,"b__");
var do_cmod = ((function (gi,gb,giter,gxs,do_mod,vec__28807,vec__28808,bind,expr,mod_pairs,vec__28809,vec__28810,_,next_expr,next_groups,to_groups,err){
return (function cljs$core$macros$for_$_emit_bind_$_do_cmod(p__28816){
var vec__28819 = p__28816;
var vec__28820 = cljs.core.nth.call(null,vec__28819,(0),null);
var k = cljs.core.nth.call(null,vec__28820,(0),null);
var v = cljs.core.nth.call(null,vec__28820,(1),null);
var pair = vec__28820;
var etc = cljs.core.nthnext.call(null,vec__28819,(1));
if(cljs.core._EQ_.call(null,k,new cljs.core.Keyword(null,"let","let",-1282412701))){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","let","cljs.core$macros/let",-160286726,null)),(function (){var x__23719__auto__ = v;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs$core$macros$for_$_emit_bind_$_do_cmod.call(null,etc);
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
} else {
if(cljs.core._EQ_.call(null,k,new cljs.core.Keyword(null,"while","while",963117786))){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","when","cljs.core$macros/when",328457725,null)),(function (){var x__23719__auto__ = v;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs$core$macros$for_$_emit_bind_$_do_cmod.call(null,etc);
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
} else {
if(cljs.core._EQ_.call(null,k,new cljs.core.Keyword(null,"when","when",-576417306))){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"if","if",1181717262,null)),(function (){var x__23719__auto__ = v;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs$core$macros$for_$_emit_bind_$_do_cmod.call(null,etc);
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"recur","recur",1202958259,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","unchecked-inc","cljs.core$macros/unchecked-inc",-1615365330,null)),(function (){var x__23719__auto__ = gi;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
} else {
if((k instanceof cljs.core.Keyword)){
return err.call(null,"Invalid 'for' keyword ",k);
} else {
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"do","do",1686842252,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","chunk-append","cljs.core/chunk-append",-243671470,null)),(function (){var x__23719__auto__ = gb;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = body_expr;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"recur","recur",1202958259,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","unchecked-inc","cljs.core$macros/unchecked-inc",-1615365330,null)),(function (){var x__23719__auto__ = gi;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));

}
}
}
}
});})(gi,gb,giter,gxs,do_mod,vec__28807,vec__28808,bind,expr,mod_pairs,vec__28809,vec__28810,_,next_expr,next_groups,to_groups,err))
;
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","fn","cljs.core$macros/fn",-187522821,null)),(function (){var x__23719__auto__ = giter;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,(function (){var x__23719__auto__ = gxs;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})()))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","lazy-seq","cljs.core$macros/lazy-seq",806482650,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","loop","cljs.core$macros/loop",1731108390,null)),(function (){var x__23719__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,(function (){var x__23719__auto__ = gxs;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = gxs;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})()))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","when-let","cljs.core$macros/when-let",-2004472648,null)),(function (){var x__23719__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,(function (){var x__23719__auto__ = gxs;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","seq","cljs.core/seq",-1649497689,null)),(function (){var x__23719__auto__ = gxs;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})()))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"if","if",1181717262,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","chunked-seq?","cljs.core/chunked-seq?",-712922369,null)),(function (){var x__23719__auto__ = gxs;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","let","cljs.core$macros/let",-160286726,null)),(function (){var x__23719__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"c__28756__auto__","c__28756__auto__",-1964064242,null)),(function (){var x__23719__auto__ = cljs.core.with_meta.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","chunk-first","cljs.core/chunk-first",-1157877305,null)),(function (){var x__23719__auto__ = gxs;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})()))),cljs.core.apply.call(null,cljs.core.array_map,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Keyword(null,"file","file",-1269645878)),cljs.core._conj.call(null,cljs.core.List.EMPTY,"/Users/clumsyjedi/workspace/clack/.cljs_rhino_repl/cljs/core.cljc"),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Keyword(null,"line","line",212345235)),cljs.core._conj.call(null,cljs.core.List.EMPTY,2279),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Keyword(null,"column","column",2078222095)),cljs.core._conj.call(null,cljs.core.List.EMPTY,52),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Keyword(null,"end-line","end-line",1837326455)),cljs.core._conj.call(null,cljs.core.List.EMPTY,2279),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Keyword(null,"end-column","end-column",1425389514)),cljs.core._conj.call(null,cljs.core.List.EMPTY,82),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Keyword(null,"tag","tag",-1290361223)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","not-native","cljs.core/not-native",-1716909265,null)))))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"size__28757__auto__","size__28757__auto__",-1013260850,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","count","cljs.core/count",-921270233,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"c__28756__auto__","c__28756__auto__",-1964064242,null)))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = gb;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","chunk-buffer","cljs.core/chunk-buffer",14093626,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"size__28757__auto__","size__28757__auto__",-1013260850,null)))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})()))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"if","if",1181717262,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","coercive-boolean","cljs.core$macros/coercive-boolean",-450758280,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","loop","cljs.core$macros/loop",1731108390,null)),(function (){var x__23719__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,(function (){var x__23719__auto__ = gi;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,(0))))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"if","if",1181717262,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","<","cljs.core$macros/<",371512596,null)),(function (){var x__23719__auto__ = gi;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"size__28757__auto__","size__28757__auto__",-1013260850,null)))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","let","cljs.core$macros/let",-160286726,null)),(function (){var x__23719__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,(function (){var x__23719__auto__ = bind;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","-nth","cljs.core/-nth",504234802,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"c__28756__auto__","c__28756__auto__",-1964064242,null)),(function (){var x__23719__auto__ = gi;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})()))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = do_cmod.call(null,mod_pairs);
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,true))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","chunk-cons","cljs.core/chunk-cons",-250075688,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","chunk","cljs.core/chunk",847936424,null)),(function (){var x__23719__auto__ = gb;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,(function (){var x__23719__auto__ = giter;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","chunk-rest","cljs.core/chunk-rest",-398161143,null)),(function (){var x__23719__auto__ = gxs;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","chunk-cons","cljs.core/chunk-cons",-250075688,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","chunk","cljs.core/chunk",847936424,null)),(function (){var x__23719__auto__ = gb;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,null))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","let","cljs.core$macros/let",-160286726,null)),(function (){var x__23719__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,(function (){var x__23719__auto__ = bind;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","first","cljs.core/first",-752535972,null)),(function (){var x__23719__auto__ = gxs;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})()))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = do_mod.call(null,mod_pairs);
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
}
});})(to_groups,err))
;
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","let","cljs.core$macros/let",-160286726,null)),(function (){var x__23719__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"iter__28758__auto__","iter__28758__auto__",1870165787,null)),(function (){var x__23719__auto__ = emit_bind.call(null,to_groups.call(null,seq_exprs));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})()))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"iter__28758__auto__","iter__28758__auto__",1870165787,null)),(function (){var x__23719__auto__ = cljs.core.second.call(null,seq_exprs);
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
});

cljs.core$macros.for$.cljs$lang$macro = true;
/**
 * Repeatedly executes body (presumably for side-effects) with
 *   bindings and filtering as provided by "for".  Does not retain
 *   the head of the sequence. Returns nil.
 */
cljs.core$macros.doseq = (function cljs$core$macros$doseq(var_args){
var args__23962__auto__ = [];
var len__23955__auto___28829 = arguments.length;
var i__23956__auto___28830 = (0);
while(true){
if((i__23956__auto___28830 < len__23955__auto___28829)){
args__23962__auto__.push((arguments[i__23956__auto___28830]));

var G__28831 = (i__23956__auto___28830 + (1));
i__23956__auto___28830 = G__28831;
continue;
} else {
}
break;
}

var argseq__23963__auto__ = ((((3) < args__23962__auto__.length))?(new cljs.core.IndexedSeq(args__23962__auto__.slice((3)),(0),null)):null);
return cljs.core$macros.doseq.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),argseq__23963__auto__);
});

cljs.core$macros.doseq.cljs$core$IFn$_invoke$arity$variadic = (function (_AMPERSAND_form,_AMPERSAND_env,seq_exprs,body){
if(cljs.core.vector_QMARK_.call(null,seq_exprs)){
} else {
throw cljs.core.ex_info.call(null,"doseq requires a vector for its binding",cljs.core.PersistentArrayMap.EMPTY);
}

if(cljs.core.even_QMARK_.call(null,cljs.core.count.call(null,seq_exprs))){
} else {
throw cljs.core.ex_info.call(null,"doseq requires an even number of forms in binding vector",cljs.core.PersistentArrayMap.EMPTY);
}


var err = (function() { 
var G__28832__delegate = function (msg){
throw cljs.core.ex_info.call(null,cljs.core.apply.call(null,cljs.core.str,msg),cljs.core.PersistentArrayMap.EMPTY);
};
var G__28832 = function (var_args){
var msg = null;
if (arguments.length > 0) {
var G__28833__i = 0, G__28833__a = new Array(arguments.length -  0);
while (G__28833__i < G__28833__a.length) {G__28833__a[G__28833__i] = arguments[G__28833__i + 0]; ++G__28833__i;}
  msg = new cljs.core.IndexedSeq(G__28833__a,0);
} 
return G__28832__delegate.call(this,msg);};
G__28832.cljs$lang$maxFixedArity = 0;
G__28832.cljs$lang$applyTo = (function (arglist__28834){
var msg = cljs.core.seq(arglist__28834);
return G__28832__delegate(msg);
});
G__28832.cljs$core$IFn$_invoke$arity$variadic = G__28832__delegate;
return G__28832;
})()
;
var step = ((function (err){
return (function cljs$core$macros$step(recform,exprs){
if(cljs.core.not.call(null,exprs)){
return new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [true,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"do","do",1686842252,null)),body)))], null);
} else {
var k = cljs.core.first.call(null,exprs);
var v = cljs.core.second.call(null,exprs);
var seqsym = cljs.core.gensym.call(null,"seq__");
var recform__$1 = (((k instanceof cljs.core.Keyword))?recform:cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"recur","recur",1202958259,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","next","cljs.core/next",-1291438473,null)),(function (){var x__23719__auto__ = seqsym;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,null),cljs.core._conj.call(null,cljs.core.List.EMPTY,(0)),cljs.core._conj.call(null,cljs.core.List.EMPTY,(0))))));
var steppair = cljs$core$macros$step.call(null,recform__$1,cljs.core.nnext.call(null,exprs));
var needrec = steppair.call(null,(0));
var subform = steppair.call(null,(1));
if(cljs.core._EQ_.call(null,k,new cljs.core.Keyword(null,"let","let",-1282412701))){
return new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [needrec,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","let","cljs.core$macros/let",-160286726,null)),(function (){var x__23719__auto__ = v;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = subform;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())))], null);
} else {
if(cljs.core._EQ_.call(null,k,new cljs.core.Keyword(null,"while","while",963117786))){
return new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [false,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","when","cljs.core$macros/when",328457725,null)),(function (){var x__23719__auto__ = v;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = subform;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(cljs.core.truth_(needrec)?new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [recform__$1], null):null))))], null);
} else {
if(cljs.core._EQ_.call(null,k,new cljs.core.Keyword(null,"when","when",-576417306))){
return new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [false,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"if","if",1181717262,null)),(function (){var x__23719__auto__ = v;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"do","do",1686842252,null)),(function (){var x__23719__auto__ = subform;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(cljs.core.truth_(needrec)?new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [recform__$1], null):null))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = recform__$1;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())))], null);
} else {
if((k instanceof cljs.core.Keyword)){
return err.call(null,"Invalid 'doseq' keyword",k);
} else {
var chunksym = cljs.core.with_meta.call(null,cljs.core.gensym.call(null,"chunk__"),new cljs.core.PersistentArrayMap(null, 1, [new cljs.core.Keyword(null,"tag","tag",-1290361223),new cljs.core.Symbol(null,"not-native","not-native",-236392494,null)], null));
var countsym = cljs.core.gensym.call(null,"count__");
var isym = cljs.core.gensym.call(null,"i__");
var recform_chunk = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"recur","recur",1202958259,null)),(function (){var x__23719__auto__ = seqsym;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = chunksym;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = countsym;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","unchecked-inc","cljs.core$macros/unchecked-inc",-1615365330,null)),(function (){var x__23719__auto__ = isym;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
var steppair_chunk = cljs$core$macros$step.call(null,recform_chunk,cljs.core.nnext.call(null,exprs));
var subform_chunk = steppair_chunk.call(null,(1));
return new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [true,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","loop","cljs.core$macros/loop",1731108390,null)),(function (){var x__23719__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,(function (){var x__23719__auto__ = seqsym;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","seq","cljs.core/seq",-1649497689,null)),(function (){var x__23719__auto__ = v;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = chunksym;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,null),(function (){var x__23719__auto__ = countsym;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,(0)),(function (){var x__23719__auto__ = isym;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,(0))))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"if","if",1181717262,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","coercive-boolean","cljs.core$macros/coercive-boolean",-450758280,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","<","cljs.core$macros/<",371512596,null)),(function (){var x__23719__auto__ = isym;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = countsym;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","let","cljs.core$macros/let",-160286726,null)),(function (){var x__23719__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,(function (){var x__23719__auto__ = k;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","-nth","cljs.core/-nth",504234802,null)),(function (){var x__23719__auto__ = chunksym;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = isym;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})()))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = subform_chunk;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(cljs.core.truth_(needrec)?new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [recform_chunk], null):null))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","when-let","cljs.core$macros/when-let",-2004472648,null)),(function (){var x__23719__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,(function (){var x__23719__auto__ = seqsym;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","seq","cljs.core/seq",-1649497689,null)),(function (){var x__23719__auto__ = seqsym;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})()))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"if","if",1181717262,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","chunked-seq?","cljs.core/chunked-seq?",-712922369,null)),(function (){var x__23719__auto__ = seqsym;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","let","cljs.core$macros/let",-160286726,null)),(function (){var x__23719__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"c__28824__auto__","c__28824__auto__",-1540836508,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","chunk-first","cljs.core/chunk-first",-1157877305,null)),(function (){var x__23719__auto__ = seqsym;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})()))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"recur","recur",1202958259,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","chunk-rest","cljs.core/chunk-rest",-398161143,null)),(function (){var x__23719__auto__ = seqsym;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"c__28824__auto__","c__28824__auto__",-1540836508,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","count","cljs.core/count",-921270233,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"c__28824__auto__","c__28824__auto__",-1540836508,null)))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,(0)))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","let","cljs.core$macros/let",-160286726,null)),(function (){var x__23719__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,(function (){var x__23719__auto__ = k;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","first","cljs.core/first",-752535972,null)),(function (){var x__23719__auto__ = seqsym;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})()))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = subform;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(cljs.core.truth_(needrec)?new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [recform__$1], null):null))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())))], null);

}
}
}
}
}
});})(err))
;
return cljs.core.nth.call(null,step.call(null,null,cljs.core.seq.call(null,seq_exprs)),(1));
});

cljs.core$macros.doseq.cljs$lang$maxFixedArity = (3);

cljs.core$macros.doseq.cljs$lang$applyTo = (function (seq28825){
var G__28826 = cljs.core.first.call(null,seq28825);
var seq28825__$1 = cljs.core.next.call(null,seq28825);
var G__28827 = cljs.core.first.call(null,seq28825__$1);
var seq28825__$2 = cljs.core.next.call(null,seq28825__$1);
var G__28828 = cljs.core.first.call(null,seq28825__$2);
var seq28825__$3 = cljs.core.next.call(null,seq28825__$2);
return cljs.core$macros.doseq.cljs$core$IFn$_invoke$arity$variadic(G__28826,G__28827,G__28828,seq28825__$3);
});

cljs.core$macros.doseq.cljs$lang$macro = true;
cljs.core$macros.array = (function cljs$core$macros$array(var_args){
var args__23962__auto__ = [];
var len__23955__auto___28838 = arguments.length;
var i__23956__auto___28839 = (0);
while(true){
if((i__23956__auto___28839 < len__23955__auto___28838)){
args__23962__auto__.push((arguments[i__23956__auto___28839]));

var G__28840 = (i__23956__auto___28839 + (1));
i__23956__auto___28839 = G__28840;
continue;
} else {
}
break;
}

var argseq__23963__auto__ = ((((2) < args__23962__auto__.length))?(new cljs.core.IndexedSeq(args__23962__auto__.slice((2)),(0),null)):null);
return cljs.core$macros.array.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__23963__auto__);
});

cljs.core$macros.array.cljs$core$IFn$_invoke$arity$variadic = (function (_AMPERSAND_form,_AMPERSAND_env,rest){
var xs_str = cljs.core.apply.call(null,cljs.core.str,cljs.core.interpose.call(null,",",cljs.core.take.call(null,cljs.core.count.call(null,rest),cljs.core.repeat.call(null,"~{}"))));
return cljs.core.vary_meta.call(null,cljs.core.list_STAR_.call(null,new cljs.core.Symbol(null,"js*","js*",-1134233646,null),[cljs.core.str("["),cljs.core.str(xs_str),cljs.core.str("]")].join(''),rest),cljs.core.assoc,new cljs.core.Keyword(null,"tag","tag",-1290361223),new cljs.core.Symbol(null,"array","array",-440182315,null));
});

cljs.core$macros.array.cljs$lang$maxFixedArity = (2);

cljs.core$macros.array.cljs$lang$applyTo = (function (seq28835){
var G__28836 = cljs.core.first.call(null,seq28835);
var seq28835__$1 = cljs.core.next.call(null,seq28835);
var G__28837 = cljs.core.first.call(null,seq28835__$1);
var seq28835__$2 = cljs.core.next.call(null,seq28835__$1);
return cljs.core$macros.array.cljs$core$IFn$_invoke$arity$variadic(G__28836,G__28837,seq28835__$2);
});

cljs.core$macros.array.cljs$lang$macro = true;
cljs.core$macros.make_array = (function cljs$core$macros$make_array(var_args){
var args28844 = [];
var len__23955__auto___28852 = arguments.length;
var i__23956__auto___28853 = (0);
while(true){
if((i__23956__auto___28853 < len__23955__auto___28852)){
args28844.push((arguments[i__23956__auto___28853]));

var G__28854 = (i__23956__auto___28853 + (1));
i__23956__auto___28853 = G__28854;
continue;
} else {
}
break;
}

var G__28851 = args28844.length;
switch (G__28851) {
case 3:
return cljs.core$macros.make_array.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
case 4:
return cljs.core$macros.make_array.cljs$core$IFn$_invoke$arity$4((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]));

break;
default:
var argseq__23974__auto__ = (new cljs.core.IndexedSeq(args28844.slice((4)),(0),null));
return cljs.core$macros.make_array.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]),argseq__23974__auto__);

}
});

cljs.core$macros.make_array.cljs$core$IFn$_invoke$arity$3 = (function (_AMPERSAND_form,_AMPERSAND_env,size){
return cljs.core.vary_meta.call(null,((typeof size === 'number')?cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","array","cljs.core$macros/array",49650437,null)),cljs.core.take.call(null,size,cljs.core.repeat.call(null,null))))):cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("js","Array.","js/Array.",1235645307,null)),(function (){var x__23719__auto__ = size;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())))),cljs.core.assoc,new cljs.core.Keyword(null,"tag","tag",-1290361223),new cljs.core.Symbol(null,"array","array",-440182315,null));
});

cljs.core$macros.make_array.cljs$core$IFn$_invoke$arity$4 = (function (_AMPERSAND_form,_AMPERSAND_env,type,size){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","make-array","cljs.core/make-array",-1802166799,null)),(function (){var x__23719__auto__ = size;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
});

cljs.core$macros.make_array.cljs$core$IFn$_invoke$arity$variadic = (function (_AMPERSAND_form,_AMPERSAND_env,type,size,more_sizes){
return cljs.core.vary_meta.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","let","cljs.core$macros/let",-160286726,null)),(function (){var x__23719__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"dims__28841__auto__","dims__28841__auto__",89067202,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","list","cljs.core$macros/list",-1408486806,null)),more_sizes)));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"dimarray__28842__auto__","dimarray__28842__auto__",-11729843,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","make-array","cljs.core/make-array",-1802166799,null)),(function (){var x__23719__auto__ = size;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})()))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","dotimes","cljs.core$macros/dotimes",-1407597661,null)),(function (){var x__23719__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"i__28843__auto__","i__28843__auto__",1218269007,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","alength","cljs.core$macros/alength",-683052937,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"dimarray__28842__auto__","dimarray__28842__auto__",-11729843,null)))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})()))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","aset","cljs.core$macros/aset",-693176374,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"dimarray__28842__auto__","dimarray__28842__auto__",-11729843,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"i__28843__auto__","i__28843__auto__",1218269007,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","apply","cljs.core/apply",1757277831,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","make-array","cljs.core/make-array",-1802166799,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,null),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"dims__28841__auto__","dims__28841__auto__",89067202,null)))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"dimarray__28842__auto__","dimarray__28842__auto__",-11729843,null))))),cljs.core.assoc,new cljs.core.Keyword(null,"tag","tag",-1290361223),new cljs.core.Symbol(null,"array","array",-440182315,null));
});

cljs.core$macros.make_array.cljs$lang$applyTo = (function (seq28845){
var G__28846 = cljs.core.first.call(null,seq28845);
var seq28845__$1 = cljs.core.next.call(null,seq28845);
var G__28847 = cljs.core.first.call(null,seq28845__$1);
var seq28845__$2 = cljs.core.next.call(null,seq28845__$1);
var G__28848 = cljs.core.first.call(null,seq28845__$2);
var seq28845__$3 = cljs.core.next.call(null,seq28845__$2);
var G__28849 = cljs.core.first.call(null,seq28845__$3);
var seq28845__$4 = cljs.core.next.call(null,seq28845__$3);
return cljs.core$macros.make_array.cljs$core$IFn$_invoke$arity$variadic(G__28846,G__28847,G__28848,G__28849,seq28845__$4);
});

cljs.core$macros.make_array.cljs$lang$maxFixedArity = (4);

cljs.core$macros.make_array.cljs$lang$macro = true;
cljs.core$macros.list = (function cljs$core$macros$list(var_args){
var args28857 = [];
var len__23955__auto___28864 = arguments.length;
var i__23956__auto___28865 = (0);
while(true){
if((i__23956__auto___28865 < len__23955__auto___28864)){
args28857.push((arguments[i__23956__auto___28865]));

var G__28866 = (i__23956__auto___28865 + (1));
i__23956__auto___28865 = G__28866;
continue;
} else {
}
break;
}

var G__28863 = args28857.length;
switch (G__28863) {
case 2:
return cljs.core$macros.list.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
default:
var argseq__23974__auto__ = (new cljs.core.IndexedSeq(args28857.slice((3)),(0),null));
return cljs.core$macros.list.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),argseq__23974__auto__);

}
});

cljs.core$macros.list.cljs$core$IFn$_invoke$arity$2 = (function (_AMPERSAND_form,_AMPERSAND_env){
return cljs.core.list(new cljs.core.Symbol(null,".-EMPTY",".-EMPTY",-471586691,null),new cljs.core.Symbol("cljs.core","List","cljs.core/List",1708954352,null));
});

cljs.core$macros.list.cljs$core$IFn$_invoke$arity$variadic = (function (_AMPERSAND_form,_AMPERSAND_env,x,xs){
if(cljs.core._EQ_.call(null,new cljs.core.Keyword(null,"constant","constant",-379609303),new cljs.core.Keyword(null,"op","op",-1882987955).cljs$core$IFn$_invoke$arity$1(cljs.analyzer.analyze.call(null,_AMPERSAND_env,x)))){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","-conj","cljs.core/-conj",2040622670,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","list","cljs.core$macros/list",-1408486806,null)),xs)));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = x;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
} else {
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","let","cljs.core$macros/let",-160286726,null)),(function (){var x__23719__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"x__28856__auto__","x__28856__auto__",-974522493,null)),(function (){var x__23719__auto__ = x;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})()))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","-conj","cljs.core/-conj",2040622670,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","list","cljs.core$macros/list",-1408486806,null)),xs)));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"x__28856__auto__","x__28856__auto__",-974522493,null)))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
}
});

cljs.core$macros.list.cljs$lang$applyTo = (function (seq28858){
var G__28859 = cljs.core.first.call(null,seq28858);
var seq28858__$1 = cljs.core.next.call(null,seq28858);
var G__28860 = cljs.core.first.call(null,seq28858__$1);
var seq28858__$2 = cljs.core.next.call(null,seq28858__$1);
var G__28861 = cljs.core.first.call(null,seq28858__$2);
var seq28858__$3 = cljs.core.next.call(null,seq28858__$2);
return cljs.core$macros.list.cljs$core$IFn$_invoke$arity$variadic(G__28859,G__28860,G__28861,seq28858__$3);
});

cljs.core$macros.list.cljs$lang$maxFixedArity = (3);

cljs.core$macros.list.cljs$lang$macro = true;
cljs.core$macros.vector = (function cljs$core$macros$vector(var_args){
var args28868 = [];
var len__23955__auto___28874 = arguments.length;
var i__23956__auto___28875 = (0);
while(true){
if((i__23956__auto___28875 < len__23955__auto___28874)){
args28868.push((arguments[i__23956__auto___28875]));

var G__28876 = (i__23956__auto___28875 + (1));
i__23956__auto___28875 = G__28876;
continue;
} else {
}
break;
}

var G__28873 = args28868.length;
switch (G__28873) {
case 2:
return cljs.core$macros.vector.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
default:
var argseq__23974__auto__ = (new cljs.core.IndexedSeq(args28868.slice((2)),(0),null));
return cljs.core$macros.vector.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__23974__auto__);

}
});

cljs.core$macros.vector.cljs$core$IFn$_invoke$arity$2 = (function (_AMPERSAND_form,_AMPERSAND_env){
return cljs.core.list(new cljs.core.Symbol(null,".-EMPTY",".-EMPTY",-471586691,null),new cljs.core.Symbol("cljs.core","PersistentVector","cljs.core/PersistentVector",-1211028272,null));
});

cljs.core$macros.vector.cljs$core$IFn$_invoke$arity$variadic = (function (_AMPERSAND_form,_AMPERSAND_env,xs){
var cnt = cljs.core.count.call(null,xs);
if((cnt < (32))){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","PersistentVector.","cljs.core/PersistentVector.",-1074647876,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,null),(function (){var x__23719__auto__ = cnt;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,(5)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,".-EMPTY-NODE",".-EMPTY-NODE",-1333332641,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","PersistentVector","cljs.core/PersistentVector",-1211028272,null)))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","array","cljs.core$macros/array",49650437,null)),xs)));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,null))));
} else {
return cljs.core.vary_meta.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,".fromArray",".fromArray",1053499311,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","PersistentVector","cljs.core/PersistentVector",-1211028272,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","array","cljs.core$macros/array",49650437,null)),xs)));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,true)))),cljs.core.assoc,new cljs.core.Keyword(null,"tag","tag",-1290361223),new cljs.core.Symbol("cljs.core","PersistentVector","cljs.core/PersistentVector",-1211028272,null));
}
});

cljs.core$macros.vector.cljs$lang$applyTo = (function (seq28869){
var G__28870 = cljs.core.first.call(null,seq28869);
var seq28869__$1 = cljs.core.next.call(null,seq28869);
var G__28871 = cljs.core.first.call(null,seq28869__$1);
var seq28869__$2 = cljs.core.next.call(null,seq28869__$1);
return cljs.core$macros.vector.cljs$core$IFn$_invoke$arity$variadic(G__28870,G__28871,seq28869__$2);
});

cljs.core$macros.vector.cljs$lang$maxFixedArity = (2);

cljs.core$macros.vector.cljs$lang$macro = true;
cljs.core$macros.array_map = (function cljs$core$macros$array_map(var_args){
var args28880 = [];
var len__23955__auto___28886 = arguments.length;
var i__23956__auto___28887 = (0);
while(true){
if((i__23956__auto___28887 < len__23955__auto___28886)){
args28880.push((arguments[i__23956__auto___28887]));

var G__28888 = (i__23956__auto___28887 + (1));
i__23956__auto___28887 = G__28888;
continue;
} else {
}
break;
}

var G__28885 = args28880.length;
switch (G__28885) {
case 2:
return cljs.core$macros.array_map.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
default:
var argseq__23974__auto__ = (new cljs.core.IndexedSeq(args28880.slice((2)),(0),null));
return cljs.core$macros.array_map.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__23974__auto__);

}
});

cljs.core$macros.array_map.cljs$core$IFn$_invoke$arity$2 = (function (_AMPERSAND_form,_AMPERSAND_env){
return cljs.core.list(new cljs.core.Symbol(null,".-EMPTY",".-EMPTY",-471586691,null),new cljs.core.Symbol("cljs.core","PersistentArrayMap","cljs.core/PersistentArrayMap",1025194468,null));
});

cljs.core$macros.array_map.cljs$core$IFn$_invoke$arity$variadic = (function (_AMPERSAND_form,_AMPERSAND_env,kvs){
var keys = cljs.core.map.call(null,cljs.core.first,cljs.core.partition.call(null,(2),kvs));
if((cljs.core.every_QMARK_.call(null,((function (keys){
return (function (p1__28878_SHARP_){
return cljs.core._EQ_.call(null,new cljs.core.Keyword(null,"op","op",-1882987955).cljs$core$IFn$_invoke$arity$1(p1__28878_SHARP_),new cljs.core.Keyword(null,"constant","constant",-379609303));
});})(keys))
,cljs.core.map.call(null,((function (keys){
return (function (p1__28879_SHARP_){
return cljs.analyzer.analyze.call(null,_AMPERSAND_env,p1__28879_SHARP_);
});})(keys))
,keys))) && (cljs.core._EQ_.call(null,cljs.core.count.call(null,cljs.core.into.call(null,cljs.core.PersistentHashSet.EMPTY,keys)),cljs.core.count.call(null,keys)))){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","PersistentArrayMap.","cljs.core/PersistentArrayMap.",-471979341,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,null),(function (){var x__23719__auto__ = (cljs.core.count.call(null,kvs) / (2));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","array","cljs.core$macros/array",49650437,null)),kvs)));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,null))));
} else {
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,".fromArray",".fromArray",1053499311,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","PersistentArrayMap","cljs.core/PersistentArrayMap",1025194468,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","array","cljs.core$macros/array",49650437,null)),kvs)));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,true),cljs.core._conj.call(null,cljs.core.List.EMPTY,false))));
}
});

cljs.core$macros.array_map.cljs$lang$applyTo = (function (seq28881){
var G__28882 = cljs.core.first.call(null,seq28881);
var seq28881__$1 = cljs.core.next.call(null,seq28881);
var G__28883 = cljs.core.first.call(null,seq28881__$1);
var seq28881__$2 = cljs.core.next.call(null,seq28881__$1);
return cljs.core$macros.array_map.cljs$core$IFn$_invoke$arity$variadic(G__28882,G__28883,seq28881__$2);
});

cljs.core$macros.array_map.cljs$lang$maxFixedArity = (2);

cljs.core$macros.array_map.cljs$lang$macro = true;
cljs.core$macros.hash_map = (function cljs$core$macros$hash_map(var_args){
var args28890 = [];
var len__23955__auto___28896 = arguments.length;
var i__23956__auto___28897 = (0);
while(true){
if((i__23956__auto___28897 < len__23955__auto___28896)){
args28890.push((arguments[i__23956__auto___28897]));

var G__28898 = (i__23956__auto___28897 + (1));
i__23956__auto___28897 = G__28898;
continue;
} else {
}
break;
}

var G__28895 = args28890.length;
switch (G__28895) {
case 2:
return cljs.core$macros.hash_map.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
default:
var argseq__23974__auto__ = (new cljs.core.IndexedSeq(args28890.slice((2)),(0),null));
return cljs.core$macros.hash_map.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__23974__auto__);

}
});

cljs.core$macros.hash_map.cljs$core$IFn$_invoke$arity$2 = (function (_AMPERSAND_form,_AMPERSAND_env){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,".-EMPTY",".-EMPTY",-471586691,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","PersistentHashMap","cljs.core/PersistentHashMap",-454120575,null)))));
});

cljs.core$macros.hash_map.cljs$core$IFn$_invoke$arity$variadic = (function (_AMPERSAND_form,_AMPERSAND_env,kvs){
var pairs = cljs.core.partition.call(null,(2),kvs);
var ks = cljs.core.map.call(null,cljs.core.first,pairs);
var vs = cljs.core.map.call(null,cljs.core.second,pairs);
return cljs.core.vary_meta.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,".fromArrays",".fromArrays",1110244209,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","PersistentHashMap","cljs.core/PersistentHashMap",-454120575,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","array","cljs.core$macros/array",49650437,null)),ks)));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","array","cljs.core$macros/array",49650437,null)),vs)));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})()))),cljs.core.assoc,new cljs.core.Keyword(null,"tag","tag",-1290361223),new cljs.core.Symbol("cljs.core","PersistentHashMap","cljs.core/PersistentHashMap",-454120575,null));
});

cljs.core$macros.hash_map.cljs$lang$applyTo = (function (seq28891){
var G__28892 = cljs.core.first.call(null,seq28891);
var seq28891__$1 = cljs.core.next.call(null,seq28891);
var G__28893 = cljs.core.first.call(null,seq28891__$1);
var seq28891__$2 = cljs.core.next.call(null,seq28891__$1);
return cljs.core$macros.hash_map.cljs$core$IFn$_invoke$arity$variadic(G__28892,G__28893,seq28891__$2);
});

cljs.core$macros.hash_map.cljs$lang$maxFixedArity = (2);

cljs.core$macros.hash_map.cljs$lang$macro = true;
cljs.core$macros.hash_set = (function cljs$core$macros$hash_set(var_args){
var args28902 = [];
var len__23955__auto___28908 = arguments.length;
var i__23956__auto___28909 = (0);
while(true){
if((i__23956__auto___28909 < len__23955__auto___28908)){
args28902.push((arguments[i__23956__auto___28909]));

var G__28910 = (i__23956__auto___28909 + (1));
i__23956__auto___28909 = G__28910;
continue;
} else {
}
break;
}

var G__28907 = args28902.length;
switch (G__28907) {
case 2:
return cljs.core$macros.hash_set.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
default:
var argseq__23974__auto__ = (new cljs.core.IndexedSeq(args28902.slice((2)),(0),null));
return cljs.core$macros.hash_set.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__23974__auto__);

}
});

cljs.core$macros.hash_set.cljs$core$IFn$_invoke$arity$2 = (function (_AMPERSAND_form,_AMPERSAND_env){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,".-EMPTY",".-EMPTY",-471586691,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","PersistentHashSet","cljs.core/PersistentHashSet",-967232330,null)))));
});

cljs.core$macros.hash_set.cljs$core$IFn$_invoke$arity$variadic = (function (_AMPERSAND_form,_AMPERSAND_env,xs){
if(((cljs.core.count.call(null,xs) <= (8))) && (cljs.core.every_QMARK_.call(null,(function (p1__28900_SHARP_){
return cljs.core._EQ_.call(null,new cljs.core.Keyword(null,"op","op",-1882987955).cljs$core$IFn$_invoke$arity$1(p1__28900_SHARP_),new cljs.core.Keyword(null,"constant","constant",-379609303));
}),cljs.core.map.call(null,(function (p1__28901_SHARP_){
return cljs.analyzer.analyze.call(null,_AMPERSAND_env,p1__28901_SHARP_);
}),xs))) && (cljs.core._EQ_.call(null,cljs.core.count.call(null,cljs.core.into.call(null,cljs.core.PersistentHashSet.EMPTY,xs)),cljs.core.count.call(null,xs)))){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","PersistentHashSet.","cljs.core/PersistentHashSet.",300313251,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,null),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","PersistentArrayMap.","cljs.core/PersistentArrayMap.",-471979341,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,null),(function (){var x__23719__auto__ = cljs.core.count.call(null,xs);
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","array","cljs.core$macros/array",49650437,null)),cljs.core.interleave.call(null,xs,cljs.core.repeat.call(null,null)))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,null))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,null))));
} else {
return cljs.core.vary_meta.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,".fromArray",".fromArray",1053499311,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","PersistentHashSet","cljs.core/PersistentHashSet",-967232330,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","array","cljs.core$macros/array",49650437,null)),xs)));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,true)))),cljs.core.assoc,new cljs.core.Keyword(null,"tag","tag",-1290361223),new cljs.core.Symbol("cljs.core","PersistentHashSet","cljs.core/PersistentHashSet",-967232330,null));
}
});

cljs.core$macros.hash_set.cljs$lang$applyTo = (function (seq28903){
var G__28904 = cljs.core.first.call(null,seq28903);
var seq28903__$1 = cljs.core.next.call(null,seq28903);
var G__28905 = cljs.core.first.call(null,seq28903__$1);
var seq28903__$2 = cljs.core.next.call(null,seq28903__$1);
return cljs.core$macros.hash_set.cljs$core$IFn$_invoke$arity$variadic(G__28904,G__28905,seq28903__$2);
});

cljs.core$macros.hash_set.cljs$lang$maxFixedArity = (2);

cljs.core$macros.hash_set.cljs$lang$macro = true;
cljs.core$macros.js_obj_STAR_ = (function cljs$core$macros$js_obj_STAR_(kvs){
var kvs_str = cljs.core.apply.call(null,cljs.core.str,cljs.core.interpose.call(null,",",cljs.core.take.call(null,cljs.core.count.call(null,kvs),cljs.core.repeat.call(null,"~{}:~{}"))));
return cljs.core.vary_meta.call(null,cljs.core.list_STAR_.call(null,new cljs.core.Symbol(null,"js*","js*",-1134233646,null),[cljs.core.str("{"),cljs.core.str(kvs_str),cljs.core.str("}")].join(''),cljs.core.apply.call(null,cljs.core.concat,kvs)),cljs.core.assoc,new cljs.core.Keyword(null,"tag","tag",-1290361223),new cljs.core.Symbol(null,"object","object",-1179821820,null));
});
cljs.core$macros.js_obj = (function cljs$core$macros$js_obj(var_args){
var args__23962__auto__ = [];
var len__23955__auto___28921 = arguments.length;
var i__23956__auto___28922 = (0);
while(true){
if((i__23956__auto___28922 < len__23955__auto___28921)){
args__23962__auto__.push((arguments[i__23956__auto___28922]));

var G__28923 = (i__23956__auto___28922 + (1));
i__23956__auto___28922 = G__28923;
continue;
} else {
}
break;
}

var argseq__23963__auto__ = ((((2) < args__23962__auto__.length))?(new cljs.core.IndexedSeq(args__23962__auto__.slice((2)),(0),null)):null);
return cljs.core$macros.js_obj.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__23963__auto__);
});

cljs.core$macros.js_obj.cljs$core$IFn$_invoke$arity$variadic = (function (_AMPERSAND_form,_AMPERSAND_env,rest){
var sym_or_str_QMARK_ = (function (x){
return ((x instanceof cljs.core.Symbol)) || (typeof x === 'string');
});
var filter_on_keys = ((function (sym_or_str_QMARK_){
return (function (f,coll){
return cljs.core.into.call(null,cljs.core.PersistentArrayMap.EMPTY,cljs.core.filter.call(null,((function (sym_or_str_QMARK_){
return (function (p__28915){
var vec__28916 = p__28915;
var k = cljs.core.nth.call(null,vec__28916,(0),null);
var _ = cljs.core.nth.call(null,vec__28916,(1),null);
return f.call(null,k);
});})(sym_or_str_QMARK_))
,coll));
});})(sym_or_str_QMARK_))
;
var kvs = cljs.core.into.call(null,cljs.core.PersistentArrayMap.EMPTY,cljs.core.map.call(null,cljs.core.vec,cljs.core.partition.call(null,(2),rest)));
var sym_pairs = filter_on_keys.call(null,cljs.core.symbol_QMARK_,kvs);
var expr__GT_local = cljs.core.zipmap.call(null,cljs.core.filter.call(null,cljs.core.complement.call(null,sym_or_str_QMARK_),cljs.core.keys.call(null,kvs)),cljs.core.repeatedly.call(null,cljs.core.gensym));
var obj = cljs.core.gensym.call(null,"obj");
if(cljs.core.empty_QMARK_.call(null,rest)){
return cljs.core$macros.js_obj_STAR_.call(null,cljs.core.List.EMPTY);
} else {
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","let","cljs.core$macros/let",-160286726,null)),(function (){var x__23719__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core.apply.call(null,cljs.core.concat,clojure.set.map_invert.call(null,expr__GT_local)),(function (){var x__23719__auto__ = obj;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core$macros.js_obj_STAR_.call(null,filter_on_keys.call(null,cljs.core.string_QMARK_,kvs));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})()))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),cljs.core.map.call(null,((function (sym_or_str_QMARK_,filter_on_keys,kvs,sym_pairs,expr__GT_local,obj){
return (function (p__28917){
var vec__28918 = p__28917;
var k = cljs.core.nth.call(null,vec__28918,(0),null);
var v = cljs.core.nth.call(null,vec__28918,(1),null);
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","aset","cljs.core$macros/aset",-693176374,null)),(function (){var x__23719__auto__ = obj;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = k;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = v;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
});})(sym_or_str_QMARK_,filter_on_keys,kvs,sym_pairs,expr__GT_local,obj))
,sym_pairs),cljs.core.map.call(null,((function (sym_or_str_QMARK_,filter_on_keys,kvs,sym_pairs,expr__GT_local,obj){
return (function (p__28919){
var vec__28920 = p__28919;
var k = cljs.core.nth.call(null,vec__28920,(0),null);
var v = cljs.core.nth.call(null,vec__28920,(1),null);
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","aset","cljs.core$macros/aset",-693176374,null)),(function (){var x__23719__auto__ = obj;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = v;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.get.call(null,kvs,k);
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
});})(sym_or_str_QMARK_,filter_on_keys,kvs,sym_pairs,expr__GT_local,obj))
,expr__GT_local),(function (){var x__23719__auto__ = obj;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
}
});

cljs.core$macros.js_obj.cljs$lang$maxFixedArity = (2);

cljs.core$macros.js_obj.cljs$lang$applyTo = (function (seq28912){
var G__28913 = cljs.core.first.call(null,seq28912);
var seq28912__$1 = cljs.core.next.call(null,seq28912);
var G__28914 = cljs.core.first.call(null,seq28912__$1);
var seq28912__$2 = cljs.core.next.call(null,seq28912__$1);
return cljs.core$macros.js_obj.cljs$core$IFn$_invoke$arity$variadic(G__28913,G__28914,seq28912__$2);
});

cljs.core$macros.js_obj.cljs$lang$macro = true;
cljs.core$macros.alength = (function cljs$core$macros$alength(_AMPERSAND_form,_AMPERSAND_env,a){
return cljs.core.vary_meta.call(null,cljs.core._conj.call(null,cljs.core._conj.call(null,(function (){var x__23719__auto__ = a;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),"~{}.length"),new cljs.core.Symbol(null,"js*","js*",-1134233646,null)),cljs.core.assoc,new cljs.core.Keyword(null,"tag","tag",-1290361223),new cljs.core.Symbol(null,"number","number",-1084057331,null));
});

cljs.core$macros.alength.cljs$lang$macro = true;
/**
 * Maps an expression across an array a, using an index named idx, and
 *   return value named ret, initialized to a clone of a, then setting
 *   each element of ret to the evaluation of expr, returning the new
 *   array ret.
 */
cljs.core$macros.amap = (function cljs$core$macros$amap(_AMPERSAND_form,_AMPERSAND_env,a,idx,ret,expr){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","let","cljs.core$macros/let",-160286726,null)),(function (){var x__23719__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"a__28924__auto__","a__28924__auto__",1343878150,null)),(function (){var x__23719__auto__ = a;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = ret;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","aclone","cljs.core/aclone",-758078968,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"a__28924__auto__","a__28924__auto__",1343878150,null)))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})()))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","loop","cljs.core$macros/loop",1731108390,null)),(function (){var x__23719__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,(function (){var x__23719__auto__ = idx;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,(0))))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"if","if",1181717262,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","<","cljs.core$macros/<",371512596,null)),(function (){var x__23719__auto__ = idx;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","alength","cljs.core$macros/alength",-683052937,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"a__28924__auto__","a__28924__auto__",1343878150,null)))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"do","do",1686842252,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","aset","cljs.core$macros/aset",-693176374,null)),(function (){var x__23719__auto__ = ret;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = idx;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = expr;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"recur","recur",1202958259,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","inc","cljs.core$macros/inc",876629257,null)),(function (){var x__23719__auto__ = idx;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = ret;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
});

cljs.core$macros.amap.cljs$lang$macro = true;
/**
 * Reduces an expression across an array a, using an index named idx,
 *   and return value named ret, initialized to init, setting ret to the
 *   evaluation of expr at each step, returning ret.
 */
cljs.core$macros.areduce = (function cljs$core$macros$areduce(_AMPERSAND_form,_AMPERSAND_env,a,idx,ret,init,expr){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","let","cljs.core$macros/let",-160286726,null)),(function (){var x__23719__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"a__28925__auto__","a__28925__auto__",1170029726,null)),(function (){var x__23719__auto__ = a;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})()))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","loop","cljs.core$macros/loop",1731108390,null)),(function (){var x__23719__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,(function (){var x__23719__auto__ = idx;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,(0)),(function (){var x__23719__auto__ = ret;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = init;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})()))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"if","if",1181717262,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","<","cljs.core$macros/<",371512596,null)),(function (){var x__23719__auto__ = idx;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","alength","cljs.core$macros/alength",-683052937,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"a__28925__auto__","a__28925__auto__",1170029726,null)))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"recur","recur",1202958259,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","inc","cljs.core$macros/inc",876629257,null)),(function (){var x__23719__auto__ = idx;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = expr;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = ret;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
});

cljs.core$macros.areduce.cljs$lang$macro = true;
/**
 * bindings => name n
 * 
 *   Repeatedly executes body (presumably for side-effects) with name
 *   bound to integers from 0 through n-1.
 */
cljs.core$macros.dotimes = (function cljs$core$macros$dotimes(var_args){
var args__23962__auto__ = [];
var len__23955__auto___28931 = arguments.length;
var i__23956__auto___28932 = (0);
while(true){
if((i__23956__auto___28932 < len__23955__auto___28931)){
args__23962__auto__.push((arguments[i__23956__auto___28932]));

var G__28933 = (i__23956__auto___28932 + (1));
i__23956__auto___28932 = G__28933;
continue;
} else {
}
break;
}

var argseq__23963__auto__ = ((((3) < args__23962__auto__.length))?(new cljs.core.IndexedSeq(args__23962__auto__.slice((3)),(0),null)):null);
return cljs.core$macros.dotimes.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),argseq__23963__auto__);
});

cljs.core$macros.dotimes.cljs$core$IFn$_invoke$arity$variadic = (function (_AMPERSAND_form,_AMPERSAND_env,bindings,body){
var i = cljs.core.first.call(null,bindings);
var n = cljs.core.second.call(null,bindings);
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","let","cljs.core$macros/let",-160286726,null)),(function (){var x__23719__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"n__28926__auto__","n__28926__auto__",-1686412286,null)),(function (){var x__23719__auto__ = n;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})()))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","loop","cljs.core$macros/loop",1731108390,null)),(function (){var x__23719__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,(function (){var x__23719__auto__ = i;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,(0))))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","when","cljs.core$macros/when",328457725,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","<","cljs.core$macros/<",371512596,null)),(function (){var x__23719__auto__ = i;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"n__28926__auto__","n__28926__auto__",-1686412286,null)))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),body,(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"recur","recur",1202958259,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","inc","cljs.core$macros/inc",876629257,null)),(function (){var x__23719__auto__ = i;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
});

cljs.core$macros.dotimes.cljs$lang$maxFixedArity = (3);

cljs.core$macros.dotimes.cljs$lang$applyTo = (function (seq28927){
var G__28928 = cljs.core.first.call(null,seq28927);
var seq28927__$1 = cljs.core.next.call(null,seq28927);
var G__28929 = cljs.core.first.call(null,seq28927__$1);
var seq28927__$2 = cljs.core.next.call(null,seq28927__$1);
var G__28930 = cljs.core.first.call(null,seq28927__$2);
var seq28927__$3 = cljs.core.next.call(null,seq28927__$2);
return cljs.core$macros.dotimes.cljs$core$IFn$_invoke$arity$variadic(G__28928,G__28929,G__28930,seq28927__$3);
});

cljs.core$macros.dotimes.cljs$lang$macro = true;
/**
 * Throws an exception if the given option map contains keys not listed
 *   as valid, else returns nil.
 */
cljs.core$macros.check_valid_options = (function cljs$core$macros$check_valid_options(var_args){
var args__23962__auto__ = [];
var len__23955__auto___28937 = arguments.length;
var i__23956__auto___28938 = (0);
while(true){
if((i__23956__auto___28938 < len__23955__auto___28937)){
args__23962__auto__.push((arguments[i__23956__auto___28938]));

var G__28939 = (i__23956__auto___28938 + (1));
i__23956__auto___28938 = G__28939;
continue;
} else {
}
break;
}

var argseq__23963__auto__ = ((((1) < args__23962__auto__.length))?(new cljs.core.IndexedSeq(args__23962__auto__.slice((1)),(0),null)):null);
return cljs.core$macros.check_valid_options.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),argseq__23963__auto__);
});

cljs.core$macros.check_valid_options.cljs$core$IFn$_invoke$arity$variadic = (function (options,valid_keys){
if(cljs.core.seq.call(null,cljs.core.apply.call(null,cljs.core.disj,cljs.core.apply.call(null,cljs.core.hash_set,cljs.core.keys.call(null,options)),valid_keys))){
throw cljs.core.apply.call(null,cljs.core.str,"Only these options are valid: ",cljs.core.first.call(null,valid_keys),cljs.core.map.call(null,(function (p1__28934_SHARP_){
return [cljs.core.str(", "),cljs.core.str(p1__28934_SHARP_)].join('');
}),cljs.core.rest.call(null,valid_keys)));
} else {
return null;
}
});

cljs.core$macros.check_valid_options.cljs$lang$maxFixedArity = (1);

cljs.core$macros.check_valid_options.cljs$lang$applyTo = (function (seq28935){
var G__28936 = cljs.core.first.call(null,seq28935);
var seq28935__$1 = cljs.core.next.call(null,seq28935);
return cljs.core$macros.check_valid_options.cljs$core$IFn$_invoke$arity$variadic(G__28936,seq28935__$1);
});
/**
 * Creates a new multimethod with the associated dispatch function.
 *   The docstring and attribute-map are optional.
 * 
 *   Options are key-value pairs and may be one of:
 *  :default    the default dispatch value, defaults to :default
 *  :hierarchy  the isa? hierarchy to use for dispatching
 *              defaults to the global hierarchy
 */
cljs.core$macros.defmulti = (function cljs$core$macros$defmulti(var_args){
var args__23962__auto__ = [];
var len__23955__auto___28949 = arguments.length;
var i__23956__auto___28950 = (0);
while(true){
if((i__23956__auto___28950 < len__23955__auto___28949)){
args__23962__auto__.push((arguments[i__23956__auto___28950]));

var G__28951 = (i__23956__auto___28950 + (1));
i__23956__auto___28950 = G__28951;
continue;
} else {
}
break;
}

var argseq__23963__auto__ = ((((3) < args__23962__auto__.length))?(new cljs.core.IndexedSeq(args__23962__auto__.slice((3)),(0),null)):null);
return cljs.core$macros.defmulti.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),argseq__23963__auto__);
});

cljs.core$macros.defmulti.cljs$core$IFn$_invoke$arity$variadic = (function (_AMPERSAND_form,_AMPERSAND_env,mm_name,options){
var docstring = ((typeof cljs.core.first.call(null,options) === 'string')?cljs.core.first.call(null,options):null);
var options__$1 = ((typeof cljs.core.first.call(null,options) === 'string')?cljs.core.next.call(null,options):options);
var m = ((cljs.core.map_QMARK_.call(null,cljs.core.first.call(null,options__$1)))?cljs.core.first.call(null,options__$1):cljs.core.PersistentArrayMap.EMPTY);
var options__$2 = ((cljs.core.map_QMARK_.call(null,cljs.core.first.call(null,options__$1)))?cljs.core.next.call(null,options__$1):options__$1);
var dispatch_fn = cljs.core.first.call(null,options__$2);
var options__$3 = cljs.core.next.call(null,options__$2);
var m__$1 = (cljs.core.truth_(docstring)?cljs.core.assoc.call(null,m,new cljs.core.Keyword(null,"doc","doc",1913296891),docstring):m);
var m__$2 = (cljs.core.truth_(cljs.core.meta.call(null,mm_name))?cljs.core.conj.call(null,cljs.core.meta.call(null,mm_name),m__$1):m__$1);
var mm_ns = [cljs.core.str(new cljs.core.Keyword(null,"name","name",1843675177).cljs$core$IFn$_invoke$arity$1(new cljs.core.Keyword(null,"ns","ns",441598760).cljs$core$IFn$_invoke$arity$1(_AMPERSAND_env)))].join('');
if(cljs.core._EQ_.call(null,cljs.core.count.call(null,options__$3),(1))){
throw (new Error("The syntax for defmulti has changed. Example: (defmulti name dispatch-fn :default dispatch-value)"));
} else {
}

var options__$4 = cljs.core.apply.call(null,cljs.core.hash_map,options__$3);
var default$ = cljs.core.get.call(null,options__$4,new cljs.core.Keyword(null,"default","default",-1987822328),new cljs.core.Keyword(null,"default","default",-1987822328));
cljs.core$macros.check_valid_options.call(null,options__$4,new cljs.core.Keyword(null,"default","default",-1987822328),new cljs.core.Keyword(null,"hierarchy","hierarchy",-1053470341));

return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","defonce","cljs.core$macros/defonce",-1096231613,null)),(function (){var x__23719__auto__ = cljs.core.with_meta.call(null,mm_name,m__$2);
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","let","cljs.core$macros/let",-160286726,null)),(function (){var x__23719__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"method-table__28940__auto__","method-table__28940__auto__",2036385411,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","atom","cljs.core/atom",1943839529,null)),(function (){var x__23719__auto__ = cljs.core.apply.call(null,cljs.core.array_map,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"prefer-table__28941__auto__","prefer-table__28941__auto__",1200997055,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","atom","cljs.core/atom",1943839529,null)),(function (){var x__23719__auto__ = cljs.core.apply.call(null,cljs.core.array_map,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"method-cache__28942__auto__","method-cache__28942__auto__",1086801806,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","atom","cljs.core/atom",1943839529,null)),(function (){var x__23719__auto__ = cljs.core.apply.call(null,cljs.core.array_map,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"cached-hierarchy__28943__auto__","cached-hierarchy__28943__auto__",-612849996,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","atom","cljs.core/atom",1943839529,null)),(function (){var x__23719__auto__ = cljs.core.apply.call(null,cljs.core.array_map,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"hierarchy__28944__auto__","hierarchy__28944__auto__",704954202,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","get","cljs.core/get",-296075407,null)),(function (){var x__23719__auto__ = options__$4;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Keyword(null,"hierarchy","hierarchy",-1053470341)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","get-global-hierarchy","cljs.core/get-global-hierarchy",48052871,null)))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})()))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","MultiFn.","cljs.core/MultiFn.",1073941573,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","symbol","cljs.core/symbol",195265748,null)),(function (){var x__23719__auto__ = mm_ns;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.name.call(null,mm_name);
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = dispatch_fn;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = default$;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"hierarchy__28944__auto__","hierarchy__28944__auto__",704954202,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"method-table__28940__auto__","method-table__28940__auto__",2036385411,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"prefer-table__28941__auto__","prefer-table__28941__auto__",1200997055,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"method-cache__28942__auto__","method-cache__28942__auto__",1086801806,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"cached-hierarchy__28943__auto__","cached-hierarchy__28943__auto__",-612849996,null)))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
});

cljs.core$macros.defmulti.cljs$lang$maxFixedArity = (3);

cljs.core$macros.defmulti.cljs$lang$applyTo = (function (seq28945){
var G__28946 = cljs.core.first.call(null,seq28945);
var seq28945__$1 = cljs.core.next.call(null,seq28945);
var G__28947 = cljs.core.first.call(null,seq28945__$1);
var seq28945__$2 = cljs.core.next.call(null,seq28945__$1);
var G__28948 = cljs.core.first.call(null,seq28945__$2);
var seq28945__$3 = cljs.core.next.call(null,seq28945__$2);
return cljs.core$macros.defmulti.cljs$core$IFn$_invoke$arity$variadic(G__28946,G__28947,G__28948,seq28945__$3);
});

cljs.core$macros.defmulti.cljs$lang$macro = true;
/**
 * Creates and installs a new method of multimethod associated with dispatch-value. 
 */
cljs.core$macros.defmethod = (function cljs$core$macros$defmethod(var_args){
var args__23962__auto__ = [];
var len__23955__auto___28957 = arguments.length;
var i__23956__auto___28958 = (0);
while(true){
if((i__23956__auto___28958 < len__23955__auto___28957)){
args__23962__auto__.push((arguments[i__23956__auto___28958]));

var G__28959 = (i__23956__auto___28958 + (1));
i__23956__auto___28958 = G__28959;
continue;
} else {
}
break;
}

var argseq__23963__auto__ = ((((4) < args__23962__auto__.length))?(new cljs.core.IndexedSeq(args__23962__auto__.slice((4)),(0),null)):null);
return cljs.core$macros.defmethod.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]),argseq__23963__auto__);
});

cljs.core$macros.defmethod.cljs$core$IFn$_invoke$arity$variadic = (function (_AMPERSAND_form,_AMPERSAND_env,multifn,dispatch_val,fn_tail){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","-add-method","cljs.core/-add-method",571092113,null)),(function (){var x__23719__auto__ = cljs.core.with_meta.call(null,multifn,new cljs.core.PersistentArrayMap(null, 1, [new cljs.core.Keyword(null,"tag","tag",-1290361223),new cljs.core.Symbol("cljs.core","MultiFn","cljs.core/MultiFn",1487419554,null)], null));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = dispatch_val;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","fn","cljs.core$macros/fn",-187522821,null)),fn_tail)));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
});

cljs.core$macros.defmethod.cljs$lang$maxFixedArity = (4);

cljs.core$macros.defmethod.cljs$lang$applyTo = (function (seq28952){
var G__28953 = cljs.core.first.call(null,seq28952);
var seq28952__$1 = cljs.core.next.call(null,seq28952);
var G__28954 = cljs.core.first.call(null,seq28952__$1);
var seq28952__$2 = cljs.core.next.call(null,seq28952__$1);
var G__28955 = cljs.core.first.call(null,seq28952__$2);
var seq28952__$3 = cljs.core.next.call(null,seq28952__$2);
var G__28956 = cljs.core.first.call(null,seq28952__$3);
var seq28952__$4 = cljs.core.next.call(null,seq28952__$3);
return cljs.core$macros.defmethod.cljs$core$IFn$_invoke$arity$variadic(G__28953,G__28954,G__28955,G__28956,seq28952__$4);
});

cljs.core$macros.defmethod.cljs$lang$macro = true;
/**
 * Evaluates expr and prints the time it took. Returns the value of expr.
 */
cljs.core$macros.time = (function cljs$core$macros$time(_AMPERSAND_form,_AMPERSAND_env,expr){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","let","cljs.core$macros/let",-160286726,null)),(function (){var x__23719__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"start__28960__auto__","start__28960__auto__",2092432306,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","system-time","cljs.core/system-time",1562011930,null)))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"ret__28961__auto__","ret__28961__auto__",1464172579,null)),(function (){var x__23719__auto__ = expr;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})()))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","prn","cljs.core/prn",1725204552,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","str","cljs.core/str",-1971828991,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,"Elapsed time: "),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,".toFixed",".toFixed",-895046938,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","-","cljs.core$macros/-",13526976,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","system-time","cljs.core/system-time",1562011930,null)))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"start__28960__auto__","start__28960__auto__",2092432306,null)))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,(6)))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY," msecs"))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"ret__28961__auto__","ret__28961__auto__",1464172579,null)))));
});

cljs.core$macros.time.cljs$lang$macro = true;
/**
 * Runs expr iterations times in the context of a let expression with
 *   the given bindings, then prints out the bindings and the expr
 *   followed by number of iterations and total time. The optional
 *   argument print-fn, defaulting to println, sets function used to
 *   print the result. expr's string representation will be produced
 *   using pr-str in any case.
 */
cljs.core$macros.simple_benchmark = (function cljs$core$macros$simple_benchmark(var_args){
var args__23962__auto__ = [];
var len__23955__auto___28976 = arguments.length;
var i__23956__auto___28977 = (0);
while(true){
if((i__23956__auto___28977 < len__23955__auto___28976)){
args__23962__auto__.push((arguments[i__23956__auto___28977]));

var G__28978 = (i__23956__auto___28977 + (1));
i__23956__auto___28977 = G__28978;
continue;
} else {
}
break;
}

var argseq__23963__auto__ = ((((5) < args__23962__auto__.length))?(new cljs.core.IndexedSeq(args__23962__auto__.slice((5)),(0),null)):null);
return cljs.core$macros.simple_benchmark.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]),(arguments[(4)]),argseq__23963__auto__);
});

cljs.core$macros.simple_benchmark.cljs$core$IFn$_invoke$arity$variadic = (function (_AMPERSAND_form,_AMPERSAND_env,bindings,expr,iterations,p__28973){
var map__28974 = p__28973;
var map__28974__$1 = ((((!((map__28974 == null)))?((((map__28974.cljs$lang$protocol_mask$partition0$ & (64))) || (map__28974.cljs$core$ISeq$))?true:false):false))?cljs.core.apply.call(null,cljs.core.hash_map,map__28974):map__28974);
var print_fn = cljs.core.get.call(null,map__28974__$1,new cljs.core.Keyword(null,"print-fn","print-fn",-1720960489),new cljs.core.Symbol(null,"println","println",-733595439,null));
var bs_str = cljs.core.pr_str.call(null,bindings);
var expr_str = cljs.core.pr_str.call(null,expr);
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","let","cljs.core$macros/let",-160286726,null)),(function (){var x__23719__auto__ = bindings;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","let","cljs.core$macros/let",-160286726,null)),(function (){var x__23719__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"start__28962__auto__","start__28962__auto__",-456083985,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,".getTime",".getTime",-1048557777,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("js","Date.","js/Date.",384205255,null)))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"ret__28963__auto__","ret__28963__auto__",441505119,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","dotimes","cljs.core$macros/dotimes",-1407597661,null)),(function (){var x__23719__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"___28964__auto__","___28964__auto__",-1702076763,null)),(function (){var x__23719__auto__ = iterations;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})()))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = expr;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"end__28965__auto__","end__28965__auto__",1486233052,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,".getTime",".getTime",-1048557777,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("js","Date.","js/Date.",384205255,null)))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"elapsed__28966__auto__","elapsed__28966__auto__",1295407294,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","-","cljs.core$macros/-",13526976,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"end__28965__auto__","end__28965__auto__",1486233052,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"start__28962__auto__","start__28962__auto__",-456083985,null)))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})()))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,(function (){var x__23719__auto__ = print_fn;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","str","cljs.core$macros/str",-2019499702,null)),(function (){var x__23719__auto__ = bs_str;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,", "),(function (){var x__23719__auto__ = expr_str;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,", "),(function (){var x__23719__auto__ = iterations;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY," runs, "),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"elapsed__28966__auto__","elapsed__28966__auto__",1295407294,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY," msecs"))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
});

cljs.core$macros.simple_benchmark.cljs$lang$maxFixedArity = (5);

cljs.core$macros.simple_benchmark.cljs$lang$applyTo = (function (seq28967){
var G__28968 = cljs.core.first.call(null,seq28967);
var seq28967__$1 = cljs.core.next.call(null,seq28967);
var G__28969 = cljs.core.first.call(null,seq28967__$1);
var seq28967__$2 = cljs.core.next.call(null,seq28967__$1);
var G__28970 = cljs.core.first.call(null,seq28967__$2);
var seq28967__$3 = cljs.core.next.call(null,seq28967__$2);
var G__28971 = cljs.core.first.call(null,seq28967__$3);
var seq28967__$4 = cljs.core.next.call(null,seq28967__$3);
var G__28972 = cljs.core.first.call(null,seq28967__$4);
var seq28967__$5 = cljs.core.next.call(null,seq28967__$4);
return cljs.core$macros.simple_benchmark.cljs$core$IFn$_invoke$arity$variadic(G__28968,G__28969,G__28970,G__28971,G__28972,seq28967__$5);
});

cljs.core$macros.simple_benchmark.cljs$lang$macro = true;
cljs.core$macros.cs = cljs.core.into.call(null,cljs.core.PersistentVector.EMPTY,cljs.core.map.call(null,cljs.core.comp.call(null,cljs.core.gensym,cljs.core.str,cljs.core.char$),cljs.core.range.call(null,(97),(118))));
cljs.core$macros.gen_apply_to_helper = (function cljs$core$macros$gen_apply_to_helper(var_args){
var args28979 = [];
var len__23955__auto___28982 = arguments.length;
var i__23956__auto___28983 = (0);
while(true){
if((i__23956__auto___28983 < len__23955__auto___28982)){
args28979.push((arguments[i__23956__auto___28983]));

var G__28984 = (i__23956__auto___28983 + (1));
i__23956__auto___28983 = G__28984;
continue;
} else {
}
break;
}

var G__28981 = args28979.length;
switch (G__28981) {
case 0:
return cljs.core$macros.gen_apply_to_helper.cljs$core$IFn$_invoke$arity$0();

break;
case 1:
return cljs.core$macros.gen_apply_to_helper.cljs$core$IFn$_invoke$arity$1((arguments[(0)]));

break;
default:
throw (new Error([cljs.core.str("Invalid arity: "),cljs.core.str(args28979.length)].join('')));

}
});

cljs.core$macros.gen_apply_to_helper.cljs$core$IFn$_invoke$arity$0 = (function (){
return cljs.core$macros.gen_apply_to_helper.call(null,(1));
});

cljs.core$macros.gen_apply_to_helper.cljs$core$IFn$_invoke$arity$1 = (function (n){
var prop = cljs.core.symbol.call(null,[cljs.core.str("-cljs$core$IFn$_invoke$arity$"),cljs.core.str(n)].join(''));
var f = cljs.core.symbol.call(null,[cljs.core.str("cljs$core$IFn$_invoke$arity$"),cljs.core.str(n)].join(''));
if((n <= (20))){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","let","cljs.core$macros/let",-160286726,null)),(function (){var x__23719__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,(function (){var x__23719__auto__ = cljs.core$macros.cs.call(null,(n - (1)));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","-first","cljs.core/-first",545297391,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"args","args",-1338879193,null)))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"args","args",-1338879193,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","-rest","cljs.core/-rest",-1829241664,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"args","args",-1338879193,null)))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})()))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"if","if",1181717262,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","==","cljs.core$macros/==",-818551413,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"argc","argc",187692008,null)),(function (){var x__23719__auto__ = n;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"if","if",1181717262,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,".",".",1975675962,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"f","f",43394975,null)),(function (){var x__23719__auto__ = prop;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,".",".",1975675962,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"f","f",43394975,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,(function (){var x__23719__auto__ = f;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),cljs.core.take.call(null,n,cljs.core$macros.cs))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"f","f",43394975,null)),cljs.core.take.call(null,n,cljs.core$macros.cs))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core$macros.gen_apply_to_helper.call(null,(n + (1)));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
} else {
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"throw","throw",595905694,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("js","Error.","js/Error.",750655924,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,"Only up to 20 arguments supported on functions"))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
}
});

cljs.core$macros.gen_apply_to_helper.cljs$lang$maxFixedArity = 1;
cljs.core$macros.gen_apply_to = (function cljs$core$macros$gen_apply_to(_AMPERSAND_form,_AMPERSAND_env){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"do","do",1686842252,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"set!","set!",250714521,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"*unchecked-if*","*unchecked-if*",1542408350,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,true))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","defn","cljs.core$macros/defn",-728332354,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"apply-to","apply-to",-1858571928,null)),(function (){var x__23719__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"f","f",43394975,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"argc","argc",187692008,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"args","args",-1338879193,null))))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","let","cljs.core$macros/let",-160286726,null)),(function (){var x__23719__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"args","args",-1338879193,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","seq","cljs.core/seq",-1649497689,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"args","args",-1338879193,null)))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})()))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"if","if",1181717262,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","zero?","cljs.core$macros/zero?",-65998367,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"argc","argc",187692008,null)))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"f","f",43394975,null)))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core$macros.gen_apply_to_helper.call(null);
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"set!","set!",250714521,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"*unchecked-if*","*unchecked-if*",1542408350,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,false))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
});

cljs.core$macros.gen_apply_to.cljs$lang$macro = true;
/**
 * Evaluates exprs in a context in which *print-fn* is bound to .append
 *   on a fresh StringBuffer.  Returns the string created by any nested
 *   printing calls.
 */
cljs.core$macros.with_out_str = (function cljs$core$macros$with_out_str(var_args){
var args__23962__auto__ = [];
var len__23955__auto___28991 = arguments.length;
var i__23956__auto___28992 = (0);
while(true){
if((i__23956__auto___28992 < len__23955__auto___28991)){
args__23962__auto__.push((arguments[i__23956__auto___28992]));

var G__28993 = (i__23956__auto___28992 + (1));
i__23956__auto___28992 = G__28993;
continue;
} else {
}
break;
}

var argseq__23963__auto__ = ((((2) < args__23962__auto__.length))?(new cljs.core.IndexedSeq(args__23962__auto__.slice((2)),(0),null)):null);
return cljs.core$macros.with_out_str.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__23963__auto__);
});

cljs.core$macros.with_out_str.cljs$core$IFn$_invoke$arity$variadic = (function (_AMPERSAND_form,_AMPERSAND_env,body){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","let","cljs.core$macros/let",-160286726,null)),(function (){var x__23719__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"sb__28986__auto__","sb__28986__auto__",1513830457,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("js","goog.string.StringBuffer.","js/goog.string.StringBuffer.",-1043451650,null)))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})()))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","binding","cljs.core$macros/binding",1855847304,null)),(function (){var x__23719__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","*print-newline*","cljs.core/*print-newline*",6231625,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,true),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","*print-fn*","cljs.core/*print-fn*",1342365176,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","fn","cljs.core$macros/fn",-187522821,null)),(function (){var x__23719__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"x__28987__auto__","x__28987__auto__",1982044668,null))))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,".append",".append",1595439852,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"sb__28986__auto__","sb__28986__auto__",1513830457,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"x__28987__auto__","x__28987__auto__",1982044668,null)))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})()))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),body)));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","str","cljs.core/str",-1971828991,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"sb__28986__auto__","sb__28986__auto__",1513830457,null)))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
});

cljs.core$macros.with_out_str.cljs$lang$maxFixedArity = (2);

cljs.core$macros.with_out_str.cljs$lang$applyTo = (function (seq28988){
var G__28989 = cljs.core.first.call(null,seq28988);
var seq28988__$1 = cljs.core.next.call(null,seq28988);
var G__28990 = cljs.core.first.call(null,seq28988__$1);
var seq28988__$2 = cljs.core.next.call(null,seq28988__$1);
return cljs.core$macros.with_out_str.cljs$core$IFn$_invoke$arity$variadic(G__28989,G__28990,seq28988__$2);
});

cljs.core$macros.with_out_str.cljs$lang$macro = true;
/**
 * Expands to code which yields a lazy sequence of the concatenation
 *   of the supplied colls.  Each coll expr is not evaluated until it is
 *   needed.
 * 
 *   (lazy-cat xs ys zs) === (concat (lazy-seq xs) (lazy-seq ys) (lazy-seq zs))
 */
cljs.core$macros.lazy_cat = (function cljs$core$macros$lazy_cat(var_args){
var args__23962__auto__ = [];
var len__23955__auto___28998 = arguments.length;
var i__23956__auto___28999 = (0);
while(true){
if((i__23956__auto___28999 < len__23955__auto___28998)){
args__23962__auto__.push((arguments[i__23956__auto___28999]));

var G__29000 = (i__23956__auto___28999 + (1));
i__23956__auto___28999 = G__29000;
continue;
} else {
}
break;
}

var argseq__23963__auto__ = ((((2) < args__23962__auto__.length))?(new cljs.core.IndexedSeq(args__23962__auto__.slice((2)),(0),null)):null);
return cljs.core$macros.lazy_cat.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__23963__auto__);
});

cljs.core$macros.lazy_cat.cljs$core$IFn$_invoke$arity$variadic = (function (_AMPERSAND_form,_AMPERSAND_env,colls){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","concat","cljs.core/concat",-1133584918,null)),cljs.core.map.call(null,(function (p1__28994_SHARP_){
return cljs.core._conj.call(null,(function (){var x__23719__auto__ = p1__28994_SHARP_;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),new cljs.core.Symbol("cljs.core$macros","lazy-seq","cljs.core$macros/lazy-seq",806482650,null));
}),colls))));
});

cljs.core$macros.lazy_cat.cljs$lang$maxFixedArity = (2);

cljs.core$macros.lazy_cat.cljs$lang$applyTo = (function (seq28995){
var G__28996 = cljs.core.first.call(null,seq28995);
var seq28995__$1 = cljs.core.next.call(null,seq28995);
var G__28997 = cljs.core.first.call(null,seq28995__$1);
var seq28995__$2 = cljs.core.next.call(null,seq28995__$1);
return cljs.core$macros.lazy_cat.cljs$core$IFn$_invoke$arity$variadic(G__28996,G__28997,seq28995__$2);
});

cljs.core$macros.lazy_cat.cljs$lang$macro = true;
cljs.core$macros.js_str = (function cljs$core$macros$js_str(_AMPERSAND_form,_AMPERSAND_env,s){
return cljs.core._conj.call(null,cljs.core._conj.call(null,(function (){var x__23719__auto__ = s;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),"''+~{}"),new cljs.core.Symbol(null,"js*","js*",-1134233646,null));
});

cljs.core$macros.js_str.cljs$lang$macro = true;
cljs.core$macros.es6_iterable = (function cljs$core$macros$es6_iterable(_AMPERSAND_form,_AMPERSAND_env,ty){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","aset","cljs.core$macros/aset",-693176374,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,".-prototype",".-prototype",-1562038608,null)),(function (){var x__23719__auto__ = ty;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","ITER_SYMBOL","cljs.core/ITER_SYMBOL",-2091399233,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","fn","cljs.core$macros/fn",-187522821,null)),(function (){var x__23719__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","this-as","cljs.core$macros/this-as",-799075148,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"this__29001__auto__","this__29001__auto__",831320109,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","es6-iterator","cljs.core/es6-iterator",856007913,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"this__29001__auto__","this__29001__auto__",831320109,null)))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
});

cljs.core$macros.es6_iterable.cljs$lang$macro = true;
/**
 * Returns a map of the intern mappings for the namespace.
 */
cljs.core$macros.ns_interns = (function cljs$core$macros$ns_interns(_AMPERSAND_form,_AMPERSAND_env,p__29002){
var vec__29008 = p__29002;
var quote = cljs.core.nth.call(null,vec__29008,(0),null);
var ns = cljs.core.nth.call(null,vec__29008,(1),null);
if((cljs.core._EQ_.call(null,quote,new cljs.core.Symbol(null,"quote","quote",1377916282,null))) && ((ns instanceof cljs.core.Symbol))){
} else {
throw (new Error([cljs.core.str("Assert failed: "),cljs.core.str("Argument to ns-interns must be a quoted symbol"),cljs.core.str("\n"),cljs.core.str("(core/and (= quote (quote quote)) (core/symbol? ns))")].join('')));
}

return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","into","cljs.core/into",1879938733,null)),(function (){var x__23719__auto__ = cljs.core.apply.call(null,cljs.core.array_map,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core.map.call(null,((function (vec__29008,quote,ns){
return (function (p__29011){
var vec__29012 = p__29011;
var sym = cljs.core.nth.call(null,vec__29012,(0),null);
var _ = cljs.core.nth.call(null,vec__29012,(1),null);
return cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","symbol","cljs.core/symbol",195265748,null)),(function (){var x__23719__auto__ = cljs.core.name.call(null,sym);
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"var","var",870848730,null)),(function (){var x__23719__auto__ = cljs.core.symbol.call(null,cljs.core.name.call(null,ns),cljs.core.name.call(null,sym));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})()))));
});})(vec__29008,quote,ns))
,cljs.core.get_in.call(null,cljs.core.deref.call(null,cljs.env._STAR_compiler_STAR_),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword("cljs.analyzer","namespaces","cljs.analyzer/namespaces",-260788927),ns,new cljs.core.Keyword(null,"defs","defs",1398449717)], null)))))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
});

cljs.core$macros.ns_interns.cljs$lang$macro = true;
/**
 * Removes the mappings for the symbol from the namespace.
 */
cljs.core$macros.ns_unmap = (function cljs$core$macros$ns_unmap(_AMPERSAND_form,_AMPERSAND_env,p__29013,p__29014){
var vec__29017 = p__29013;
var quote0 = cljs.core.nth.call(null,vec__29017,(0),null);
var ns = cljs.core.nth.call(null,vec__29017,(1),null);
var vec__29018 = p__29014;
var quote1 = cljs.core.nth.call(null,vec__29018,(0),null);
var sym = cljs.core.nth.call(null,vec__29018,(1),null);
if((cljs.core._EQ_.call(null,quote0,new cljs.core.Symbol(null,"quote","quote",1377916282,null))) && ((ns instanceof cljs.core.Symbol)) && (cljs.core._EQ_.call(null,quote1,new cljs.core.Symbol(null,"quote","quote",1377916282,null))) && ((sym instanceof cljs.core.Symbol))){
} else {
throw (new Error([cljs.core.str("Assert failed: "),cljs.core.str("Arguments to ns-unmap must be quoted symbols"),cljs.core.str("\n"),cljs.core.str("(core/and (= quote0 (quote quote)) (core/symbol? ns) (= quote1 (quote quote)) (core/symbol? sym))")].join('')));
}

cljs.core.swap_BANG_.call(null,cljs.env._STAR_compiler_STAR_,cljs.core.update_in,new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword("cljs.analyzer","namespaces","cljs.analyzer/namespaces",-260788927),ns,new cljs.core.Keyword(null,"defs","defs",1398449717)], null),cljs.core.dissoc,sym);

return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","js-delete","cljs.core$macros/js-delete",387769082,null)),(function (){var x__23719__auto__ = cljs.compiler.munge.call(null,ns);
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.compiler.munge.call(null,[cljs.core.str(sym)].join(''));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
});

cljs.core$macros.ns_unmap.cljs$lang$macro = true;
/**
 * Non-atomically swaps the value of the volatile as if:
 * (apply f current-value-of-vol args). Returns the value that
 * was swapped in.
 */
cljs.core$macros.vswap_BANG_ = (function cljs$core$macros$vswap_BANG_(var_args){
var args__23962__auto__ = [];
var len__23955__auto___29024 = arguments.length;
var i__23956__auto___29025 = (0);
while(true){
if((i__23956__auto___29025 < len__23955__auto___29024)){
args__23962__auto__.push((arguments[i__23956__auto___29025]));

var G__29026 = (i__23956__auto___29025 + (1));
i__23956__auto___29025 = G__29026;
continue;
} else {
}
break;
}

var argseq__23963__auto__ = ((((4) < args__23962__auto__.length))?(new cljs.core.IndexedSeq(args__23962__auto__.slice((4)),(0),null)):null);
return cljs.core$macros.vswap_BANG_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]),argseq__23963__auto__);
});

cljs.core$macros.vswap_BANG_.cljs$core$IFn$_invoke$arity$variadic = (function (_AMPERSAND_form,_AMPERSAND_env,vol,f,args){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","-vreset!","cljs.core/-vreset!",-1186516972,null)),(function (){var x__23719__auto__ = vol;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,(function (){var x__23719__auto__ = f;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","-deref","cljs.core/-deref",-1260480154,null)),(function (){var x__23719__auto__ = vol;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),args)));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
});

cljs.core$macros.vswap_BANG_.cljs$lang$maxFixedArity = (4);

cljs.core$macros.vswap_BANG_.cljs$lang$applyTo = (function (seq29019){
var G__29020 = cljs.core.first.call(null,seq29019);
var seq29019__$1 = cljs.core.next.call(null,seq29019);
var G__29021 = cljs.core.first.call(null,seq29019__$1);
var seq29019__$2 = cljs.core.next.call(null,seq29019__$1);
var G__29022 = cljs.core.first.call(null,seq29019__$2);
var seq29019__$3 = cljs.core.next.call(null,seq29019__$2);
var G__29023 = cljs.core.first.call(null,seq29019__$3);
var seq29019__$4 = cljs.core.next.call(null,seq29019__$3);
return cljs.core$macros.vswap_BANG_.cljs$core$IFn$_invoke$arity$variadic(G__29020,G__29021,G__29022,G__29023,seq29019__$4);
});

cljs.core$macros.vswap_BANG_.cljs$lang$macro = true;
cljs.core$macros.load_file_STAR_ = (function cljs$core$macros$load_file_STAR_(_AMPERSAND_form,_AMPERSAND_env,f){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,".",".",1975675962,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("js","goog","js/goog",-70605150,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"nodeGlobalRequire","nodeGlobalRequire",167018599,null)),(function (){var x__23719__auto__ = f;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
});

cljs.core$macros.load_file_STAR_.cljs$lang$macro = true;
/**
 * If form represents a macro form, returns its expansion,
 *   else returns form.
 */
cljs.core$macros.macroexpand_1 = (function cljs$core$macros$macroexpand_1(_AMPERSAND_form,_AMPERSAND_env,quoted){
if(cljs.core._EQ_.call(null,cljs.core.first.call(null,quoted),new cljs.core.Symbol(null,"quote","quote",1377916282,null))){
} else {
throw (new Error([cljs.core.str("Assert failed: "),cljs.core.str("Argument to macroexpand-1 must be quoted"),cljs.core.str("\n"),cljs.core.str("(core/= (core/first quoted) (quote quote))")].join('')));
}

var form = cljs.core.second.call(null,quoted);
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"quote","quote",1377916282,null)),(function (){var x__23719__auto__ = cljs.analyzer.macroexpand_1.call(null,_AMPERSAND_env,form);
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
});

cljs.core$macros.macroexpand_1.cljs$lang$macro = true;
/**
 * Repeatedly calls macroexpand-1 on form until it no longer
 *   represents a macro form, then returns it.  Note neither
 *   macroexpand-1 nor macroexpand expand macros in subforms.
 */
cljs.core$macros.macroexpand = (function cljs$core$macros$macroexpand(_AMPERSAND_form,_AMPERSAND_env,quoted){
if(cljs.core._EQ_.call(null,cljs.core.first.call(null,quoted),new cljs.core.Symbol(null,"quote","quote",1377916282,null))){
} else {
throw (new Error([cljs.core.str("Assert failed: "),cljs.core.str("Argument to macroexpand must be quoted"),cljs.core.str("\n"),cljs.core.str("(core/= (core/first quoted) (quote quote))")].join('')));
}

var form = cljs.core.second.call(null,quoted);
var env = _AMPERSAND_env;
var form__$1 = form;
var form_SINGLEQUOTE_ = cljs.analyzer.macroexpand_1.call(null,env,form__$1);
while(true){
if(!((form__$1 === form_SINGLEQUOTE_))){
var G__29027 = form_SINGLEQUOTE_;
var G__29028 = cljs.analyzer.macroexpand_1.call(null,env,form_SINGLEQUOTE_);
form__$1 = G__29027;
form_SINGLEQUOTE_ = G__29028;
continue;
} else {
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"quote","quote",1377916282,null)),(function (){var x__23719__auto__ = form_SINGLEQUOTE_;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
}
break;
}
});

cljs.core$macros.macroexpand.cljs$lang$macro = true;
cljs.core$macros.multi_arity_fn_QMARK_ = (function cljs$core$macros$multi_arity_fn_QMARK_(fdecl){
return ((1) < cljs.core.count.call(null,fdecl));
});
cljs.core$macros.variadic_fn_QMARK_ = (function cljs$core$macros$variadic_fn_QMARK_(fdecl){
var and__22873__auto__ = cljs.core._EQ_.call(null,(1),cljs.core.count.call(null,fdecl));
if(and__22873__auto__){
return cljs.core.some.call(null,new cljs.core.PersistentHashSet(null, new cljs.core.PersistentArrayMap(null, 1, [new cljs.core.Symbol(null,"&","&",-2144855648,null),null], null), null),cljs.core.ffirst.call(null,fdecl));
} else {
return and__22873__auto__;
}
});
cljs.core$macros.variadic_fn_STAR_ = (function cljs$core$macros$variadic_fn_STAR_(var_args){
var args29029 = [];
var len__23955__auto___29034 = arguments.length;
var i__23956__auto___29035 = (0);
while(true){
if((i__23956__auto___29035 < len__23955__auto___29034)){
args29029.push((arguments[i__23956__auto___29035]));

var G__29036 = (i__23956__auto___29035 + (1));
i__23956__auto___29035 = G__29036;
continue;
} else {
}
break;
}

var G__29031 = args29029.length;
switch (G__29031) {
case 2:
return cljs.core$macros.variadic_fn_STAR_.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core$macros.variadic_fn_STAR_.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error([cljs.core.str("Invalid arity: "),cljs.core.str(args29029.length)].join('')));

}
});

cljs.core$macros.variadic_fn_STAR_.cljs$core$IFn$_invoke$arity$2 = (function (sym,method){
return cljs.core$macros.variadic_fn_STAR_.call(null,sym,method,true);
});

cljs.core$macros.variadic_fn_STAR_.cljs$core$IFn$_invoke$arity$3 = (function (sym,p__29032,solo){
var vec__29033 = p__29032;
var arglist = cljs.core.nth.call(null,vec__29033,(0),null);
var body = cljs.core.nthnext.call(null,vec__29033,(1));
var method = vec__29033;
var sig = cljs.core.remove.call(null,new cljs.core.PersistentHashSet(null, new cljs.core.PersistentArrayMap(null, 1, [new cljs.core.Symbol(null,"&","&",-2144855648,null),null], null), null),arglist);
var restarg = cljs.core.gensym.call(null,"seq");
var get_delegate = ((function (sig,restarg,vec__29033,arglist,body,method){
return (function cljs$core$macros$get_delegate(){
return new cljs.core.Symbol(null,"cljs$core$IFn$_invoke$arity$variadic","cljs$core$IFn$_invoke$arity$variadic",-378825034,null);
});})(sig,restarg,vec__29033,arglist,body,method))
;
var get_delegate_prop = ((function (sig,restarg,vec__29033,arglist,body,method){
return (function cljs$core$macros$get_delegate_prop(){
return cljs.core.symbol.call(null,[cljs.core.str("-"),cljs.core.str(get_delegate.call(null))].join(''));
});})(sig,restarg,vec__29033,arglist,body,method))
;
var param_bind = ((function (sig,restarg,vec__29033,arglist,body,method){
return (function cljs$core$macros$param_bind(param){
return cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,(function (){var x__23719__auto__ = param;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,(function (){var x__23719__auto__ = cljs.core.with_meta.call(null,new cljs.core.Symbol("cljs.core","first","cljs.core/first",-752535972,null),cljs.core.apply.call(null,cljs.core.array_map,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Keyword(null,"file","file",-1269645878)),cljs.core._conj.call(null,cljs.core.List.EMPTY,"/Users/clumsyjedi/workspace/clack/.cljs_rhino_repl/cljs/core.cljc"),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Keyword(null,"line","line",212345235)),cljs.core._conj.call(null,cljs.core.List.EMPTY,2725),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Keyword(null,"column","column",2078222095)),cljs.core._conj.call(null,cljs.core.List.EMPTY,49),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Keyword(null,"end-line","end-line",1837326455)),cljs.core._conj.call(null,cljs.core.List.EMPTY,2725),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Keyword(null,"end-column","end-column",1425389514)),cljs.core._conj.call(null,cljs.core.List.EMPTY,54),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Keyword("cljs.analyzer","no-resolve","cljs.analyzer/no-resolve",-1872351017)),cljs.core._conj.call(null,cljs.core.List.EMPTY,true))))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = restarg;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = restarg;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,(function (){var x__23719__auto__ = cljs.core.with_meta.call(null,new cljs.core.Symbol("cljs.core","next","cljs.core/next",-1291438473,null),cljs.core.apply.call(null,cljs.core.array_map,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Keyword(null,"file","file",-1269645878)),cljs.core._conj.call(null,cljs.core.List.EMPTY,"/Users/clumsyjedi/workspace/clack/.cljs_rhino_repl/cljs/core.cljc"),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Keyword(null,"line","line",212345235)),cljs.core._conj.call(null,cljs.core.List.EMPTY,2726),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Keyword(null,"column","column",2078222095)),cljs.core._conj.call(null,cljs.core.List.EMPTY,51),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Keyword(null,"end-line","end-line",1837326455)),cljs.core._conj.call(null,cljs.core.List.EMPTY,2726),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Keyword(null,"end-column","end-column",1425389514)),cljs.core._conj.call(null,cljs.core.List.EMPTY,55),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Keyword("cljs.analyzer","no-resolve","cljs.analyzer/no-resolve",-1872351017)),cljs.core._conj.call(null,cljs.core.List.EMPTY,true))))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = restarg;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})()))));
});})(sig,restarg,vec__29033,arglist,body,method))
;
var apply_to = ((function (sig,restarg,vec__29033,arglist,body,method){
return (function cljs$core$macros$apply_to(){
if(((1) < cljs.core.count.call(null,sig))){
var params = cljs.core.repeatedly.call(null,(cljs.core.count.call(null,sig) - (1)),cljs.core.gensym);
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","fn","cljs.core$macros/fn",-187522821,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,(function (){var x__23719__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,(function (){var x__23719__auto__ = restarg;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})()))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","let","cljs.core$macros/let",-160286726,null)),(function (){var x__23719__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core.mapcat.call(null,param_bind,params)))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,".",".",1975675962,null)),(function (){var x__23719__auto__ = sym;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,(function (){var x__23719__auto__ = get_delegate.call(null);
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),params,(function (){var x__23719__auto__ = restarg;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
} else {
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","fn","cljs.core$macros/fn",-187522821,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,(function (){var x__23719__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,(function (){var x__23719__auto__ = restarg;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})()))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,".",".",1975675962,null)),(function (){var x__23719__auto__ = sym;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,(function (){var x__23719__auto__ = get_delegate.call(null);
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core","seq","cljs.core/seq",-1649497689,null)),(function (){var x__23719__auto__ = restarg;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
}
});})(sig,restarg,vec__29033,arglist,body,method))
;
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"do","do",1686842252,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"set!","set!",250714521,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,".",".",1975675962,null)),(function (){var x__23719__auto__ = sym;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = get_delegate_prop.call(null);
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","fn","cljs.core$macros/fn",-187522821,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,(function (){var x__23719__auto__ = cljs.core.vec.call(null,sig);
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),body)));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(cljs.core.truth_(solo)?cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"set!","set!",250714521,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,".",".",1975675962,null)),(function (){var x__23719__auto__ = sym;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"-cljs$lang$maxFixedArity","-cljs$lang$maxFixedArity",-1481434279,null)))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = (cljs.core.count.call(null,sig) - (1));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())))):null),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"set!","set!",250714521,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,".",".",1975675962,null)),(function (){var x__23719__auto__ = sym;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"-cljs$lang$applyTo","-cljs$lang$applyTo",-225535181,null)))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = apply_to.call(null);
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
});

cljs.core$macros.variadic_fn_STAR_.cljs$lang$maxFixedArity = 3;
cljs.core$macros.copy_arguments = (function cljs$core$macros$copy_arguments(_AMPERSAND_form,_AMPERSAND_env,dest){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","let","cljs.core$macros/let",-160286726,null)),(function (){var x__23719__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"len__29038__auto__","len__29038__auto__",1660533816,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","alength","cljs.core$macros/alength",-683052937,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","js-arguments","cljs.core$macros/js-arguments",390128540,null)))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})()))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","loop","cljs.core$macros/loop",1731108390,null)),(function (){var x__23719__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"i__29039__auto__","i__29039__auto__",-249955001,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,(0))))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","when","cljs.core$macros/when",328457725,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","<","cljs.core$macros/<",371512596,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"i__29039__auto__","i__29039__auto__",-249955001,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"len__29038__auto__","len__29038__auto__",1660533816,null)))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,".push",".push",-1497267248,null)),(function (){var x__23719__auto__ = dest;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","aget","cljs.core$macros/aget",1976136178,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","js-arguments","cljs.core$macros/js-arguments",390128540,null)))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"i__29039__auto__","i__29039__auto__",-249955001,null)))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"recur","recur",1202958259,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","inc","cljs.core$macros/inc",876629257,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"i__29039__auto__","i__29039__auto__",-249955001,null)))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
});

cljs.core$macros.copy_arguments.cljs$lang$macro = true;
cljs.core$macros.variadic_fn = (function cljs$core$macros$variadic_fn(name,meta,p__29042){
var vec__29045 = p__29042;
var vec__29046 = cljs.core.nth.call(null,vec__29045,(0),null);
var arglist = cljs.core.nth.call(null,vec__29046,(0),null);
var body = cljs.core.nthnext.call(null,vec__29046,(1));
var method = vec__29046;
var fdecl = vec__29045;
var dest_args = ((function (vec__29045,vec__29046,arglist,body,method,fdecl){
return (function cljs$core$macros$variadic_fn_$_dest_args(c){
return cljs.core.map.call(null,((function (vec__29045,vec__29046,arglist,body,method,fdecl){
return (function (n){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","aget","cljs.core$macros/aget",1976136178,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","js-arguments","cljs.core$macros/js-arguments",390128540,null)))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = n;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
});})(vec__29045,vec__29046,arglist,body,method,fdecl))
,cljs.core.range.call(null,c));
});})(vec__29045,vec__29046,arglist,body,method,fdecl))
;
var rname = cljs.core.symbol.call(null,[cljs.core.str(cljs.analyzer._STAR_cljs_ns_STAR_)].join(''),[cljs.core.str(name)].join(''));
var sig = cljs.core.remove.call(null,new cljs.core.PersistentHashSet(null, new cljs.core.PersistentArrayMap(null, 1, [new cljs.core.Symbol(null,"&","&",-2144855648,null),null], null), null),arglist);
var c_1 = (cljs.core.count.call(null,sig) - (1));
var meta__$1 = cljs.core.assoc.call(null,meta,new cljs.core.Keyword(null,"top-fn","top-fn",-2056129173),new cljs.core.PersistentArrayMap(null, 5, [new cljs.core.Keyword(null,"variadic","variadic",882626057),true,new cljs.core.Keyword(null,"max-fixed-arity","max-fixed-arity",-690205543),c_1,new cljs.core.Keyword(null,"method-params","method-params",-980792179),new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [sig], null),new cljs.core.Keyword(null,"arglists","arglists",1661989754),(function (){var x__23719__auto__ = arglist;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),new cljs.core.Keyword(null,"arglists-meta","arglists-meta",1944829838),cljs.core.doall.call(null,cljs.core.map.call(null,meta,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [arglist], null)))], null));
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"do","do",1686842252,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"def","def",597100991,null)),(function (){var x__23719__auto__ = cljs.core.with_meta.call(null,name,meta__$1);
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","fn","cljs.core$macros/fn",-187522821,null)),(function (){var x__23719__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"var_args","var_args",1214280389,null))))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","let","cljs.core$macros/let",-160286726,null)),(function (){var x__23719__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"args__29040__auto__","args__29040__auto__",-1812178002,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","array","cljs.core$macros/array",49650437,null)))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})()))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","copy-arguments","cljs.core$macros/copy-arguments",-1675962356,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"args__29040__auto__","args__29040__auto__",-1812178002,null)))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","let","cljs.core$macros/let",-160286726,null)),(function (){var x__23719__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"argseq__29041__auto__","argseq__29041__auto__",-368352990,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","when","cljs.core$macros/when",328457725,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","<","cljs.core$macros/<",371512596,null)),(function (){var x__23719__auto__ = c_1;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","alength","cljs.core$macros/alength",-683052937,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"args__29040__auto__","args__29040__auto__",-1812178002,null)))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"new","new",-444906321,null)),(function (){var x__23719__auto__ = cljs.core.with_meta.call(null,new cljs.core.Symbol("cljs.core","IndexedSeq","cljs.core/IndexedSeq",-228688698,null),cljs.core.apply.call(null,cljs.core.array_map,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Keyword(null,"file","file",-1269645878)),cljs.core._conj.call(null,cljs.core.List.EMPTY,"/Users/clumsyjedi/workspace/clack/.cljs_rhino_repl/cljs/core.cljc"),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Keyword(null,"line","line",212345235)),cljs.core._conj.call(null,cljs.core.List.EMPTY,2773),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Keyword(null,"column","column",2078222095)),cljs.core._conj.call(null,cljs.core.List.EMPTY,55),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Keyword(null,"end-line","end-line",1837326455)),cljs.core._conj.call(null,cljs.core.List.EMPTY,2773),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Keyword(null,"end-column","end-column",1425389514)),cljs.core._conj.call(null,cljs.core.List.EMPTY,75),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Keyword("cljs.analyzer","no-resolve","cljs.analyzer/no-resolve",-1872351017)),cljs.core._conj.call(null,cljs.core.List.EMPTY,true))))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,".slice",".slice",1874048374,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"args__29040__auto__","args__29040__auto__",-1812178002,null)),(function (){var x__23719__auto__ = c_1;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,(0)),cljs.core._conj.call(null,cljs.core.List.EMPTY,null))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})()))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,".",".",1975675962,null)),(function (){var x__23719__auto__ = rname;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"cljs$core$IFn$_invoke$arity$variadic","cljs$core$IFn$_invoke$arity$variadic",-378825034,null)),dest_args.call(null,c_1),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"argseq__29041__auto__","argseq__29041__auto__",-368352990,null)))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core$macros.variadic_fn_STAR_.call(null,rname,method);
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
});
cljs.core$macros.multi_arity_fn = (function cljs$core$macros$multi_arity_fn(name,meta,fdecl){
var dest_args = (function cljs$core$macros$multi_arity_fn_$_dest_args(c){
return cljs.core.map.call(null,(function (n){
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","aget","cljs.core$macros/aget",1976136178,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","js-arguments","cljs.core$macros/js-arguments",390128540,null)))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = n;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
}),cljs.core.range.call(null,c));
});
var fixed_arity = (function cljs$core$macros$multi_arity_fn_$_fixed_arity(rname,sig){
var c = cljs.core.count.call(null,sig);
return new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [c,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,".",".",1975675962,null)),(function (){var x__23719__auto__ = rname;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,(function (){var x__23719__auto__ = cljs.core.symbol.call(null,[cljs.core.str("cljs$core$IFn$_invoke$arity$"),cljs.core.str(c)].join(''));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),dest_args.call(null,c))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())))], null);
});
var fn_method = (function cljs$core$macros$multi_arity_fn_$_fn_method(p__29059){
var vec__29061 = p__29059;
var sig = cljs.core.nth.call(null,vec__29061,(0),null);
var body = cljs.core.nthnext.call(null,vec__29061,(1));
var method = vec__29061;
if(cljs.core.truth_(cljs.core.some.call(null,new cljs.core.PersistentHashSet(null, new cljs.core.PersistentArrayMap(null, 1, [new cljs.core.Symbol(null,"&","&",-2144855648,null),null], null), null),sig))){
return cljs.core$macros.variadic_fn_STAR_.call(null,name,method,false);
} else {
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"set!","set!",250714521,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,".",".",1975675962,null)),(function (){var x__23719__auto__ = name;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.symbol.call(null,[cljs.core.str("-cljs$core$IFn$_invoke$arity$"),cljs.core.str(cljs.core.count.call(null,sig))].join(''));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","fn","cljs.core$macros/fn",-187522821,null)),(function (){var x__23719__auto__ = method;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
}
});
var rname = cljs.core.symbol.call(null,[cljs.core.str(cljs.analyzer._STAR_cljs_ns_STAR_)].join(''),[cljs.core.str(name)].join(''));
var arglists = cljs.core.map.call(null,cljs.core.first,fdecl);
var varsig_QMARK_ = ((function (rname,arglists){
return (function (p1__29047_SHARP_){
return cljs.core.some.call(null,new cljs.core.PersistentHashSet(null, new cljs.core.PersistentArrayMap(null, 1, [new cljs.core.Symbol(null,"&","&",-2144855648,null),null], null), null),p1__29047_SHARP_);
});})(rname,arglists))
;
var variadic = cljs.core.boolean$.call(null,cljs.core.some.call(null,varsig_QMARK_,arglists));
var sigs = cljs.core.remove.call(null,varsig_QMARK_,arglists);
var maxfa = cljs.core.apply.call(null,cljs.core.max,cljs.core.concat.call(null,cljs.core.map.call(null,cljs.core.count,sigs),new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [(cljs.core.count.call(null,cljs.core.first.call(null,cljs.core.filter.call(null,varsig_QMARK_,arglists))) - (2))], null)));
var meta__$1 = cljs.core.assoc.call(null,meta,new cljs.core.Keyword(null,"top-fn","top-fn",-2056129173),new cljs.core.PersistentArrayMap(null, 5, [new cljs.core.Keyword(null,"variadic","variadic",882626057),variadic,new cljs.core.Keyword(null,"max-fixed-arity","max-fixed-arity",-690205543),maxfa,new cljs.core.Keyword(null,"method-params","method-params",-980792179),sigs,new cljs.core.Keyword(null,"arglists","arglists",1661989754),arglists,new cljs.core.Keyword(null,"arglists-meta","arglists-meta",1944829838),cljs.core.doall.call(null,cljs.core.map.call(null,meta,arglists))], null));
var args_sym = cljs.core.gensym.call(null,"args");
return cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"do","do",1686842252,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"def","def",597100991,null)),(function (){var x__23719__auto__ = cljs.core.with_meta.call(null,name,meta__$1);
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","fn","cljs.core$macros/fn",-187522821,null)),(function (){var x__23719__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"var_args","var_args",1214280389,null))))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","let","cljs.core$macros/let",-160286726,null)),(function (){var x__23719__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,(function (){var x__23719__auto__ = args_sym;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","array","cljs.core$macros/array",49650437,null)))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})()))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","copy-arguments","cljs.core$macros/copy-arguments",-1675962356,null)),(function (){var x__23719__auto__ = args_sym;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","case","cljs.core$macros/case",-2131866965,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","alength","cljs.core$macros/alength",-683052937,null)),(function (){var x__23719__auto__ = args_sym;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),cljs.core.mapcat.call(null,((function (rname,arglists,varsig_QMARK_,variadic,sigs,maxfa,meta__$1,args_sym){
return (function (p1__29048_SHARP_){
return fixed_arity.call(null,rname,p1__29048_SHARP_);
});})(rname,arglists,varsig_QMARK_,variadic,sigs,maxfa,meta__$1,args_sym))
,sigs),(function (){var x__23719__auto__ = ((variadic)?cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","let","cljs.core$macros/let",-160286726,null)),(function (){var x__23719__auto__ = cljs.core.vec.call(null,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"argseq__29049__auto__","argseq__29049__auto__",-1248787268,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"new","new",-444906321,null)),(function (){var x__23719__auto__ = cljs.core.with_meta.call(null,new cljs.core.Symbol("cljs.core","IndexedSeq","cljs.core/IndexedSeq",-228688698,null),cljs.core.apply.call(null,cljs.core.array_map,cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Keyword(null,"file","file",-1269645878)),cljs.core._conj.call(null,cljs.core.List.EMPTY,"/Users/clumsyjedi/workspace/clack/.cljs_rhino_repl/cljs/core.cljc"),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Keyword(null,"line","line",212345235)),cljs.core._conj.call(null,cljs.core.List.EMPTY,2830),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Keyword(null,"column","column",2078222095)),cljs.core._conj.call(null,cljs.core.List.EMPTY,58),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Keyword(null,"end-line","end-line",1837326455)),cljs.core._conj.call(null,cljs.core.List.EMPTY,2830),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Keyword(null,"end-column","end-column",1425389514)),cljs.core._conj.call(null,cljs.core.List.EMPTY,78),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Keyword("cljs.analyzer","no-resolve","cljs.analyzer/no-resolve",-1872351017)),cljs.core._conj.call(null,cljs.core.List.EMPTY,true))))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,".slice",".slice",1874048374,null)),(function (){var x__23719__auto__ = args_sym;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = maxfa;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,(0)),cljs.core._conj.call(null,cljs.core.List.EMPTY,null))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})()))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,".",".",1975675962,null)),(function (){var x__23719__auto__ = rname;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"cljs$core$IFn$_invoke$arity$variadic","cljs$core$IFn$_invoke$arity$variadic",-378825034,null)),dest_args.call(null,maxfa),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"argseq__29049__auto__","argseq__29049__auto__",-1248787268,null)))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})()))):(cljs.core.truth_(new cljs.core.Keyword(null,"macro","macro",-867863404).cljs$core$IFn$_invoke$arity$1(meta__$1))?cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"throw","throw",595905694,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("js","Error.","js/Error.",750655924,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","str","cljs.core$macros/str",-2019499702,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,"Invalid arity: "),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","-","cljs.core$macros/-",13526976,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","alength","cljs.core$macros/alength",-683052937,null)),(function (){var x__23719__auto__ = args_sym;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,(2)))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})()))):cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"throw","throw",595905694,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("js","Error.","js/Error.",750655924,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","str","cljs.core$macros/str",-2019499702,null)),cljs.core._conj.call(null,cljs.core.List.EMPTY,"Invalid arity: "),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol("cljs.core$macros","alength","cljs.core$macros/alength",-683052937,null)),(function (){var x__23719__auto__ = args_sym;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),cljs.core.map.call(null,fn_method,fdecl),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"set!","set!",250714521,null)),(function (){var x__23719__auto__ = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,".",".",1975675962,null)),(function (){var x__23719__auto__ = name;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"-cljs$lang$maxFixedArity","-cljs$lang$maxFixedArity",-1481434279,null)))));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),(function (){var x__23719__auto__ = maxfa;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})())));
});
/**
 * Same as (def name (core/fn [params* ] exprs*)) or (def
 *  name (core/fn ([params* ] exprs*)+)) with any doc-string or attrs added
 *  to the var metadata. prepost-map defines a map with optional keys
 *  :pre and :post that contain collections of pre or post conditions.
 * @param {...*} var_args
 */
cljs.core$macros.defn = (function() { 
var cljs$core$macros$defn__delegate = function (_AMPERSAND_form,_AMPERSAND_env,name,fdecl){
if((name instanceof cljs.core.Symbol)){
} else {
throw (new Error("First argument to defn must be a symbol"));
}

var m = ((typeof cljs.core.first.call(null,fdecl) === 'string')?new cljs.core.PersistentArrayMap(null, 1, [new cljs.core.Keyword(null,"doc","doc",1913296891),cljs.core.first.call(null,fdecl)], null):cljs.core.PersistentArrayMap.EMPTY);
var fdecl__$1 = ((typeof cljs.core.first.call(null,fdecl) === 'string')?cljs.core.next.call(null,fdecl):fdecl);
var m__$1 = ((cljs.core.map_QMARK_.call(null,cljs.core.first.call(null,fdecl__$1)))?cljs.core.conj.call(null,m,cljs.core.first.call(null,fdecl__$1)):m);
var fdecl__$2 = ((cljs.core.map_QMARK_.call(null,cljs.core.first.call(null,fdecl__$1)))?cljs.core.next.call(null,fdecl__$1):fdecl__$1);
var fdecl__$3 = ((cljs.core.vector_QMARK_.call(null,cljs.core.first.call(null,fdecl__$2)))?(function (){var x__23719__auto__ = fdecl__$2;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})():fdecl__$2);
var m__$2 = ((cljs.core.map_QMARK_.call(null,cljs.core.last.call(null,fdecl__$3)))?cljs.core.conj.call(null,m__$1,cljs.core.last.call(null,fdecl__$3)):m__$1);
var fdecl__$4 = ((cljs.core.map_QMARK_.call(null,cljs.core.last.call(null,fdecl__$3)))?cljs.core.butlast.call(null,fdecl__$3):fdecl__$3);
var m__$3 = cljs.core.conj.call(null,new cljs.core.PersistentArrayMap(null, 1, [new cljs.core.Keyword(null,"arglists","arglists",1661989754),cljs.core._conj.call(null,(function (){var x__23719__auto__ = cljs.core$macros.sigs.call(null,fdecl__$4);
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})(),new cljs.core.Symbol(null,"quote","quote",1377916282,null))], null),m__$2);
var m__$4 = cljs.core.conj.call(null,(cljs.core.truth_(cljs.core.meta.call(null,name))?cljs.core.meta.call(null,name):cljs.core.PersistentArrayMap.EMPTY),m__$3);
if(cljs.core.truth_(cljs.core$macros.multi_arity_fn_QMARK_.call(null,fdecl__$4))){
return cljs.core$macros.multi_arity_fn.call(null,name,(cljs.core.truth_(cljs.compiler.checking_types_QMARK_.call(null))?cljs.core.update_in.call(null,m__$4,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword(null,"jsdoc","jsdoc",1745183516)], null),cljs.core.conj,"@param {...*} var_args"):m__$4),fdecl__$4);
} else {
if(cljs.core.truth_(cljs.core$macros.variadic_fn_QMARK_.call(null,fdecl__$4))){
return cljs.core$macros.variadic_fn.call(null,name,(cljs.core.truth_(cljs.compiler.checking_types_QMARK_.call(null))?cljs.core.update_in.call(null,m__$4,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword(null,"jsdoc","jsdoc",1745183516)], null),cljs.core.conj,"@param {...*} var_args"):m__$4),fdecl__$4);
} else {
return cljs.core._conj.call(null,(function (){var x__23719__auto__ = cljs.core.with_meta.call(null,name,m__$4);
return cljs.core._conj.call(null,(function (){var x__23719__auto____$1 = cljs.core.cons.call(null,new cljs.core.Symbol("cljs.core$macros","fn","cljs.core$macros/fn",-187522821,null),fdecl__$4);
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto____$1);
})(),x__23719__auto__);
})(),new cljs.core.Symbol(null,"def","def",597100991,null));

}
}
};
var cljs$core$macros$defn = function (_AMPERSAND_form,_AMPERSAND_env,name,var_args){
var fdecl = null;
if (arguments.length > 3) {
var G__29062__i = 0, G__29062__a = new Array(arguments.length -  3);
while (G__29062__i < G__29062__a.length) {G__29062__a[G__29062__i] = arguments[G__29062__i + 3]; ++G__29062__i;}
  fdecl = new cljs.core.IndexedSeq(G__29062__a,0);
} 
return cljs$core$macros$defn__delegate.call(this,_AMPERSAND_form,_AMPERSAND_env,name,fdecl);};
cljs$core$macros$defn.cljs$lang$maxFixedArity = 3;
cljs$core$macros$defn.cljs$lang$applyTo = (function (arglist__29063){
var _AMPERSAND_form = cljs.core.first(arglist__29063);
arglist__29063 = cljs.core.next(arglist__29063);
var _AMPERSAND_env = cljs.core.first(arglist__29063);
arglist__29063 = cljs.core.next(arglist__29063);
var name = cljs.core.first(arglist__29063);
var fdecl = cljs.core.rest(arglist__29063);
return cljs$core$macros$defn__delegate(_AMPERSAND_form,_AMPERSAND_env,name,fdecl);
});
cljs$core$macros$defn.cljs$core$IFn$_invoke$arity$variadic = cljs$core$macros$defn__delegate;
return cljs$core$macros$defn;
})()
;
cljs.core$macros.defn.cljs$lang$macro = true;
/**
 * Like defn, but the resulting function name is declared as a
 *   macro and will be used as a macro by the compiler when it is
 *   called.
 */
cljs.core$macros.defmacro = (function cljs$core$macros$defmacro(var_args){
var args__23962__auto__ = [];
var len__23955__auto___29068 = arguments.length;
var i__23956__auto___29069 = (0);
while(true){
if((i__23956__auto___29069 < len__23955__auto___29068)){
args__23962__auto__.push((arguments[i__23956__auto___29069]));

var G__29070 = (i__23956__auto___29069 + (1));
i__23956__auto___29069 = G__29070;
continue;
} else {
}
break;
}

var argseq__23963__auto__ = ((((3) < args__23962__auto__.length))?(new cljs.core.IndexedSeq(args__23962__auto__.slice((3)),(0),null)):null);
return cljs.core$macros.defmacro.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),argseq__23963__auto__);
});

cljs.core$macros.defmacro.cljs$core$IFn$_invoke$arity$variadic = (function (_AMPERSAND_form,_AMPERSAND_env,name,args){
var prefix = (function (){var p = (function (){var x__23719__auto__ = cljs.core.vary_meta.call(null,name,cljs.core.assoc,new cljs.core.Keyword(null,"macro","macro",-867863404),true);
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})();
var args__$1 = args;
while(true){
var f = cljs.core.first.call(null,args__$1);
if(typeof f === 'string'){
var G__29071 = cljs.core.cons.call(null,f,p);
var G__29072 = cljs.core.next.call(null,args__$1);
p = G__29071;
args__$1 = G__29072;
continue;
} else {
if(cljs.core.map_QMARK_.call(null,f)){
var G__29073 = cljs.core.cons.call(null,f,p);
var G__29074 = cljs.core.next.call(null,args__$1);
p = G__29073;
args__$1 = G__29074;
continue;
} else {
return p;
}
}
break;
}
})();
var fdecl = (function (){var fd = args;
while(true){
if(typeof cljs.core.first.call(null,fd) === 'string'){
var G__29075 = cljs.core.next.call(null,fd);
fd = G__29075;
continue;
} else {
if(cljs.core.map_QMARK_.call(null,cljs.core.first.call(null,fd))){
var G__29076 = cljs.core.next.call(null,fd);
fd = G__29076;
continue;
} else {
return fd;
}
}
break;
}
})();
var fdecl__$1 = ((cljs.core.vector_QMARK_.call(null,cljs.core.first.call(null,fdecl)))?(function (){var x__23719__auto__ = fdecl;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto__);
})():fdecl);
var add_implicit_args = ((function (prefix,fdecl,fdecl__$1){
return (function (fd){
var args__$1 = cljs.core.first.call(null,fd);
return cljs.core.cons.call(null,cljs.core.vec.call(null,cljs.core.cons.call(null,new cljs.core.Symbol(null,"&form","&form",1482799337,null),cljs.core.cons.call(null,new cljs.core.Symbol(null,"&env","&env",-919163083,null),args__$1))),cljs.core.next.call(null,fd));
});})(prefix,fdecl,fdecl__$1))
;
var add_args = ((function (prefix,fdecl,fdecl__$1,add_implicit_args){
return (function (acc,ds){
while(true){
if((ds == null)){
return acc;
} else {
var d = cljs.core.first.call(null,ds);
if(cljs.core.map_QMARK_.call(null,d)){
return cljs.core.conj.call(null,acc,d);
} else {
var G__29077 = cljs.core.conj.call(null,acc,add_implicit_args.call(null,d));
var G__29078 = cljs.core.next.call(null,ds);
acc = G__29077;
ds = G__29078;
continue;
}
}
break;
}
});})(prefix,fdecl,fdecl__$1,add_implicit_args))
;
var fdecl__$2 = cljs.core.seq.call(null,add_args.call(null,cljs.core.PersistentVector.EMPTY,fdecl__$1));
var decl = (function (){var p = prefix;
var d = fdecl__$2;
while(true){
if(cljs.core.truth_(p)){
var G__29079 = cljs.core.next.call(null,p);
var G__29080 = cljs.core.cons.call(null,cljs.core.first.call(null,p),d);
p = G__29079;
d = G__29080;
continue;
} else {
return d;
}
break;
}
})();
return cljs.core._conj.call(null,(function (){var x__23719__auto__ = cljs.core.cons.call(null,new cljs.core.Symbol("cljs.core$macros","defn","cljs.core$macros/defn",-728332354,null),decl);
return cljs.core._conj.call(null,(function (){var x__23719__auto____$1 = cljs.core._conj.call(null,(function (){var x__23719__auto____$1 = cljs.core.sequence.call(null,cljs.core.seq.call(null,cljs.core.concat.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,".",".",1975675962,null)),(function (){var x__23719__auto____$1 = name;
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto____$1);
})(),cljs.core._conj.call(null,cljs.core.List.EMPTY,new cljs.core.Symbol(null,"-cljs$lang$macro","-cljs$lang$macro",443600924,null)))));
return cljs.core._conj.call(null,cljs.core._conj.call(null,cljs.core.List.EMPTY,true),x__23719__auto____$1);
})(),new cljs.core.Symbol(null,"set!","set!",250714521,null));
return cljs.core._conj.call(null,cljs.core.List.EMPTY,x__23719__auto____$1);
})(),x__23719__auto__);
})(),new cljs.core.Symbol(null,"do","do",1686842252,null));
});

cljs.core$macros.defmacro.cljs$lang$maxFixedArity = (3);

cljs.core$macros.defmacro.cljs$lang$applyTo = (function (seq29064){
var G__29065 = cljs.core.first.call(null,seq29064);
var seq29064__$1 = cljs.core.next.call(null,seq29064);
var G__29066 = cljs.core.first.call(null,seq29064__$1);
var seq29064__$2 = cljs.core.next.call(null,seq29064__$1);
var G__29067 = cljs.core.first.call(null,seq29064__$2);
var seq29064__$3 = cljs.core.next.call(null,seq29064__$2);
return cljs.core$macros.defmacro.cljs$core$IFn$_invoke$arity$variadic(G__29065,G__29066,G__29067,seq29064__$3);
});
cljs.core$macros.defmacro.cljs$lang$macro = true;

//# sourceMappingURL=core$macros.js.map