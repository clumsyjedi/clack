// Compiled by ClojureScript 1.8.51 {}
goog.provide('cljs.source_map');
goog.require('cljs.core');
goog.require('goog.object');
goog.require('clojure.string');
goog.require('clojure.set');
goog.require('cljs.source_map.base64_vlq');
/**
 * Take a seq of source file names and return a map from
 * file number to integer index. For reverse source maps.
 */
cljs.source_map.indexed_sources = (function cljs$source_map$indexed_sources(sources){
return cljs.core.reduce.call(null,(function (m,p__29205){
var vec__29206 = p__29205;
var i = cljs.core.nth.call(null,vec__29206,(0),null);
var v = cljs.core.nth.call(null,vec__29206,(1),null);
return cljs.core.assoc.call(null,m,v,i);
}),cljs.core.PersistentArrayMap.EMPTY,cljs.core.map_indexed.call(null,(function (a,b){
return new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [a,b], null);
}),sources));
});
/**
 * Take a seq of source file names and return a comparator
 * that can be used to construct a sorted map. For reverse
 * source maps.
 */
cljs.source_map.source_compare = (function cljs$source_map$source_compare(sources){
var sources__$1 = cljs.source_map.indexed_sources.call(null,sources);
return ((function (sources__$1){
return (function (a,b){
return cljs.core.compare.call(null,sources__$1.call(null,a),sources__$1.call(null,b));
});
;})(sources__$1))
});
/**
 * Take a source map segment represented as a vector
 * and return a map.
 */
cljs.source_map.seg__GT_map = (function cljs$source_map$seg__GT_map(seg,source_map){
var vec__29208 = seg;
var gcol = cljs.core.nth.call(null,vec__29208,(0),null);
var source = cljs.core.nth.call(null,vec__29208,(1),null);
var line = cljs.core.nth.call(null,vec__29208,(2),null);
var col = cljs.core.nth.call(null,vec__29208,(3),null);
var name = cljs.core.nth.call(null,vec__29208,(4),null);
return new cljs.core.PersistentArrayMap(null, 5, [new cljs.core.Keyword(null,"gcol","gcol",309250807),gcol,new cljs.core.Keyword(null,"source","source",-433931539),(goog.object.get(source_map,"sources")[source]),new cljs.core.Keyword(null,"line","line",212345235),line,new cljs.core.Keyword(null,"col","col",-1959363084),col,new cljs.core.Keyword(null,"name","name",1843675177),(function (){var temp__4657__auto__ = new cljs.core.Keyword(null,"name","name",1843675177).cljs$core$IFn$_invoke$arity$1(cljs.core.meta.call(null,seg));
if(cljs.core.truth_(temp__4657__auto__)){
var name__$1 = temp__4657__auto__;
return (goog.object.get(source_map,"names")[name__$1]);
} else {
return null;
}
})()], null);
});
/**
 * Combine a source map segment vector and a relative
 * source map segment vector and combine them to get
 * an absolute segment posititon information as a vector.
 */
cljs.source_map.seg_combine = (function cljs$source_map$seg_combine(seg,relseg){
var vec__29211 = seg;
var gcol = cljs.core.nth.call(null,vec__29211,(0),null);
var source = cljs.core.nth.call(null,vec__29211,(1),null);
var line = cljs.core.nth.call(null,vec__29211,(2),null);
var col = cljs.core.nth.call(null,vec__29211,(3),null);
var name = cljs.core.nth.call(null,vec__29211,(4),null);
var vec__29212 = relseg;
var rgcol = cljs.core.nth.call(null,vec__29212,(0),null);
var rsource = cljs.core.nth.call(null,vec__29212,(1),null);
var rline = cljs.core.nth.call(null,vec__29212,(2),null);
var rcol = cljs.core.nth.call(null,vec__29212,(3),null);
var rname = cljs.core.nth.call(null,vec__29212,(4),null);
var nseg = new cljs.core.PersistentVector(null, 5, 5, cljs.core.PersistentVector.EMPTY_NODE, [(gcol + rgcol),((function (){var or__22885__auto__ = source;
if(cljs.core.truth_(or__22885__auto__)){
return or__22885__auto__;
} else {
return (0);
}
})() + rsource),((function (){var or__22885__auto__ = line;
if(cljs.core.truth_(or__22885__auto__)){
return or__22885__auto__;
} else {
return (0);
}
})() + rline),((function (){var or__22885__auto__ = col;
if(cljs.core.truth_(or__22885__auto__)){
return or__22885__auto__;
} else {
return (0);
}
})() + rcol),((function (){var or__22885__auto__ = name;
if(cljs.core.truth_(or__22885__auto__)){
return or__22885__auto__;
} else {
return (0);
}
})() + rname)], null);
if(cljs.core.truth_(name)){
return cljs.core.with_meta.call(null,nseg,new cljs.core.PersistentArrayMap(null, 1, [new cljs.core.Keyword(null,"name","name",1843675177),(name + rname)], null));
} else {
return nseg;
}
});
/**
 * Helper for decode-reverse. Take a reverse source map and
 *   update it with a segment map.
 */
cljs.source_map.update_reverse_result = (function cljs$source_map$update_reverse_result(result,segmap,gline){
var map__29215 = segmap;
var map__29215__$1 = ((((!((map__29215 == null)))?((((map__29215.cljs$lang$protocol_mask$partition0$ & (64))) || (map__29215.cljs$core$ISeq$))?true:false):false))?cljs.core.apply.call(null,cljs.core.hash_map,map__29215):map__29215);
var gcol = cljs.core.get.call(null,map__29215__$1,new cljs.core.Keyword(null,"gcol","gcol",309250807));
var source = cljs.core.get.call(null,map__29215__$1,new cljs.core.Keyword(null,"source","source",-433931539));
var line = cljs.core.get.call(null,map__29215__$1,new cljs.core.Keyword(null,"line","line",212345235));
var col = cljs.core.get.call(null,map__29215__$1,new cljs.core.Keyword(null,"col","col",-1959363084));
var name = cljs.core.get.call(null,map__29215__$1,new cljs.core.Keyword(null,"name","name",1843675177));
var d = new cljs.core.PersistentArrayMap(null, 2, [new cljs.core.Keyword(null,"gline","gline",-1086242431),gline,new cljs.core.Keyword(null,"gcol","gcol",309250807),gcol], null);
var d__$1 = (cljs.core.truth_(name)?cljs.core.assoc.call(null,d,new cljs.core.Keyword(null,"name","name",1843675177),name):d);
return cljs.core.update_in.call(null,result,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [source], null),cljs.core.fnil.call(null,((function (map__29215,map__29215__$1,gcol,source,line,col,name,d,d__$1){
return (function (m){
return cljs.core.update_in.call(null,m,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [line], null),cljs.core.fnil.call(null,((function (map__29215,map__29215__$1,gcol,source,line,col,name,d,d__$1){
return (function (m__$1){
return cljs.core.update_in.call(null,m__$1,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [col], null),cljs.core.fnil.call(null,((function (map__29215,map__29215__$1,gcol,source,line,col,name,d,d__$1){
return (function (v){
return cljs.core.conj.call(null,v,d__$1);
});})(map__29215,map__29215__$1,gcol,source,line,col,name,d,d__$1))
,cljs.core.PersistentVector.EMPTY));
});})(map__29215,map__29215__$1,gcol,source,line,col,name,d,d__$1))
,cljs.core.sorted_map.call(null)));
});})(map__29215,map__29215__$1,gcol,source,line,col,name,d,d__$1))
,cljs.core.sorted_map.call(null)));
});
/**
 * Convert a v3 source map JSON object into a reverse source map
 *   mapping original ClojureScript source locations to the generated
 *   JavaScript.
 */
cljs.source_map.decode_reverse = (function cljs$source_map$decode_reverse(var_args){
var args29217 = [];
var len__23955__auto___29221 = arguments.length;
var i__23956__auto___29222 = (0);
while(true){
if((i__23956__auto___29222 < len__23955__auto___29221)){
args29217.push((arguments[i__23956__auto___29222]));

var G__29223 = (i__23956__auto___29222 + (1));
i__23956__auto___29222 = G__29223;
continue;
} else {
}
break;
}

var G__29219 = args29217.length;
switch (G__29219) {
case 1:
return cljs.source_map.decode_reverse.cljs$core$IFn$_invoke$arity$1((arguments[(0)]));

break;
case 2:
return cljs.source_map.decode_reverse.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
default:
throw (new Error([cljs.core.str("Invalid arity: "),cljs.core.str(args29217.length)].join('')));

}
});

cljs.source_map.decode_reverse.cljs$core$IFn$_invoke$arity$1 = (function (source_map){
return cljs.source_map.decode_reverse.call(null,goog.object.get(source_map,"mappings"),source_map);
});

cljs.source_map.decode_reverse.cljs$core$IFn$_invoke$arity$2 = (function (mappings,source_map){
var sources = goog.object.get(source_map,"sources");
var relseg_init = new cljs.core.PersistentVector(null, 5, 5, cljs.core.PersistentVector.EMPTY_NODE, [(0),(0),(0),(0),(0)], null);
var lines = cljs.core.seq.call(null,clojure.string.split.call(null,mappings,/;/));
var gline = (0);
var lines__$1 = lines;
var relseg = relseg_init;
var result = cljs.core.sorted_map_by.call(null,cljs.source_map.source_compare.call(null,sources));
while(true){
if(lines__$1){
var line = cljs.core.first.call(null,lines__$1);
var vec__29220 = ((clojure.string.blank_QMARK_.call(null,line))?new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [result,relseg], null):(function (){var segs = cljs.core.seq.call(null,clojure.string.split.call(null,line,/,/));
var segs__$1 = segs;
var relseg__$1 = relseg;
var result__$1 = result;
while(true){
if(segs__$1){
var seg = cljs.core.first.call(null,segs__$1);
var nrelseg = cljs.source_map.seg_combine.call(null,cljs.source_map.base64_vlq.decode.call(null,seg),relseg__$1);
var G__29225 = cljs.core.next.call(null,segs__$1);
var G__29226 = nrelseg;
var G__29227 = cljs.source_map.update_reverse_result.call(null,result__$1,cljs.source_map.seg__GT_map.call(null,nrelseg,source_map),gline);
segs__$1 = G__29225;
relseg__$1 = G__29226;
result__$1 = G__29227;
continue;
} else {
return new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [result__$1,relseg__$1], null);
}
break;
}
})());
var result__$1 = cljs.core.nth.call(null,vec__29220,(0),null);
var relseg__$1 = cljs.core.nth.call(null,vec__29220,(1),null);
var G__29228 = (gline + (1));
var G__29229 = cljs.core.next.call(null,lines__$1);
var G__29230 = cljs.core.assoc.call(null,relseg__$1,(0),(0));
var G__29231 = result__$1;
gline = G__29228;
lines__$1 = G__29229;
relseg = G__29230;
result = G__29231;
continue;
} else {
return result;
}
break;
}
});

cljs.source_map.decode_reverse.cljs$lang$maxFixedArity = 2;
/**
 * Helper for decode. Take a source map and update it based on a
 *   segment map.
 */
cljs.source_map.update_result = (function cljs$source_map$update_result(result,segmap,gline){
var map__29235 = segmap;
var map__29235__$1 = ((((!((map__29235 == null)))?((((map__29235.cljs$lang$protocol_mask$partition0$ & (64))) || (map__29235.cljs$core$ISeq$))?true:false):false))?cljs.core.apply.call(null,cljs.core.hash_map,map__29235):map__29235);
var gcol = cljs.core.get.call(null,map__29235__$1,new cljs.core.Keyword(null,"gcol","gcol",309250807));
var source = cljs.core.get.call(null,map__29235__$1,new cljs.core.Keyword(null,"source","source",-433931539));
var line = cljs.core.get.call(null,map__29235__$1,new cljs.core.Keyword(null,"line","line",212345235));
var col = cljs.core.get.call(null,map__29235__$1,new cljs.core.Keyword(null,"col","col",-1959363084));
var name = cljs.core.get.call(null,map__29235__$1,new cljs.core.Keyword(null,"name","name",1843675177));
var d = new cljs.core.PersistentArrayMap(null, 3, [new cljs.core.Keyword(null,"line","line",212345235),line,new cljs.core.Keyword(null,"col","col",-1959363084),col,new cljs.core.Keyword(null,"source","source",-433931539),source], null);
var d__$1 = (cljs.core.truth_(name)?cljs.core.assoc.call(null,d,new cljs.core.Keyword(null,"name","name",1843675177),name):d);
return cljs.core.update_in.call(null,result,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [gline], null),cljs.core.fnil.call(null,((function (map__29235,map__29235__$1,gcol,source,line,col,name,d,d__$1){
return (function (m){
return cljs.core.update_in.call(null,m,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [gcol], null),cljs.core.fnil.call(null,((function (map__29235,map__29235__$1,gcol,source,line,col,name,d,d__$1){
return (function (p1__29232_SHARP_){
return cljs.core.conj.call(null,p1__29232_SHARP_,d__$1);
});})(map__29235,map__29235__$1,gcol,source,line,col,name,d,d__$1))
,cljs.core.PersistentVector.EMPTY));
});})(map__29235,map__29235__$1,gcol,source,line,col,name,d,d__$1))
,cljs.core.sorted_map.call(null)));
});
/**
 * Convert a v3 source map JSON object into a source map mapping
 *   generated JavaScript source locations to the original
 *   ClojureScript.
 */
cljs.source_map.decode = (function cljs$source_map$decode(var_args){
var args29237 = [];
var len__23955__auto___29241 = arguments.length;
var i__23956__auto___29242 = (0);
while(true){
if((i__23956__auto___29242 < len__23955__auto___29241)){
args29237.push((arguments[i__23956__auto___29242]));

var G__29243 = (i__23956__auto___29242 + (1));
i__23956__auto___29242 = G__29243;
continue;
} else {
}
break;
}

var G__29239 = args29237.length;
switch (G__29239) {
case 1:
return cljs.source_map.decode.cljs$core$IFn$_invoke$arity$1((arguments[(0)]));

break;
case 2:
return cljs.source_map.decode.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
default:
throw (new Error([cljs.core.str("Invalid arity: "),cljs.core.str(args29237.length)].join('')));

}
});

cljs.source_map.decode.cljs$core$IFn$_invoke$arity$1 = (function (source_map){
return cljs.source_map.decode.call(null,goog.object.get(source_map,"mappings"),source_map);
});

cljs.source_map.decode.cljs$core$IFn$_invoke$arity$2 = (function (mappings,source_map){
var sources = goog.object.get(source_map,"sources");
var relseg_init = new cljs.core.PersistentVector(null, 5, 5, cljs.core.PersistentVector.EMPTY_NODE, [(0),(0),(0),(0),(0)], null);
var lines = cljs.core.seq.call(null,clojure.string.split.call(null,mappings,/;/));
var gline = (0);
var lines__$1 = lines;
var relseg = relseg_init;
var result = cljs.core.PersistentArrayMap.EMPTY;
while(true){
if(lines__$1){
var line = cljs.core.first.call(null,lines__$1);
var vec__29240 = ((clojure.string.blank_QMARK_.call(null,line))?new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [result,relseg], null):(function (){var segs = cljs.core.seq.call(null,clojure.string.split.call(null,line,/,/));
var segs__$1 = segs;
var relseg__$1 = relseg;
var result__$1 = result;
while(true){
if(segs__$1){
var seg = cljs.core.first.call(null,segs__$1);
var nrelseg = cljs.source_map.seg_combine.call(null,cljs.source_map.base64_vlq.decode.call(null,seg),relseg__$1);
var G__29245 = cljs.core.next.call(null,segs__$1);
var G__29246 = nrelseg;
var G__29247 = cljs.source_map.update_result.call(null,result__$1,cljs.source_map.seg__GT_map.call(null,nrelseg,source_map),gline);
segs__$1 = G__29245;
relseg__$1 = G__29246;
result__$1 = G__29247;
continue;
} else {
return new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [result__$1,relseg__$1], null);
}
break;
}
})());
var result__$1 = cljs.core.nth.call(null,vec__29240,(0),null);
var relseg__$1 = cljs.core.nth.call(null,vec__29240,(1),null);
var G__29248 = (gline + (1));
var G__29249 = cljs.core.next.call(null,lines__$1);
var G__29250 = cljs.core.assoc.call(null,relseg__$1,(0),(0));
var G__29251 = result__$1;
gline = G__29248;
lines__$1 = G__29249;
relseg = G__29250;
result = G__29251;
continue;
} else {
return result;
}
break;
}
});

cljs.source_map.decode.cljs$lang$maxFixedArity = 2;
/**
 * Take a nested sorted map encoding line and column information
 * for a file and return a vector of vectors of encoded segments.
 * Each vector represents a line, and the internal vectors are segments
 * representing the contents of the line.
 */
cljs.source_map.lines__GT_segs = (function cljs$source_map$lines__GT_segs(lines){
var relseg = cljs.core.atom.call(null,new cljs.core.PersistentVector(null, 5, 5, cljs.core.PersistentVector.EMPTY_NODE, [(0),(0),(0),(0),(0)], null));
return cljs.core.reduce.call(null,((function (relseg){
return (function (segs,cols){
cljs.core.swap_BANG_.call(null,relseg,((function (relseg){
return (function (p__29258){
var vec__29259 = p__29258;
var _ = cljs.core.nth.call(null,vec__29259,(0),null);
var source = cljs.core.nth.call(null,vec__29259,(1),null);
var line = cljs.core.nth.call(null,vec__29259,(2),null);
var col = cljs.core.nth.call(null,vec__29259,(3),null);
var name = cljs.core.nth.call(null,vec__29259,(4),null);
return new cljs.core.PersistentVector(null, 5, 5, cljs.core.PersistentVector.EMPTY_NODE, [(0),source,line,col,name], null);
});})(relseg))
);

return cljs.core.conj.call(null,segs,cljs.core.reduce.call(null,((function (relseg){
return (function (cols__$1,p__29260){
var vec__29261 = p__29260;
var gcol = cljs.core.nth.call(null,vec__29261,(0),null);
var sidx = cljs.core.nth.call(null,vec__29261,(1),null);
var line = cljs.core.nth.call(null,vec__29261,(2),null);
var col = cljs.core.nth.call(null,vec__29261,(3),null);
var name = cljs.core.nth.call(null,vec__29261,(4),null);
var seg = vec__29261;
var offset = cljs.core.map.call(null,cljs.core._,seg,cljs.core.deref.call(null,relseg));
cljs.core.swap_BANG_.call(null,relseg,((function (offset,vec__29261,gcol,sidx,line,col,name,seg,relseg){
return (function (p__29262){
var vec__29263 = p__29262;
var _ = cljs.core.nth.call(null,vec__29263,(0),null);
var ___$1 = cljs.core.nth.call(null,vec__29263,(1),null);
var ___$2 = cljs.core.nth.call(null,vec__29263,(2),null);
var ___$3 = cljs.core.nth.call(null,vec__29263,(3),null);
var lname = cljs.core.nth.call(null,vec__29263,(4),null);
return new cljs.core.PersistentVector(null, 5, 5, cljs.core.PersistentVector.EMPTY_NODE, [gcol,sidx,line,col,(function (){var or__22885__auto__ = name;
if(cljs.core.truth_(or__22885__auto__)){
return or__22885__auto__;
} else {
return lname;
}
})()], null);
});})(offset,vec__29261,gcol,sidx,line,col,name,seg,relseg))
);

return cljs.core.conj.call(null,cols__$1,cljs.source_map.base64_vlq.encode.call(null,offset));
});})(relseg))
,cljs.core.PersistentVector.EMPTY,cols));
});})(relseg))
,cljs.core.PersistentVector.EMPTY,lines);
});
/**
 * Take an internal source map representation represented as nested
 * sorted maps of file, line, column and return a source map v3 JSON
 * string.
 */
cljs.source_map.encode = (function cljs$source_map$encode(m,opts){
var lines = cljs.core.atom.call(null,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.PersistentVector.EMPTY], null));
var names__GT_idx = cljs.core.atom.call(null,cljs.core.PersistentArrayMap.EMPTY);
var name_idx = cljs.core.atom.call(null,(0));
var preamble_lines = cljs.core.take.call(null,(function (){var or__22885__auto__ = new cljs.core.Keyword(null,"preamble-line-count","preamble-line-count",-659949744).cljs$core$IFn$_invoke$arity$1(opts);
if(cljs.core.truth_(or__22885__auto__)){
return or__22885__auto__;
} else {
return (0);
}
})(),cljs.core.repeat.call(null,cljs.core.PersistentVector.EMPTY));
var info__GT_segv = ((function (lines,names__GT_idx,name_idx,preamble_lines){
return (function (info,source_idx,line,col){
var segv = new cljs.core.PersistentVector(null, 4, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword(null,"gcol","gcol",309250807).cljs$core$IFn$_invoke$arity$1(info),source_idx,line,col], null);
var temp__4655__auto__ = new cljs.core.Keyword(null,"name","name",1843675177).cljs$core$IFn$_invoke$arity$1(info);
if(cljs.core.truth_(temp__4655__auto__)){
var name = temp__4655__auto__;
var idx = (function (){var temp__4655__auto____$1 = cljs.core.get.call(null,cljs.core.deref.call(null,names__GT_idx),name);
if(cljs.core.truth_(temp__4655__auto____$1)){
var idx = temp__4655__auto____$1;
return idx;
} else {
var cidx = cljs.core.deref.call(null,name_idx);
cljs.core.swap_BANG_.call(null,names__GT_idx,cljs.core.assoc,name,cidx);

cljs.core.swap_BANG_.call(null,name_idx,cljs.core.inc);

return cidx;
}
})();
return cljs.core.conj.call(null,segv,idx);
} else {
return segv;
}
});})(lines,names__GT_idx,name_idx,preamble_lines))
;
var encode_cols = ((function (lines,names__GT_idx,name_idx,preamble_lines,info__GT_segv){
return (function (infos,source_idx,line,col){
var seq__29317 = cljs.core.seq.call(null,infos);
var chunk__29318 = null;
var count__29319 = (0);
var i__29320 = (0);
while(true){
if((i__29320 < count__29319)){
var info = cljs.core._nth.call(null,chunk__29318,i__29320);
var segv_29367 = info__GT_segv.call(null,info,source_idx,line,col);
var gline_29368 = new cljs.core.Keyword(null,"gline","gline",-1086242431).cljs$core$IFn$_invoke$arity$1(info);
var lc_29369 = cljs.core.count.call(null,cljs.core.deref.call(null,lines));
if((gline_29368 > (lc_29369 - (1)))){
cljs.core.swap_BANG_.call(null,lines,((function (seq__29317,chunk__29318,count__29319,i__29320,segv_29367,gline_29368,lc_29369,info,lines,names__GT_idx,name_idx,preamble_lines,info__GT_segv){
return (function (lines__$1){
return cljs.core.conj.call(null,cljs.core.into.call(null,lines__$1,cljs.core.repeat.call(null,((gline_29368 - (lc_29369 - (1))) - (1)),cljs.core.PersistentVector.EMPTY)),new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [segv_29367], null));
});})(seq__29317,chunk__29318,count__29319,i__29320,segv_29367,gline_29368,lc_29369,info,lines,names__GT_idx,name_idx,preamble_lines,info__GT_segv))
);
} else {
cljs.core.swap_BANG_.call(null,lines,((function (seq__29317,chunk__29318,count__29319,i__29320,segv_29367,gline_29368,lc_29369,info,lines,names__GT_idx,name_idx,preamble_lines,info__GT_segv){
return (function (lines__$1){
return cljs.core.update_in.call(null,lines__$1,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [gline_29368], null),cljs.core.conj,segv_29367);
});})(seq__29317,chunk__29318,count__29319,i__29320,segv_29367,gline_29368,lc_29369,info,lines,names__GT_idx,name_idx,preamble_lines,info__GT_segv))
);
}

var G__29370 = seq__29317;
var G__29371 = chunk__29318;
var G__29372 = count__29319;
var G__29373 = (i__29320 + (1));
seq__29317 = G__29370;
chunk__29318 = G__29371;
count__29319 = G__29372;
i__29320 = G__29373;
continue;
} else {
var temp__4657__auto__ = cljs.core.seq.call(null,seq__29317);
if(temp__4657__auto__){
var seq__29317__$1 = temp__4657__auto__;
if(cljs.core.chunked_seq_QMARK_.call(null,seq__29317__$1)){
var c__23696__auto__ = cljs.core.chunk_first.call(null,seq__29317__$1);
var G__29374 = cljs.core.chunk_rest.call(null,seq__29317__$1);
var G__29375 = c__23696__auto__;
var G__29376 = cljs.core.count.call(null,c__23696__auto__);
var G__29377 = (0);
seq__29317 = G__29374;
chunk__29318 = G__29375;
count__29319 = G__29376;
i__29320 = G__29377;
continue;
} else {
var info = cljs.core.first.call(null,seq__29317__$1);
var segv_29378 = info__GT_segv.call(null,info,source_idx,line,col);
var gline_29379 = new cljs.core.Keyword(null,"gline","gline",-1086242431).cljs$core$IFn$_invoke$arity$1(info);
var lc_29380 = cljs.core.count.call(null,cljs.core.deref.call(null,lines));
if((gline_29379 > (lc_29380 - (1)))){
cljs.core.swap_BANG_.call(null,lines,((function (seq__29317,chunk__29318,count__29319,i__29320,segv_29378,gline_29379,lc_29380,info,seq__29317__$1,temp__4657__auto__,lines,names__GT_idx,name_idx,preamble_lines,info__GT_segv){
return (function (lines__$1){
return cljs.core.conj.call(null,cljs.core.into.call(null,lines__$1,cljs.core.repeat.call(null,((gline_29379 - (lc_29380 - (1))) - (1)),cljs.core.PersistentVector.EMPTY)),new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [segv_29378], null));
});})(seq__29317,chunk__29318,count__29319,i__29320,segv_29378,gline_29379,lc_29380,info,seq__29317__$1,temp__4657__auto__,lines,names__GT_idx,name_idx,preamble_lines,info__GT_segv))
);
} else {
cljs.core.swap_BANG_.call(null,lines,((function (seq__29317,chunk__29318,count__29319,i__29320,segv_29378,gline_29379,lc_29380,info,seq__29317__$1,temp__4657__auto__,lines,names__GT_idx,name_idx,preamble_lines,info__GT_segv){
return (function (lines__$1){
return cljs.core.update_in.call(null,lines__$1,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [gline_29379], null),cljs.core.conj,segv_29378);
});})(seq__29317,chunk__29318,count__29319,i__29320,segv_29378,gline_29379,lc_29380,info,seq__29317__$1,temp__4657__auto__,lines,names__GT_idx,name_idx,preamble_lines,info__GT_segv))
);
}

var G__29381 = cljs.core.next.call(null,seq__29317__$1);
var G__29382 = null;
var G__29383 = (0);
var G__29384 = (0);
seq__29317 = G__29381;
chunk__29318 = G__29382;
count__29319 = G__29383;
i__29320 = G__29384;
continue;
}
} else {
return null;
}
}
break;
}
});})(lines,names__GT_idx,name_idx,preamble_lines,info__GT_segv))
;
var seq__29321_29385 = cljs.core.seq.call(null,cljs.core.map_indexed.call(null,((function (lines,names__GT_idx,name_idx,preamble_lines,info__GT_segv,encode_cols){
return (function (i,v){
return new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [i,v], null);
});})(lines,names__GT_idx,name_idx,preamble_lines,info__GT_segv,encode_cols))
,m));
var chunk__29322_29386 = null;
var count__29323_29387 = (0);
var i__29324_29388 = (0);
while(true){
if((i__29324_29388 < count__29323_29387)){
var vec__29325_29389 = cljs.core._nth.call(null,chunk__29322_29386,i__29324_29388);
var source_idx_29390 = cljs.core.nth.call(null,vec__29325_29389,(0),null);
var vec__29326_29391 = cljs.core.nth.call(null,vec__29325_29389,(1),null);
var __29392 = cljs.core.nth.call(null,vec__29326_29391,(0),null);
var lines_29393__$1 = cljs.core.nth.call(null,vec__29326_29391,(1),null);
var seq__29327_29394 = cljs.core.seq.call(null,lines_29393__$1);
var chunk__29328_29395 = null;
var count__29329_29396 = (0);
var i__29330_29397 = (0);
while(true){
if((i__29330_29397 < count__29329_29396)){
var vec__29331_29398 = cljs.core._nth.call(null,chunk__29328_29395,i__29330_29397);
var line_29399 = cljs.core.nth.call(null,vec__29331_29398,(0),null);
var cols_29400 = cljs.core.nth.call(null,vec__29331_29398,(1),null);
var seq__29332_29401 = cljs.core.seq.call(null,cols_29400);
var chunk__29333_29402 = null;
var count__29334_29403 = (0);
var i__29335_29404 = (0);
while(true){
if((i__29335_29404 < count__29334_29403)){
var vec__29336_29405 = cljs.core._nth.call(null,chunk__29333_29402,i__29335_29404);
var col_29406 = cljs.core.nth.call(null,vec__29336_29405,(0),null);
var infos_29407 = cljs.core.nth.call(null,vec__29336_29405,(1),null);
encode_cols.call(null,infos_29407,source_idx_29390,line_29399,col_29406);

var G__29408 = seq__29332_29401;
var G__29409 = chunk__29333_29402;
var G__29410 = count__29334_29403;
var G__29411 = (i__29335_29404 + (1));
seq__29332_29401 = G__29408;
chunk__29333_29402 = G__29409;
count__29334_29403 = G__29410;
i__29335_29404 = G__29411;
continue;
} else {
var temp__4657__auto___29412 = cljs.core.seq.call(null,seq__29332_29401);
if(temp__4657__auto___29412){
var seq__29332_29413__$1 = temp__4657__auto___29412;
if(cljs.core.chunked_seq_QMARK_.call(null,seq__29332_29413__$1)){
var c__23696__auto___29414 = cljs.core.chunk_first.call(null,seq__29332_29413__$1);
var G__29415 = cljs.core.chunk_rest.call(null,seq__29332_29413__$1);
var G__29416 = c__23696__auto___29414;
var G__29417 = cljs.core.count.call(null,c__23696__auto___29414);
var G__29418 = (0);
seq__29332_29401 = G__29415;
chunk__29333_29402 = G__29416;
count__29334_29403 = G__29417;
i__29335_29404 = G__29418;
continue;
} else {
var vec__29337_29419 = cljs.core.first.call(null,seq__29332_29413__$1);
var col_29420 = cljs.core.nth.call(null,vec__29337_29419,(0),null);
var infos_29421 = cljs.core.nth.call(null,vec__29337_29419,(1),null);
encode_cols.call(null,infos_29421,source_idx_29390,line_29399,col_29420);

var G__29422 = cljs.core.next.call(null,seq__29332_29413__$1);
var G__29423 = null;
var G__29424 = (0);
var G__29425 = (0);
seq__29332_29401 = G__29422;
chunk__29333_29402 = G__29423;
count__29334_29403 = G__29424;
i__29335_29404 = G__29425;
continue;
}
} else {
}
}
break;
}

var G__29426 = seq__29327_29394;
var G__29427 = chunk__29328_29395;
var G__29428 = count__29329_29396;
var G__29429 = (i__29330_29397 + (1));
seq__29327_29394 = G__29426;
chunk__29328_29395 = G__29427;
count__29329_29396 = G__29428;
i__29330_29397 = G__29429;
continue;
} else {
var temp__4657__auto___29430 = cljs.core.seq.call(null,seq__29327_29394);
if(temp__4657__auto___29430){
var seq__29327_29431__$1 = temp__4657__auto___29430;
if(cljs.core.chunked_seq_QMARK_.call(null,seq__29327_29431__$1)){
var c__23696__auto___29432 = cljs.core.chunk_first.call(null,seq__29327_29431__$1);
var G__29433 = cljs.core.chunk_rest.call(null,seq__29327_29431__$1);
var G__29434 = c__23696__auto___29432;
var G__29435 = cljs.core.count.call(null,c__23696__auto___29432);
var G__29436 = (0);
seq__29327_29394 = G__29433;
chunk__29328_29395 = G__29434;
count__29329_29396 = G__29435;
i__29330_29397 = G__29436;
continue;
} else {
var vec__29338_29437 = cljs.core.first.call(null,seq__29327_29431__$1);
var line_29438 = cljs.core.nth.call(null,vec__29338_29437,(0),null);
var cols_29439 = cljs.core.nth.call(null,vec__29338_29437,(1),null);
var seq__29339_29440 = cljs.core.seq.call(null,cols_29439);
var chunk__29340_29441 = null;
var count__29341_29442 = (0);
var i__29342_29443 = (0);
while(true){
if((i__29342_29443 < count__29341_29442)){
var vec__29343_29444 = cljs.core._nth.call(null,chunk__29340_29441,i__29342_29443);
var col_29445 = cljs.core.nth.call(null,vec__29343_29444,(0),null);
var infos_29446 = cljs.core.nth.call(null,vec__29343_29444,(1),null);
encode_cols.call(null,infos_29446,source_idx_29390,line_29438,col_29445);

var G__29447 = seq__29339_29440;
var G__29448 = chunk__29340_29441;
var G__29449 = count__29341_29442;
var G__29450 = (i__29342_29443 + (1));
seq__29339_29440 = G__29447;
chunk__29340_29441 = G__29448;
count__29341_29442 = G__29449;
i__29342_29443 = G__29450;
continue;
} else {
var temp__4657__auto___29451__$1 = cljs.core.seq.call(null,seq__29339_29440);
if(temp__4657__auto___29451__$1){
var seq__29339_29452__$1 = temp__4657__auto___29451__$1;
if(cljs.core.chunked_seq_QMARK_.call(null,seq__29339_29452__$1)){
var c__23696__auto___29453 = cljs.core.chunk_first.call(null,seq__29339_29452__$1);
var G__29454 = cljs.core.chunk_rest.call(null,seq__29339_29452__$1);
var G__29455 = c__23696__auto___29453;
var G__29456 = cljs.core.count.call(null,c__23696__auto___29453);
var G__29457 = (0);
seq__29339_29440 = G__29454;
chunk__29340_29441 = G__29455;
count__29341_29442 = G__29456;
i__29342_29443 = G__29457;
continue;
} else {
var vec__29344_29458 = cljs.core.first.call(null,seq__29339_29452__$1);
var col_29459 = cljs.core.nth.call(null,vec__29344_29458,(0),null);
var infos_29460 = cljs.core.nth.call(null,vec__29344_29458,(1),null);
encode_cols.call(null,infos_29460,source_idx_29390,line_29438,col_29459);

var G__29461 = cljs.core.next.call(null,seq__29339_29452__$1);
var G__29462 = null;
var G__29463 = (0);
var G__29464 = (0);
seq__29339_29440 = G__29461;
chunk__29340_29441 = G__29462;
count__29341_29442 = G__29463;
i__29342_29443 = G__29464;
continue;
}
} else {
}
}
break;
}

var G__29465 = cljs.core.next.call(null,seq__29327_29431__$1);
var G__29466 = null;
var G__29467 = (0);
var G__29468 = (0);
seq__29327_29394 = G__29465;
chunk__29328_29395 = G__29466;
count__29329_29396 = G__29467;
i__29330_29397 = G__29468;
continue;
}
} else {
}
}
break;
}

var G__29469 = seq__29321_29385;
var G__29470 = chunk__29322_29386;
var G__29471 = count__29323_29387;
var G__29472 = (i__29324_29388 + (1));
seq__29321_29385 = G__29469;
chunk__29322_29386 = G__29470;
count__29323_29387 = G__29471;
i__29324_29388 = G__29472;
continue;
} else {
var temp__4657__auto___29473 = cljs.core.seq.call(null,seq__29321_29385);
if(temp__4657__auto___29473){
var seq__29321_29474__$1 = temp__4657__auto___29473;
if(cljs.core.chunked_seq_QMARK_.call(null,seq__29321_29474__$1)){
var c__23696__auto___29475 = cljs.core.chunk_first.call(null,seq__29321_29474__$1);
var G__29476 = cljs.core.chunk_rest.call(null,seq__29321_29474__$1);
var G__29477 = c__23696__auto___29475;
var G__29478 = cljs.core.count.call(null,c__23696__auto___29475);
var G__29479 = (0);
seq__29321_29385 = G__29476;
chunk__29322_29386 = G__29477;
count__29323_29387 = G__29478;
i__29324_29388 = G__29479;
continue;
} else {
var vec__29345_29480 = cljs.core.first.call(null,seq__29321_29474__$1);
var source_idx_29481 = cljs.core.nth.call(null,vec__29345_29480,(0),null);
var vec__29346_29482 = cljs.core.nth.call(null,vec__29345_29480,(1),null);
var __29483 = cljs.core.nth.call(null,vec__29346_29482,(0),null);
var lines_29484__$1 = cljs.core.nth.call(null,vec__29346_29482,(1),null);
var seq__29347_29485 = cljs.core.seq.call(null,lines_29484__$1);
var chunk__29348_29486 = null;
var count__29349_29487 = (0);
var i__29350_29488 = (0);
while(true){
if((i__29350_29488 < count__29349_29487)){
var vec__29351_29489 = cljs.core._nth.call(null,chunk__29348_29486,i__29350_29488);
var line_29490 = cljs.core.nth.call(null,vec__29351_29489,(0),null);
var cols_29491 = cljs.core.nth.call(null,vec__29351_29489,(1),null);
var seq__29352_29492 = cljs.core.seq.call(null,cols_29491);
var chunk__29353_29493 = null;
var count__29354_29494 = (0);
var i__29355_29495 = (0);
while(true){
if((i__29355_29495 < count__29354_29494)){
var vec__29356_29496 = cljs.core._nth.call(null,chunk__29353_29493,i__29355_29495);
var col_29497 = cljs.core.nth.call(null,vec__29356_29496,(0),null);
var infos_29498 = cljs.core.nth.call(null,vec__29356_29496,(1),null);
encode_cols.call(null,infos_29498,source_idx_29481,line_29490,col_29497);

var G__29499 = seq__29352_29492;
var G__29500 = chunk__29353_29493;
var G__29501 = count__29354_29494;
var G__29502 = (i__29355_29495 + (1));
seq__29352_29492 = G__29499;
chunk__29353_29493 = G__29500;
count__29354_29494 = G__29501;
i__29355_29495 = G__29502;
continue;
} else {
var temp__4657__auto___29503__$1 = cljs.core.seq.call(null,seq__29352_29492);
if(temp__4657__auto___29503__$1){
var seq__29352_29504__$1 = temp__4657__auto___29503__$1;
if(cljs.core.chunked_seq_QMARK_.call(null,seq__29352_29504__$1)){
var c__23696__auto___29505 = cljs.core.chunk_first.call(null,seq__29352_29504__$1);
var G__29506 = cljs.core.chunk_rest.call(null,seq__29352_29504__$1);
var G__29507 = c__23696__auto___29505;
var G__29508 = cljs.core.count.call(null,c__23696__auto___29505);
var G__29509 = (0);
seq__29352_29492 = G__29506;
chunk__29353_29493 = G__29507;
count__29354_29494 = G__29508;
i__29355_29495 = G__29509;
continue;
} else {
var vec__29357_29510 = cljs.core.first.call(null,seq__29352_29504__$1);
var col_29511 = cljs.core.nth.call(null,vec__29357_29510,(0),null);
var infos_29512 = cljs.core.nth.call(null,vec__29357_29510,(1),null);
encode_cols.call(null,infos_29512,source_idx_29481,line_29490,col_29511);

var G__29513 = cljs.core.next.call(null,seq__29352_29504__$1);
var G__29514 = null;
var G__29515 = (0);
var G__29516 = (0);
seq__29352_29492 = G__29513;
chunk__29353_29493 = G__29514;
count__29354_29494 = G__29515;
i__29355_29495 = G__29516;
continue;
}
} else {
}
}
break;
}

var G__29517 = seq__29347_29485;
var G__29518 = chunk__29348_29486;
var G__29519 = count__29349_29487;
var G__29520 = (i__29350_29488 + (1));
seq__29347_29485 = G__29517;
chunk__29348_29486 = G__29518;
count__29349_29487 = G__29519;
i__29350_29488 = G__29520;
continue;
} else {
var temp__4657__auto___29521__$1 = cljs.core.seq.call(null,seq__29347_29485);
if(temp__4657__auto___29521__$1){
var seq__29347_29522__$1 = temp__4657__auto___29521__$1;
if(cljs.core.chunked_seq_QMARK_.call(null,seq__29347_29522__$1)){
var c__23696__auto___29523 = cljs.core.chunk_first.call(null,seq__29347_29522__$1);
var G__29524 = cljs.core.chunk_rest.call(null,seq__29347_29522__$1);
var G__29525 = c__23696__auto___29523;
var G__29526 = cljs.core.count.call(null,c__23696__auto___29523);
var G__29527 = (0);
seq__29347_29485 = G__29524;
chunk__29348_29486 = G__29525;
count__29349_29487 = G__29526;
i__29350_29488 = G__29527;
continue;
} else {
var vec__29358_29528 = cljs.core.first.call(null,seq__29347_29522__$1);
var line_29529 = cljs.core.nth.call(null,vec__29358_29528,(0),null);
var cols_29530 = cljs.core.nth.call(null,vec__29358_29528,(1),null);
var seq__29359_29531 = cljs.core.seq.call(null,cols_29530);
var chunk__29360_29532 = null;
var count__29361_29533 = (0);
var i__29362_29534 = (0);
while(true){
if((i__29362_29534 < count__29361_29533)){
var vec__29363_29535 = cljs.core._nth.call(null,chunk__29360_29532,i__29362_29534);
var col_29536 = cljs.core.nth.call(null,vec__29363_29535,(0),null);
var infos_29537 = cljs.core.nth.call(null,vec__29363_29535,(1),null);
encode_cols.call(null,infos_29537,source_idx_29481,line_29529,col_29536);

var G__29538 = seq__29359_29531;
var G__29539 = chunk__29360_29532;
var G__29540 = count__29361_29533;
var G__29541 = (i__29362_29534 + (1));
seq__29359_29531 = G__29538;
chunk__29360_29532 = G__29539;
count__29361_29533 = G__29540;
i__29362_29534 = G__29541;
continue;
} else {
var temp__4657__auto___29542__$2 = cljs.core.seq.call(null,seq__29359_29531);
if(temp__4657__auto___29542__$2){
var seq__29359_29543__$1 = temp__4657__auto___29542__$2;
if(cljs.core.chunked_seq_QMARK_.call(null,seq__29359_29543__$1)){
var c__23696__auto___29544 = cljs.core.chunk_first.call(null,seq__29359_29543__$1);
var G__29545 = cljs.core.chunk_rest.call(null,seq__29359_29543__$1);
var G__29546 = c__23696__auto___29544;
var G__29547 = cljs.core.count.call(null,c__23696__auto___29544);
var G__29548 = (0);
seq__29359_29531 = G__29545;
chunk__29360_29532 = G__29546;
count__29361_29533 = G__29547;
i__29362_29534 = G__29548;
continue;
} else {
var vec__29364_29549 = cljs.core.first.call(null,seq__29359_29543__$1);
var col_29550 = cljs.core.nth.call(null,vec__29364_29549,(0),null);
var infos_29551 = cljs.core.nth.call(null,vec__29364_29549,(1),null);
encode_cols.call(null,infos_29551,source_idx_29481,line_29529,col_29550);

var G__29552 = cljs.core.next.call(null,seq__29359_29543__$1);
var G__29553 = null;
var G__29554 = (0);
var G__29555 = (0);
seq__29359_29531 = G__29552;
chunk__29360_29532 = G__29553;
count__29361_29533 = G__29554;
i__29362_29534 = G__29555;
continue;
}
} else {
}
}
break;
}

var G__29556 = cljs.core.next.call(null,seq__29347_29522__$1);
var G__29557 = null;
var G__29558 = (0);
var G__29559 = (0);
seq__29347_29485 = G__29556;
chunk__29348_29486 = G__29557;
count__29349_29487 = G__29558;
i__29350_29488 = G__29559;
continue;
}
} else {
}
}
break;
}

var G__29560 = cljs.core.next.call(null,seq__29321_29474__$1);
var G__29561 = null;
var G__29562 = (0);
var G__29563 = (0);
seq__29321_29385 = G__29560;
chunk__29322_29386 = G__29561;
count__29323_29387 = G__29562;
i__29324_29388 = G__29563;
continue;
}
} else {
}
}
break;
}

var source_map_file_contents = (function (){var G__29365 = {"version": (3), "file": new cljs.core.Keyword(null,"file","file",-1269645878).cljs$core$IFn$_invoke$arity$1(opts), "sources": (function (){var paths = cljs.core.keys.call(null,m);
var f = cljs.core.comp.call(null,((new cljs.core.Keyword(null,"source-map-timestamp","source-map-timestamp",1973015633).cljs$core$IFn$_invoke$arity$1(opts) === true)?((function (paths,lines,names__GT_idx,name_idx,preamble_lines,info__GT_segv,encode_cols){
return (function (p1__29264_SHARP_){
return [cljs.core.str(p1__29264_SHARP_),cljs.core.str("?rel="),cljs.core.str((new Date()).valueOf())].join('');
});})(paths,lines,names__GT_idx,name_idx,preamble_lines,info__GT_segv,encode_cols))
:cljs.core.identity),((function (paths,lines,names__GT_idx,name_idx,preamble_lines,info__GT_segv,encode_cols){
return (function (p1__29265_SHARP_){
return cljs.core.last.call(null,clojure.string.split.call(null,p1__29265_SHARP_,/\//));
});})(paths,lines,names__GT_idx,name_idx,preamble_lines,info__GT_segv,encode_cols))
);
return cljs.core.into_array.call(null,cljs.core.map.call(null,f,paths));
})(), "lineCount": new cljs.core.Keyword(null,"lines","lines",-700165781).cljs$core$IFn$_invoke$arity$1(opts), "mappings": clojure.string.join.call(null,";",cljs.core.map.call(null,((function (lines,names__GT_idx,name_idx,preamble_lines,info__GT_segv,encode_cols){
return (function (p1__29266_SHARP_){
return clojure.string.join.call(null,",",p1__29266_SHARP_);
});})(lines,names__GT_idx,name_idx,preamble_lines,info__GT_segv,encode_cols))
,cljs.source_map.lines__GT_segs.call(null,cljs.core.concat.call(null,preamble_lines,cljs.core.deref.call(null,lines))))), "names": cljs.core.into_array.call(null,cljs.core.map.call(null,clojure.set.map_invert.call(null,cljs.core.deref.call(null,names__GT_idx)),cljs.core.range.call(null,cljs.core.count.call(null,cljs.core.deref.call(null,names__GT_idx)))))};
if(cljs.core.truth_(new cljs.core.Keyword(null,"sources-content","sources-content",1729970239).cljs$core$IFn$_invoke$arity$1(opts))){
var G__29366 = G__29365;
goog.object.set(G__29366,"sourcesContent",cljs.core.into_array.call(null,new cljs.core.Keyword(null,"sources-content","sources-content",1729970239).cljs$core$IFn$_invoke$arity$1(opts)));

return G__29366;
} else {
return G__29365;
}
})();
return JSON.stringify(source_map_file_contents);
});
/**
 * Merge an internal source map representation of a single
 * ClojureScript file mapping original to generated with a
 * second source map mapping original JS to generated JS.
 * The is to support source maps that work through multiple
 * compilation steps like Google Closure optimization passes.
 */
cljs.source_map.merge_source_maps = (function cljs$source_map$merge_source_maps(cljs_map,js_map){
var line_map_seq = cljs.core.seq.call(null,cljs_map);
var new_lines = cljs.core.sorted_map.call(null);
while(true){
if(line_map_seq){
var vec__29569 = cljs.core.first.call(null,line_map_seq);
var line = cljs.core.nth.call(null,vec__29569,(0),null);
var col_map = cljs.core.nth.call(null,vec__29569,(1),null);
var new_cols = (function (){var col_map_seq = cljs.core.seq.call(null,col_map);
var new_cols = cljs.core.sorted_map.call(null);
while(true){
if(col_map_seq){
var vec__29570 = cljs.core.first.call(null,col_map_seq);
var col = cljs.core.nth.call(null,vec__29570,(0),null);
var infos = cljs.core.nth.call(null,vec__29570,(1),null);
var G__29574 = cljs.core.next.call(null,col_map_seq);
var G__29575 = cljs.core.assoc.call(null,new_cols,col,cljs.core.reduce.call(null,((function (col_map_seq,new_cols,line_map_seq,new_lines,vec__29570,col,infos,vec__29569,line,col_map){
return (function (v,p__29571){
var map__29572 = p__29571;
var map__29572__$1 = ((((!((map__29572 == null)))?((((map__29572.cljs$lang$protocol_mask$partition0$ & (64))) || (map__29572.cljs$core$ISeq$))?true:false):false))?cljs.core.apply.call(null,cljs.core.hash_map,map__29572):map__29572);
var gline = cljs.core.get.call(null,map__29572__$1,new cljs.core.Keyword(null,"gline","gline",-1086242431));
var gcol = cljs.core.get.call(null,map__29572__$1,new cljs.core.Keyword(null,"gcol","gcol",309250807));
return cljs.core.into.call(null,v,cljs.core.get_in.call(null,js_map,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [gline,gcol], null)));
});})(col_map_seq,new_cols,line_map_seq,new_lines,vec__29570,col,infos,vec__29569,line,col_map))
,cljs.core.PersistentVector.EMPTY,infos));
col_map_seq = G__29574;
new_cols = G__29575;
continue;
} else {
return new_cols;
}
break;
}
})();
var G__29576 = cljs.core.next.call(null,line_map_seq);
var G__29577 = cljs.core.assoc.call(null,new_lines,line,new_cols);
line_map_seq = G__29576;
new_lines = G__29577;
continue;
} else {
return new_lines;
}
break;
}
});
/**
 * Given a ClojureScript to JavaScript source map, invert it. Useful when
 * mapping JavaScript stack traces when environment support is unavailable.
 */
cljs.source_map.invert_reverse_map = (function cljs$source_map$invert_reverse_map(reverse_map){
var inverted = cljs.core.atom.call(null,cljs.core.sorted_map.call(null));
var seq__29628_29678 = cljs.core.seq.call(null,reverse_map);
var chunk__29629_29679 = null;
var count__29630_29680 = (0);
var i__29631_29681 = (0);
while(true){
if((i__29631_29681 < count__29630_29680)){
var vec__29632_29682 = cljs.core._nth.call(null,chunk__29629_29679,i__29631_29681);
var line_29683 = cljs.core.nth.call(null,vec__29632_29682,(0),null);
var columns_29684 = cljs.core.nth.call(null,vec__29632_29682,(1),null);
var seq__29633_29685 = cljs.core.seq.call(null,columns_29684);
var chunk__29634_29686 = null;
var count__29635_29687 = (0);
var i__29636_29688 = (0);
while(true){
if((i__29636_29688 < count__29635_29687)){
var vec__29637_29689 = cljs.core._nth.call(null,chunk__29634_29686,i__29636_29688);
var column_29690 = cljs.core.nth.call(null,vec__29637_29689,(0),null);
var column_info_29691 = cljs.core.nth.call(null,vec__29637_29689,(1),null);
var seq__29638_29692 = cljs.core.seq.call(null,column_info_29691);
var chunk__29639_29693 = null;
var count__29640_29694 = (0);
var i__29641_29695 = (0);
while(true){
if((i__29641_29695 < count__29640_29694)){
var map__29642_29696 = cljs.core._nth.call(null,chunk__29639_29693,i__29641_29695);
var map__29642_29697__$1 = ((((!((map__29642_29696 == null)))?((((map__29642_29696.cljs$lang$protocol_mask$partition0$ & (64))) || (map__29642_29696.cljs$core$ISeq$))?true:false):false))?cljs.core.apply.call(null,cljs.core.hash_map,map__29642_29696):map__29642_29696);
var gline_29698 = cljs.core.get.call(null,map__29642_29697__$1,new cljs.core.Keyword(null,"gline","gline",-1086242431));
var gcol_29699 = cljs.core.get.call(null,map__29642_29697__$1,new cljs.core.Keyword(null,"gcol","gcol",309250807));
var name_29700 = cljs.core.get.call(null,map__29642_29697__$1,new cljs.core.Keyword(null,"name","name",1843675177));
cljs.core.swap_BANG_.call(null,inverted,cljs.core.update_in,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [gline_29698], null),cljs.core.fnil.call(null,((function (seq__29638_29692,chunk__29639_29693,count__29640_29694,i__29641_29695,seq__29633_29685,chunk__29634_29686,count__29635_29687,i__29636_29688,seq__29628_29678,chunk__29629_29679,count__29630_29680,i__29631_29681,map__29642_29696,map__29642_29697__$1,gline_29698,gcol_29699,name_29700,vec__29637_29689,column_29690,column_info_29691,vec__29632_29682,line_29683,columns_29684,inverted){
return (function (columns__$1){
return cljs.core.update_in.call(null,columns__$1,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [gcol_29699], null),cljs.core.fnil.call(null,cljs.core.conj,cljs.core.PersistentVector.EMPTY),new cljs.core.PersistentArrayMap(null, 3, [new cljs.core.Keyword(null,"line","line",212345235),line_29683,new cljs.core.Keyword(null,"col","col",-1959363084),column_29690,new cljs.core.Keyword(null,"name","name",1843675177),name_29700], null));
});})(seq__29638_29692,chunk__29639_29693,count__29640_29694,i__29641_29695,seq__29633_29685,chunk__29634_29686,count__29635_29687,i__29636_29688,seq__29628_29678,chunk__29629_29679,count__29630_29680,i__29631_29681,map__29642_29696,map__29642_29697__$1,gline_29698,gcol_29699,name_29700,vec__29637_29689,column_29690,column_info_29691,vec__29632_29682,line_29683,columns_29684,inverted))
,cljs.core.sorted_map.call(null)));

var G__29701 = seq__29638_29692;
var G__29702 = chunk__29639_29693;
var G__29703 = count__29640_29694;
var G__29704 = (i__29641_29695 + (1));
seq__29638_29692 = G__29701;
chunk__29639_29693 = G__29702;
count__29640_29694 = G__29703;
i__29641_29695 = G__29704;
continue;
} else {
var temp__4657__auto___29705 = cljs.core.seq.call(null,seq__29638_29692);
if(temp__4657__auto___29705){
var seq__29638_29706__$1 = temp__4657__auto___29705;
if(cljs.core.chunked_seq_QMARK_.call(null,seq__29638_29706__$1)){
var c__23696__auto___29707 = cljs.core.chunk_first.call(null,seq__29638_29706__$1);
var G__29708 = cljs.core.chunk_rest.call(null,seq__29638_29706__$1);
var G__29709 = c__23696__auto___29707;
var G__29710 = cljs.core.count.call(null,c__23696__auto___29707);
var G__29711 = (0);
seq__29638_29692 = G__29708;
chunk__29639_29693 = G__29709;
count__29640_29694 = G__29710;
i__29641_29695 = G__29711;
continue;
} else {
var map__29644_29712 = cljs.core.first.call(null,seq__29638_29706__$1);
var map__29644_29713__$1 = ((((!((map__29644_29712 == null)))?((((map__29644_29712.cljs$lang$protocol_mask$partition0$ & (64))) || (map__29644_29712.cljs$core$ISeq$))?true:false):false))?cljs.core.apply.call(null,cljs.core.hash_map,map__29644_29712):map__29644_29712);
var gline_29714 = cljs.core.get.call(null,map__29644_29713__$1,new cljs.core.Keyword(null,"gline","gline",-1086242431));
var gcol_29715 = cljs.core.get.call(null,map__29644_29713__$1,new cljs.core.Keyword(null,"gcol","gcol",309250807));
var name_29716 = cljs.core.get.call(null,map__29644_29713__$1,new cljs.core.Keyword(null,"name","name",1843675177));
cljs.core.swap_BANG_.call(null,inverted,cljs.core.update_in,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [gline_29714], null),cljs.core.fnil.call(null,((function (seq__29638_29692,chunk__29639_29693,count__29640_29694,i__29641_29695,seq__29633_29685,chunk__29634_29686,count__29635_29687,i__29636_29688,seq__29628_29678,chunk__29629_29679,count__29630_29680,i__29631_29681,map__29644_29712,map__29644_29713__$1,gline_29714,gcol_29715,name_29716,seq__29638_29706__$1,temp__4657__auto___29705,vec__29637_29689,column_29690,column_info_29691,vec__29632_29682,line_29683,columns_29684,inverted){
return (function (columns__$1){
return cljs.core.update_in.call(null,columns__$1,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [gcol_29715], null),cljs.core.fnil.call(null,cljs.core.conj,cljs.core.PersistentVector.EMPTY),new cljs.core.PersistentArrayMap(null, 3, [new cljs.core.Keyword(null,"line","line",212345235),line_29683,new cljs.core.Keyword(null,"col","col",-1959363084),column_29690,new cljs.core.Keyword(null,"name","name",1843675177),name_29716], null));
});})(seq__29638_29692,chunk__29639_29693,count__29640_29694,i__29641_29695,seq__29633_29685,chunk__29634_29686,count__29635_29687,i__29636_29688,seq__29628_29678,chunk__29629_29679,count__29630_29680,i__29631_29681,map__29644_29712,map__29644_29713__$1,gline_29714,gcol_29715,name_29716,seq__29638_29706__$1,temp__4657__auto___29705,vec__29637_29689,column_29690,column_info_29691,vec__29632_29682,line_29683,columns_29684,inverted))
,cljs.core.sorted_map.call(null)));

var G__29717 = cljs.core.next.call(null,seq__29638_29706__$1);
var G__29718 = null;
var G__29719 = (0);
var G__29720 = (0);
seq__29638_29692 = G__29717;
chunk__29639_29693 = G__29718;
count__29640_29694 = G__29719;
i__29641_29695 = G__29720;
continue;
}
} else {
}
}
break;
}

var G__29721 = seq__29633_29685;
var G__29722 = chunk__29634_29686;
var G__29723 = count__29635_29687;
var G__29724 = (i__29636_29688 + (1));
seq__29633_29685 = G__29721;
chunk__29634_29686 = G__29722;
count__29635_29687 = G__29723;
i__29636_29688 = G__29724;
continue;
} else {
var temp__4657__auto___29725 = cljs.core.seq.call(null,seq__29633_29685);
if(temp__4657__auto___29725){
var seq__29633_29726__$1 = temp__4657__auto___29725;
if(cljs.core.chunked_seq_QMARK_.call(null,seq__29633_29726__$1)){
var c__23696__auto___29727 = cljs.core.chunk_first.call(null,seq__29633_29726__$1);
var G__29728 = cljs.core.chunk_rest.call(null,seq__29633_29726__$1);
var G__29729 = c__23696__auto___29727;
var G__29730 = cljs.core.count.call(null,c__23696__auto___29727);
var G__29731 = (0);
seq__29633_29685 = G__29728;
chunk__29634_29686 = G__29729;
count__29635_29687 = G__29730;
i__29636_29688 = G__29731;
continue;
} else {
var vec__29646_29732 = cljs.core.first.call(null,seq__29633_29726__$1);
var column_29733 = cljs.core.nth.call(null,vec__29646_29732,(0),null);
var column_info_29734 = cljs.core.nth.call(null,vec__29646_29732,(1),null);
var seq__29647_29735 = cljs.core.seq.call(null,column_info_29734);
var chunk__29648_29736 = null;
var count__29649_29737 = (0);
var i__29650_29738 = (0);
while(true){
if((i__29650_29738 < count__29649_29737)){
var map__29651_29739 = cljs.core._nth.call(null,chunk__29648_29736,i__29650_29738);
var map__29651_29740__$1 = ((((!((map__29651_29739 == null)))?((((map__29651_29739.cljs$lang$protocol_mask$partition0$ & (64))) || (map__29651_29739.cljs$core$ISeq$))?true:false):false))?cljs.core.apply.call(null,cljs.core.hash_map,map__29651_29739):map__29651_29739);
var gline_29741 = cljs.core.get.call(null,map__29651_29740__$1,new cljs.core.Keyword(null,"gline","gline",-1086242431));
var gcol_29742 = cljs.core.get.call(null,map__29651_29740__$1,new cljs.core.Keyword(null,"gcol","gcol",309250807));
var name_29743 = cljs.core.get.call(null,map__29651_29740__$1,new cljs.core.Keyword(null,"name","name",1843675177));
cljs.core.swap_BANG_.call(null,inverted,cljs.core.update_in,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [gline_29741], null),cljs.core.fnil.call(null,((function (seq__29647_29735,chunk__29648_29736,count__29649_29737,i__29650_29738,seq__29633_29685,chunk__29634_29686,count__29635_29687,i__29636_29688,seq__29628_29678,chunk__29629_29679,count__29630_29680,i__29631_29681,map__29651_29739,map__29651_29740__$1,gline_29741,gcol_29742,name_29743,vec__29646_29732,column_29733,column_info_29734,seq__29633_29726__$1,temp__4657__auto___29725,vec__29632_29682,line_29683,columns_29684,inverted){
return (function (columns__$1){
return cljs.core.update_in.call(null,columns__$1,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [gcol_29742], null),cljs.core.fnil.call(null,cljs.core.conj,cljs.core.PersistentVector.EMPTY),new cljs.core.PersistentArrayMap(null, 3, [new cljs.core.Keyword(null,"line","line",212345235),line_29683,new cljs.core.Keyword(null,"col","col",-1959363084),column_29733,new cljs.core.Keyword(null,"name","name",1843675177),name_29743], null));
});})(seq__29647_29735,chunk__29648_29736,count__29649_29737,i__29650_29738,seq__29633_29685,chunk__29634_29686,count__29635_29687,i__29636_29688,seq__29628_29678,chunk__29629_29679,count__29630_29680,i__29631_29681,map__29651_29739,map__29651_29740__$1,gline_29741,gcol_29742,name_29743,vec__29646_29732,column_29733,column_info_29734,seq__29633_29726__$1,temp__4657__auto___29725,vec__29632_29682,line_29683,columns_29684,inverted))
,cljs.core.sorted_map.call(null)));

var G__29744 = seq__29647_29735;
var G__29745 = chunk__29648_29736;
var G__29746 = count__29649_29737;
var G__29747 = (i__29650_29738 + (1));
seq__29647_29735 = G__29744;
chunk__29648_29736 = G__29745;
count__29649_29737 = G__29746;
i__29650_29738 = G__29747;
continue;
} else {
var temp__4657__auto___29748__$1 = cljs.core.seq.call(null,seq__29647_29735);
if(temp__4657__auto___29748__$1){
var seq__29647_29749__$1 = temp__4657__auto___29748__$1;
if(cljs.core.chunked_seq_QMARK_.call(null,seq__29647_29749__$1)){
var c__23696__auto___29750 = cljs.core.chunk_first.call(null,seq__29647_29749__$1);
var G__29751 = cljs.core.chunk_rest.call(null,seq__29647_29749__$1);
var G__29752 = c__23696__auto___29750;
var G__29753 = cljs.core.count.call(null,c__23696__auto___29750);
var G__29754 = (0);
seq__29647_29735 = G__29751;
chunk__29648_29736 = G__29752;
count__29649_29737 = G__29753;
i__29650_29738 = G__29754;
continue;
} else {
var map__29653_29755 = cljs.core.first.call(null,seq__29647_29749__$1);
var map__29653_29756__$1 = ((((!((map__29653_29755 == null)))?((((map__29653_29755.cljs$lang$protocol_mask$partition0$ & (64))) || (map__29653_29755.cljs$core$ISeq$))?true:false):false))?cljs.core.apply.call(null,cljs.core.hash_map,map__29653_29755):map__29653_29755);
var gline_29757 = cljs.core.get.call(null,map__29653_29756__$1,new cljs.core.Keyword(null,"gline","gline",-1086242431));
var gcol_29758 = cljs.core.get.call(null,map__29653_29756__$1,new cljs.core.Keyword(null,"gcol","gcol",309250807));
var name_29759 = cljs.core.get.call(null,map__29653_29756__$1,new cljs.core.Keyword(null,"name","name",1843675177));
cljs.core.swap_BANG_.call(null,inverted,cljs.core.update_in,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [gline_29757], null),cljs.core.fnil.call(null,((function (seq__29647_29735,chunk__29648_29736,count__29649_29737,i__29650_29738,seq__29633_29685,chunk__29634_29686,count__29635_29687,i__29636_29688,seq__29628_29678,chunk__29629_29679,count__29630_29680,i__29631_29681,map__29653_29755,map__29653_29756__$1,gline_29757,gcol_29758,name_29759,seq__29647_29749__$1,temp__4657__auto___29748__$1,vec__29646_29732,column_29733,column_info_29734,seq__29633_29726__$1,temp__4657__auto___29725,vec__29632_29682,line_29683,columns_29684,inverted){
return (function (columns__$1){
return cljs.core.update_in.call(null,columns__$1,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [gcol_29758], null),cljs.core.fnil.call(null,cljs.core.conj,cljs.core.PersistentVector.EMPTY),new cljs.core.PersistentArrayMap(null, 3, [new cljs.core.Keyword(null,"line","line",212345235),line_29683,new cljs.core.Keyword(null,"col","col",-1959363084),column_29733,new cljs.core.Keyword(null,"name","name",1843675177),name_29759], null));
});})(seq__29647_29735,chunk__29648_29736,count__29649_29737,i__29650_29738,seq__29633_29685,chunk__29634_29686,count__29635_29687,i__29636_29688,seq__29628_29678,chunk__29629_29679,count__29630_29680,i__29631_29681,map__29653_29755,map__29653_29756__$1,gline_29757,gcol_29758,name_29759,seq__29647_29749__$1,temp__4657__auto___29748__$1,vec__29646_29732,column_29733,column_info_29734,seq__29633_29726__$1,temp__4657__auto___29725,vec__29632_29682,line_29683,columns_29684,inverted))
,cljs.core.sorted_map.call(null)));

var G__29760 = cljs.core.next.call(null,seq__29647_29749__$1);
var G__29761 = null;
var G__29762 = (0);
var G__29763 = (0);
seq__29647_29735 = G__29760;
chunk__29648_29736 = G__29761;
count__29649_29737 = G__29762;
i__29650_29738 = G__29763;
continue;
}
} else {
}
}
break;
}

var G__29764 = cljs.core.next.call(null,seq__29633_29726__$1);
var G__29765 = null;
var G__29766 = (0);
var G__29767 = (0);
seq__29633_29685 = G__29764;
chunk__29634_29686 = G__29765;
count__29635_29687 = G__29766;
i__29636_29688 = G__29767;
continue;
}
} else {
}
}
break;
}

var G__29768 = seq__29628_29678;
var G__29769 = chunk__29629_29679;
var G__29770 = count__29630_29680;
var G__29771 = (i__29631_29681 + (1));
seq__29628_29678 = G__29768;
chunk__29629_29679 = G__29769;
count__29630_29680 = G__29770;
i__29631_29681 = G__29771;
continue;
} else {
var temp__4657__auto___29772 = cljs.core.seq.call(null,seq__29628_29678);
if(temp__4657__auto___29772){
var seq__29628_29773__$1 = temp__4657__auto___29772;
if(cljs.core.chunked_seq_QMARK_.call(null,seq__29628_29773__$1)){
var c__23696__auto___29774 = cljs.core.chunk_first.call(null,seq__29628_29773__$1);
var G__29775 = cljs.core.chunk_rest.call(null,seq__29628_29773__$1);
var G__29776 = c__23696__auto___29774;
var G__29777 = cljs.core.count.call(null,c__23696__auto___29774);
var G__29778 = (0);
seq__29628_29678 = G__29775;
chunk__29629_29679 = G__29776;
count__29630_29680 = G__29777;
i__29631_29681 = G__29778;
continue;
} else {
var vec__29655_29779 = cljs.core.first.call(null,seq__29628_29773__$1);
var line_29780 = cljs.core.nth.call(null,vec__29655_29779,(0),null);
var columns_29781 = cljs.core.nth.call(null,vec__29655_29779,(1),null);
var seq__29656_29782 = cljs.core.seq.call(null,columns_29781);
var chunk__29657_29783 = null;
var count__29658_29784 = (0);
var i__29659_29785 = (0);
while(true){
if((i__29659_29785 < count__29658_29784)){
var vec__29660_29786 = cljs.core._nth.call(null,chunk__29657_29783,i__29659_29785);
var column_29787 = cljs.core.nth.call(null,vec__29660_29786,(0),null);
var column_info_29788 = cljs.core.nth.call(null,vec__29660_29786,(1),null);
var seq__29661_29789 = cljs.core.seq.call(null,column_info_29788);
var chunk__29662_29790 = null;
var count__29663_29791 = (0);
var i__29664_29792 = (0);
while(true){
if((i__29664_29792 < count__29663_29791)){
var map__29665_29793 = cljs.core._nth.call(null,chunk__29662_29790,i__29664_29792);
var map__29665_29794__$1 = ((((!((map__29665_29793 == null)))?((((map__29665_29793.cljs$lang$protocol_mask$partition0$ & (64))) || (map__29665_29793.cljs$core$ISeq$))?true:false):false))?cljs.core.apply.call(null,cljs.core.hash_map,map__29665_29793):map__29665_29793);
var gline_29795 = cljs.core.get.call(null,map__29665_29794__$1,new cljs.core.Keyword(null,"gline","gline",-1086242431));
var gcol_29796 = cljs.core.get.call(null,map__29665_29794__$1,new cljs.core.Keyword(null,"gcol","gcol",309250807));
var name_29797 = cljs.core.get.call(null,map__29665_29794__$1,new cljs.core.Keyword(null,"name","name",1843675177));
cljs.core.swap_BANG_.call(null,inverted,cljs.core.update_in,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [gline_29795], null),cljs.core.fnil.call(null,((function (seq__29661_29789,chunk__29662_29790,count__29663_29791,i__29664_29792,seq__29656_29782,chunk__29657_29783,count__29658_29784,i__29659_29785,seq__29628_29678,chunk__29629_29679,count__29630_29680,i__29631_29681,map__29665_29793,map__29665_29794__$1,gline_29795,gcol_29796,name_29797,vec__29660_29786,column_29787,column_info_29788,vec__29655_29779,line_29780,columns_29781,seq__29628_29773__$1,temp__4657__auto___29772,inverted){
return (function (columns__$1){
return cljs.core.update_in.call(null,columns__$1,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [gcol_29796], null),cljs.core.fnil.call(null,cljs.core.conj,cljs.core.PersistentVector.EMPTY),new cljs.core.PersistentArrayMap(null, 3, [new cljs.core.Keyword(null,"line","line",212345235),line_29780,new cljs.core.Keyword(null,"col","col",-1959363084),column_29787,new cljs.core.Keyword(null,"name","name",1843675177),name_29797], null));
});})(seq__29661_29789,chunk__29662_29790,count__29663_29791,i__29664_29792,seq__29656_29782,chunk__29657_29783,count__29658_29784,i__29659_29785,seq__29628_29678,chunk__29629_29679,count__29630_29680,i__29631_29681,map__29665_29793,map__29665_29794__$1,gline_29795,gcol_29796,name_29797,vec__29660_29786,column_29787,column_info_29788,vec__29655_29779,line_29780,columns_29781,seq__29628_29773__$1,temp__4657__auto___29772,inverted))
,cljs.core.sorted_map.call(null)));

var G__29798 = seq__29661_29789;
var G__29799 = chunk__29662_29790;
var G__29800 = count__29663_29791;
var G__29801 = (i__29664_29792 + (1));
seq__29661_29789 = G__29798;
chunk__29662_29790 = G__29799;
count__29663_29791 = G__29800;
i__29664_29792 = G__29801;
continue;
} else {
var temp__4657__auto___29802__$1 = cljs.core.seq.call(null,seq__29661_29789);
if(temp__4657__auto___29802__$1){
var seq__29661_29803__$1 = temp__4657__auto___29802__$1;
if(cljs.core.chunked_seq_QMARK_.call(null,seq__29661_29803__$1)){
var c__23696__auto___29804 = cljs.core.chunk_first.call(null,seq__29661_29803__$1);
var G__29805 = cljs.core.chunk_rest.call(null,seq__29661_29803__$1);
var G__29806 = c__23696__auto___29804;
var G__29807 = cljs.core.count.call(null,c__23696__auto___29804);
var G__29808 = (0);
seq__29661_29789 = G__29805;
chunk__29662_29790 = G__29806;
count__29663_29791 = G__29807;
i__29664_29792 = G__29808;
continue;
} else {
var map__29667_29809 = cljs.core.first.call(null,seq__29661_29803__$1);
var map__29667_29810__$1 = ((((!((map__29667_29809 == null)))?((((map__29667_29809.cljs$lang$protocol_mask$partition0$ & (64))) || (map__29667_29809.cljs$core$ISeq$))?true:false):false))?cljs.core.apply.call(null,cljs.core.hash_map,map__29667_29809):map__29667_29809);
var gline_29811 = cljs.core.get.call(null,map__29667_29810__$1,new cljs.core.Keyword(null,"gline","gline",-1086242431));
var gcol_29812 = cljs.core.get.call(null,map__29667_29810__$1,new cljs.core.Keyword(null,"gcol","gcol",309250807));
var name_29813 = cljs.core.get.call(null,map__29667_29810__$1,new cljs.core.Keyword(null,"name","name",1843675177));
cljs.core.swap_BANG_.call(null,inverted,cljs.core.update_in,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [gline_29811], null),cljs.core.fnil.call(null,((function (seq__29661_29789,chunk__29662_29790,count__29663_29791,i__29664_29792,seq__29656_29782,chunk__29657_29783,count__29658_29784,i__29659_29785,seq__29628_29678,chunk__29629_29679,count__29630_29680,i__29631_29681,map__29667_29809,map__29667_29810__$1,gline_29811,gcol_29812,name_29813,seq__29661_29803__$1,temp__4657__auto___29802__$1,vec__29660_29786,column_29787,column_info_29788,vec__29655_29779,line_29780,columns_29781,seq__29628_29773__$1,temp__4657__auto___29772,inverted){
return (function (columns__$1){
return cljs.core.update_in.call(null,columns__$1,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [gcol_29812], null),cljs.core.fnil.call(null,cljs.core.conj,cljs.core.PersistentVector.EMPTY),new cljs.core.PersistentArrayMap(null, 3, [new cljs.core.Keyword(null,"line","line",212345235),line_29780,new cljs.core.Keyword(null,"col","col",-1959363084),column_29787,new cljs.core.Keyword(null,"name","name",1843675177),name_29813], null));
});})(seq__29661_29789,chunk__29662_29790,count__29663_29791,i__29664_29792,seq__29656_29782,chunk__29657_29783,count__29658_29784,i__29659_29785,seq__29628_29678,chunk__29629_29679,count__29630_29680,i__29631_29681,map__29667_29809,map__29667_29810__$1,gline_29811,gcol_29812,name_29813,seq__29661_29803__$1,temp__4657__auto___29802__$1,vec__29660_29786,column_29787,column_info_29788,vec__29655_29779,line_29780,columns_29781,seq__29628_29773__$1,temp__4657__auto___29772,inverted))
,cljs.core.sorted_map.call(null)));

var G__29814 = cljs.core.next.call(null,seq__29661_29803__$1);
var G__29815 = null;
var G__29816 = (0);
var G__29817 = (0);
seq__29661_29789 = G__29814;
chunk__29662_29790 = G__29815;
count__29663_29791 = G__29816;
i__29664_29792 = G__29817;
continue;
}
} else {
}
}
break;
}

var G__29818 = seq__29656_29782;
var G__29819 = chunk__29657_29783;
var G__29820 = count__29658_29784;
var G__29821 = (i__29659_29785 + (1));
seq__29656_29782 = G__29818;
chunk__29657_29783 = G__29819;
count__29658_29784 = G__29820;
i__29659_29785 = G__29821;
continue;
} else {
var temp__4657__auto___29822__$1 = cljs.core.seq.call(null,seq__29656_29782);
if(temp__4657__auto___29822__$1){
var seq__29656_29823__$1 = temp__4657__auto___29822__$1;
if(cljs.core.chunked_seq_QMARK_.call(null,seq__29656_29823__$1)){
var c__23696__auto___29824 = cljs.core.chunk_first.call(null,seq__29656_29823__$1);
var G__29825 = cljs.core.chunk_rest.call(null,seq__29656_29823__$1);
var G__29826 = c__23696__auto___29824;
var G__29827 = cljs.core.count.call(null,c__23696__auto___29824);
var G__29828 = (0);
seq__29656_29782 = G__29825;
chunk__29657_29783 = G__29826;
count__29658_29784 = G__29827;
i__29659_29785 = G__29828;
continue;
} else {
var vec__29669_29829 = cljs.core.first.call(null,seq__29656_29823__$1);
var column_29830 = cljs.core.nth.call(null,vec__29669_29829,(0),null);
var column_info_29831 = cljs.core.nth.call(null,vec__29669_29829,(1),null);
var seq__29670_29832 = cljs.core.seq.call(null,column_info_29831);
var chunk__29671_29833 = null;
var count__29672_29834 = (0);
var i__29673_29835 = (0);
while(true){
if((i__29673_29835 < count__29672_29834)){
var map__29674_29836 = cljs.core._nth.call(null,chunk__29671_29833,i__29673_29835);
var map__29674_29837__$1 = ((((!((map__29674_29836 == null)))?((((map__29674_29836.cljs$lang$protocol_mask$partition0$ & (64))) || (map__29674_29836.cljs$core$ISeq$))?true:false):false))?cljs.core.apply.call(null,cljs.core.hash_map,map__29674_29836):map__29674_29836);
var gline_29838 = cljs.core.get.call(null,map__29674_29837__$1,new cljs.core.Keyword(null,"gline","gline",-1086242431));
var gcol_29839 = cljs.core.get.call(null,map__29674_29837__$1,new cljs.core.Keyword(null,"gcol","gcol",309250807));
var name_29840 = cljs.core.get.call(null,map__29674_29837__$1,new cljs.core.Keyword(null,"name","name",1843675177));
cljs.core.swap_BANG_.call(null,inverted,cljs.core.update_in,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [gline_29838], null),cljs.core.fnil.call(null,((function (seq__29670_29832,chunk__29671_29833,count__29672_29834,i__29673_29835,seq__29656_29782,chunk__29657_29783,count__29658_29784,i__29659_29785,seq__29628_29678,chunk__29629_29679,count__29630_29680,i__29631_29681,map__29674_29836,map__29674_29837__$1,gline_29838,gcol_29839,name_29840,vec__29669_29829,column_29830,column_info_29831,seq__29656_29823__$1,temp__4657__auto___29822__$1,vec__29655_29779,line_29780,columns_29781,seq__29628_29773__$1,temp__4657__auto___29772,inverted){
return (function (columns__$1){
return cljs.core.update_in.call(null,columns__$1,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [gcol_29839], null),cljs.core.fnil.call(null,cljs.core.conj,cljs.core.PersistentVector.EMPTY),new cljs.core.PersistentArrayMap(null, 3, [new cljs.core.Keyword(null,"line","line",212345235),line_29780,new cljs.core.Keyword(null,"col","col",-1959363084),column_29830,new cljs.core.Keyword(null,"name","name",1843675177),name_29840], null));
});})(seq__29670_29832,chunk__29671_29833,count__29672_29834,i__29673_29835,seq__29656_29782,chunk__29657_29783,count__29658_29784,i__29659_29785,seq__29628_29678,chunk__29629_29679,count__29630_29680,i__29631_29681,map__29674_29836,map__29674_29837__$1,gline_29838,gcol_29839,name_29840,vec__29669_29829,column_29830,column_info_29831,seq__29656_29823__$1,temp__4657__auto___29822__$1,vec__29655_29779,line_29780,columns_29781,seq__29628_29773__$1,temp__4657__auto___29772,inverted))
,cljs.core.sorted_map.call(null)));

var G__29841 = seq__29670_29832;
var G__29842 = chunk__29671_29833;
var G__29843 = count__29672_29834;
var G__29844 = (i__29673_29835 + (1));
seq__29670_29832 = G__29841;
chunk__29671_29833 = G__29842;
count__29672_29834 = G__29843;
i__29673_29835 = G__29844;
continue;
} else {
var temp__4657__auto___29845__$2 = cljs.core.seq.call(null,seq__29670_29832);
if(temp__4657__auto___29845__$2){
var seq__29670_29846__$1 = temp__4657__auto___29845__$2;
if(cljs.core.chunked_seq_QMARK_.call(null,seq__29670_29846__$1)){
var c__23696__auto___29847 = cljs.core.chunk_first.call(null,seq__29670_29846__$1);
var G__29848 = cljs.core.chunk_rest.call(null,seq__29670_29846__$1);
var G__29849 = c__23696__auto___29847;
var G__29850 = cljs.core.count.call(null,c__23696__auto___29847);
var G__29851 = (0);
seq__29670_29832 = G__29848;
chunk__29671_29833 = G__29849;
count__29672_29834 = G__29850;
i__29673_29835 = G__29851;
continue;
} else {
var map__29676_29852 = cljs.core.first.call(null,seq__29670_29846__$1);
var map__29676_29853__$1 = ((((!((map__29676_29852 == null)))?((((map__29676_29852.cljs$lang$protocol_mask$partition0$ & (64))) || (map__29676_29852.cljs$core$ISeq$))?true:false):false))?cljs.core.apply.call(null,cljs.core.hash_map,map__29676_29852):map__29676_29852);
var gline_29854 = cljs.core.get.call(null,map__29676_29853__$1,new cljs.core.Keyword(null,"gline","gline",-1086242431));
var gcol_29855 = cljs.core.get.call(null,map__29676_29853__$1,new cljs.core.Keyword(null,"gcol","gcol",309250807));
var name_29856 = cljs.core.get.call(null,map__29676_29853__$1,new cljs.core.Keyword(null,"name","name",1843675177));
cljs.core.swap_BANG_.call(null,inverted,cljs.core.update_in,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [gline_29854], null),cljs.core.fnil.call(null,((function (seq__29670_29832,chunk__29671_29833,count__29672_29834,i__29673_29835,seq__29656_29782,chunk__29657_29783,count__29658_29784,i__29659_29785,seq__29628_29678,chunk__29629_29679,count__29630_29680,i__29631_29681,map__29676_29852,map__29676_29853__$1,gline_29854,gcol_29855,name_29856,seq__29670_29846__$1,temp__4657__auto___29845__$2,vec__29669_29829,column_29830,column_info_29831,seq__29656_29823__$1,temp__4657__auto___29822__$1,vec__29655_29779,line_29780,columns_29781,seq__29628_29773__$1,temp__4657__auto___29772,inverted){
return (function (columns__$1){
return cljs.core.update_in.call(null,columns__$1,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [gcol_29855], null),cljs.core.fnil.call(null,cljs.core.conj,cljs.core.PersistentVector.EMPTY),new cljs.core.PersistentArrayMap(null, 3, [new cljs.core.Keyword(null,"line","line",212345235),line_29780,new cljs.core.Keyword(null,"col","col",-1959363084),column_29830,new cljs.core.Keyword(null,"name","name",1843675177),name_29856], null));
});})(seq__29670_29832,chunk__29671_29833,count__29672_29834,i__29673_29835,seq__29656_29782,chunk__29657_29783,count__29658_29784,i__29659_29785,seq__29628_29678,chunk__29629_29679,count__29630_29680,i__29631_29681,map__29676_29852,map__29676_29853__$1,gline_29854,gcol_29855,name_29856,seq__29670_29846__$1,temp__4657__auto___29845__$2,vec__29669_29829,column_29830,column_info_29831,seq__29656_29823__$1,temp__4657__auto___29822__$1,vec__29655_29779,line_29780,columns_29781,seq__29628_29773__$1,temp__4657__auto___29772,inverted))
,cljs.core.sorted_map.call(null)));

var G__29857 = cljs.core.next.call(null,seq__29670_29846__$1);
var G__29858 = null;
var G__29859 = (0);
var G__29860 = (0);
seq__29670_29832 = G__29857;
chunk__29671_29833 = G__29858;
count__29672_29834 = G__29859;
i__29673_29835 = G__29860;
continue;
}
} else {
}
}
break;
}

var G__29861 = cljs.core.next.call(null,seq__29656_29823__$1);
var G__29862 = null;
var G__29863 = (0);
var G__29864 = (0);
seq__29656_29782 = G__29861;
chunk__29657_29783 = G__29862;
count__29658_29784 = G__29863;
i__29659_29785 = G__29864;
continue;
}
} else {
}
}
break;
}

var G__29865 = cljs.core.next.call(null,seq__29628_29773__$1);
var G__29866 = null;
var G__29867 = (0);
var G__29868 = (0);
seq__29628_29678 = G__29865;
chunk__29629_29679 = G__29866;
count__29630_29680 = G__29867;
i__29631_29681 = G__29868;
continue;
}
} else {
}
}
break;
}

return cljs.core.deref.call(null,inverted);
});

//# sourceMappingURL=source_map.js.map