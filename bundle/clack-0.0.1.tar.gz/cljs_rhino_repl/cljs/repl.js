// Compiled by ClojureScript 1.8.51 {}
goog.provide('cljs.repl');
goog.require('cljs.core');
cljs.repl.print_doc = (function cljs$repl$print_doc(m){
cljs.core.println.call(null,"-------------------------");

cljs.core.println.call(null,[cljs.core.str((function (){var temp__4657__auto__ = new cljs.core.Keyword(null,"ns","ns",441598760).cljs$core$IFn$_invoke$arity$1(m);
if(cljs.core.truth_(temp__4657__auto__)){
var ns = temp__4657__auto__;
return [cljs.core.str(ns),cljs.core.str("/")].join('');
} else {
return null;
}
})()),cljs.core.str(new cljs.core.Keyword(null,"name","name",1843675177).cljs$core$IFn$_invoke$arity$1(m))].join(''));

if(cljs.core.truth_(new cljs.core.Keyword(null,"protocol","protocol",652470118).cljs$core$IFn$_invoke$arity$1(m))){
cljs.core.println.call(null,"Protocol");
} else {
}

if(cljs.core.truth_(new cljs.core.Keyword(null,"forms","forms",2045992350).cljs$core$IFn$_invoke$arity$1(m))){
var seq__24082_24096 = cljs.core.seq.call(null,new cljs.core.Keyword(null,"forms","forms",2045992350).cljs$core$IFn$_invoke$arity$1(m));
var chunk__24083_24097 = null;
var count__24084_24098 = (0);
var i__24085_24099 = (0);
while(true){
if((i__24085_24099 < count__24084_24098)){
var f_24100 = cljs.core._nth.call(null,chunk__24083_24097,i__24085_24099);
cljs.core.println.call(null,"  ",f_24100);

var G__24101 = seq__24082_24096;
var G__24102 = chunk__24083_24097;
var G__24103 = count__24084_24098;
var G__24104 = (i__24085_24099 + (1));
seq__24082_24096 = G__24101;
chunk__24083_24097 = G__24102;
count__24084_24098 = G__24103;
i__24085_24099 = G__24104;
continue;
} else {
var temp__4657__auto___24105 = cljs.core.seq.call(null,seq__24082_24096);
if(temp__4657__auto___24105){
var seq__24082_24106__$1 = temp__4657__auto___24105;
if(cljs.core.chunked_seq_QMARK_.call(null,seq__24082_24106__$1)){
var c__23723__auto___24107 = cljs.core.chunk_first.call(null,seq__24082_24106__$1);
var G__24108 = cljs.core.chunk_rest.call(null,seq__24082_24106__$1);
var G__24109 = c__23723__auto___24107;
var G__24110 = cljs.core.count.call(null,c__23723__auto___24107);
var G__24111 = (0);
seq__24082_24096 = G__24108;
chunk__24083_24097 = G__24109;
count__24084_24098 = G__24110;
i__24085_24099 = G__24111;
continue;
} else {
var f_24112 = cljs.core.first.call(null,seq__24082_24106__$1);
cljs.core.println.call(null,"  ",f_24112);

var G__24113 = cljs.core.next.call(null,seq__24082_24106__$1);
var G__24114 = null;
var G__24115 = (0);
var G__24116 = (0);
seq__24082_24096 = G__24113;
chunk__24083_24097 = G__24114;
count__24084_24098 = G__24115;
i__24085_24099 = G__24116;
continue;
}
} else {
}
}
break;
}
} else {
if(cljs.core.truth_(new cljs.core.Keyword(null,"arglists","arglists",1661989754).cljs$core$IFn$_invoke$arity$1(m))){
var arglists_24117 = new cljs.core.Keyword(null,"arglists","arglists",1661989754).cljs$core$IFn$_invoke$arity$1(m);
if(cljs.core.truth_((function (){var or__22912__auto__ = new cljs.core.Keyword(null,"macro","macro",-867863404).cljs$core$IFn$_invoke$arity$1(m);
if(cljs.core.truth_(or__22912__auto__)){
return or__22912__auto__;
} else {
return new cljs.core.Keyword(null,"repl-special-function","repl-special-function",1262603725).cljs$core$IFn$_invoke$arity$1(m);
}
})())){
cljs.core.prn.call(null,arglists_24117);
} else {
cljs.core.prn.call(null,((cljs.core._EQ_.call(null,new cljs.core.Symbol(null,"quote","quote",1377916282,null),cljs.core.first.call(null,arglists_24117)))?cljs.core.second.call(null,arglists_24117):arglists_24117));
}
} else {
}
}

if(cljs.core.truth_(new cljs.core.Keyword(null,"special-form","special-form",-1326536374).cljs$core$IFn$_invoke$arity$1(m))){
cljs.core.println.call(null,"Special Form");

cljs.core.println.call(null," ",new cljs.core.Keyword(null,"doc","doc",1913296891).cljs$core$IFn$_invoke$arity$1(m));

if(cljs.core.contains_QMARK_.call(null,m,new cljs.core.Keyword(null,"url","url",276297046))){
if(cljs.core.truth_(new cljs.core.Keyword(null,"url","url",276297046).cljs$core$IFn$_invoke$arity$1(m))){
return cljs.core.println.call(null,[cljs.core.str("\n  Please see http://clojure.org/"),cljs.core.str(new cljs.core.Keyword(null,"url","url",276297046).cljs$core$IFn$_invoke$arity$1(m))].join(''));
} else {
return null;
}
} else {
return cljs.core.println.call(null,[cljs.core.str("\n  Please see http://clojure.org/special_forms#"),cljs.core.str(new cljs.core.Keyword(null,"name","name",1843675177).cljs$core$IFn$_invoke$arity$1(m))].join(''));
}
} else {
if(cljs.core.truth_(new cljs.core.Keyword(null,"macro","macro",-867863404).cljs$core$IFn$_invoke$arity$1(m))){
cljs.core.println.call(null,"Macro");
} else {
}

if(cljs.core.truth_(new cljs.core.Keyword(null,"repl-special-function","repl-special-function",1262603725).cljs$core$IFn$_invoke$arity$1(m))){
cljs.core.println.call(null,"REPL Special Function");
} else {
}

cljs.core.println.call(null," ",new cljs.core.Keyword(null,"doc","doc",1913296891).cljs$core$IFn$_invoke$arity$1(m));

if(cljs.core.truth_(new cljs.core.Keyword(null,"protocol","protocol",652470118).cljs$core$IFn$_invoke$arity$1(m))){
var seq__24086 = cljs.core.seq.call(null,new cljs.core.Keyword(null,"methods","methods",453930866).cljs$core$IFn$_invoke$arity$1(m));
var chunk__24087 = null;
var count__24088 = (0);
var i__24089 = (0);
while(true){
if((i__24089 < count__24088)){
var vec__24090 = cljs.core._nth.call(null,chunk__24087,i__24089);
var name = cljs.core.nth.call(null,vec__24090,(0),null);
var map__24091 = cljs.core.nth.call(null,vec__24090,(1),null);
var map__24091__$1 = ((((!((map__24091 == null)))?((((map__24091.cljs$lang$protocol_mask$partition0$ & (64))) || (map__24091.cljs$core$ISeq$))?true:false):false))?cljs.core.apply.call(null,cljs.core.hash_map,map__24091):map__24091);
var doc = cljs.core.get.call(null,map__24091__$1,new cljs.core.Keyword(null,"doc","doc",1913296891));
var arglists = cljs.core.get.call(null,map__24091__$1,new cljs.core.Keyword(null,"arglists","arglists",1661989754));
cljs.core.println.call(null);

cljs.core.println.call(null," ",name);

cljs.core.println.call(null," ",arglists);

if(cljs.core.truth_(doc)){
cljs.core.println.call(null," ",doc);
} else {
}

var G__24118 = seq__24086;
var G__24119 = chunk__24087;
var G__24120 = count__24088;
var G__24121 = (i__24089 + (1));
seq__24086 = G__24118;
chunk__24087 = G__24119;
count__24088 = G__24120;
i__24089 = G__24121;
continue;
} else {
var temp__4657__auto__ = cljs.core.seq.call(null,seq__24086);
if(temp__4657__auto__){
var seq__24086__$1 = temp__4657__auto__;
if(cljs.core.chunked_seq_QMARK_.call(null,seq__24086__$1)){
var c__23723__auto__ = cljs.core.chunk_first.call(null,seq__24086__$1);
var G__24122 = cljs.core.chunk_rest.call(null,seq__24086__$1);
var G__24123 = c__23723__auto__;
var G__24124 = cljs.core.count.call(null,c__23723__auto__);
var G__24125 = (0);
seq__24086 = G__24122;
chunk__24087 = G__24123;
count__24088 = G__24124;
i__24089 = G__24125;
continue;
} else {
var vec__24093 = cljs.core.first.call(null,seq__24086__$1);
var name = cljs.core.nth.call(null,vec__24093,(0),null);
var map__24094 = cljs.core.nth.call(null,vec__24093,(1),null);
var map__24094__$1 = ((((!((map__24094 == null)))?((((map__24094.cljs$lang$protocol_mask$partition0$ & (64))) || (map__24094.cljs$core$ISeq$))?true:false):false))?cljs.core.apply.call(null,cljs.core.hash_map,map__24094):map__24094);
var doc = cljs.core.get.call(null,map__24094__$1,new cljs.core.Keyword(null,"doc","doc",1913296891));
var arglists = cljs.core.get.call(null,map__24094__$1,new cljs.core.Keyword(null,"arglists","arglists",1661989754));
cljs.core.println.call(null);

cljs.core.println.call(null," ",name);

cljs.core.println.call(null," ",arglists);

if(cljs.core.truth_(doc)){
cljs.core.println.call(null," ",doc);
} else {
}

var G__24126 = cljs.core.next.call(null,seq__24086__$1);
var G__24127 = null;
var G__24128 = (0);
var G__24129 = (0);
seq__24086 = G__24126;
chunk__24087 = G__24127;
count__24088 = G__24128;
i__24089 = G__24129;
continue;
}
} else {
return null;
}
}
break;
}
} else {
return null;
}
}
});

//# sourceMappingURL=repl.js.map